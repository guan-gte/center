export default {
  iv: '87654321',
  desKey: 'ssh$shz*'
}
