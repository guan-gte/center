global.Http = {
    // 注册 phone code password
    register: '/user/client/user/register',
    // 登录 phone password
    login: '/user/client/user/login',
    // 验证码登录 phone code
    loginByCode: '/user/client/user/loginByCode',
    // 修改密码 phone code password
    changePassword: '/user/client/user/changePassword',
    // 修改性别 sex
    setSex: '/user/client/user/setSex',
    // 修改头像 headPic
    setHeadPic: '/user/client/user/setHeadPic',
    // 修改昵称 nickName
    setNickName: '/user/client/user/setNickName',
    // 获取用户信息
    getUserInfo: '/user/client/user/getUserInfo',
    // 获取注册验证码 phone
    sendRegisterCode: '/user/client/sms/sendRegisterCode',
    // 登录验证码 phone
    sendLoginCode: '/user/client/sms/sendLoginCode',
    // 修改密码验证码 phone
    sendChangePasswordCode: '/user/client/sms/sendChangePasswordCode',
    // 添加地址 name phone address detail isDefault
    addUserAddress: '/user/client/address/addUserAddress',
    // 编辑地址 地址id name phone address detail isDefault
    editUserAddress: '/user/client/address/editUserAddress',
    // 删除地址 id
    delUserAddress: '/user/client/address/delUserAddress',
    // 设置默认地址
    setDefaultUserAddress: '/user/client/address/setDefaultUserAddress',
    // 获取默认地址
    getUserDefaultAddress: '/user/client/address/getUserDefaultAddress',
    // 地址列表
    getUserAddressList: '/user/client/address/getUserAddressList',
    // 首页
    // banner
    getAppBannerList: '/shop/client/banner/getAppBannerList',
    // 场景接口
    getAppSceneList: '/shop/client/goods/getAppSceneList',
    // 首页获取分类
    getAppHomeCatList: '/shop/client/goods/getAppHomeCatList',
    // 根据分类获取商品列表 current catId size
    getGoodsListByCatId: '/shop/client/goods/getGoodsListByCatId',
    // ---------------------------------------------------------------------
    // 分类
    getGoodsCatList: '/shop/client/goods/getGoodsCatList',
    // 筛选列表
    getGoodsSearchList: '/shop/client/goods/getGoodsSearchList',
    // 列表 catId current size search:{small: '',  big: '', sort: '', sortType: '', type: '', scene = []}
    getGoodsListByCatId: '/shop/client/goods/getGoodsListByCatId',
    // ---------------------------------------------------------------------
    // 推荐列表
    getHotGoodsList: '/shop/client/goods/getHotGoodsList',
    // 商品信息 goodsId
    getGoodsInfo: '/shop/client/goods/getGoodsInfo',
    // 商品参数 goodsId
    getGoodsParam: '/shop/client/goods/getGoodsParam',
    // 商品详情  goodsId
    getGoodsDetail: '/shop/client/goods/getGoodsDetail',
    // 整机配件 相关配件 goodsId
    getGoodsPartsList: '/shop/client/goods/getGoodsPartsList',
    // 收藏  goodsId
    collectGoods: '/shop/client/collect/collectGoods',
    // 取消收藏 goodsId
    cancelCollectGoods: '/shop/client/collect/cancelCollectGoods',
    // 收藏列表
    getCollectGoodsList: '/shop/client/collect/getCollectGoodsList',
    // 足迹列表
    getHistoryGoodsList: '/shop/client/collect/getHistoryGoodsList',
    // 清除足迹 idList[]
    cleanHistory: '/shop/client/collect/cleanHistory',
    // 添加，减少购物车 goodsId num
    editCart: '/shop/client/cart/editCart',
    // 删除购物车 idList[]
    delCart: '/shop/client/cart/delCart',
    // 获取购物车列表
    getCartList: '/shop/client/cart/getCartList',
    // ---------------------------------------------------------------------
    // 下单订单 goodsList
    parseOrder: '/shop/client/order/parseOrder',
    // 创建订单 goodsList[] invoiceId addressId
    createOrder: '/shop/client/order/createOrder',
    // 列表 current size type
    getOrderList: '/shop/client/order/getOrderList',
    // 订单详情 orderNo
    getOrderInfo: '/shop/client/order/getOrderInfo',
    // 取消订单 orderNo
    cancelOrder: '/shop/client/order/cancelOrder',
    // 确认收货 orderNo
    receiveOrder: '/shop/client/order/receiveOrder',
    // 获取用户发票
    getUserInvoice: '/shop/client/invoice/getUserInvoice',
    // 设置用户发票 company taxNo
    setUserInvoice: '/shop/client/invoice/setUserInvoice',
    // 其他数量
    getOtherNum: '/shop/client/user/getOtherNum',
    // 订单数量
    getOrderNum: '/shop/client/user/getOrderNum',
    // 添加到购物车 goodsId
    addCart: '/shop/client/cart/addCart',
    // 收藏多个商品 goodsIdList[]
    collectGoodsList: '/shop/client/collect/collectGoodsList',
    // 支付  payMethod orderNo
    payOrder: '/shop/client/pay/payOrder',
    // 首页搜索 name current size
    searchGoodsListByGoodsName: '/shop/client/goods/searchGoodsListByGoodsName',
};

