global.Static = {
    // 订单状态
    orderStatus: {
        // 未支付
        orderStatus_un: 0, 
        // 已支付(待发货)
        orderStatus_pay: 1,   
        // 已取消 
        orderStatus_cancel: 2,     
        // 已关闭
        orderStatus_close: 3,  
        // 已发货(待签收)    
        orderStatus_send: 4,   
        // 已收货    
        orderStatus_receive: 5,    
        // 已完成
        orderStatus_complete: 6    
    }
};
