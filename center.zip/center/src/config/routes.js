export default [
    {
        path: '/',
        redirect: '/welcome'
    },
    {
        path: '/login',
        component: resolve => require(['../view/login/Login.vue'], resolve)
    },
    {
        path: '/changePwd',
        component: resolve => require(['../view/login/ChangePwd.vue'], resolve)
    },
    {
        path: '/',
        component: resolve => require(['../common/Home.vue'], resolve),
        meta: { title: '自述文件' },
        children:[
            {
                path: '/welcome',
                component: resolve => require(['../view/Welcome.vue'], resolve),
                meta: { title: '欢迎!' }
            },
/*********************  Base  **********************************/
            // base
            {
                path: '/icon',
                component: resolve => require(['../view/base/Icon.vue'], resolve),
                meta: { title: 'hello world' }
            },
            {
                path: '/table',
                component: resolve => require(['../view/base/BaseTable.vue'], resolve),
                meta: { title: '基础表格' }
            },
            {
                path: '/tabs',
                component: resolve => require(['../view/base/Tabs.vue'], resolve),
                meta: { title: 'tab选项卡' }
            },
            {
                path: '/form',
                component: resolve => require(['../view/base/BaseForm.vue'], resolve),
                meta: { title: '基本表单' }
            },
            {
                // 富文本编辑器组件
                path: '/editor',
                component: resolve => require(['../view/base/VueEditor.vue'], resolve),
                meta: { title: '富文本编辑器' }
            },
            {
                // markdown组件
                path: '/markdown',
                component: resolve => require(['../view/base/Markdown.vue'], resolve),
                meta: { title: 'markdown编辑器' }
            },
            {
                // 图片上传组件
                path: '/upload',
                component: resolve => require(['../view/base/Upload.vue'], resolve),
                meta: { title: '文件上传' }
            },
            {
                // vue-schart组件
                path: '/charts',
                component: resolve => require(['../view/base/BaseCharts.vue'], resolve),
                meta: { title: 'schart图表' }
            },
            {
                // 拖拽列表组件
                path: '/drag',
                component: resolve => require(['../view/base/DragList.vue'], resolve),
                meta: { title: '拖拽列表' }
            },
            {
                // 权限页面
                path: '/permission',
                component: resolve => require(['../view/base/Permission.vue'], resolve),
                meta: { title: '权限测试', permission: true }
            },
            {
                path: '/404',
                component: resolve => require(['../view/base/404.vue'], resolve),
                meta: { title: '404' }
            },
            {
                path: '/403',
                component: resolve => require(['../view/base/403.vue'], resolve),
                meta: { title: '403' }
            },
            /*********************  PersonalCenter  **********************************/
            // 设置中心
            {
                path: '/information',
                component: resolve => require(['../view/PersonalCenter/Setfocus/Myinformation.vue'], resolve),
                meta: { title: '我的资料' }
            },
            {
                path: '/Address',
                component: resolve => require(['../view/PersonalCenter/Setfocus/MyReceivingAddress.vue'], resolve),
                meta: { title: '我的收货地址' }
            },
            {
                path: '/Qualifications',
                component: resolve => require(['../view/PersonalCenter/Setfocus/TicketAdditionQualifications.vue'], resolve),
                meta: { title: '新增我的收货地址' }
            },
            {
                path: '/editQualifications',
                component: resolve => require(['../view/PersonalCenter/Setfocus/editQualifications.vue'], resolve),
                meta: { title: '编辑我的收货地址' }
            },
            {
                path: '/security',
                component: resolve => require(['../view/PersonalCenter/Setfocus/Accountsecurity.vue'], resolve),
                meta: { title: '账户安全' }
            },
            // 我的优惠券
            {
                path: '/coupon',
                component: resolve => require(['../view/PersonalCenter/Myequipment/equipment.vue'], resolve),
                meta: { title: '查看我的设备' }
            },
            {
                path: '/Tracks',
                component: resolve => require(['../view/PersonalCenter/MyTracks/MyTracks.vue'], resolve),
                meta: { title: '我的足迹' }
            },
            {
                path: '/Collection',
                component: resolve => require(['../view/PersonalCenter/MyCollection/MyCollection.vue'], resolve),
                meta: { title: '' }
            },
            {
                path: '/equipment',
                component: resolve => require(['../view/PersonalCenter/Myequipment/Myequipment.vue'], resolve),
                meta: { title: '我的设备' }
            },
            {
                path: '/coupon',
                component: resolve => require(['../view/PersonalCenter/Myequipment/equipment.vue'], resolve),
                meta: { title: '查看我的设备' }
            },
            {
                path: '/records',
                component: resolve => require(['../view/PersonalCenter/Myequipment/Maintenancerecords.vue'], resolve),
                meta: { title: '查看设备维护记录' }
            },
            {
                path: '/Replacement',
                component: resolve => require(['../view/PersonalCenter/Myequipment/Replacementofrecords.vue'], resolve),
                meta: { title: '查看配件更换记录' }
            },
            {
                path: '/cart',
                component: resolve => require(['../view/PersonalCenter/Myshoppingcart/Myshoppingcart.vue'], resolve),
                meta: { title: '我的购物车' }
            },
            {
                path: '/details',
                component: resolve => require(['../view/PersonalCenter/OrderCenter/Orderdetails.vue'], resolve),
                meta: { title: '订单详情' }
            },
            // {
            //     path: '/refund',
            //     component: resolve => require(['../view/PersonalCenter/OrderCenter/refund.vue'], resolve),
            //     meta: { title: '退款' }
            // },
            // {
            //     path: '/received',
            //     component: resolve => require(['../view/PersonalCenter/OrderCenter/Tobereceived.vue'], resolve),
            //     meta: { title: '待收货' }
            // },
            // {
            //     path: '/shipped',
            //     component: resolve => require(['../view/PersonalCenter/OrderCenter/Tobeshipped.vue'], resolve),
            //     meta: { title: '待发货' }
            // },
            // {
            //     path: '/behalf',
            //     component: resolve => require(['../view/PersonalCenter/OrderCenter/Paymentonbehalf.vue'], resolve),
            //     meta: { title: '待付款' }
            // },
            {
                path: '/order',
                component: resolve => require(['../view/PersonalCenter/OrderCenter/Fullorder.vue'], resolve),
                meta: { title: '全部订单' }
            },
            {
                path: '/Center',
                component: resolve => require(['../view/PersonalCenter/PersonalCenter.vue'], resolve),
                meta: { title: '个人中心' }
            },
            {
                path: '/Myco',
                component: resolve => require(['../view/PersonalCenter/Mycoupon/Mycoupon.vue'], resolve),
                meta: { title: '更多会员信息' }
            },
            {
                path: '/Taqua',
                component: resolve => require(['../view/PersonalCenter/Setfocus/TicketAdditionQua.vue'], resolve),
                meta: { title: '增票资质' }
            },
            {
                path: '/Tickadd',
                component: resolve => require(['../view/PersonalCenter/Setfocus/TiCketadd.vue'], resolve),
                meta: { title: '增添票资质' }
            },
            {
                path: '/Ticke',
                component: resolve => require(['../view/PersonalCenter/Setfocus/Ticketa.vue'], resolve),
                meta: { title: '增票审核' }
            },
            // {
            //     path: '/Ticke2',
            //     component: resolve => require(['../view/PersonalCenter/Setfocus/Ticketa2.vue'], resolve),
            //     meta: { title: '审核通过' }
            // },
            // {
            //     path: '/Ticke3',
            //     component: resolve => require(['../view/PersonalCenter/Setfocus/Ticketa3.vue'], resolve),
            //     meta: { title: '待审核' }
            // },
            {
                path: '/invo',
                component: resolve => require(['../view/PersonalCenter/invoice/invoice.vue'], resolve),
                meta: { title: '发票' }
            },
            {
                path: '/invoon',
                component: resolve => require(['../view/PersonalCenter/invoice/invoiceon.vue'], resolve),
                meta: { title: '开发票' }
            },
        ]
    },
    {
        path: '*',
        redirect: '/404'
    }
]
