import Vue from 'vue'
let vm = new Vue()
export default vm
