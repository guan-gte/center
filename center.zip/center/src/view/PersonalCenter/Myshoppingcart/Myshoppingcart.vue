<!--<template>-->
    <!--<div>-->
        <!--<div  v-for="(item,index) in mylist" :key="index">-->
            <!--<div style="width: 100%;background: #eee;height: 60px;line-height: 60px;display: inline-block">-->
                <!--<div style="display: inline-block;width: 100px;text-align: center">-->
                    <!--<input type="checkbox" class="check goods-check goodsCheck"-->
                           <!--v-model="item.this_all" @change="check_list(index)">全选-->
                <!--</div>-->

                <!--<div style="display: inline-block;width: 300px;text-align: center">-->
                    <!--<span>商品信息</span>-->
                <!--</div>-->
                <!--<div style="display: inline-block;width: 120px;text-align: center">-->
                    <!--<span>单价（元）</span>-->
                <!--</div>-->
                <!--<div style="display: inline-block;width: 120px;text-align: center">-->
                    <!--<span>数量</span>-->
                <!--</div>-->
                <!--<div style="display: inline-block;width: 120px;text-align: center">-->
                    <!--<span>金额</span>-->
                <!--</div>-->
                <!--<div style="display: inline-block;width: 120px;text-align: center">-->
                    <!--<span>操作</span>-->
                <!--</div>-->

            <!--</div>-->

                    <!--<ul>-->
                        <!--<li v-for="(goods,nindex) in item.newlist" :key="nindex">-->
                            <!--<div style="width: 921px;border: 1px solid#eee;height: 114px;position: relative">-->
                                <!--<div style="position: absolute;top: 50%;left: 3.2%;transform: translate(-50%,-50%);">-->
                                        <!--<input style="width: 16px;height: 16px" type="checkbox" v-model="goods.check_one" @change="click_input(index,nindex)">-->
                                <!--</div>-->

                                    <!--<div style="position: absolute;top: 50%;left: 12%;transform: translate(-50%,-50%)">-->
                                        <!--<img src="https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg" alt="" style="width: 100px;height: 100px">-->
                                    <!--</div>-->
                                    <!--<div style="width: 240px;position: absolute;top: 50%;left: 32%;transform: translate(-50%,-50%)">-->
                                        <!--{{goods.newname}}-->
                                    <!--</div>-->


                                <!--<div style=";position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%)">-->
                                    <!--￥<b class="price">-->
                                    <!--{{goods.price}}-->
                                    <!--</b>-->
                                <!--</div>-->
                                <!--<div style="width: 80px;position: absolute;top: 50%;left: 64%;transform: translate(-50%,-50%)">-->
                                    <!--<a href="javascript:;" @click="deleteto(index,nindex),money()">-</a>-->
                                    <!--<input type="number"  value="1" v-on:input ="money"-->
                                                   <!--v-model.number="goods.count" required="required"-->
                                                   <!--@blur.prevent="changeCount(index,nindex)" style="width: 40px;text-align: center">-->
                                    <!--<a href="javascript:;" @click="add(index,nindex),money()">+</a>-->
                                <!--</div>-->

                                <!--<div style="position: absolute;top: 50%;left: 77.2%;transform: translate(-50%,-50%)">-->
                                    <!--￥<b class="price">-->
                                    <!--{{goods.price*goods.count}}-->
                                <!--</b>-->
                                <!--</div>-->

                                <!--<div style="width: 80px;position: absolute;top: 50%;left: 90.8%;transform: translate(-50%,-50%)">-->
                                    <!--<div>移入收藏夹</div>-->
                                    <!--<div @change="del()">删除商品</div>-->
                                <!--</div>-->
                            <!--</div>-->
                        <!--</li>-->
                    <!--</ul>-->
            <!--</div>-->


            <!--<div style="width: 100%;height: 140px;background: #eee;position: relative">-->
                <!--<div style="position: absolute;top: 20%;left: 4%;transform: translate(-50%,-50%)">-->
                    <!--<input type="checkbox" v-model="checkall" @change="check_all()">全选-->
                <!--</div>-->
                <!--<div style="position: absolute;top: 20%;left: 64%;transform: translate(-50%,-50%)">-->
                    <!--<strong style="font-size: 14px;color: #333333">已选择<span  style="display: inline-block;font-size: 0.5rem"></span>件商品</strong>-->
                <!--</div>-->
                <!--<div style="position: absolute;top: 20%;left: 80%;transform: translate(-50%,-50%)">-->
                    <!--<strong style="font-size: 14px;color: #333333">结算金额：<span class="total" style="display: inline-block;font-size: 0.5rem;font-size: 24px;color: red">￥{{allprice}}</span></strong>-->
                <!--</div>-->
                <!--<div style="position: absolute;top: 54%;left: 80%;transform: translate(-50%,-50%)">-->
                    <!--<span style="padding: 16px 30px;background-color: red;color: #fff;border: 1px solid red;border-radius:4%" @click="btn()">去结算</span>-->
                <!--</div>-->

            <!--</div>-->

    <!--</div>-->
<!--</template>-->
<!--<script>-->
    <!--export default {-->
        <!--name: 'ShopCar',-->
        <!--data () {-->
            <!--return {-->
                <!--mylist:[-->
                    <!--{-->
                        <!--this_all:false,-->
                        <!--newlist:[-->
                            <!--{-->
                                <!--newname:"阿萨德啦",-->
                                <!--count: 1,-->
                                <!--color:"600ml",-->
                                <!--check_one:false,-->
                                <!--price:600-->
                            <!--},-->
                            <!--{-->
                                <!--newname:"啊送快递很快就",-->
                                <!--count: 1,-->
                                <!--color:"标准版222",-->
                                <!--check_one:false,-->
                                <!--price:200}]-->
                    <!--},-->
                <!--],-->
                <!--checkall:false,-->
                <!--allprice:0,-->
                <!--cpmylist:[],-->

            <!--}-->
        <!--},-->
        <!--computed:{-->

        <!--},-->
        <!--methods:{-->

            <!--//  input失去焦点触发值永远为1-->
            <!--changeCount:function(index,nindex){-->
                <!--if (this.mylist[index].newlist[nindex].count <= 1) {-->
                    <!--this.mylist[index].newlist[nindex].count = 1-->
                <!--} else {-->
                    <!--return true;-->
                <!--}-->
            <!--},-->
            <!--//   减少商品-->
            <!--deleteto(index,nindex) {-->
                <!--if (this.mylist[index].newlist[nindex].count == 1) {} else {-->
                    <!--this.mylist[index].newlist[nindex].count&#45;&#45;;-->
                <!--}-->
            <!--},-->
            <!--//  增加商品-->
            <!--add(index,nindex) {-->
                <!--this.mylist[index].newlist[nindex].count++;-->
            <!--},-->
            <!--//  选择所有的购物车商品-->
            <!--check_all:function(){-->
                <!--var that = this;-->
                <!--that.mylist.forEach(item1 => {-->
                    <!--item1.this_all=that.checkall-->
                    <!--item1.newlist.forEach(item2 => {-->
                        <!--item2.check_one=that.checkall-->
                    <!--})-->
                <!--});-->
                <!--that.money();-->
            <!--},-->
            <!--abc:function(){-->
                <!--var that = this;-->
                <!--var aaa = that.mylist.filter(item2 =>{-->
                    <!--return item2.this_all==true-->
                <!--})-->
                <!--aaa.length==that.mylist.length ? that.checkall = true : that.checkall = false-->
                <!--that.money();-->
            <!--},-->
            <!--check_list:function(i){-->
                <!--var that = this;-->
                <!--that.mylist[i].newlist.forEach(item1 =>{-->
                    <!--item1.check_one=that.mylist[i].this_all-->
                <!--})-->
                <!--that.abc();-->

            <!--},-->
            <!--//删除商品-->
            <!--del:function(){-->
                <!--this.goods.splice(nindex,1)-->
            <!--},-->
            <!--//  商品checkbox-->
            <!--click_input:function(i,j){-->
                <!--var that = this;-->
                <!--var checklist = that.mylist[i].newlist.filter(item1 =>{-->
                    <!--return item1.check_one==true-->
                <!--})-->

                <!--checklist.length==that.mylist[i].newlist.length ? that.mylist[i].this_all = true : that.mylist[i].this_all = false-->
                <!--that.abc();-->

            <!--},-->
<!--//  计算总价格-->
            <!--money:function(){-->
                <!--var that = this;-->
                <!--this.allprice=0;-->
                <!--that.mylist.forEach(item1 =>{-->
                    <!--item1.newlist.forEach(item2 =>{-->
                        <!--if(item2.check_one==true){-->
                            <!--that.allprice+=item2.price * item2.count;-->
                        <!--}-->
                    <!--})-->
                <!--})-->

            <!--},-->
            <!--//  提交时候-->
            <!--btn:function(){-->
                <!--var that = this;-->
                <!--that.cpmylist=JSON.parse(JSON.stringify(that.mylist));-->
                <!--that.cpmylist.filter(item1 =>{-->
                    <!--item1.newlist = item1.newlist.filter(item2 =>{-->
                        <!--return item2.check_one==true-->
                    <!--})-->
                <!--})-->
                <!--that.cpmylist=that.cpmylist.filter(item3 =>{-->
                    <!--return item3.newlist.length!=0-->
                <!--})-->

                <!--if(that.cpmylist.length==0){-->
                    <!--alert("请选择商品哦！")-->
                <!--}else{-->
                    <!--that.cpmylist.forEach(item4 =>{-->
                            <!--alert("您需要付"+that.allprice+"元");-->
                    <!--})-->
                <!--}-->
            <!--}-->
        <!--},-->
    <!--}-->
<!--</script>-->




<!--<template>-->
    <!--<el-row>-->
        <!--<el-col>-->
            <!--<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">-->
                <!--<el-table-column type="selection" label="全选" width="55">-->
                <!--</el-table-column>-->

                <!--<el-table-column label="商品信息" width="240" height="114" align="center">-->
                    <!--<template slot-scope="scope" >-->
                        <!--<div style="height: 80px;overflow: hidden;display: block">-->
                            <!--<div style="position: absolute;top: 50%;transform: translateY(-50%);">-->
                                <!--<img src="https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg" style="width: 80px;height: 80px">-->
                            <!--</div>-->
                            <!--<div style="position: absolute;top: 50%;left: 38%;transform: translateY(-50%)">-->
                                <!--<div style="margin-left: 10px;width: 120px">{{ scope.row.Cyname }}</div>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</template>-->
                <!--</el-table-column>-->

                <!--<el-table-column label="单价（元）" width="140">-->
                    <!--<template slot-scope="scope">-->
                        <!--<span style="margin-left: 10px">{{ scope.row.CyPrice }}</span>-->
                    <!--</template>-->
                <!--</el-table-column>-->

                <!--<el-table-column label="数量" width="140">-->
                    <!--<template slot-scope="scope">-->
                        <!--&lt;!&ndash;<span style="margin-left: 10px">{{ scope.row.CyNumber }}</span>&ndash;&gt;-->
                        <!--<button v-bind:disabled="scope.row.CyNumber === 0" v-on:click="scope.row.CyNumber-=1">-</button>-->
                        <!--{{ scope.row.CyNumber }}-->
                        <!--<button v-on:click="scope.row.CyNumber+=1">+</button>-->
                    <!--</template>-->
                <!--</el-table-column>-->

                <!--<el-table-column label="金额" width="140">-->
                    <!--<template slot-scope="scope">-->
                        <!--<span style="margin-left: 10px">￥{{totalPrice()}}</span>-->
                    <!--</template>-->
                <!--</el-table-column>-->

                <!--<el-table-column label="操作" width="180">-->
                    <!--<template slot-scope="scope">-->
                        <!--<div>移入收藏夹</div>-->
                        <!--<div>移除商品</div>-->
                    <!--</template>-->
                <!--</el-table-column>-->

            <!--</el-table>-->
            <!--<div style="margin-top: 20px">-->
                <!--<el-button @click="toggleSelection()">取消选择</el-button>-->
            <!--</div>-->
        <!--</el-col>-->
    <!--</el-row>-->
<!--</template>-->

<!--<script>-->
    <!--export default {-->
        <!--data() {-->
            <!--return {-->
                <!--tableData: [-->
                    <!--{-->
                        <!--Cyurl:'https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg',-->
                        <!--Cyname: '王小虎王小虎王小虎王小虎王小虎王小虎',-->
                        <!--CyPrice: 18990,-->
                        <!--CyNumber:1,-->
                        <!--// Cymoney:'￥18990',-->
                    <!--},-->
                    <!--{-->
                        <!--Cyurl:'https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg',-->
                        <!--Cyname: '王小虎',-->
                        <!--CyPrice: 18990,-->
                        <!--CyNumber:1,-->
                        <!--// Cymoney:'￥18990',-->
                    <!--},-->
                <!--],-->
                <!--multipleSelection: []-->
            <!--}-->
        <!--},-->

        <!--methods: {-->
            <!--toggleSelection(rows) {-->
                <!--if (rows) {-->
                    <!--rows.forEach(row => {-->
                        <!--this.$refs.multipleTable.toggleRowSelection(row);-->
                    <!--});-->
                <!--} else {-->
                    <!--this.$refs.multipleTable.clearSelection();-->
                <!--}-->
            <!--},-->
            <!--handleSelectionChange(val) {-->
                <!--this.multipleSelection = val;-->
            <!--},-->
            <!--totalPrice : function(){-->
                <!--var totalP = 0;-->
                <!--for (var i = 0,len = this.tableData.length;i<len;i++) {-->
                    <!--totalP+=this.tableData[i].CyPrice*this.tableData[i].CyNumber;-->
                <!--}-->
                <!--return totalP;-->
            <!--}-->
        <!--}-->
    <!--}-->
<!--</script>-->


<template>
    <el-row>
        <el-col>
                <section class="cartMain">
                    <div class="cartMain_hd">
                        <ul class="order_lists cartTop">
                            <li class="list_chk">
                                <!--所有商品全选-->
                                <input type="checkbox" id="all" class="whole_check">
                                <label for="all" :class="fetchData.status?'mark':''" @click="cartchoose()"></label>
                                全选
                            </li>
                            <li class="list_con">商品信息</li>
                            <!--<li class="list_info">商品参数</li>-->
                            <li class="list_price">单价</li>
                            <li class="list_amount">数量</li>
                            <li class="list_sum">金额</li>
                            <li class="list_op">操作</li>

                        </ul>
                    </div>

                    <div class="cartBox" v-for="item in fetchData.list" key="index">
                        <div class="order_content">
                            <ul class="order_lists" v-for="pro in item.products">
                                <li class="list_chk">
                                    <input type="checkbox" id="checkbox_2" class="son_check">
                                    <label for="checkbox_2" :class="pro.checked?'mark':''" @click="choose(item,pro)"></label>
                                </li>
                                <li class="list_con">
                                    <div class="list_img"><a href="javascript:;"><img :src="pro.img" alt=""></a></div>
                                    <div class="list_text"><a href="javascript:;">{{pro.text}}</a>
                                        <!--<span class="list_custom">定制</span>-->
                                    </div>
                                </li>
                                <li class="list_price">
                                    <p class="price">￥{{pro.price}}</p>
                                </li>
                                <li class="list_amount">
                                    <div class="amount_box">
                                        <a href="javascript:;" class="reduce reSty" @click="reduce(pro)">-</a>
                                        <input type="text" v-model="pro.num" class="sum">
                                        <a href="javascript:;" class="plus" @click="add(pro)">+</a>
                                    </div>
                                </li>
                                <li class="list_sum">
                                    <p class="sum_price">￥{{pro.sum}}</p>
                                </li>
                                <li class="list_op">
                                    <p class="collect"><a href="javascript:;" class="colBtn">收藏商品</a></p>
                                    <p class="del"><a href="javascript:;" class="delBtn">移除商品</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>



                    <!--底部-->
                    <div class="bar-wrapper">
                        <div class="bar-right">
                            <div class="piece">已选商品<strong class="piece_num">{{this.fetchData.allnum}}</strong>件</div>
                            <div class="totalMoney">共计: <strong class="total_text">￥{{this.fetchData.allsum}}</strong></div>
                            <div class="calBtn"><a href="javascript:;">结算</a></div>
                        </div>
                    </div>
                </section>
                <!--<section class="model_bg"></section>-->
                <!--<section class="my_model">-->
                    <!--<p class="title">删除宝贝<span class="closeModel">X</span></p>-->
                    <!--<p>您确认要删除该宝贝吗？</p>-->
                    <!--<div class="opBtn"><a href="javascript:;" class="dialog-sure">确定</a><a href="javascript:;" class="dialog-close">关闭</a></div>-->
                <!--</section>-->
        </el-col>
    </el-row>
</template>

<script>
export default {
            data() {
                    return {
                        fetchData:{
                            list:[
                                {
                                    shop_id:2,
                                    shop_name:'卷卷旗舰店',
                                    products:[
                                        {
                                            pro_id:201,
                                            text:'剃须刀剃须刀剃须刀剃须刀剃须刀剃须刀剃须刀剃须刀',
                                            price:580,
                                            num:1,
                                            img:'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1152319114,1644542883&fm=27&gp=0.jpg',
                                            sum:580,
                                            checked:false
                                        },
                                        {
                                            pro_id:202,
                                            text:'卫生纸卫生纸卫生纸卫生纸卫生纸卫生纸卫生纸卫生纸',
                                            price:780,
                                            num:1,
                                            img:'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2462509639,879829946&fm=27&gp=0.jpg',
                                            sum:780,
                                            checked:false
                                        }
                                    ],
                                    check:false,
                                    choose:0,
                                },
                            ],
                            status:false,//全选选中状态
                            allchoose:0,//店铺选中个数
                            allsum:0,//总计价格
                            allnum:0,//总计数量
                        }
                    }
            },
    methods:{
        choosetrue(item,pro){
            pro.checked=true//将商品选中状态改为true
            ++item.choose===item.products.length?item.check=true:''//这里执行了两部，选中商品数量先+1，再与该店铺商品数量比较，如果相等就更改店铺选中状态为true
            item.check?++this.fetchData.allchoose===this.fetchData.list.length?this.fetchData.status=true:this.fetchData.status=false:''//如果店铺选中状态改为true，选中店铺数量先+1，再与店铺数量比较，如果相等就更改全选选中状态为true
            this.fetchData.allsum+=pro.sum
            this.fetchData.allnum+=pro.num
        },
        choosefalse(item,pro){
            pro.checked=false//将商品选中状态改为false
            --item.choose//选中商品数量-1
            if(item.check){//如果店铺是被选中的，更改店铺选中状态
                item.check=false
                --this.fetchData.allchoose//并且选中店铺数量-1
            }
            this.fetchData.status=false//无论之前全选的状态，将其改为false就行
            this.fetchData.allsum-=pro.sum//商品总计价格变动
            this.fetchData.allnum-=pro.num
        },
        choose(item,pro){
            !pro.checked?this.choosetrue(item,pro):this.choosefalse(item,pro)
        },
        shoptrue(item){
            item.products.forEach((pro)=>{
                pro.checked===false?this.choosetrue(item,pro):''//循环店铺中的商品，先筛选出目前没选中的商品，给它执行choosetrue函数
            })
        },
        shopfalse(item){
            item.products.forEach((pro)=>{
                pro.checked===true?this.choosefalse(item,pro):''//循环店铺中的商品，先筛选出目前被选中的商品，给它执行choosefalse函数
            })
        },
        shopchoose(item){
            !item.check?this.shoptrue(item):this.shopfalse(item)
        },
        cartchoose(){
            this.fetchData.status=!this.fetchData.status//取反改变状态
            this.fetchData.status?this.fetchData.list.forEach((item)=>this.shoptrue(item)):this.fetchData.list.forEach((item)=>this.shopfalse(item))//根据取反后的状态进行相应的店铺按钮操作
        },
        add(pro){
            pro.num++
            pro.sum+=pro.price
            pro.checked?this.fetchData.allsum+=pro.price:this.fetchData.allsum
        },
        reduce(pro){
            if(pro.num===1){
                pro.num
            }else{
                pro.num--
                pro.sum-=pro.price
                pro.checked?this.fetchData.allsum-=pro.price:this.fetchData.allsum
            }
        }

                    }
                }
</script>

<style scoped>
    /* 清除内外边距 */

    body, h1, h2, h3, h4, h5, h6, hr, p, blockquote,
        /* structural elements 结构元素 */

    dl, dt, dd, ul, ol, li,
        /* list elements 列表元素 */

    pre,
        /* text formatting elements 文本格式元素 */

    fieldset, lengend, button, input, textarea,
        /* form elements 表单元素 */

    th, td {
        /* table elements 表格元素 */
        margin: 0;
        padding: 0;
    }
    /* 设置默认字体 */

    body, button, input, select, textarea {
        /* for ie */
        /*font: 12px/1 Tahoma, Helvetica, Arial, "宋体", sans-serif;*/
        font: 12px/1 Tahoma, Helvetica, Arial, "\5b8b\4f53", sans-serif;
        /* 用 ascii 字符表示，使得在任何编码下都无问题 */
    }

    h1 {
        font-size: 25px;
        /* 18px / 12px = 1.5 */
        text-align:center;
        color:#f60
    }

    h2 {
        font-size: 16px;
    }

    h3 {
        font-size: 14px;
    }

    h4, h5, h6 {
        font-size: 100%;
    }

    address, cite, dfn, em, var {
        font-style: normal;
    }
    /* 将斜体扶正 */

    code, kbd, pre, samp, tt {
        font-family: "Courier New", Courier, monospace;
    }
    /* 统一等宽字体 */

    small {
        font-size: 12px;
    }
    /* 小于 12px 的中文很难阅读，让 small 正常化 */
    /* 重置列表元素 */

    ul, ol {
        list-style: none;
    }
    /* 重置文本格式元素 */

    a {
        text-decoration: none;
        color: #000;
    }
    /*a:hover { text-decoration: underline; }*/

    abbr[title], acronym[title] {
        /* 注：1.ie6 不支持 abbr; 2.这里用了属性选择符，ie6 下无效果 */
        border-bottom: 1px dotted;
        cursor: help;
    }

    q:before, q:after {
        content: '';
    }
    /* 重置表单元素 */

    legend {
        color: #000;
    }
    /* for ie6 */

    fieldset, img {
        border: none;
    }
    /* img 搭车：让链接里的 img 无边框 */
    /* 注：optgroup 无法扶正 */

    button, input, select, textarea {
        font-size: 100%;
        /* 使得表单元素在 ie 下能继承字体大小 */
    }
    /* 重置表格元素 */

    table {
        border-collapse: collapse;
        border-spacing: 0;
    }
    /* 重置 hr */

    hr {
        border: none;
        height: 1px;
    }
    /* 让非ie浏览器默认也显示垂直滚动条，防止因滚动条引起的闪烁 */

    html {
        overflow-y: scroll;
    }
    /*  浮动  */

    /*.fl {*/
        /*float: left*/
    /*}*/

    /*.fr {*/
        /*float: right*/
    /*}*/
    /*!*  清除浮动  *!*/

    .clearfix:after {
        content: " ";
        display: block;
        clear: both;
        visibility: hidden;
    }
    html,body{
        position: relative;
        width: 100%;
        min-height: 950px;
    }
    input[type="checkbox"]{
        display: none;
    }
    label{
        position: relative;
        display: inline-block;
        z-index: 1;
        border: 1px solid #b8b8b8;
        margin-left: 10px;
        border-radius: 1px;
        width: 12px;
        height: 12px;
        cursor: pointer;
    }
    label.mark{
        background: url("https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2240787215,432903790&fm=27&gp=0.jpg") no-repeat -1px -1px;
        background-size:15px;
    }

    a:hover{
        color: #ff8000;
        text-decoration: underline;
    }



    .cartMain{
        position: relative;
        width: 1200px;
        min-width: 1200px;
        max-width: 1200px;
        margin: 0 auto;
        padding: 0px 0px 100px;
        min-height: 210px;
    }
    /*购物车头部*/
    .cartMain_hd{
        width: 100%;
        height: 50px;
        line-height: 50px;
        color: #3c3c3c;
    }
    .cartMain_hd .cartTop{
        height: 50px;
    }
    .cartMain_hd .cartTop .list_chk{
        width: 80px;
        text-indent: 30px;
    }
    .cartMain_hd .cartTop .list_con{
        width: 312px;
    }
    .cartMain_hd .cartTop .list_chk label{
        position: absolute;
        left: 10px;
        top:19px;
        margin: 0;
    }
    /*.cartMain_hd .cartTop .list_info{*/
        /*padding: 0;*/
        /*text-indent: 15px;*/
    /*}*/
    .cartMain_hd .cartTop .list_con{
        text-indent: 140px;
    }


    .cartBox{
        width: 100%;
        margin-bottom: 15px;
    }
    .cartBox .shop_info{
        position: relative;
        width: 100%;
        height: 38px;
        background-color: #fff;
        line-height: 38px;
        vertical-align: baseline;
    }
    .cartBox .shop_info .all_check{
        position: relative;
        float: left;
        width: 30px;
        height: 38px;
    }

    .cartBox .shop_info .all_check input[type="checkbox"]{
        position: absolute;
        z-index: 0;
        left: -20px;
        top: -20px;
    }
    .cartBox .shop_info .all_check .shop{
        position: absolute;
        top:13px;
    }
    /*.cartBox .shop_info .shop_name{*/
        /*float: left;*/
    /*}*/



    /*商品列表*/
    .cartBox .order_content{
        border: 1px solid #ccc;
    }
    .cartBox .order_content a{
        display: block;
    }
    .order_charge{
        width: 100%;
        height: 40px;
        border-bottom: 1px solid #e7e7e7;
    }
    .order_charge p{
        display: inline-block;
        line-height: 40px;
    }
    .order_charge p.charge_info{
        margin:0 30px 0 50px;
    }
    .order_charge p.charge_info span{
        border: 1px solid #f60;
        padding:2px;
        color: #f60;
    }
    .order_lists{
        width: 100%;
        height: 130px;
        border-bottom: 1px solid #e7e7e7;
    }
    .order_lists:last-child{
        border-bottom: none;
    }
    .order_lists li{
        float: left;
        height: 100%;
    }

    .order_lists .list_chk{
        position: relative;
        width: 80px;
    }
    .order_lists .list_chk input[type="checkbox"]{
        position: absolute;
        z-index: 0;
        left: -20px;
        top: -20px;
    }
    .order_lists .list_chk label{
        margin: 20px 0 0 24px;
    }

    .order_lists .list_con{
        width: 300px;
    }
    .order_lists .list_con .list_img{
        width: 80px;
        height: 80px;
        margin-top: 20px;
        float: left;
    }
    .order_lists .list_con .list_img img{
        width: 100%;
        vertical-align: top;
    }
    .order_lists .list_con .list_text{
        margin: 20px 0 0 10px;
        line-height: 18px;
        width: 200px;
        float: left;
    }
    .order_lists .list_con .list_text a{
        color: #3c3c3c;
        margin-bottom: 5px;
    }
    .order_lists .list_con .list_text a:hover{
        color: #ff873e;
        text-decoration: underline;
    }
    .order_lists .list_con .list_text .list_custom{
        background-color:#ff8000;
        padding:3px;
        border-radius: 3px;
        color: #fff;
    }
    /*.order_lists .list_info{*/
        /*width: 160px;*/
        /*box-sizing: border-box;*/
        /*padding: 20px 0;*/
    /*}*/
    /*.order_lists .list_info p{*/
        /*color: #9c9c9c;*/
        /*line-height: 18px;*/
        /*margin-left: 15px;*/
    /*}*/
    .order_lists .list_price{
        width: 80px;
    }
    .order_lists .list_price .price{
        margin-top: 20px;
        line-height: 18px;
        font-family: Verdana,Tahoma,arial;
        color: #3c3c3c;
        font-weight: bold;
    }
    .order_lists .list_price .charge{
        position: relative;
        z-index: 4
    }
    .order_lists .list_price .charge p{
        color: #ff0000;
        border:1px solid #ff0000;
        width: 50px;
        height:15px;
        line-height: 15px;
        padding:3px;
    }
    .order_lists .list_price .charge .chargebox{
        display: none;
        width: 300px;
        height: 110px;
        background: #000;
        z-index: 1;
    }
    .order_lists .list_amount{
        width: 120px;
    }
    .order_lists .list_amount .amount_box{
        margin-top: 20px;
        width: 77px;
        height: 25px;
        position: relative;
    }
    .order_lists .list_amount .amount_box input{
        width: 39px;
        height: 15px;
        line-height: 15px;
        border: 1px solid #aaa;
        color: #343434;
        text-align: center;
        padding: 4px 0;
        background-color: #fff;
        z-index: 2;
        position: absolute;
        left: 18px;
        float: left;
    }
    .order_lists .list_amount .amount_box a{
        float: left;
        height: 23px;
        width: 17px;
        border: 1px solid #e5e5e5;
        background: #f0f0f0;
        text-align: center;
        line-height: 23px;
        color: #444;
        position: absolute;
        top:0;
    }
    .order_lists .list_amount .amount_box a:hover{
        border-color: #ff873e;
        text-decoration: none;
        color: #ff873e;
        z-index: 3;
    }

    .order_lists .list_amount .amount_box .reduce{
        left: 0;
    }

    .order_lists .list_amount .amount_box .reSty{
        color: #cbcbcb;
    }
    .order_lists .list_amount .amount_box .reSty:hover{
        border-right: none;
        border-color: #e5e5e5;
        text-decoration: none;
        color: #cbcbcb;
    }

    .order_lists .list_amount .amount_box .plus{
        border-left-color: transparent;
        right: 0;
    }


    .order_lists .list_sum{
        width: 60px;
    }
    .order_lists .list_sum .sum_price{
        line-height: 18px;
        margin-top: 20px;
        font-family: Verdana,Tahoma,arial;
        color: #900;
        font-weight: bold;
    }
    .order_lists .list_op{
        width: 120px;
    }
    .order_lists .list_op .collect{
        margin-top: 20px;
    }
    .order_lists .list_op .del{
        line-height: 18px;
        margin:5px 0;
    }
    .order_lists .list_op .custombox{
        width: 200px;
        height: 350px;
        background-color: #000;
        display: none;
        position: relative;
        z-index: 9
    }
    /*底部总计算价*/
    .bar-wrapper{
        width: 940px;
        height: 50px;
        position: fixed;
        bottom: 10px;
        z-index: 99;
        background: #e5e5e5;
    }
    .bar-wrapper .bar-right{
        float: right;
        color: #3c3c3c;
    }
    .bar-wrapper .bar-right strong{
        color: #900;
    }

    .bar-wrapper .bar-right .piece{
        float: left;
        min-width: 110px;
        margin-right: 20px;
        height: 50px;
        line-height: 50px;
    }
    .bar-wrapper .bar-right .piece .piece_num{
        display: inline-block;
        padding: 0 10px;
        font-weight: 700;
        font-size: 18px;
        font-family: tohoma,arial;
    }
    .bar-wrapper .bar-right .totalMoney{
        float: left;
        min-width: 100px;
        height: 50px;
        line-height: 50px;
    }
    .bar-wrapper .bar-right .totalMoney .total_text{
        float: right;
        font-weight: 400;
        font-size: 20px;
        font-family: Arial;
        vertical-align: middle;
        margin-right: 10px;
        margin-left: 15px;
    }
    .bar-wrapper .bar-right .calBtn{
        float: left;
    }
    .bar-wrapper .bar-right .calBtn a{
        display: block;
        width: 120px;
        height: 50px;
        color: #fff;
        background: #B0B0B0;
        cursor: not-allowed;
        font-size: 22px;
        letter-spacing: 5px;
        text-decoration: none;
        line-height: 50px;
        text-align: center;
        border-radius: 2px;
    }
    .bar-wrapper .bar-right .calBtn a.btn_sty{
        background: #ff873e;
        cursor: pointer;
    }

    /*自己定义的模态框*/
    .model_bg{
        position: absolute;
        top:0;
        left: 0;
        bottom: 0;
        right: 0;
        background: rgba(0,0,0,.6);
        z-index: 999;
        display: none;
    }
    .my_model{
        position: fixed;
        display: none;
        top:50%;
        left: 50%;
        margin-top: -50px;
        margin-left: -200px;
        z-index: 9999;
        width: 360px;
        height: 120px;
        border: 1px solid #aeaeae;
        border-radius: 3px;
        padding: 20px;
        background: #fff;
    }
    .my_model .title{
        font-size: 14px;
        color: #3c3c3c;
        font-weight: 700;
        margin-bottom: 20px;
    }
    .my_model .title .closeModel{
        float: right;
        cursor: pointer;
    }
    .my_model p{
        line-height:16px;
    }
    .my_model .opBtn{
        margin-top: 20px;
    }
    .my_model .opBtn a{
        width: 58px;
        height: 28px;
        line-height: 28px;
        text-align: center;
        -webkit-border-radius: 1px;
        -moz-border-radius: 1px;
        -ms-border-radius: 1px;
        border-radius: 1px;
        display: inline-block;
        margin-right: 10px;
        font-weight: 700;
    }
    .my_model .dialog-sure{
        background: #52a0e5;
        color: #fff;
        border: 1px solid #52a0e5;
    }

    .my_model .dialog-close{
        background: #fff;
        border: 1px solid #d9d9d9;
        color: #3c3c3c;
    }
</style>
