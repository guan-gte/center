<template>
    <el-row>
        <el-col :span="4">
            <div class="grid">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">设置中心</span>
            </div>
        </el-col>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 8px ">
            <el-breadcrumb-item :to="{ path: 'information' }"><span style="color: #a5a5a5;font-weight: 400">设置中心</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5;font-weight: 400">增票资质</span></el-breadcrumb-item>
        </el-breadcrumb>
        <el-col :span="24">
            <div class="box-tick">
                <span class="tex-tick">增值税发票</span>
            </div>
            <div class="box-tickone">
                <i class="el-icon-lx-infofill icon-color"></i>
                <span class="texduo-tick">注意有效增值税发票开票资质仅为一个</span>
            </div>

            <div style="margin-top: 42px">
                <span class="text-tick">增票资质信息</span>
            </div>
        </el-col>

        <!--<el-row style="position: relative;top: 24px;margin-left: 190px">-->
            <!--<el-form ref="form" :model="sizeForm" label-width="120px" size="medium" >-->
                <!--<el-form-item label="单位名称:">-->
                    <!--<span style="color: red">*</span>-->
                    <!--<el-input v-model="sizeForm.name" placeholder="请输入您的公司名称" style="width: 436px"></el-input>-->
                <!--</el-form-item>-->

                <!--<el-form-item label="纳税人识别码:" >-->
                    <!--<span style="color: red">*</span>-->
                    <!--<el-input v-model="sizeForm.Name"  placeholder="请输入您的纳税人识别码" style="width: 436px"></el-input>-->
                <!--</el-form-item>-->

                <!--<el-form-item label="注册地址:" >-->
                    <!--<span style="color: red">*</span>-->
                    <!--<el-input v-model="sizeForm.region" placeholder="请输入您的公司地址" style="width: 436px"></el-input>-->
                <!--</el-form-item>-->

                <!--<el-form-item label="手机（固话）:" >-->
                    <!--<span style="color: red">*</span>-->
                    <!--<el-input v-model="sizeForm.shesop" placeholder="请输入公司联系方式" style="width: 436px"></el-input>-->
                <!--</el-form-item>-->

                <!--<el-form-item label="开户银行:" >-->
                    <!--<span style="color: red">*</span>-->
                    <!--<el-input v-model="sizeForm.banck" placeholder="请输入您的开户银行" style="width: 436px;"></el-input>-->
                <!--</el-form-item>-->

                <!--<el-form-item label="银行账号:" >-->
                    <!--<span style="color: red">*</span>-->
                    <!--<el-input v-model="sizeForm.bancknuber" placeholder="请输入您的开户行账号" style="width: 436px"></el-input>-->
                <!--</el-form-item>-->
            <!--</el-form>-->
        <!--</el-row>-->



        <el-col>
        <div style="margin-top: 42px">
            <span class="text-tick">增票收票地址</span>
        </div>
            <div style="position: relative;top: 24px;margin-left: 190px">
            <el-form ref="form" :rules="rules" :model="sizeForm"  label-width="120px" size="medium" >
                <el-form-item label="收票人姓名:" prop="name">
                    <span style="color: red">*</span>
                    <el-input v-model="sizeForm.name" placeholder="请输入您的收票人姓名" style="width: 436px"></el-input>
                </el-form-item>

                <el-form-item label="收票人手机号:" prop="Name">
                    <span style="color: red">*</span>
                    <el-input v-model="sizeForm.Name"  placeholder="请输入您的收票人手机号" style="width: 436px"></el-input>
                </el-form-item>

                <el-form ref="form" :model="sizeForm" label-width="120px" size="medium">
                    <el-form-item label="收票人省份:" >
                        <span style="color: red">*</span>
                        <el-cascader :options="cityListNew" v-model="shopCityCodeList"></el-cascader>
                    </el-form-item>
                </el-form>

                <el-form-item label="收票人地址:" prop="region">
                    <span style="color: red">*</span>
                    <el-input v-model="sizeForm.region" placeholder="请输入您的收票人地址" style="width: 436px"></el-input>
                </el-form-item>
            </el-form>
            </div>
        </el-col>
        <el-col>
        <div style="text-align: center" class="box-ckeadd">
        <span>点击确认即同意<label style="color: red;cursor: pointer">《增票资质确认书》</label></span>
        <div style="position: relative;top: 30px">
            <button class="ok-ent">确认</button>
            <button class="et-duw">取消</button>
        </div>
        </div>
        </el-col>


    </el-row>
</template>
<script>
    import newCity from '../../../js/newCity';
    export default {
        data() {
            return {
                radio: '1',
                sizeForm: {
                    name: '',
                    Name:'',
                    region: '',
                    shesop:'',
                    banck:'',
                    bancknuber:'',
                    // date2: '',
                    delivery: false,
                    resource: '',
                    desc: '',
                } ,
                // 省市区
                cityListNew: newCity,
                // shop地址
                shopCityCodeList: [],
                rules: {
                    name: [
                        { required: true, message: '请输入姓名', trigger: 'blur' },
                        { min: 2, max: 12, message: '长度在 2 到 12 个字符', trigger: 'blur' }
                    ],
                    Name: [
                        { required: true, message: '请选输入手机号', trigger: 'blur' },
                        { min: 11, max: 11, message: '请输入正确的手机号', trigger: 'blur' }
                    ],
                    region: [
                        { required: true, message: '请选输入详细地址', trigger: 'blur' }
                    ],

                },
                methods: {
                    parsePost () {
                        // base info
                        // 省市区转字符串
                        let address = '';
                        this.cityListNew.forEach((item) => {
                            if (item.value == this.shopCityCodeList[0]) {
                                address += item.label;
                                item.children.forEach((jtem) => {
                                    if (jtem.value == this.shopCityCodeList[1]) {
                                        address += jtem.label;
                                        jtem.children.forEach((ktem) => {
                                            if (ktem.value == this.shopCityCodeList[2]) {
                                                address += ktem.label;
                                            }
                                        });
                                    }
                                });
                            }
                        });
                        this.postData.address = address;
                        this.postData.cityCode = this.shopCityCodeList[this.shopCityCodeList.length - 1];
                        // bank
                        this.postData.bankName = this.bankName;
                        this.postData.bankCode = this.bankCode;
                        this.postData.bankCard = this.bankCard;
                        this.postData.bankCityCode = this.bankCityCode[this.bankCityCode.length - 1];
                        this.postData.openBankCode = this.openBankCode;
                        // 认证类型 1 企业 2 个体户
                        this.postData.type = 2;
                        if (this.id) {
                            this.postData.id = this.id;
                        }
                    },

                    // submitForm(sizeForm) {
                    //     this.$refs[sizeForm].validate((valid) => {
                    //         if (valid) {
                    //             alert('submit!');
                    //         } else {
                    //             console.log('error submit!!');
                    //             return false;
                    //         }
                    //     });
                    // },
                }
            }
        },
    }
</script>
<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 40px;
        color: #545454;
        font-weight: normal;
    }
    /*.el-input--mini .el-input__inner{*/
        /*height: 48px!important;*/
        /*line-height: 48px!important;*/
    /*}*/
    .box-tick{
        width: 817px;
        height: 48px;
        line-height: 48px;
        margin-left: 36px;margin-top: 20px;
        background:#efefef ;
    }
    .tex-tick{
        font-family: MicrosoftYaHei-Bold;
        font-size: 20px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0;
        color: #676565;
        margin-left: 24px;
    }
    .box-tickone{
        width: 815px;
        height: 48px;
        border: solid 1px #ffc45e;
        background: #fffdee;
        line-height: 48px;
        margin-left: 36px;margin-top: 10px;
    }
    .texduo-tick{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 30px;
        letter-spacing: 0;
        color: #fe7200;
        margin-left: 72px;
    }

    .text-tick{
        font-family: MicrosoftYaHei;
        font-size: 18px;
        font-weight: bold;
        font-stretch: normal;
        line-height: 42px;
        letter-spacing: 0px;
        color: #323232;
        margin-left: 122px;
    }
    .box-ckeadd{
        width: auto;
        height: 24px;
        font-family: MicrosoftYaHei;
        font-size: 14px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 24px;
        letter-spacing: 0;
        color: #5c5c5c;
        position: relative;
        top: 62px;
    }
    .ok-ent{
        border: 1px solid  #ff0000;
        width: 148px;
        height: 40px;
        background-color: #ff0000;
        border-radius: 5px;
        font-family: MicrosoftYaHei;
        font-size: 18px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 40px;
        letter-spacing: 0px;
        color: #ffffff;
        margin-right: 4px;
    }
    .et-duw{
        width: 148px;
        height: 40px;
        border-radius: 5px;
        border: 1px solid  #666666;
        font-family: MicrosoftYaHei;
        background-color: #fff;
        font-size: 18px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 40px;
        letter-spacing: 0px;
        color: #383838;
        margin-left: 4px;
    }
    .icon-color{
        font-size: 24px;
        color:#ffac2d;
        position: relative;
        left: 70px;
        top: 4px;
        -webkit-transform: rotate(180deg);
    }
</style>
