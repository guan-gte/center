<template>
    <el-row>
        <el-col :span="4">
            <div class="grid bg-purple-banner">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">设置中心</span>
            </div>
        </el-col>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px ">
            <el-breadcrumb-item :to="{ path: 'information' }"><span style="color: #a5a5a5;font-weight: 400">设置中心</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">我的资料</span></el-breadcrumb-item>
        </el-breadcrumb>

        <el-row style="margin-top: 60px;margin-left: 54px">
            <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
                <el-form-item label="我的头像" >
                    <div class="block">
                        <img :src="sizeForm.headPic" style="width: 120px;height: 120px">
                        <span @click.native="" style="color: red;font-size: 16px;cursor: pointer">修改头像</span>
                    </div>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
                <el-form-item label="昵称" >
                    <el-input v-model="sizeForm.nickName" style="width: 200px"></el-input>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
                <el-form-item label="性别" >
                    <el-radio v-model="radio" label="1">男</el-radio>
                    <el-radio v-model="radio" label="2">女</el-radio>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
                <el-form-item label="我的姓名" >
                    <el-input v-model="sizeForm.nickName" style="width: 200px"></el-input>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
                <el-form-item label="我的联系方式" >
                    <el-input v-model="sizeForm.phone" style="width: 200px"></el-input>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
                <el-form-item label="我的行业信息" >
                    <el-input v-model="sizeForm.resource" style="width: 200px"></el-input>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
                <el-form-item required label="我的公司地址" >
                        <el-cascader :options="cityListNew" v-model="shopCityCodeList"></el-cascader>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
                <el-form-item label="详细地址" >
                    <el-input type="textarea" v-model="sizeForm.desc" style="width: 240px"></el-input>
                </el-form-item>
            </el-form>

            <el-button type="primary" style="margin-left: 140px">保存</el-button>
            <el-button>取消</el-button>

        </el-row>

    </el-row>

</template>

<script>
    import newCity from '../../../js/newCity';
    export default {
        data() {
            return {
                radio: '1',
                sizeForm: {
                    // nickName: '222',
                    // Name:'111',
                    // region: '333',
                    // delivery: false,
                    // type: [],
                    // resource: '',
                    // desc: '',
                    // src: 'https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg'
                } ,
                // 省市区
                cityListNew: newCity,
                // shop地址
                shopCityCodeList: [],
                methods: {
                    parsePost () {
                        // base info
                        // 省市区转字符串
                        let address = '';
                        this.cityListNew.forEach((item) => {
                            if (item.value == this.shopCityCodeList[0]) {
                                address += item.label;
                                item.children.forEach((jtem) => {
                                    if (jtem.value == this.shopCityCodeList[1]) {
                                        address += jtem.label;
                                        jtem.children.forEach((ktem) => {
                                            if (ktem.value == this.shopCityCodeList[2]) {
                                                address += ktem.label;
                                            }
                                        });
                                    }
                                });
                            }
                        });
                        this.postData.address = address;
                        this.postData.cityCode = this.shopCityCodeList[this.shopCityCodeList.length - 1];
                        // bank
                        this.postData.bankName = this.bankName;
                        this.postData.bankCode = this.bankCode;
                        this.postData.bankCard = this.bankCard;
                        this.postData.bankCityCode = this.bankCityCode[this.bankCityCode.length - 1];
                        this.postData.openBankCode = this.openBankCode;
                        // 认证类型 1 企业 2 个体户
                        this.postData.type = 2;
                        if (this.id) {
                            this.postData.id = this.id;
                        }
                    },
                }
            }
        },
        created(){
            this.function();
        },
        methods: {
            function(){
                Sun.post({
                    url: Http.getUserInfo,
                    data: {
                    },
                    success: (data) => {
                        Sun.setLogin(data);
                        console.log(data)
                        this.sizeForm= data;
                        // Sun.isLogin = true;

                    },
                    fail: (data) => {

                    }
                });
            }
        }
    }
</script>

<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
    }
</style>
