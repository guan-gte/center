<template>
    <el-row>
        <el-col :span="4">
            <div class="grid">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">设置中心</span>
            </div>
        </el-col>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 8px ">
            <el-breadcrumb-item :to="{ path: 'information' }"><span style="color: #a5a5a5;font-weight: 400">设置中心</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5;font-weight: 400">增票资质</span></el-breadcrumb-item>
        </el-breadcrumb>
        <el-col>
            <div class="box-tick">
                <span class="tex-tick">增值税发票</span>
            </div>
            <div class="box-tickone">
                <i class="el-icon-lx-infofill icon-color"></i>
                <span class="texduo-tick">
                    注意有效增值税发票开票资质仅为一个
                </span>
            </div>
            <div class="box-ticke" v-if="type === '1'">
                <span style="margin-left: 24px">我的增值税发票资质:<label>审核通过</label></span>
                <span class="eit-et" @click="modify()">修改资质</span>
            </div>
            <div class="box-ticke" v-else-if="type === '2'">
                <span style="margin-left: 24px">我的增值税发票资质:<label>待审核</label></span>
            </div>
            <div class="box-ticke" v-if="type === '3'">
                <span style="margin-left: 24px">我的增值税发票资质:<label style="color: red">审核不通过</label></span>
                <span class="eit-et" @click="modify()">重新提交</span>
            </div>

            <div class="warning" v-if="type === '3'">
                <i class="el-icon-lx-warnfill icon-coloron"></i>
                <span>审核不通过，原因是购票人员信息，该证件号码在企业下面没有做实名登记</span>
            </div>
        </el-col>

        <el-col>
            <div style="margin-top: 16px">
                <span class="text-tick">增票资质信息</span>
            </div>
            <div style="position: relative;margin-left: 54px">
                <div class="name-span">
                    <span>您的公司名称:</span>
                    <span>{{sizeForm.name}}</span>
                </div>

                <div class="name-span">
                    <span>您的纳税人识别码:</span>
                    <span>{{sizeForm.nubmer}}</span>
                </div>

                <div class="name-span">
                    <span>您的公司地址:</span>
                    <span>{{sizeForm.address}}</span>
                </div>

                <div class="name-span">
                    <span>公司联系方式:</span>
                    <span>{{sizeForm.Telephone}}</span>
                </div>

                <div class="name-span">
                    <span>您的开户银行:</span>
                    <span>{{sizeForm.Bank}}</span>
                </div>

                <div class="name-span">
                    <span>您的开户行账号:</span>
                    <span>{{sizeForm.Accountnumber}}</span>
                </div>

                <div>
                <span class="looke">查看 <label>《增票资质确认书》<div class="xin-pir"></div></label></span>
                </div>
            </div>

            <!--<div style="margin-top: 42px">-->
                <!--<span class="text-tick">增票收票地址</span>-->
                <!--<span class="text-xiu">修改</span>-->
            <!--</div>-->
            <!--<div style="position: relative;margin-left: 54px">-->
                <!--<div class="name-span">-->
                    <!--<span>收票人姓名:</span>-->
                    <!--<span>{{sizeForm.Fullname}}</span>-->
                <!--</div>-->

                <!--<div class="name-span">-->
                    <!--<span>收票人手机号:</span>-->
                    <!--<span>{{sizeForm.phonenumber}}</span>-->
                <!--</div>-->

                <!--<div class="name-span">-->
                    <!--<span>收票人省份:</span>-->
                    <!--<span>{{sizeForm.Province}}</span>-->
                <!--</div>-->

                <!--<div class="name-span">-->
                    <!--<span>收票人地址:</span>-->
                    <!--<span>{{sizeForm.addresses}}</span>-->
                <!--</div>-->
            <!--</div>-->
        </el-col>


    </el-row>
</template>
<script>
    export default {
        data() {
            return {
                type:'1',
                sizeForm: {
                    name: '梁玉玺清洁产品集团有限公司',
                    nubmer:'4512313241322312',
                    address: '上海市嘉定区江桥镇金园五路1号A栋',
                    Telephone:'18297938805',
                    Bank:'中国银行上海浦东支行',
                    Accountnumber:'6228480668539611677',
                    Fullname:'王竹',
                    phonenumber:'182197938805',
                    Province:'上海嘉定区',
                    addresses:'上海市嘉定区江桥镇金园五路1号A栋'
                } ,
            }
        },
        methods: {
            modify() {
                Sun.push('/Tickadd');
            }
        }
    }
</script>
<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 40px;
        color: #545454;
        font-weight: normal;
    }
    .box-tick{
        width: 817px;
        height: 48px;
        line-height: 48px;
        margin-left: 36px;margin-top: 20px;
        background:#efefef ;
    }
    .tex-tick{
        font-family: MicrosoftYaHei-Bold;
        font-size: 20px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0;
        color: #676565;
        margin-left: 24px;
    }
    .box-ticke{
        width: 817px;
        display: block;
        line-height: 88px;
        margin-left: 36px;margin-top: 20px;
        font-family: MicrosoftYaHei;
        font-size: 18px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #5c5c5c;
    }
    .box-ticke label{
        margin-left: 10px;
    }
    .box-tickone{
        width: 815px;
        height: 48px;
        border: solid 1px #ffc45e;
        background: #fffdee;
        line-height: 48px;
        margin-left: 36px;margin-top: 10px;
    }
    .texduo-tick{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 30px;
        letter-spacing: 0;
        color: #fe7200;
        margin-left: 72px;
    }

    .text-tick{
        font-family: MicrosoftYaHei;
        font-size: 18px;
        font-weight: bold;
        font-stretch: normal;
        line-height: 42px;
        letter-spacing: 0px;
        color: #323232;
        margin-left: 56px;
    }
   .name-span{
       font-family: MicrosoftYaHei;
       font-size: 16px;
       font-weight: normal;
       font-stretch: normal;
       line-height: 42px;
       letter-spacing: 0px;
       color: #5c5c5c;
   }
    .looke{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0;
        color: #5c5c5c;
    }
    .looke label{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        letter-spacing: 0px;
        color: #ff0000;
        cursor: pointer;
        /*text-decoration:underline red;*/
    }
    .text-xiu{
        font-family: MicrosoftYaHei;
        font-size: 14px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #172692;
        margin-left: 24px;
        cursor: pointer;
    }
    .xin-pir{
        width: 110px;
        height: 1px;
        display: flex;
        background-color: red;margin-left: 54px;
    }
    .icon-color{
        font-size: 24px;
        color:#ffac2d;
        position: relative;
        left: 70px;
        top: 4px;
        -webkit-transform: rotate(180deg);
    }
    .eit-et{
        padding: 4px 26px;background-color: #dcdbdb;font-size: 18px;margin-left: 40px;cursor: pointer;
    }
    .icon-coloron{
        font-size: 24px;
        color:#ffac2d;
        position: relative;
        left: 70px;
        top: 4px;
    }
    .eit-et{
        padding: 4px 26px;background-color: #dcdbdb;font-size: 18px;margin-left: 40px;cursor: pointer;
    }
    .warning{
        font-family: MicrosoftYaHei;
        font-size: 14px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 21px;
        letter-spacing: 0px;
        color: #ff0000;
    }
    .warning span{
        margin-left: 80px;
    }
</style>
