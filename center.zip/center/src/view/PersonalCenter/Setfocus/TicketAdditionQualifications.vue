<template>
    <el-row>
        <el-col :span="4">
        <div class="grid bg-purple-banner">
            <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">设置中心</span>
        </div>
        </el-col>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px ">
            <el-breadcrumb-item :to="{ path: 'information' }"><span style="color: #a5a5a5;font-weight: 400">设置中心</span></el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: 'Address'}"><span style="color: #a5a5a5;font-weight: 400">我的收货地址</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">新增收货地址</span></el-breadcrumb-item>
        </el-breadcrumb>

        <el-row style="margin-top: 50px;margin-left: 54px">
            <el-form ref="form" :model="sizeForm" label-width="140px" size="mini">
                <el-form-item label="请输入收货人姓名" >
                    <el-input v-model="sizeForm.name" style="width: 366px"></el-input>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="140px" size="mini">
                <el-form-item label="请输入收货人电话" >
                    <el-input v-model="sizeForm.region" style="width: 366px"></el-input>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="140px" size="mini">
                <el-form-item label="请选择所在地区" >
                    <el-cascader :options="cityListNew" v-model="shopCityCodeList"></el-cascader>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="140px" size="mini">
                <el-form-item label="请输入详细地址" >
                    <el-input type="textarea" v-model="sizeForm.desc" style="width: 366px;"></el-input>
                </el-form-item>
            </el-form>

            <div style="margin-bottom: 20px;margin-top: 20px;margin-left: 140px">
                <el-checkbox v-model="checked">设置为默认地址</el-checkbox>
            </div>


            <el-button type="primary"  style="margin-left: 140px">保存</el-button>
            <el-button>取消</el-button>

        </el-row>

    </el-row>

</template>

<script>
    import newCity from '../../../js/newCity';
    export default {
        data() {
            return {
                checked:'',
                radio: '1',
                sizeForm: {
                    name: '李四',
                    region: '111',
                    delivery: false,
                    type: [],
                    desc: '1111',
                } ,
                // 省市区
                cityListNew: newCity,
                // shop地址
                shopCityCodeList: [],
                created(){
                    this.function();
                },
                methods: {
                    parsePost () {
                        // base info
                        // 省市区转字符串
                        let address = '';
                        this.cityListNew.forEach((item) => {
                            if (item.value == this.shopCityCodeList[0]) {
                                address += item.label;
                                item.children.forEach((jtem) => {
                                    if (jtem.value == this.shopCityCodeList[1]) {
                                        address += jtem.label;
                                        jtem.children.forEach((ktem) => {
                                            if (ktem.value == this.shopCityCodeList[2]) {
                                                address += ktem.label;
                                            }
                                        });
                                    }
                                });
                            }
                        });
                        this.postData.address = address;
                        this.postData.cityCode = this.shopCityCodeList[this.shopCityCodeList.length - 1];
                        // bank
                        this.postData.bankName = this.bankName;
                        this.postData.bankCode = this.bankCode;
                        this.postData.bankCard = this.bankCard;
                        this.postData.bankCityCode = this.bankCityCode[this.bankCityCode.length - 1];
                        this.postData.openBankCode = this.openBankCode;
                        // 认证类型 1 企业 2 个体户
                        this.postData.type = 2;
                        if (this.id) {
                            this.postData.id = this.id;
                        }
                    },
                    function(){
                        Sun.post({
                            url: Http.addUserAddress,
                            data: {
                                name:'',
                                phone:'',
                                address:'',
                                detail:'',
                                isDefault:'',
                            },
                            success: (data) => {
                                // Sun.setLogin(data);
                                console.log(data);
                                // this.tableata= data;
                                // Sun.isLogin = true;

                            },
                            fail: (data) => {

                            }
                        });
                    }
                }
            }
        },
    }
</script>

<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
    }
</style>
<style>
    .cell span[data-v-03c96452]{
        font-size: 16px!important;
        color: #666666!important;
    }
</style>
