<template>
    <el-row>
        <el-col :span="4">
            <div class="grid bg-purple-banner">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">设置中心</span>
            </div>
        </el-col>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px ">
            <el-breadcrumb-item :to="{ path: 'information' }"><span style="color: #a5a5a5;font-weight: 400">设置中心</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">我的收货地址</span></el-breadcrumb-item>
        </el-breadcrumb>
        <div style="padding: 30px 0 0 20px" @click="handlenew()">
            <!--<el-button  size="mini" >-->
                <span style="font-size: 16px;color: #ff0000;cursor: pointer">+新增收货地址</span>
            <!--</el-button>-->
        </div>

    <el-row style="margin-top: 20px;overflow: hidden">
    <el-table :data="tableata" border style="width: 98%;margin-left: 10px">
        <el-table-column label="收货人" width="100" align="center">
            <template slot-scope="scope">
                <span class="ef-name">{{ scope.row.name }}</span>
            </template>
        </el-table-column>

        <el-table-column label="地址" width="240" align="center">
            <template slot-scope="scope">
                <span class="ef-name">{{ scope.row.address }}</span>
            </template>
        </el-table-column>

        <el-table-column label="详细地址" width="140" align="center">
            <template slot-scope="scope">
                <span class="ef-name">{{ scope.row.detail }}</span>
            </template>
        </el-table-column>

        <el-table-column label="电话/手机" width="140" align="center">
            <template slot-scope="scope">
                        <span class="ef-name">{{ scope.row.phone }}</span>
            </template>
        </el-table-column>

        <el-table-column label="操作" width="283" text-align="center" align="center">
            <template slot-scope="scope">
                <!--<el-button size="mini" >编辑</el-button>-->
                <span class="in-put-an" @click="handleEdit()">编辑</span>
                <!--<el-button size="mini" type="danger" >删除</el-button>-->
                <span class="in-put-an" @click="deleteRow()">删除</span>
                <!--<el-button size="mini" >设为默认</el-button>-->
                <div class="in-put-an">
                    <label v-if="bubber">设为默认</label>
                    <!--<label style="font-weight: 600" >默认收货地址</label>-->
                </div>
            </template>
        </el-table-column>
    </el-table>

    </el-row>

    </el-row>
</template>

<script>
    export default {
        data() {
            return {
                bubber:true,
                turbent:false,
                tableata: []
            }
        },
        created(){
            this.function();
        },
        methods: {
            handleEdit() {
                Sun.push('/editQualifications');
            },
            handlenew() {
                Sun.push('/Qualifications');
            },
            deleteRow() {
                Sun.post({
                    url: Http.delUserAddress,
                    data:{
                        id:'',
                    },
                    success: (data) => {
                        // Sun.setLogin(data);
                        console.log(data)
                        // this.tableata= data;
                        // Sun.isLogin = true;

                    },
                    fail: (data) => {

                    }
                })
            },
            function(){
                Sun.post({
                    url: Http.getUserAddressList,
                    data: {

                    },
                    success: (data) => {
                        // Sun.setLogin(data);
                        console.log(data);
                        this.tableata= data;
                        // Sun.isLogin = true;

                    },
                    fail: (data) => {

                    }
                });
            }
        }
    }
</script>

<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
    }
    .el-table_2_column_6     is-leaf{
        text-align: center;
    }
    .in-put-an{
        cursor: pointer;
        color: #373737;
        font-size: 14px!important;
    }
    .in-put-an label{
        cursor: pointer;
        color: #373737;
        font-size: 14px!important;
    }
    .in-put-an:hover{
        color: red!important;
    }
    .ef-name{
        margin-left: 10px;
        font-size: 16px!important;
    }
</style>
<style>
    /*.el-table th{*/
        /*background: #eee!important;*/
    /*}*/
    .el-table tr:hover{
        background-color: #fff!important;
    }
</style>
