<template>
<el-row>
    <el-col :span="4">
        <div class="grid">
            <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">设置中心</span>
        </div>
    </el-col>
    <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px ">
        <el-breadcrumb-item :to="{ path: 'information' }"><span style="color: #a5a5a5;font-weight: 400">设置中心</span></el-breadcrumb-item>
        <el-breadcrumb-item><span style="color: #a5a5a5;font-weight: 400">增票资质</span></el-breadcrumb-item>
    </el-breadcrumb>
    <div class="box-bbx">
        <span>您的增票资质:<label>{{tableData.state}}</label></span>
        <button class="bot-tton" @click="entpush()" >点击上传</button>
    </div>

</el-row>
</template>

<script>
    export default {
        data() {
            return {
                tableData: {
                    state:'未上传'
                },

            }
        },
        methods: {
            entpush(){
                Sun.push('/Tickadd');
            },
        }

    }
</script>

<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
        color: #545454;
        font-weight: normal;

    }
    .bot-tton{
        background: #e03538;;color: #fff;padding: 4px 6px;width: 126px;
        height: 32px;
        border-radius: 5px;margin-left: 42px;border: solid 0px #e03538;
    }
    .box-bbx{
        line-height: 60px;background-color: #fffdee;
        width: 915px;
        height: 60px;
        border: solid 1px #ffc45e;
        margin-top: 20px;
    }
    .box-bbx span{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 42px;
        letter-spacing: 0;
        color: #3c3b3b;
        margin-left: 32px;
    }
    .box-bbx span label{
        font-family: MicrosoftYaHei;
        font-size: 14px;
        font-weight: normal;
        letter-spacing: 0;
        color: #9f9f9f;
    }
</style>
