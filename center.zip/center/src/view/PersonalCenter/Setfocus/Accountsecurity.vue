<template>
    <el-row>
        <el-col :span="4">
            <div class="grid bg-purple-banner">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">设置中心</span>
            </div>
        </el-col>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px ">
            <el-breadcrumb-item :to="{ path: 'information' }"><span style="color: #a5a5a5;font-weight: 400">设置中心</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">账户安全</span></el-breadcrumb-item>
        </el-breadcrumb>


        <el-row>
            <el-form ref="form" :model="sizeForm" label-width="140px" size="mini">
                <el-form-item label="我的账户" >
                    <el-input v-model="sizeForm.account" style="width: 200px"></el-input>
                </el-form-item>
            </el-form>

            <el-form ref="form" :model="sizeForm" label-width="140px" size="mini">
                <el-form-item label="我的密码" >
                    <!--<el-button v-model="sizeForm.Password" @click="show">修改密码</el-button>-->
                    <router-link to="/logo">
                        <span class="x-gip">修改密码</span>
                    </router-link>
                </el-form-item>
            </el-form>

            <!--<el-form ref="form" :model="sizeForm" label-width="140px" size="mini" v-if="brptt">-->
                <!--<el-form-item label="请输入旧密码" >-->
                    <!--<el-input v-model="sizeForm.account" style="width: 200px"></el-input>-->
                <!--</el-form-item>-->
            <!--</el-form>-->

            <!--<el-form ref="form" :model="sizeForm" label-width="140px" size="mini" v-if="brptt">-->
                <!--<el-form-item label="请输入新密码" >-->
                    <!--<el-input v-model="sizeForm.account" style="width: 200px"></el-input>-->
                <!--</el-form-item>-->
            <!--</el-form>-->

        </el-row>

    </el-row>
</template>

<script>
    export default {
        data() {

            return {
                brptt:false,
                sizeForm: {
                    account: '张三',
                    Password:'1745126265',
                } ,
            }
        },
        methods: {
            show:function () {
                this.brptt= !this.brptt;
            }
        }
    }
</script>

<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
    }
    .x-gip{
        font-size: 14px;
        color: #ff0000;
        font-weight: normal;
        cursor: pointer;
    }
</style>
