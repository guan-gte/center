<script src="../../../js/util.js"></script>
<template>
    <el-row>
        <el-col :span="24">
            <div class="grid bg-purple-banner">
                <div class="grid bg-purple-banner">
                    <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">我的足迹</span>
                </div>
                <div style="position: absolute;top:40px;right:10%;transform: translateY(-50%)">
                    <i class="el-icon-lx-delete">批量删除</i>
                </div>
            </div>
        </el-col>

        <el-row  :gutter="20" v-for="(item,index) in pubb" :key="index" style="margin-left: 20px">
            <div style="font-size: 18px;">
                <span style="color: #737373;font-weight: bold;">{{item.time}}</span>
                <div style="border: 1px solid#cccccc;width: 86%;position: relative;bottom: 10px;left: 96px"></div>
            </div>
            <el-col :span="6" >
                <div class="grid-conn bg-purple" v-for="(list, foryue) in item.list" :key="foryue">
                    <img class="log2" :src="list.img" alt="">
                    <div class="name-set">{{list.name}}{{list.model}}</div>
                    <div class="Price-set">￥{{list.price}}</div>
                </div>
            </el-col>
        </el-row>
    </el-row>

</template>

<script>
    import img_logo from '../../../assets/ponr.jpg';
    import {formatDay} from "../../../js/util";

    export default {
        name: 'name',
        data() {
            return {
                logo: img_logo,
                pubb:[
                    {   time:"今日浏览",
                        list:[
                            {name:'德威莱克德威莱克德威莱克',Model:'DW520A',Price:'￥9999'}
                            ]
                    },

                ]
                ,
            }
        },
        created(){
            this.function();
        },
        methods: {
            function(){
                Sun.post({
                    url: Http.getHistoryGoodsList,
                    data:{
                        records:'',
                    },
                    success: (data) => {
                        // console.log(data);
                        // console.log(data.records)
                        // this.pubb= data.records;
                        let list = [];
                        // console.log(list)
                        data.records.forEach((value) => {
                            let time = formatDay(value.createTime);
                            let has = false;
                            list.forEach((item) => {
                                if (item.time === time) {
                                    item.list.push(value);
                                    has = true;
                                }
                            });
                            if (!has) {
                                list.push({time: time, list: [value]});
                            }
                            console.log(111)
                        });
                        console.log(list)
                        console.log(11111)
                        this.pubb=list

                        console.log(this.pubb)
                        // console.log(this.details)
                        // this.details.commodity=data.records.goodsList
                        // console.log(Sun.user)
                    },
                    fail: (data) => {

                    }

                });
            },

        },
        filters: {
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '';
                }
            }
        }

    }
</script>

<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 16px;
        padding-bottom: 30px;
    }
    .grid div{
        display: inline-block;
        position: relative;
    }
    .el-col-6{
        width: 100%!important;
    }
     .grid-conn{
        width: 202px;
        height: 320px;
        margin-top: 20px;
         float: left;
         margin-right: 20px;
         cursor: pointer;
    }
    .log2{
        width: 202px;
        height: 202px;
    }
    .bg-purple {
        background: #fff;
        /*border: 1px solid#eee;*/
        box-sizing: border-box;
    }
    .content .el-row{
        padding-bottom: 20px;
    }

    .grid-content {
        border-radius: 4px;
        min-height: 36px;
    }
    .row-bg {
        padding: 10px 0;
        background-color: #f9fafc;
    }
    .Price-set{
        width: 86px;
        font-family: MicrosoftYaHei;
        font-size: 18px;
        font-weight: bold;
        font-stretch: normal;
        line-height: 36px;
        letter-spacing: -1px;
        color: #ff0000;
        padding: 0 0 0 10px;
    }

    .name-set{
        width: 153px;
        height: 33px;
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 18px;
        letter-spacing: -1px;
        color: #7d7c7d;
        padding: 5px 0 0 10px;
    }
</style>
<style>
    /*.content{*/
        /*overflow-x: hidden;*/
    /*}*/
</style>
