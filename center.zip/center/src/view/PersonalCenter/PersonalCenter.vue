<template>
    <el-row>
        <el-row>
            <!--1-->
            <el-col :span="24">
                <div class="grid-content bg-purple-dark">
                    <div class="all">
                        <img :src="url">
                    </div>
                    <el-form ref="form" label-width="150px" class="infor">
                        <span class="p-title">{{shopInf.nickName}}</span>
                        <span class="p-title" style="line-height: 40px">{{shopInf.phone}}</span>
                    </el-form>

                    <el-form ref="form" disabled label-width="150px" class="infor-right">
                    <el-rate v-model="value" style="position: relative;right: 60px" :colors="['#fadb14', '#fadb14', '#fadb14']"></el-rate>
                    </el-form>

                    <span @click="dip = !dip" style="float: right; margin-right: 300px;position: relative;bottom: 30px">我的会员</span>
                    <ul class="ul-liput" v-if="dip">
                        <li style="width: 55%;">当前会员级别:
                            <el-rate v-model="value" disabled style="display: inline-block" :colors="[' #4a5679', ' #4a5679', ' #4a5679']"></el-rate>
                        </li>
                        <li style="width: 45%;">当前消费金额:{{shopInf.nubm1}}</li>
                        <li style="width: 60%;">下一级会员级别:
                            <el-rate v-model="value1" disabled style="display: inline-block" :colors="[' #4a5679', ' #4a5679', ' #4a5679']"></el-rate>
                        </li>
                        <li style="width: 40%;">需要消费金额:{{shopInf.nubm2}}</li>
                    </ul>
                </div>
            </el-col>
        </el-row>
        <!--2-->
        <el-row :gutter="20">
            <el-col :span="6" v-for="(btem,kndex) in total" :key="btem" style="overflow: hidden;border-bottom: 1px solid#eee;height: 78px">
                <div class="grid-con bg-purple"  @click="orderDetail(btem)">
                    <div class="box-r-er" style="color: #333333;">{{btem.title}}(<span style="color: red">{{btem.numb}}</span>)</div>
                </div>
            </el-col>

            <div style="margin-left: 80px;line-height: 102px">
                <span class="Hyuan">我的会员服务</span>
                <ul class="ul-beff">
                    <router-link to="/Myco" @click.native="selectnav('first')">
                        <li >1.<span style="color: #4a5679;border-bottom: 1px solid#1d2088">梁玉玺节</span></li>
                    </router-link>
                    <li>2.<span style="color: red">不计免赔</span>(300元以内)</li>
                    <li>3.绿色通道：<span style="color: red">3000元以内现更换再收费</span></li>
                    <li>4.<span style="color: red">本市上门时效24小时</span></li>
                    <li>5.享有<span style="color: red">95折</span>优惠</li>
                </ul>
                <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{ path: '/Myco' }" style="float: right;margin-right: 80px;"><span style="color: #4a5679!important;cursor: pointer;">更多会员信息></span> </el-breadcrumb-item>
                </el-breadcrumb>
            </div>

        </el-row>
        <!--3-->
        <el-row>
            <el-col :span="24">
                <div class="Recommend bg-purple-dark">
                    <div style="color: #4c4b4b;font-weight:600">为您推荐</div>
                    <div class="mend">换一批</div>
                </div>
            </el-col>
        </el-row>
        <!--4-->
        <el-row :gutter="20">
            <el-col :span="6" v-for="(item, index) in tootd" :key="item">
                <div class="grid-conn bg-purple">
                    <img class="log2" :src="logo" alt="">
                    <div class="name-set">{{item.current}}{{item.Model}}</div>
                    <div class="Price-set">{{item.Price}}</div>
                </div>
            </el-col>
        </el-row>
    </el-row>


</template>

<script>
    import img_logo from '../../assets/ponr.jpg';
    export default {
        extends: Sun.vuePage,
        // name: 'index',
        data() {
            return {
                value:1,
                value1:2,
                dip:true,
                url:'',
                size:10,
                colors: ['#99A9BF', '#F7BA2A', '#FF9900'],
                logo: img_logo,
                shopInf: {
                    nickName: '',
                    phone: '',
                    levelId:'',
                    nubm2:'',
                },
                total: [
                    {
                        title:'待付款',
                        type:1,
                        numb:1
                    },{
                        title:'待发货',
                        type:2,
                        numb:1
                    },
                    {
                        title:'待收货',
                        type:3,
                        numb:1
                    },
                    {
                        title:'全部订单',
                        type:4,
                        numb:1
                    }
                    // {name: '待付款',num:1},
                    // {name: '待发货',num:1,},
                    // {name: '待收货',num:1,},
                    // {name: '全部订单',num:1,}
                ],
                tootd:[
                    {
                        current:'',
                        Price:'',
                    }
                ],

            }
        },
        computed: {

        },
        created(){
            this.function();
            this.function(e);
            // this.test ()
        // this.$nextTick(() => { this.getlocal()})
        },
        // mounted(){
        //     this.$nextTick(function () {
        //         window.addEventListener('scroll',this.handleScroll)
        //
        //     })
        // },
        deactivated(){
        },
        methods: {
            orderDetail (btem) {
                Sun.push('/order', {name: btem.name});
            },
            selectnav(selectindex){
                let selectedindex=selectindex;
                localStorage.setItem('first',selectedindex)
            },

            function(){
                Sun.post({
                    url: Http.login,
                    data: {
                        phone: 13003016904,
                        password: 336699
                    },
                    success: (data) => {
                        Sun.setLogin(data);
                        this.shopInf= data;
                        this.url=data.headPic;
                        // Sun.isLogin = true;
                        console.log(Sun.user)
                    },
                    fail: (data) => {

                    }
                });
            },
            function(){
                Sun.post({
                    url: Http.getOrderList,
                    data: {

                    },
                    success: (data) => {
                        // Sun.setLogin(data);


                        // Sun.isLogin = true;
                        console.log(data)
                    },
                    fail: (data) => {

                    }
                })

            }
        }
    }
</script>

<style scoped>
    .content-box{
        background: #fff!important;
    }
    .grid-content {
        border-radius: 4px;
        height: 178px!important;
        border: 0;

    }
    .p-title{
        width: 200px;
        float: left;
    }
    .bg-purple-dark {
        background: #f7fcfc;
        display: block;
        position: relative;
    }
    /*1111*/
    .bg-purple {
        background: #fff;

    }
    .Price-set{
        width: 86px;
        font-family: MicrosoftYaHei;
        font-size: 18px;
        font-weight: bold;
        font-stretch: normal;
        line-height: 36px;
        letter-spacing: -1px;
        color: #ff0000;
    }

    .name-set{
        width: 153px;
        height: 33px;
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 18px;
        letter-spacing: -1px;
        color: #7d7c7d;
        padding: 5px 0 0;
    }

    .ul-beff{
        margin-left: 40px;
        color: #464A54
    }
    .ul-beff li{
        width: 278px;
        /*height: 17px;*/
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 30px;
        letter-spacing: 0px;
        color: #666666;
    }
    .grid-con {
        margin-top: 20px;
       border-left: 1px solid#eee;
        height: 58px;
        cursor: pointer;
    }
    .ul-liput{
        width: 420px;
       position: absolute;
        top: 50%;
        left: 52%;
        transform: translateY(-50%);
    }
    .ul-liput li{
        display: inline-block;
        width: 190px;
        float: left;
        overflow: hidden;
        color: #4a5679
    }
    .all img{
        width: 140px;
        height: 140px;
        border-radius: 50%;
        position: absolute;
        top: 50%;
        left: 2%;
        transform: translateY(-50%);
    }
    .container{
        width: 57.34px;
        float: right;
        position: relative;
        padding: 0;
        border: 0;
        background: #f1fdf6;
        margin-right: 160px;
    }
/*.container-vif{*/
    /*width: 320px;*/
    /*text-align: center;*/
    /*position: relative;*/
    /*right: 140px;*/
/*}*/
    .infor{
        padding: 0;
        position: relative;
        top: 56px;
        overflow: hidden;
        width: 200px;
        left: 180px;
    }
    .infor div{
        margin-bottom: 0;
        font-size: 16px;
    }
    .infor-right{
        position: absolute;
        top: 40%;
        left: 42%;
        transform: translateY(-60%);
    }

    .grid-con{
        text-align: center;
    }
    .grid-con div{
        display: inline-block;
        position: relative;
        top: 10px;
    }
    .Recommend{
        height: 46px;
        margin-top: 40px;
        background-color: #e3e2e2;
        line-height: 46px;
        padding-left: 10px;
        font-size: 20px;
    }
    .Recommend div{
        display: inline-block;
    }
    .mend{
        float: right;
        font-size: 12px;
        padding-right: 40px;
        color: #a9abab;
        cursor: pointer;
    }
    .grid-conn{
        width: 202px;
        height: 320px;
        margin: 20px auto 0;
        cursor: pointer;

    }
    .log2{
        width: 202px;
        height: 202px;
    }
    .el-col-6{
        width: 25%;
        padding: 0!important;
    }
    .Hyuan{
        color: #505050;line-height: 30px;font-size: 18px;font-weight: normal;
        cursor: pointer;
    }

    .box-r-er:hover{text-decoration:underline;}

</style>

