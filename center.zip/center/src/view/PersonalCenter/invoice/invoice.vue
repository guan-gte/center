<template>
    <el-row>
        <el-col :span="4">
            <div class="grid">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">我的发票</span>
            </div>
        </el-col>

        <el-col class="test">
            <el-tabs type="border-card">
                <el-tab-pane >
                    <span slot="label">全部订单</span>
                    <div style="overflow: hidden;width: 100%;text-align: center;background-color: #eee;height: 40px;line-height:40px; ">
                        <div style="float: left;width: 30%">订单编号</div>
                        <div style="float: left;width: 25%">订单金额</div>
                        <div style="float: left;width: 25%">开票状态</div>
                        <div style="float: left;width: 20%">物流信息</div>
                    </div>
                       <div class="box" v-for="(item, bin) in order" :key="bin">
                           <div class="box-border">
                               <span class="border-posn numtet">{{item.number}}</span>
                           </div>
                           <div class="box-border" style="width: 25%;">
                               <span class="border-posn picrtet">{{item.pirc}}</span>
                           </div>
                           <div class="box-border" style="width: 25%;">
                               <div class="border-posn">
                                   <div v-if="type ==='1'" >已开票</div>
                                   <div v-if="type ==='2'">未开票</div>
                                   <button @click="handlenew()">开票</button>
                               </div>
                           </div>
                           <div class="box-border" style="width: 20%;">
                               <div class="border-posn">
                                   <div @click="dialogFormVisible = true" class="loocktet">查看物流</div>
                               </div>
                           </div>
                       </div>
                </el-tab-pane>
                <el-tab-pane>
                    <span slot="label"><i class="el-icon-date"></i>已开发票订单</span>
                    <div style="overflow: hidden;width: 100%;text-align: center;background-color: #eee;height: 40px;line-height:40px; ">
                        <div style="float: left;width: 30%">订单编号</div>
                        <div style="float: left;width: 25%">订单金额</div>
                        <div style="float: left;width: 25%">开票状态</div>
                        <div style="float: left;width: 20%">物流信息</div>
                    </div>
                    <div class="box" v-for="(item, bing) in order" :key="bing">
                        <div class="box-border">
                            <span class="border-posn numtet">{{item.number}}</span>
                        </div>
                        <div class="box-border" style="width: 25%;">
                            <span class="border-posn picrtet">{{item.pirc}}</span>
                        </div>
                        <div class="box-border" style="width: 25%;">
                            <div class="border-posn">
                                <div v-if="type ==='1'" >已开票</div>
                                <div v-if="type ==='2'">未开票</div>
                                <button @click="handlenew()">开票</button>
                            </div>
                        </div>
                        <div class="box-border" style="width: 20%;">
                            <div class="border-posn">
                                <div @click="dialogFormVisible = true" class="loocktet">查看物流</div>
                            </div>
                        </div>
                    </div>
                </el-tab-pane>
                <el-tab-pane>
                    <span slot="label"><i class="el-icon-date"></i>未开发票订单</span>
                    <div style="overflow: hidden;width: 100%;text-align: center;background-color: #eee;height: 40px;line-height:40px; ">
                        <div style="float: left;width: 30%">订单编号</div>
                        <div style="float: left;width: 25%">订单金额</div>
                        <div style="float: left;width: 25%">开票状态</div>
                        <div style="float: left;width: 20%">物流信息</div>
                    </div>
                    <div class="box" v-for="(item, binges) in order" :key="binges">
                        <div class="box-border">
                            <span class="border-posn numtet">{{item.number}}</span>
                        </div>
                        <div class="box-border" style="width: 25%;">
                            <span class="border-posn picrtet">{{item.pirc}}</span>
                        </div>
                        <div class="box-border" style="width: 25%;">
                            <div class="border-posn">
                                <div v-if="type ==='1'" >已开票</div>
                                <div v-if="type ==='2'">未开票</div>
                                <button @click="handlenew()">开票</button>
                            </div>
                        </div>
                        <div class="box-border" style="width: 20%;">
                            <div class="border-posn">
                                <div @click="dialogFormVisible = true" class="loocktet">查看物流</div>
                            </div>
                        </div>
                    </div>
                </el-tab-pane>
                <el-dialog title="物流信息" :visible.sync="dialogFormVisible">
                    <el-form :model="form">
                        <div style="position: relative;top: 24px;">
                            <div class="ce-model">
                                <span>发货状态:</span>
                                <span>{{form.Deliverystatus}}</span>
                            </div>
                            <div>
                                <span class="sh-daacall">收货信息</span>
                                <div>{{form.name}}</div>
                                <div>{{form.address}}</div>
                            </div>

                            <div>
                                <span class="sh-daacall">物流信息</span>
                                <div>{{form.information}}</div>
                            </div>
                        </div>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
                    </div>
                </el-dialog>
            </el-tabs>
        </el-col>





    </el-row>
</template>
<script>
    export default {
        data() {
            return {
                type:'1',
                order:[
                    {
                        number:'7894561235895845896',
                        pirc:'￥19800',
                    },
                    {
                        number:'7894561235895845896',
                        pirc:'￥19800',
                    }
                ],
                dialogTableVisible: false,
                dialogFormVisible: false,
                form: {
                    Deliverystatus:'等待发货',
                    name:'王竹 18297938805',
                    address:'上海市嘉定区金园五路1号',
                    information:'暂无信息',
                },
                formLabelWidth: '120px',
            }
        },
        methods: {
            handlenew(){
                Sun.push('/invoon');
            },
        }
    }
</script>
<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 40px;
        color: #545454;
        font-weight: normal;
    }
    .box{
        width: 100%;overflow: hidden
    }
    .box-border{
        width: 30%;height: 110px;text-align: center;float: left;
        border: 1px solid#eee;box-sizing: border-box;position: relative;
        background-color: #f9f9f9;
    }
    .border-posn{
        position: absolute;top: 50%;left: 50%;transform:translate(-50%,-50%);line-height: 30px;
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #666666;
    }
    .numtet{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #6767f7;
        text-decoration:underline;
        cursor: pointer;
    }
    .picrtet{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #666666;
    }
    .loocktet{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        text-decoration:underline;
        letter-spacing: 0px;
        color: #ff0000;
        cursor: pointer;
    }
    .border-posn button{
        width: 62px;
        height: 31px;
        background-color: #ff0000;
        border-radius: 5px;box-sizing: border-box;border: 1px solid#ff0000;color: #fff;
    }
    .ce-model{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #545454;
        position: relative;bottom: 24px;
    }
    .sh-daacall{
        font-family: MicrosoftYaHei;
        font-size: 18px;
        font-weight: bold;
        font-stretch: normal;
        line-height: 30px;
        letter-spacing: 0px;
        color: #2f2f2f;
    }
</style>
<style lang="less" scoped>
    .test{
        /deep/ .el-dialog__header{
            background-color: red!important;
            color: red!important;
        }
    }
</style>
<style>
    .el-dialog__header{
        background-color: #eee;
    }
</style>
