<template>
    <el-dialog title="编辑" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px">
            <el-form-item required :label=" '编号'">
                <el-input v-model="form.id" disabled style="width: 200px"></el-input>
            </el-form-item>
            <el-form-item required :label="'位置'">
                <el-input v-model="form.name" style="width: 200px"></el-input>
            </el-form-item>

            <el-form-item required :label="'请选择跳转类型'">
                <el-select v-model="value" placeholder="请选择" style="width: 100px">
                    <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <!--链接-->
            <el-form-item v-if="value == '选项2'" required :label="'请选输入链接地址'">
                <el-input v-model="form.rul" style="width: 200px"></el-input>
            </el-form-item>
            <!--图片-->
            <el-form-item v-if="value == '选项1'" required :label="'请添加图片'">
                <div class="crop-demo" v-model="form.img">
                    <!--<div class="crop-demo-btn">-->
                    <!--<input class="crop-input" type="file" name="image" accept="image/*" @change="setImage"/>-->
                    <!--</div>-->
                    <el-upload
                        class="upload-demo"
                        action="https://jsonplaceholder.typicode.com/posts/"
                        :on-preview="handlePreview"
                        :on-remove="handleRemove"
                        :before-remove="beforeRemove"
                        multiple
                        :limit="3"
                        :on-exceed="handleExceed"
                        :file-list="fileList">
                        <el-button size="small" type="primary">点击上传</el-button>
                    </el-upload>
                </div>
            </el-form-item>
            <!--商品-->
            <el-form-item v-if="value == '选项3'" required :label="'请输入商品ID'">
                <el-input v-model="form.name" style="width: 200px"></el-input>
            </el-form-item>
            <el-form-item v-if="value == '选项3'" required :label="'请输入商品名称'">
                <el-input v-model="form.name" style="width: 200px"></el-input>
            </el-form-item>

            <el-form-item required label="请选择启用状态">
                <el-switch v-model="form.status" active-color="#13ce66" inactive-color="#ddd"></el-switch>
            </el-form-item>

        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap} from "../../../../js/util";

    export default {
        data() {
            return {
                form: {},
                selected:'1',
                setImage:'',
                options: [{
                    value: '选项1',
                    label: '图片'
                }, {
                    value: '选项2',
                    label: '链接'
                }, {
                    value: '选项3',
                    label: '商品'
                }],
                value: '选项1',
                fileList: [{name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'},
                    {name: 'food2.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}]

            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                // if (!this.form.name) {
                //     Sun.showError(this.type == 1 ? '请输入客户标签' : '请输入客户行业');
                //     return;
                // }
                // 编辑
                this.form.id = this.id;
                this.form.name = this.name;
                this.form.status=this.status;
                this.form.url = this.url;
                this.form.type = this.type;
                this.form.img = this.img;
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file);
            },
            handleExceed(files, fileList) {
                this.$message.warning(`当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`确定移除 ${ file.name }？`);
            }
        },
        props: ['data', 'show', 'callBack', 'id', 'url', 'type'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
