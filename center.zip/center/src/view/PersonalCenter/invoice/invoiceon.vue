<template>
    <el-row>
        <el-col :span="4">
            <div class="grid">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">我的发票</span>
            </div>
        </el-col>

        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px">
            <el-breadcrumb-item :to="{ path: '/' }"><span style="color: #a5a5a5">我的发票</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">开取发票</span></el-breadcrumb-item>
        </el-breadcrumb>

        <el-col>
            <span class="Invoiceselection">发票选择：</span>
        </el-col>

        <div class="box-style">
            <div class="box-topsty">
                <el-checkbox id="check1" type="checkbox" v-model="check1" @change="che1" style="cursor: pointer">
                    <span class="tex-sty">个人发票</span>
                </el-checkbox>
                <label v-if="check1">
                        <span>个人名称：</span>
                        <input type="text">
                        <span>纳税人识别码：</span>
                        <input type="text">
                </label>
            </div>
            <div class="box-topsty">
                <el-checkbox id="check2" type="checkbox" v-model="check2" @change="che2" style="cursor: pointer">
                    <span class="tex-sty">企业普通发票</span>
                </el-checkbox>
                <label v-if="check2">
                    <div style="display: inline-block">
                        <span>企业名称：</span>
                        <input type="text">
                        <span>纳税人识别码：</span>
                        <input type="text">
                    </div>
                </label>
            </div>
            <div class="box-topsty">
                <el-checkbox id="check3" disabled type="checkbox" v-model="check3" @change="che3" style="cursor: pointer">
                   <span class="tex-sty">企业增值税专用发票</span>
                </el-checkbox>
                <label v-if="check3">
                    <div style="display: inline-block">
                        <span>企业名称：</span>
                        <input type="text">
                        <span>纳税人识别码：</span>
                        <input type="text">
                    </div>
                </label>
            </div>
            <span class="ren-zw" @click="modify()">您还未进行增票资质认证，点击认证</span>
        </div>

        <el-col style="border-bottom: 1px solid#eee;width: 94%;margin-left: 50px;">
            <span class="AddressStyle">请选择收票地址：</span>
        </el-col>

        <el-col>
            <div style="padding: 20px 0 10px;margin-left: 30px ">
                <i class="el-icon-lx-location" style="color: red;"></i>
                <span style="font-family: MicrosoftYaHei;
	font-size: 16px;
	font-weight: normal;
	font-stretch: normal;
	letter-spacing: 0px;
	color: #666666;">寄送至</span>
            </div>

            <el-table :data="tableData" style="width: 100%">
                <el-table-column type="selection" width="41">

                </el-table-column>
                <el-table-column label="地址" width="220" align="center">
                    <template slot-scope="scope">
                        <span class="des-tex-sty">{{ scope.row.address }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="详细地址" width="180" align="center">
                    <template slot-scope="scope">
                        <span class="des-tex-sty">{{ scope.row.Detailedaddress}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="收票联系人" width="180" align="center">
                    <template slot-scope="scope">
                        <span class="des-tex-sty">{{ scope.row.name }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="默认地址" width="100" align="center">
                    <template slot-scope="scope">
                        <span class="des-tex-sty">默认</span>
                    </template>
                </el-table-column>
                <el-table-column label="修改地址" width="100" align="center">
                    <template slot-scope="scope">
                        <el-button size="mini" type="danger" @click="dialogFormVisible = true">修改</el-button>
                    </template>
                </el-table-column>
                <el-table-column label="删除" width="100" align="center">
                    <template slot-scope="scope">
                        <el-button size="mini" type="danger"  @click.native.prevent="deleteRow(scope.$index, tableData)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div style="margin-top: 20px">
                <button type="text" @click="dialogFormVisible = true" class="newadd">新增地址</button>
                <el-dialog title="新增地址" :visible.sync="dialogFormVisible">
                    <el-form :model="form">
                        <div style="position: relative;top: 24px;">
                            <el-form ref="form" :rules="rules" :model="sizeForm" label-width="120px" size="medium" >
                                <el-form :model="sizeForm" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
                                <el-form-item label="收票人姓名:"  prop="name">
                                    <span style="color: red">*</span>
                                    <el-input v-model="sizeForm.name"  placeholder="请输入您的收票人姓名" style="width: 436px"></el-input>
                                </el-form-item>

                                <el-form-item label="收票人手机号:"  prop="Name">
                                    <span style="color: red">*</span>
                                    <el-input v-model="sizeForm.Name"  placeholder="请输入您的收票人手机号" style="width: 436px"></el-input>
                                </el-form-item>

                                <el-form ref="form" :model="sizeForm" label-width="120px" size="medium">
                                    <el-form-item label="收票人省份:"  prop="shopCityCodeList">
                                        <span style="color: red">*</span>
                                        <el-cascader :options="cityListNew" v-model="shopCityCodeList"></el-cascader>
                                    </el-form-item>
                                </el-form>

                                <el-form-item label="收票人地址:" prop="region">
                                    <span style="color: red">*</span>
                                    <el-input v-model="sizeForm.region" placeholder="请输入您的收票人地址" style="width: 436px"></el-input>
                                </el-form-item>
                                </el-form>
                            </el-form>
                        </div>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button  type="primary" @click="submitForm('ruleForm')">确 定</el-button>
                    </div>
                </el-dialog>
            </div>
            <div style="text-align: center;margin-top: 72px">
                <button class="ok-que">确定</button>
                <button class="on-qu">取消</button>
            </div>
        </el-col>
    </el-row>
</template>
<script>
    import newCity from '../../../js/newCity';
    export default {
        data() {
            return {
                disabled:true,
                check1:false,
                check2:true,
                check3:false,
                sizeForm: {
                    name: '',
                    Name:'',
                    region: '',
                    shesop:'',
                    banck:'',
                    bancknuber:'',
                    // date2: '',
                    delivery: false,
                    resource: '',
                    desc: '',
                } ,
                rules: {
                    name: [
                        { required: true, message: '请输入姓名', trigger: 'blur' },
                        { min: 2, max: 12, message: '长度在 2 到 12 个字符', trigger: 'blur' }
                    ],
                    Name: [
                        { required: true, message: '请选输入手机号', trigger: 'blur' },
                        { min: 11, max: 11, message: '请输入正确的手机号', trigger: 'blur' }
                    ],
                    shopCityCodeList: [
                        { type: 'date', required: true, message: '请选择日期', trigger: 'change' }
                    ],
                    region: [
                        { required: true, message: '请选输入详细地址', trigger: 'blur' }
                    ],

                },
                tableData: [
                    {
                        address:'能蒙古呼和浩特自治区能蒙古呼和浩',
                        Detailedaddress:'能蒙古呼和浩特自治区能蒙古呼和浩',
                    date: '上海',
                    name: '王小虎 1885545113',
                },
                    {
                        address:'能蒙古呼和浩特自治区能蒙古呼和浩',
                        Detailedaddress:'能蒙古呼和浩特自治区能蒙古呼和浩',
                        date: '上海',
                        name: '王小虎 1885545113',
                    },
                    {
                        address:'能蒙古呼和浩特自治区能蒙古呼和浩',
                        Detailedaddress:'能蒙古呼和浩特自治区能蒙古呼和浩',
                        date: '上海',
                        name: '王小虎 1885545113',
                    },
                    {
                        address:'能蒙古呼和浩特自治区能蒙古呼和浩',
                        Detailedaddress:'能蒙古呼和浩特自治区能蒙古呼和浩',
                        date: '上海',
                        name: '王小虎 1885545113',
                    },
                ],
                // 省市区
                cityListNew: newCity,
                // shop地址
                shopCityCodeList: [],
                // dialogTableVisible: false,
                dialogFormVisible: false,
                form: {
                    name: '',
                    region: '',
                    date1: '',
                    date2: '',
                    delivery: false,
                    type: [],
                    resource: '',
                    desc: ''
                },
                formLabelWidth: '120px'
            }
        },
        methods: {
            deleteRow(index, rows) {
                rows.splice(index, 1);
            },
            parsePost () {
                // base info
                // 省市区转字符串
                let address = '';
                this.cityListNew.forEach((item) => {
                    if (item.value == this.shopCityCodeList[0]) {
                        address += item.label;
                        item.children.forEach((jtem) => {
                            if (jtem.value == this.shopCityCodeList[1]) {
                                address += jtem.label;
                                jtem.children.forEach((ktem) => {
                                    if (ktem.value == this.shopCityCodeList[2]) {
                                        address += ktem.label;
                                    }
                                });
                            }
                        });
                    }
                });
                this.postData.address = address;
                this.postData.cityCode = this.shopCityCodeList[this.shopCityCodeList.length - 1];
                // bank
                this.postData.bankName = this.bankName;
                this.postData.bankCode = this.bankCode;
                this.postData.bankCard = this.bankCard;
                this.postData.bankCityCode = this.bankCityCode[this.bankCityCode.length - 1];
                this.postData.openBankCode = this.openBankCode;
                // 认证类型 1 企业 2 个体户
                this.postData.type = 2;
                if (this.id) {
                    this.postData.id = this.id;
                }
            },
            che1(ito){
                if(ito){
                    this.check2 = false;
                    this.check3 = false;
                }
            },
            che2(ito){
                if(ito){
                    this.check1 = false;
                    this.check3 = false;
                }
            },
            che3(ito){
                if(ito){
                    this.check1 = false;
                    this.check2 = false;
                }
            },
            modify() {
                Sun.push('/Tickadd');
            },
            handleDelete(index, row) {
                console.log(index, row);
            },
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.dialogFormVisible = false;
                        console.log(111)
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
        }
    }
</script>
<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
    }
    .AddressStyle{
        width: 87px;
        font-family: MicrosoftYaHei;
        font-size: 20px;
        font-weight: bold;
        font-stretch: normal;
        line-height: 40px;
        letter-spacing: 0px;
        color: #545454;
    }
    .ok-que{
        width: 148px;
        height: 40px;
        background-color: #ff0000;
        border: solid 0px #ff0000;
        border-radius: 5px;
        cursor: pointer;
    }
    .on-qu{
        width: 148px;
        height: 40px;
        border-radius: 5px;
        border: solid 0px #666666;
        cursor: pointer;
    }
    .newadd{
        width: 121px;
        height: 32px;
        background: #eee;
        border: solid 0px #eee;
        cursor: pointer;
        margin-left: 60px;
    }
    .des-tex-sty{
        margin-left: 10px;
        font-family: MicrosoftYaHei;
        font-size: 16px!important;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #666666!important;
    }
    .Invoiceselection{
        width: 87px;
        font-family: MicrosoftYaHei;
        font-size: 20px;
        font-weight: bold;
        font-stretch: normal;
        line-height: 80px;
        margin-left: 50px;
        letter-spacing: 0px;
        color: #545454;
    }
    .box-style{
        border: 1px solid #fff;
        display: block;
        overflow: hidden;
        margin-left: 68px;
        padding-bottom:96px;
    }
    .box-topsty{
        line-height: 40px;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #666666;
    }
    .box-topsty input{
        line-height: 28px;width: 245px
    }
    .ren-zw{
        font-family: MicrosoftYaHei;
        font-size: 16px!important;
        font-weight: normal;
        font-stretch: normal;
        line-height: 30px;
        letter-spacing: 0px;
        color: #ff0000;
        margin-left: 30px;
        text-decoration:underline;
        cursor: pointer;
    }
    .tex-sty{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #666666;
    }

</style>
