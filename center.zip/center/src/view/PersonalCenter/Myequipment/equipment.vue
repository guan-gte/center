<template>
    <el-row>
        <el-col :span="4">
            <div class="grid">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">我的设备</span>
            </div>
        </el-col>

        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px">
            <el-breadcrumb-item :to="{ path: '/' }"><span style="color: #a5a5a5">我的设备</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">查看设备</span></el-breadcrumb-item>
        </el-breadcrumb>

        <div style="width: 100%;position: relative;height: 240px;border-bottom: 1px solid#eee;margin: 0 0 40px;color: #7d7c7d">
            <img :src="url">
            <div style="position: absolute;top: 12%;left: 24%">
                <div class="non-name">{{name}}</div>
                <div style="padding: 2px 0;font-size: 14px" v-for="(datesd,foryou) in datesd" :key="foryou">{{datesd.datesed}}{{datesd.date}}</div>
            </div>
            <span @click="handlenew()" class="my-s-b">设备维护记录</span>
            <span @click="handlienew()" class="w-hu-jl" >配件更换记录</span>
        </div>

        <el-tabs v-model="activeName" @tab-click="handleClick" style="padding: 0 6px 0">
            <el-tab-pane label="全部" name="first">
                <div class="g-go" v-for="(Detaileddata,foront) in Detaileddata" :key="foront">
                    <img :src="url" style="width: 153px;height: 153px">
                    <div style="position: absolute;top: 20%;left: 24%">
                        <div class="n-name">{{Detaileddata.name}}</div>
                        <div class="da-data">{{Detaileddata.datesed}}{{Detaileddata.date}}</div>
                        <div class="da-data">{{Detaileddata.dateseds}}{{Detaileddata.dates}}</div>
                    </div>
                    <span class="shop-bj">购买该配件</span>
                </div>
            </el-tab-pane>

            <el-tab-pane label="将要过期" name="second">
                <div class="g-go" v-for="(Detaileddata,foront) in Detaileddata" :key="foront">
                    <img :src="url" style="width: 153px;height: 153px;">
                    <div style="position: absolute;top: 20%;left: 24%">
                        <div class="n-name">{{Detaileddata.name}}</div>
                        <div class="da-data">{{Detaileddata.datesed}}{{Detaileddata.date}}</div>
                        <div class="da-data">{{Detaileddata.dateseds}}{{Detaileddata.dates}}</div>
                    </div>
                    <span class="shop-bj">购买该配件</span>
                </div>
            </el-tab-pane>

            <el-tab-pane label="已经过期" name="third">
                <div class="g-go" v-for="(Detaileddata,foront) in Detaileddata" :key="foront">
                    <img :src="url" style="width: 153px;height: 153px">
                    <div style="position: absolute;top: 20%;left: 24%;">
                        <div class="n-name">{{Detaileddata.name}}</div>
                        <div class="da-data">{{Detaileddata.datesed}}{{Detaileddata.date}}</div>
                        <div class="da-data">{{Detaileddata.dateseds}}{{Detaileddata.dates}}</div>
                    </div>
                    <span class="shop-bj">购买该配件</span>
                </div>
            </el-tab-pane>
        </el-tabs>

    </el-row>

</template>

<script>
    export default {
        data() {
            return {
                name:'德威莱克德威威莱克威莱克',
                activeName: 'second',
                url:'https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg',
                datesd:[
                    {datesed:'购买日期：',date:'2019-08-14'},
                    {datesed:'近期维护日期：',date:'2019-12-14'},
                    {datesed:'下期维护日期：',date:'2020-02-14'}
                ],
                Detaileddata:[
                    {name:'德威莱克阿萨德三德威莱克阿萨德三大大',datesed:'上次更换日期：',date:'2019-08-14',dateseds:'建议更换日期：',dates:'2019-08-14'},
                    {name:'德威莱克阿萨德德威莱克阿萨德三大三大',datesed:'上次更换日期：',date:'2019-08-14',dateseds:'建议更换日期：',dates:'2019-08-14'},
                    {name:'德威莱克阿萨德威莱克阿萨德三大德三大',datesed:'上次更换日期：',date:'2019-08-14',dateseds:'建议更换日期：',dates:'2019-08-14'},
                    {name:'德威莱克阿萨德威莱克阿萨德三大德三大',datesed:'上次更换日期：',date:'2019-08-14',dateseds:'建议更换日期：',dates:'2019-08-14'},
                    {name:'德威莱克阿萨德威莱克阿萨德三大德三大',datesed:'上次更换日期：',date:'2019-08-14',dateseds:'建议更换日期：',dates:'2019-08-14'},
                ]
            }
        },
        methods: {
            handleClick(tab, event) {
                console.log(tab, event);
            },
            handlenew(){
                Sun.push('/records');
            },
            handlienew(){
                Sun.push('/Replacement');
            }
        }
    }
</script>

<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
    }
    img{
        /*width: 100px;*/
        /*height: 100px*/
    }
    .non-name{
        padding:0 0 30px;font-size: 20px;width: 340px
    }
    .my-s-b{
        position:relative;left:14px;border: 1px solid#a0a0a0;padding: 6px 24px;color: #666666;font-size: 14px;cursor: pointer;
    }
    .w-hu-jl{
        position:relative;left:80px;color:#dfff;border: 1px solid red;padding: 6px 24px;background: red;font-size: 14px;cursor: pointer;
    }
    .n-name{
        padding:0 0 22px;
        width: 235px;font-size: 20px;
        font-weight: 400;color: #545454;
    }
    .da-data{
        font-family: MicrosoftYaHei;
        font-size: 14px;
        font-weight: normal;
        color: #7d7c7d;
    }
    .shop-bj{
        color:#565656;padding: 6px 24px;background:#eee;
        position: absolute;top:50%;right: 10%;transform: translateY(-50%);
        font-size: 14px;
        cursor: pointer;
    }
    .g-go{
        width: 100%;position: relative;height: 164px;cursor: pointer
    }

</style>
