<template>
    <el-row style="position: relative">
        <el-col :span="4">
            <div class="grid">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">我的设备</span>
            </div>
        </el-col>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px ">
            <el-breadcrumb-item :to="{ path: 'equipment' }"><span style="color: #a5a5a5;font-weight: 400">我的设备</span></el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: 'coupon' }"><span style="color: #a5a5a5;font-weight: 400">查看设备</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">配件更换记录</span></el-breadcrumb-item>
        </el-breadcrumb>

        <el-table :data="tableData" border style="width: 891px;margin-left: 10px">
            <el-table-column label="更换日期" width="300" align="center" >
                <template slot-scope="scope">
                    <span class="da-det">{{ scope.row.date}}</span>
                </template>
            </el-table-column>
            <el-table-column  label="配件名称" width="589" align="center" >
                <template slot-scope="scope">
                    <div v-for="(address,foryue) in scope.row.address" :key="foryue" style="margin-left: 10px;font-size: 16px;color: #666666">
                        <span class="a-aoored-e da-det">{{address.aoored }}</span>
                    </div>
                </template>
            </el-table-column>
        </el-table>
        <div class="block" style="position: absolute;top: 600px;left: 30%;transform: translateY(50%)">
            <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="100"
                layout="total, sizes, prev, pager, next, jumper"
                background
                :total="1">
            </el-pagination>
        </div>
    </el-row>

</template>

<script>
    export default {
        data() {
            return {
                currentPage: 4,
                tableData: [{
                    date: '2016-05-02',
                    address: [
                        {
                            aoored:'龙克洗地机/车针盘 B-19寸/480mm',
                        },
                    ],
                },
                    {
                        date: '2016-05-02',
                        address: [
                            {
                                aoored:'龙克洗地机/车针盘 B-19寸/480mm',
                            },
                        ],
                    },
                    {
                        date: '2016-05-02',
                        address: [
                            {
                                aoored:'龙克洗地机/车针盘 B-19寸/480mm',
                            },
                        ],
                    },
                    {
                        date: '2016-05-02',
                        address: [
                            {
                                aoored:'龙克洗地机/车针盘 B-19寸/480mm',
                            },
                        ],
                    },
                    {
                        date: '2016-05-02',
                        address: [
                            {
                                aoored:'龙克洗地机/车针盘 B-19寸/480mm',
                            },
                        ],
                    }
                ]
            }
        },
        methods: {
            handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
            }
        }
    }
</script>

<style scoped>
    .da-det{
        margin-left: 10px;font-size: 16px;color: #7d7d7d;line-height: 31px;
    }
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
    }
    img{
        width: 100px;
        height: 100px
    }
    .a-aoored-e:hover{text-decoration:underline;color: #C20C0C;cursor: pointer}
</style>
