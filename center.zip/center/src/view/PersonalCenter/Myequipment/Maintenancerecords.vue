<template>
    <el-row>
        <el-col :span="4">
            <div class="grid">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">我的设备</span>
            </div>
        </el-col>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="position: relative;top: 24px;right: 28px ">
            <el-breadcrumb-item :to="{ path: 'equipment' }"><span style="color: #a5a5a5;font-weight: 400">我的设备</span></el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: 'coupon'}"><span style="color: #a5a5a5;font-weight: 400">查看设备</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">配件维护记录</span></el-breadcrumb-item>
        </el-breadcrumb>

        <el-table :data="tableData" border style="width:893px;margin-top: 3px;margin-left: 10px">
            <el-table-column label="维护日期" width="134" align="center" >
                <template slot-scope="scope">
                    <span class="co-lo-r">{{ scope.row.date}}</span>
                </template>
            </el-table-column>
            <el-table-column label="订单编号" width="202" align="center" >
                <template slot-scope="scope">
                    <span class="co-lo-r">{{ scope.row.OrderNumber }}</span>
                </template>
            </el-table-column>
            <el-table-column label="维护人" width="126" align="center" >
                <template slot-scope="scope">
                    <span class="co-lo-r">{{ scope.row.name }}</span>
                </template>
            </el-table-column>
            <el-table-column label="联系方式" width="170" align="center" >
                <template slot-scope="scope">
                    <span class="co-lo-r">{{ scope.row.Contactinformation }}</span>
                </template>
            </el-table-column>
            <el-table-column  label="维护记录" width="259" align="center" >
                <template slot-scope="scope">
                    <span class="s-m-address" style="margin-left: 10px;font-size: 16px;color: #5971c1;">
                        {{scope.row.address }}
                    </span>
                </template>
            </el-table-column>
        </el-table>

        <div class="block" style="position: absolute;top: 600px;left: 30%;transform: translateY(50%)">
            <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="10"
                layout="total, sizes, prev, pager, next, jumper"
                background
                :total="1">
            </el-pagination>
        </div>
    </el-row>

</template>

<script>
    export default {
        data() {
            return {
                currentPage: 4,
                tableData: [{
                    date: '2016-05-02',
                    OrderNumber:'156132156486132',
                    Contactinformation:'18297938805',
                    name: '王小虎',
                    address: '设备维修',

                },
                    {
                        date: '2016-05-02',
                        OrderNumber:'156132156486132',
                        Contactinformation:'18297938805',
                        name: '王小虎',
                        address: '上门维修',

                    },
                    {
                        date: '2016-05-02',
                        OrderNumber:'156132156486132',
                        Contactinformation:'18297938805',
                        name: '王小虎',
                        address: '设备维修',

                    }
                ]
            }
        },
        methods: {
            handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
            }
        }
    }
</script>

<style scoped>
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
        color: #545454;
        font-weight: normal;
    }
    img{
        width: 100px;
        height: 100px
    }
    .s-m-address{
        cursor: pointer;
    }
    .s-m-address:hover{text-decoration:underline;color: #C20C0C!important;}
</style>
<style>
    .cell{
        font-size: 18px!important;
        color: #373737!important;
        font-weight: normal!important;
    }
    .el-table th.is-leaf{
        border-color:  #b5b5b5;
    }
    .el-table--border td{
        border-color:  #b5b5b5;
        box-sizing: border-box!important;
        /*border-right: 1px solid #a0a0a0!important;*/

    }
    .el-table--border {
        border: 1px solid #b5b5b5;
        box-sizing: border-box;
    }
    .co-lo-r{
        margin-left: 10px;font-size: 16px;color: #7d7d7d;line-height: 31px;
    }
</style>
