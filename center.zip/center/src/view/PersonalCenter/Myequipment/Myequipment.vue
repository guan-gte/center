<template>
    <el-row class="y-pet">
        <el-col :span="24">
            <div class="grid bg-purple-banner">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">我的设备</span>
            </div>
        </el-col>

        <el-table :data="tableData" border style="width: 100%;">
            <el-table-column label="设备名称" width="304" align="center">
                <template slot-scope="scope" style="position: relative ;overflow: hidden">
                    <img :src="scope.row.url" >
                    <span class="n-name">
                        {{ scope.row.name }}
                    </span>
                </template>
            </el-table-column>
            <el-table-column label="购买时间" width="180" align="center">
                <template slot-scope="scope">
                    <span class="s-b-dot">{{ scope.row.date }}</span>
                </template>
            </el-table-column>
            <el-table-column  label="设备状态" width="240" align="center">
                <template slot-scope="scope">
                    <div v-for="(address,foryue) in scope.row.address" :key="foryue" class="s-b-dot">
                        {{address.aoored }}
                    </div>
                </template>
            </el-table-column>
            <el-table-column label="操作" width="197" align="center">
                <template slot-scope="scope">
                    <router-link  :to="{path:'/coupon'}"><span class="c-k-cupon">查看我的设备</span></router-link>
                </template>
            </el-table-column>
        </el-table>
    </el-row>

</template>

<script>
    export default {
        data() {
            return {
                tableData: [{
                    date: '2016-05-02',
                    name: '限1个配件已经超出使用期限超出使用期限',
                    address: [
                        {
                            aoored:'1更换配件',
                        },
                        {
                            aoored:'2更换配件',
                        },
                        {
                            aoored:'2更换配件',
                        },
                    ],
                    url:'https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg'
                }, {
                    date: '2016-05-04',
                    name: '1个配件已经超出使用期限',
                    address:[
                        {
                            aoored:'无需更换配件',
                        },
                    ],
                    url:'https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg'
                }, {
                    date: '2016-05-01',
                    name: '1个配件已经超出使用期限1个配件已经超出使用期限',
                    address: [
                        {
                            aoored:'两个配件即将需要更换',
                        },
                        {
                            aoored:'1个配件已经超出使用期限',
                        },
                    ],
                    url:'https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg'
                }, {
                    date: '2016-05-03',
                    name: '王小虎王小虎王小虎王小虎王小虎',
                    address:[
                        {
                            aoored:'1更换配件',
                        },
                        {
                            aoored:'2更换配件',
                        },
                    ],
                    url:'https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg'
                }]
            }
        },
        methods: {

        }
    }
</script>

<style scoped>
    .s-b-dot{
        margin-left: 10px;
        font-size: 14px;
        color: #797979;
    }
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
    }
    .n-name{
        font-size: 16px;margin-left: 10px;position: absolute;top: 50%;transform: translateY(-50%);    width: 182px;
        left: 33%;color: #797979;
    }
    img{
        width: 100px;
        height: 100px;
        float: left;
    }
    .c-k-cupon{
        font-size: 14px;font-weight: normal;color: #666666;
    }
    .c-k-cupon:hover{text-decoration:underline;color: #C20C0C;font-size: 14px;font-weight: normal;}
</style>
<style lang="less" scoped>
    .el-table__header-wrapper .el-table__header .has-gutter {
    /deep/.el-table th{
        background:red!important;
    }
    }
</style>
