<template>
    <el-row>
        <el-row>
            <span class="text-more">我的订单</span>

            <el-row style="padding: 68px 0 6px;color:#666666;">
                <el-tabs type="border-card" @tab-click="handleClick">
                    <el-tab-pane>
                        <span slot="label"><i class="el-icon-date"></i> 全部订单</span>
                        <div class="grid-content bg-purple-dark">
                            <div style="width: 14%;font-size: 14px">商品信息</div>
                            <div style="width: 30%;font-size: 14px;padding-left: 100px">单价</div>
                            <div style="width: 12%;font-size: 14px">数量</div>
                            <div style="width: 14%;font-size: 14px">实付款</div>
                            <div style="width: 14%;font-size: 14px">交易状态</div>
                            <div style="width: 12%;font-size: 14px">交易操作</div>
                        </div>
                        <el-col>
                            <div class="box"  v-for="(ietm, index) in details" :key="index">
                                <div class="column">
                                    <span style="padding:0 30px">{{ietm.date}}</span>
                                    <span style="padding:0 30px">订单编号：{{ietm.orderNo}}</span>
                                    <span style="padding:0 0 0 300px;font-size: 14px;color: red">{{ietm.orderNo}}</span>
                                </div>
                                <div class="box-on">
                                    <div class="box-spin"  v-for="(shop, foryue) in ietm.goodsList" :key="foryue">
                                        <img style="width: 120px;height: 120px;padding: 2px 2px" :src="shop.img">
                                        <span style="width: 160px">{{shop.model}}{{shop.name}}</span>
                                        <span style="left:56%;">{{shop.price}}</span>
                                        <span style="left:84%;">{{shop.num}}</span>
                                    </div>
                                    <div class="box-czuo">
                                        <span style="color: red">￥{{ietm.totalMoney}}</span>
                                        <span style="left: 80%" v-for="(Transaction, peed) in ietm.goodsList" :key="peed">
                                    <div style="margin: 4px 0">{{Transaction.totalMoney}}</div>
                                     <router-link  :to="{path:'/details'}">
                                         <div style="margin: 4px 0;color: #666666" >订单详情</div>
                                     </router-link>
                                    <div style="margin: 4px 0" v-if="type === '2'">物流信息</div>
                                    <div style="margin: 4px 0" v-if="type === '2'">申请售后</div>
                                </span>
                                        <span style="left: 93%;cursor: pointer;width: 66px;">交易操作</span>
                                    </div>
                                </div>
                            </div>
                        </el-col>
                    </el-tab-pane>
                    <el-tab-pane>
                        <span slot="label"><i class="el-icon-date"></i>待付款</span>
                        <div class="grid-content bg-purple-dark">
                            <div style="width: 14%;font-size: 14px">商品信息</div>
                            <div style="width: 30%;font-size: 14px;padding-left: 100px">单价</div>
                            <div style="width: 12%;font-size: 14px">数量</div>
                            <div style="width: 14%;font-size: 14px">实付款</div>
                            <div style="width: 14%;font-size: 14px">交易状态</div>
                            <div style="width: 12%;font-size: 14px">交易操作</div>
                        </div>
                        <el-col>
                            <div class="box"  v-for="(ietm, index) in details" :key="index">
                                <div class="column">
                                    <span style="padding:0 30px">{{ietm.date}}</span>
                                    <span style="padding:0 30px">订单编号：{{ietm.orderNo}}</span>
                                    <span style="padding:0 0 0 300px;font-size: 14px;color: red">{{ietm.Transtate}}</span>
                                </div>
                                <div class="box-on">
                                    <div class="box-spin"  v-for="(shop, foryue) in ietm.goodsList" :key="foryue">
                                        <img style="width: 120px;height: 120px;padding: 2px 2px" :src="shop.img">
                                        <span style="width: 160px">{{shop.model}}{{shop.name}}</span>
                                        <span style="left:56%;">{{shop.price}}</span>
                                        <span style="left:84%;">{{shop.num}}</span>
                                    </div>
                                    <div class="box-czuo">
                                        <span style="color: red">￥{{ietm.totalMoney}}</span>
                                        <span style="left: 80%" v-for="(Transaction, peed) in ietm.goodsList" :key="peed">
                                    <div style="margin: 4px 0">{{Transaction.totalMoney}}</div>
                                     <router-link  :to="{path:'/details'}">
                                         <div style="margin: 4px 0;color: #666666" >订单详情</div>
                                     </router-link>
                                    <div style="margin: 4px 0" v-if="type === '2'">物流信息</div>
                                    <div style="margin: 4px 0" v-if="type === '2'">申请售后</div>
                                </span>
                                        <span style="left: 93%;cursor: pointer;width: 66px;">交易操作</span>
                                    </div>
                                </div>
                            </div>
                        </el-col>
                    </el-tab-pane>
                    <el-tab-pane>
                        <span slot="label"><i class="el-icon-date"></i>待发货</span>
                        <div class="grid-content bg-purple-dark">
                            <div style="width: 14%;font-size: 14px">商品信息</div>
                            <div style="width: 30%;font-size: 14px;padding-left: 100px">单价</div>
                            <div style="width: 12%;font-size: 14px">数量</div>
                            <div style="width: 14%;font-size: 14px">实付款</div>
                            <div style="width: 14%;font-size: 14px">交易状态</div>
                            <div style="width: 12%;font-size: 14px">交易操作</div>
                        </div>
                        <el-col>
                            <div class="box"  v-for="(ietm, index) in details" :key="index">
                                <div class="column">
                                    <span style="padding:0 30px">{{ietm.date}}</span>
                                    <span style="padding:0 30px">订单编号：{{ietm.orderNo}}</span>
                                    <span style="padding:0 0 0 300px;font-size: 14px;color: red">{{ietm.Transtate}}</span>
                                </div>
                                <div class="box-on">
                                    <div class="box-spin"  v-for="(shop, foryue) in ietm.goodsList" :key="foryue">
                                        <img style="width: 120px;height: 120px;padding: 2px 2px" :src="shop.img">
                                        <span style="width: 160px">{{shop.model}}{{shop.name}}</span>
                                        <span style="left:56%;">{{shop.price}}</span>
                                        <span style="left:84%;">{{shop.num}}</span>
                                    </div>
                                    <div class="box-czuo">
                                        <span style="color: red">￥{{ietm.totalMoney}}</span>
                                        <span style="left: 80%" v-for="(Transaction, peed) in ietm.goodsList" :key="peed">
                                    <div style="margin: 4px 0">{{Transaction.totalMoney}}</div>
                                     <router-link  :to="{path:'/details'}">
                                         <div style="margin: 4px 0;color: #666666" >订单详情</div>
                                     </router-link>
                                    <div style="margin: 4px 0" v-if="type === '2'">物流信息</div>
                                    <div style="margin: 4px 0" v-if="type === '2'">申请售后</div>
                                </span>
                                        <span style="left: 93%;cursor: pointer;width: 66px;">交易操作</span>
                                    </div>
                                </div>
                            </div>
                        </el-col>
                    </el-tab-pane>
                    <el-tab-pane>
                        <span slot="label"><i class="el-icon-date"></i>待收货</span>
                        <div class="grid-content bg-purple-dark">
                            <div style="width: 14%;font-size: 14px">商品信息</div>
                            <div style="width: 30%;font-size: 14px;padding-left: 100px">单价</div>
                            <div style="width: 12%;font-size: 14px">数量</div>
                            <div style="width: 14%;font-size: 14px">实付款</div>
                            <div style="width: 14%;font-size: 14px">交易状态</div>
                            <div style="width: 12%;font-size: 14px">交易操作</div>
                        </div>
                        <el-col>
                            <div class="box"  v-for="(ietm, index) in details" :key="index">
                                <div class="column">
                                    <span style="padding:0 30px">{{ietm.date}}</span>
                                    <span style="padding:0 30px">订单编号：{{ietm.orderNo}}</span>
                                    <span style="padding:0 0 0 300px;font-size: 14px;color: red">{{ietm.Transtate}}</span>
                                </div>
                                <div class="box-on">
                                    <div class="box-spin"  v-for="(shop, foryue) in ietm.goodsList" :key="foryue">
                                        <img style="width: 120px;height: 120px;padding: 2px 2px" :src="shop.img">
                                        <span style="width: 160px">{{shop.model}}{{shop.name}}</span>
                                        <span style="left:56%;">{{shop.price}}</span>
                                        <span style="left:84%;">{{shop.num}}</span>
                                    </div>
                                    <div class="box-czuo">
                                        <span style="color: red">￥{{ietm.totalMoney}}</span>
                                        <span style="left: 80%" v-for="(Transaction, peed) in ietm.goodsList" :key="peed">
                                    <div style="margin: 4px 0">{{Transaction.totalMoney}}</div>
                                     <router-link  :to="{path:'/details'}">
                                         <div style="margin: 4px 0;color: #666666" >订单详情</div>
                                     </router-link>
                                    <div style="margin: 4px 0" v-if="type === '2'">物流信息</div>
                                    <div style="margin: 4px 0" v-if="type === '2'">申请售后</div>
                                </span>
                                        <span style="left: 93%;cursor: pointer;width: 66px;">交易操作</span>
                                    </div>
                                </div>
                            </div>
                        </el-col>
                    </el-tab-pane>
                    <el-tab-pane>
                        <span slot="label"><i class="el-icon-date"></i>退款</span>
                    </el-tab-pane>
                </el-tabs>
            </el-row>


        </el-row>


    </el-row>
</template>

<script>
    export default {
        data() {
            return {
                type:'2',
                show:true,
                details:[],
            }
        },
        created(){
            this.function();
        },
        methods: {
            handleClick() {
                console.log();
                // console.log(11111)
            },
            function(){
                Sun.post({
                    url: Http.getOrderList,
                    data:{
                        current:'',
                        size:'',
                        type:'1',
                    },
                    success: (data) => {
                        console.log(data)
                        this.details= data.records;
                        // console.log(this.details)
                        // this.details.commodity=data.records.goodsList
                        // console.log(Sun.user)
                    },
                    fail: (data) => {

                    }

                });
            },

        }
    }
</script>

<style scoped>
    .text-more{
        border-bottom: 2px solid red;
        font-family: MicrosoftYaHei;
        font-size: 20px;
        font-weight: bold;
        font-stretch: normal;
        color: #545454;
        position: relative;
        top: 24px;
        margin-left: 24px;
    }

    .box{
        width: auto;
        /*border: 1px solid#eee;*/
        box-sizing: border-box;
        padding: 20px 0 20px;
        color: #666666;

    }
    .box-on{
        width:99.68%;height: 100%;
        overflow: hidden;
        border: 1px solid#eee;
        box-sizing: border-box;
        position: relative;
    }
    .box-spin{
        float: left;
        width: 540px;
        height: 125px;
        position: relative;
        border: 1px solid#eee;
        box-sizing: border-box
    }
    .box-spin span{
        position:absolute;
        top:50%;
        transform: translateY(-50%)
    }
    .box-czuo{
        float: right;
        width: 379px;
        height:100%;
    }
    .box-czuo span{
        position: absolute;
        top: 50%;
        left: 65%;
        transform: translate(-50%,-50%);

    }

    .box-yuan{
        display:inline-block;
        width: 41px;
        height:41px;
        border:1px solid#e1e1e1;
        background:#e1e1e1;
        border-radius: 50%;
        position: relative;
    }
    .box-nav{
        color: #fff;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%)
    }
    .box-der{
        position: absolute;border: 1px solid#dddddd;padding: 0 66px 0;top: 18%;
    }
    .column{
        width: auto;
        height: 32px;
        line-height: 32px;
        background-color: #eeeeee;
    }



    .bg-purple-banner{
        background: #fff;
        border: 1px solid#eee;
        box-sizing: border-box;
    }
    .bg-purple-dark {
        background: #fff;
        border: 1px solid#eee;
        box-sizing: border-box;
        margin-top: 10px;
    }
    .grid{
        height: 54px;
        line-height: 54px;
        padding-left: 20px;
    }
    .grid-content {
        /*border-radius: 4px;*/
        width: auto;
        height: 50px;
        line-height: 50px;
        background:#e0e0e0;

    }
    .grid-content div{
        display: inline-block;
        font-size: 0;
        /*border: 1px solid#eee;*/
        box-sizing: border-box;
        text-align: center;
    }

</style>
