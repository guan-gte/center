<template>
    <el-row>
        <el-row>
            <span class="text-more">我的订单</span>
            <el-breadcrumb separator-class="el-icon-arrow-right" style="padding: 16px 124px;position: relative;bottom: 10px">
            <el-breadcrumb-item :to="{ path: '/Center' }"><span style="color: #a5a5a5">我的订单</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5;">全部订单</span></el-breadcrumb-item>
            <el-breadcrumb-item><span style="color: #a5a5a5">订单详情</span></el-breadcrumb-item>
            </el-breadcrumb>
            <!--finish-status="error"-->
            <el-steps :active="2" align-center process-status="wait" style="margin-top:56px ">
            <el-step title="拍下商品" description="2019-06-20 18:06:26"></el-step>
            <el-step title="支付到平台" description="2019-06-20 18:06:26"></el-step>
            <el-step title="卖家发货" description="2019-06-20 18:06:26"></el-step>
            <el-step title="确认收货" description="2019-06-20 18:06:26"></el-step>
            </el-steps>
            <!--<div style="position: relative;margin-left: 182px;padding: 0 0 80px">-->
            <!--<div class="box-yuan">-->
            <!--<span class="box-nav">1</span>-->
            <!--</div>-->
            <!--<span class="box-der" style="left: 6%"></span>-->
            <!--<span style="position: absolute;top:60px;left: -10px">拍下商品</span>-->
            <!--<span style="position: absolute;top:100px;left: -18px">2019-06-20</span>-->
            <!--<span style="position: absolute;top:120px;left: -12px">18:06:26</span>-->

            <!--<div class="box-yuan" style="left: 18%">-->
            <!--<span class="box-nav">2</span>-->
            <!--</div>-->
            <!--<span class="box-der" style="left: 30.5%"></span>-->
            <!--<span style="position: absolute;top:60px;left:160px">支付到平台</span>-->
            <!--<span style="position: absolute;top:100px;left:160px">2019-06-20</span>-->
            <!--<span style="position: absolute;top:120px;left: 166px">18:06:26</span>-->

            <!--<div class="box-yuan" style="left: 36%">-->
            <!--<span class="box-nav">3</span>-->
            <!--</div>-->
            <!--<span class="box-der" style="left: 55%"></span>-->
            <!--<div class="box-yuan" style="left: 54%">-->
            <!--<span class="box-nav">4</span>-->
            <!--</div>-->

            <!--</div>-->

            <el-row style="padding: 36px 0 2px">
                <el-col :span="24">
                    <div class="grid-cont bg-pur-dark">
                        <div style="width: 30%;font-size: 14px;margin-left: 20px">订单信息</div>
                    </div>
                </el-col>
                <div style="overflow: hidden;width: 924px;height: 250px;border:1px solid#eee;box-sizing: border-box">
                    <div style="float: left;width: 50%;height: 100%;border-right: 1px solid#eee;box-sizing: border-box">
                        <!--<el-form ref="form" :model="form" label-width="80px">-->
                            <!--<el-form-item label="收货地址:" style="padding: 30px 0 90px 62px; ">-->
                                <!--<span style="width: 214px;font-size: 18px">{{form.name}}</span>-->
                            <!--</el-form-item>-->
                            <!--<el-form-item label="备注信息:" style="padding: 0 62px; ">-->
                                <!--<span style="font-size: 18px">{{form.mapzi}}</span>-->
                            <!--</el-form-item>-->
                        <!--</el-form>-->
                        <div style="color: #636363;font-size: 18px;">
                            <div style="position: absolute;top:36%;left: 10%;">
                                收货地址:
                            <div style="width: 214px;position: absolute;left:86px;top: 0;">{{form.name}}</div>
                            </div>
                            <div style="position: absolute;top:77%;left: 10%;">
                                备注信息:
                                <div style="width: 214px;position: absolute;left:86px;top: 0;">{{form.mapzi}}</div>
                            </div>
                        </div>
                    </div>
                    <div style="float: right;width: 50%;height: 100%">
                        <div style="color: #636363">
                            <div style="font-size: 18px;position: absolute;top:40.6%;left: 60%;">
                                订单状态:
                                <div style="width: 214px;position: absolute;left:86px;top: 0;">{{form.state}}</div>
                            </div>
                            <div style="font-size: 18px;position: absolute;top:58%;left: 60%;">
                                物流:
                                <div style="width: 214px;position: absolute;left:86px;top: 0;">{{form.logistics}}</div>
                            </div>
                            <div style="font-size: 18px;position: absolute;top:68%;left: 60%">
                                运单号:
                                <div style="width: 214px;position: absolute;left:86px;top: 2px;">{{form.FreightBillNo}}</div>
                            </div>
                            <div style="font-size: 18px;position: absolute;top:78%;left: 60%">
                                订单编号:
                                <div style="width: 214px;position: absolute;left:86px;top: 2px;">{{form.OrderNumber}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </el-row>


            <el-row style="padding: 36px 0 2px">
                <el-col :span="24">
                    <div class="grid-content bg-purple-dark">
                        <div style="width: 30%;font-size: 14px">商品名称</div>
                        <div style="width: 15%;font-size: 14px;padding-left: 100px">单价</div>
                        <div style="width: 30%;font-size: 14px">数量</div>
                        <div style="width: 20%;font-size: 14px">交易状态</div>
                    </div>
                </el-col>
            </el-row>

            <el-row>
                <el-col>
                    <div class="box">
                        <div class="box-on">
                            <div class="box-spin" v-for="(ietm, index) in details" :key="index">
                                <img style="width: 120px;height: 120px" src="https://images-cn.ssl-images-amazon.com/images/I/71k%2BuD3Ku6L._AA200_.jpg" >
                                <span style="width: 160px;font-size: 16px;">{{ietm.name}}</span>
                                <span style="left:54%;">{{ietm.Deweyvisitors}}</span>
                                <span style="left:82%;">{{ietm.number}}</span>
                            </div>
                            <div class="box-czuo">
                                <span style="left: 88%">{{state}}</span>
                            </div>
                        </div>
                    </div>
                </el-col>
            </el-row>

        </el-row>


    </el-row>
</template>

<script>
    export default {
        data() {
            return {
                state:'1已完成',
                form:{
                    name:'王竹, 18297938805,\n' +
                        '上海 上海市 嘉定区 江桥镇 \n' +
                        '上海嘉定区江桥万达广场9\n' +
                        '号楼0817 ',
                    mapzi:'请确认好产品的配件完整',
                    state:'卖家发货',
                    logistics:'中通快递',
                    FreightBillNo:'77493296377493296',
                    OrderNumber:'15613284546568896'

                },
                details: [
                    { name:'德威来客德威来客德威来客DW520',
                    Deweyvisitors:'￥29980',
                    number:'1',
                    },
                    { name:'德威来客德威来客德威来客DW520',
                        Deweyvisitors:'￥29980',
                        number:'1',
                    },
        ]

            }

        },
        created(){
            this.function();
        },
        methods: {
            function(){
                Sun.post({
                    url: Http.getOrderList,
                    data: {
                    },
                    success: (data) => {
                        Sun.setLogin(data);
                        console.log(data)
                        // this.sizeForm= data;
                        // Sun.isLogin = true;

                    },
                    fail: (data) => {

                    }
                });
            }
        }
    }
</script>

<style scoped>
    .text-more{
        border-bottom: 2px solid red;
        font-family: MicrosoftYaHei;
        font-size: 20px;
        font-weight: bold;
        font-stretch: normal;
        color: #545454;
        position: relative;
        top: 24px;
        margin-left: 24px;
    }

    .box{
        width: 100%;
        /*border: 1px solid#eee;*/
        box-sizing: border-box;
        font-size: 16px;
        color: #666666;
    }

    .box-on{
        width:100%;height: 100%;
        overflow: hidden;
        border: 1px solid#eee;
        box-sizing: border-box;
        position: relative;
    }
    .box-spin{
        float: left;
        width: 680px;
        height: 125px;
        position: relative;
        border: 1px solid#eee;
        box-sizing: border-box;
    }
    .box-spin span{
        position:absolute;
        top:50%;
        transform: translateY(-50%)
    }
    .box-czuo{
        float: right;
        /*width: 379px;*/
        height:100%;
    }
    .box-czuo span{
        position: absolute;
        top: 50%;
        left: 65%;
        transform: translate(-50%,-50%);

    }

    .box-yuan{
        display:inline-block;
        width: 41px;
        height:41px;
        border:1px solid#e1e1e1;
        background:#e1e1e1;
        border-radius: 50%;
        position: relative;
    }
    .box-nav{
        color: #fff;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%)
    }
    .box-der{
        position: absolute;border: 1px solid#dddddd;padding: 0 66px 0;top: 18%;
    }
    .column{
        width: 924px;
        height: 32px;
        line-height: 32px;
        background-color: #eeeeee;
    }



    .bg-purple-banner{
        background: #fff;
        border: 1px solid#eee;
        box-sizing: border-box;
    }
    .bg-purple-dark {
        background: #fff;
        border: 1px solid#eee;
        box-sizing: border-box;
        margin-top: 10px;
    }
    .bg-pur-dark{
        background: #fff;
        border: 1px solid#eee;
        box-sizing: border-box;
        margin-top: 10px;

    }
    .grid{
        height: 54px;
        line-height: 54px;
        padding-left: 20px;
    }
    .grid-content {
        /*border-radius: 4px;*/
        width: 924px;
        height: 32px;
        line-height: 32px;
        background:#e0e0e0;

    }
    .grid-cont{
        width: 924px;
        height: 32px;
        line-height: 32px;
        background:#e0e0e0;
    }
    .grid-content div{
        display: inline-block;
        font-size: 0;
        /*border: 1px solid#eee;*/
        box-sizing: border-box;
        text-align: center;
    }

</style>
