<template>
    <el-row>
        <el-col :span="4">
            <div class="grid bg-purple-banner">
                <span style="border-bottom: 2px solid red;font-size: 20px;font-weight: 400">我的收藏</span>
            </div>
        </el-col>

        <el-col :span="24">
            <el-tabs v-model="activeName" >
                <el-tab-pane label="全部商品" name="first">
                    <el-row :gutter="20">
                        <el-col :span="6" v-for="(item, index) in tootd" :key="index">
                            <div class="grid-conn bg-purple">
                                <label style="position: absolute;font-size: 22px;"><i class="el-icon-lx-delete"></i></label>
                                <img class="log2" :src="item.img" alt="">
                                <div class="name-set">{{item.name}}{{item.model}}</div>
                                <div class="Price-set"><span>￥</span>{{item.price}}</div>
                            </div>
                        </el-col>
                    </el-row>
                </el-tab-pane>
                <el-tab-pane label="降价（2）" name="second">
                    <el-row :gutter="20">
                        <el-col :span="6" v-for="(item, index) in pubb" :key="index">
                            <el-popover
                                placement="top-start"
                                title="标题"
                                width="200"
                                trigger="hover"
                                content="这是一段内容,这是一段内容,这是一段内容,这是一段内容。">
                                <el-button slot="reference">
                                    <div class="grid-conn bg-purple">
                                        <img class="log2" :src="logo" alt="">
                                        <div class="name-set">{{item.name}}{{item.Model}}</div>
                                        <div class="Price-set">{{item.Price}}</div>
                                    </div>
                                </el-button>
                            </el-popover>
                        </el-col>
                    </el-row>
                </el-tab-pane>
                <el-tab-pane label="失效（1）" name="third">
                    <el-row :gutter="20">
                        <el-col :span="6" v-for="(item, index) in pebb" :key="index">
                            <div class="grid-conn bg-purple">
                                <img class="log2" :src="logo" alt="">
                                <div class="name-set">{{item.name}}{{item.Model}}</div>
                                <div class="Price-set">{{item.price}}</div>
                            </div>
                        </el-col>
                    </el-row>
                </el-tab-pane>
            </el-tabs>
        </el-col>

        <el-col :span="24" style="position: fixed;bottom: 100px;transform: translateX(10%)">
            <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="100"
                layout="total, sizes, prev, pager, next, jumper"
                background
                :total="1">
            </el-pagination>
        </el-col>
    </el-row>

</template>

<script>
    export default {
        name: 'name',
        data() {
            return {
                visible: false,
                activeName:'first',
                currentPage: 4,
                tootd:[ ],
                pubb:[ ],
                pebb:[ ]
            }
        },
        created(){
            this.function();
            // this.test ()
            // this.$nextTick(() => { this.getlocal()})
        },
        methods: {
            handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
            },
            function(){
                Sun.post({
                    url: Http.getCollectGoodsList,
                    data:{
                        img:'',
                        model:'',
                        name:'',
                        price:'',
                    },
                    success: (data) => {
                        console.log(data)
                        this.tootd= data.records;
                        // this.url=data.headPic;
                        // Sun.isLogin = true;
                        // console.log(Sun.user)
                    },
                    fail: (data) => {

                    }

                });
            },

        }
    }
</script>

<style scoped>
    .el-col-6{
        padding: 0!important;
        width: 24%!important;
    }
    .grid{
        height: 58px;
        line-height: 58px;
        padding-left: 20px;
        color: #545454;
        font-weight: normal;

    }
    .grid-conn{
        width: 202px;
        height: 320px;
        margin-left: 26px;
        cursor: pointer;
    }
    .log2{
        width: 202px;
        height: 202px;
    }
    .name-set{
        width: 153px;
        height: 33px;
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 18px;
        letter-spacing: -1px;
        color: #7d7c7d;
        padding: 5px 0 0 10px;
    }
    .Price-set{
        width: 86px;
        font-family: MicrosoftYaHei;
        font-size: 18px;
        font-weight: bold;
        font-stretch: normal;
        line-height: 36px;
        letter-spacing: -1px;
        color: #ff0000;
        padding: 0 0 0 10px;
    }

    /*.grid-conn img:hover{*/
        /*!*display: none;*!*/
        /*background-image: url("//icweiliimg9.pstatp.com/weili/l/621444685046087739.jpg");*/
        /*z-index: 222;*/
    /*}*/
</style>
