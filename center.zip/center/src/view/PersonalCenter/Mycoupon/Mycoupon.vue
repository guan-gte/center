<template>
    <el-row>
        <span class="text-more">个人中心</span>
    <el-breadcrumb separator-class="el-icon-arrow-right" style="padding: 16px 94px;position: relative;bottom: 10px">
        <el-breadcrumb-item :to="{ path: '/Center' }"><span style="color: #a5a5a5;font-weight: 400">个人中心</span></el-breadcrumb-item>
        <el-breadcrumb-item><span style="color: #a5a5a5">更多会员信息</span></el-breadcrumb-item>
    </el-breadcrumb>

    <el-table :data="tableData" border style="width: 100%;">
        <el-table-column label="序号" width="174" align="center" >
            <template slot-scope="scope">
                <span style="margin-left: 10px;color: #666666">{{ scope.row.number }}</span>
            </template>
        </el-table-column>
        <el-table-column label="金额" width="180" align="center">
            <template slot-scope="scope">
                        <span size="medium" style="color: #666666;font-size: 16px">{{ scope.row.money }}</span>
            </template>
        </el-table-column>
        <el-table-column label="级别" width="210" align="center">
            <template slot-scope="scope">
                <el-rate v-model="scope.row.value" disabled style="display: inline-block;" :colors="['#ff0000', '#ff0000', '#ff0000']"></el-rate>
                <div style="color:#ff0000;font-size:16px ">{{scope.row.level}}</div>
            </template>
        </el-table-column>
        <el-table-column label="享受福利" width="357" align="center">
            <template slot-scope="scope">
                <div style="margin-left: 10px;text-align: left;color: #666666;font-size: 16px" v-for="(welfare,foryoue) in scope.row.welfare" :key="foryoue">
                    {{ welfare.new}}
                </div>
            </template>
        </el-table-column>
    </el-table>

        <div style="padding: 8px 20px 30px">
            <span class="beizhu">备注：</span>
            <div class="box-twen">
                <span class="tit-on">每个星级的待遇，仅限于该订单的产品</span>
                <span class="tit-tw">（例如：第一次消费商品A，金额5万元，享受一星级福利。 第二次
             消费商品B,金额3万元，享受二星级福利，但是第一次消费商品A仍享受一星级福利）</span>
                <span class="tit-su">（活动机型，不享受会员优惠）</span>
            </div>
        </div>
        <div class="box-on" id="first">
            <div class="title-lipo">梁玉玺节礼品</div>
            <div class="title-nlipi" v-for="(gift,fitur) in gift" :key="fitur">{{gift.gifts}}</div>
        </div>

    </el-row>
</template>

<script>
    export default {
        data() {
            return {
                tableData: [
                    {
                    number: '1',
                    money: '5万元以内',
                    value: 1,
                    welfare: [{
                        new: '原价采购'
                    }]
                },
                    {
                    number: '2',
                    money: '5万元-10万元',
                    value: 2,
                    welfare: [
                        {new: '1."梁玉玺节" 根据星级快递会员礼品'},
                        {
                            new: ' 2.享有98折优惠'
                        }
                    ]
                },
                    {
                    number: '3',
                    money: '10万元-20万元',
                    value: 3,
                    welfare: [
                        {new: '1."梁玉玺节" 根据星级快递会员礼品'},
                        {new: '2.不计免赔（300元以内）'},
                        {new: '3.绿色通道：3000元以内先更换再收费'},
                        {new: '4.本市上门时效24小时'},
                        {new: '5.享有95折优惠'},
                    ]
                },
                    {
                        number: '4',
                        money: '20万元-50万元',
                        value: 4,
                        welfare: [
                            {new: '1."梁玉玺节" 根据星级快递会员礼品'},
                            {new: '2.不计免赔（300元以内）'},
                            {new: '3.绿色通道：3000元以内先更换再收费'},
                            {new: '4.本市上门时效18小时'},
                            {new: '5.延保3个月'},
                            {new: '6.享有92折优惠'},
                        ]
                    },
                    {
                        number: '5',
                        money: '50万元-80万元',
                        value: 5,
                        welfare: [
                            {new: '1."梁玉玺节" 根据星级快递会员礼品'},
                            {new: '2.不计免赔（300元以内）'},
                            {new: '3.绿色通道：3000元以内先更换再收费'},
                            {new: '4.本市上门时效12小时'},
                            {new: '5.延保6个月'},
                            {new: '6.顶机服务'},
                            {new: '7.享有9折优惠'},
                        ]
                    },
                    {
                        number: '6',
                        money: '80万元以上  ',
                        value: 5,
                        level:'Plus',
                        welfare: [
                            {new: '1."梁玉玺节" 根据星级快递会员礼品'},
                            {new: '2.不计免赔（300元以内）'},
                            {new: '3.绿色通道：3000元以内先更换再收费'},
                            {new: '4.过保后免上门费'},
                            {new: '5.本市上门时效6小时'},
                            {new: '6.免费顶机'},
                            {new: '7.延保12个月'},
                            {new: '8.享有88折优惠'},
                        ]
                    }

                ],
                gift:[
                    {gifts:'LYX饮用水（1箱）,'},
                    {gifts:'LYX毛巾（10条）,'},
                    {gifts:'LYX白酒（5瓶）,'},
                    {gifts:'LYX打火机（1套 ）,'},
                    {gifts:'LYX烟灰缸（1个）,'},
                    {gifts:'LYX喷香机（1个）,'},
                    {gifts:'LYX饮抽纸盒（1套）,'},
                    {gifts:'吸尘器（1个）,'},
                    {gifts:'蒸汽机（1个）,'},
                    {gifts:'扫地机器人（1个）,'},
                ]
                    }
                 },
        created(){
            this.$nextTick(() => { this.getlocal()})
        },
        mounted(){
            this.$nextTick(function () {
                window.addEventListener('scroll',this.handleScroll)

            })
        },
        methods: {
            getlocal(){
                // Sun.readData('flistt');K V
                let  select = localStorage.getItem("first");
                let  anchorElement = document.getElementById(select);
                if(select){
                    anchorElement.scrollIntoView();
                }
            }
        }
                     }

</script>

<style scoped>
    .text-more{
        border-bottom: 2px solid red;
        font-family: MicrosoftYaHei;
        font-size: 20px;
        font-weight: bold;
        font-stretch: normal;
        color: #545454;
        position: relative;
        top: 20px;
    }
    .box-on{
        border: 1px solid#6A6A6A
    }
    .title-lipo{
        padding: 16px 0 14px 30px;
        font-size: 22px;
        color: #ff0000;
        font-family: MicrosoftYaHei;
        font-weight: normal;
        font-style: italic;
        font-stretch: normal;
        letter-spacing: 0;

    }
    .title-nlipi{
        font-family: MicrosoftYaHei;
        font-size: 16px;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0;
        color: #ff0000;
        line-height: 10px;
        display: inline-block;
        padding: 1px 10px 22px 30px;
    }
    .beizhu{
        font-size: 18px;
        line-height: 30px;
        color: #7d7d7d
    }
    .box-twen{
        margin-left: 48px;
        position: relative;
        bottom: 30px;
        line-height: 30px;
    }
    .tit-on{
        font-size: 16px;
        color: #292929
    }
    .tit-tw{
        font-size: 15px;
        color: #666666
    }

    .tit-su{
        width: 164px;
        height: 15px;
        font-family: MicrosoftYaHei;
        font-size: 14px;
        font-weight: normal;
        font-stretch: normal;
        line-height: 30px;
        letter-spacing: 0;
        color: #565656;
    }
</style>
