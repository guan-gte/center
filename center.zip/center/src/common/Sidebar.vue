<template>
    <div class="sidebar">
        <el-menu class="sidebar-el-menu" :default-active="onRoutes" :collapse="collapse" background-color="#fff"
            text-color="#bfcbd9" active-text-color="#20a0ff" unique-opened router>
            <template v-for="item in menuList">
                <template v-if="item.childlist.length">
                    <el-submenu :index="item.path ? item.path : Math.random() + ''" :key="item.path ? item.path : Math.random()">
                        <template slot="title">
                            <i :class="item.icon"></i><span slot="title">{{ item.name }}</span>
                        </template>
                        <template v-for="subItem in item.childlist">
                            <el-submenu v-if="subItem.childlist.length" :index="subItem.path ? subItem.path : Math.random() + ''" :key="subItem.path ? subItem.path : Math.random()">
                                <template slot="title">{{ subItem.name }}</template>
                                <el-menu-item v-for="(threeItem,i) in subItem.childlist" :key="i" :index="threeItem.path ? threeItem.path : Math.random() + ''">
                                    {{ threeItem.name }}
                                </el-menu-item>
                            </el-submenu>
                            <el-menu-item v-else :index="subItem.path ? subItem.path : Math.random() + ''" :key="subItem.path ? subItem.path : Math.random()">
                                {{ subItem.name }}
                            </el-menu-item>
                        </template>
                    </el-submenu>
                </template>
                <template v-else>
                    <el-menu-item :index="item.path ? item.path : Math.random() + ''" :key="item.path">
                        <i :class="item.icon" style="color: red"></i>
                        <span slot="title">{{ item.name }}</span>
                    </el-menu-item>
                </template>
            </template>
        </el-menu>
    </div>
</template>

<script>
    import bus from '../common/bus';
    export default {
        data() {
            return {
                collapse: false,
                menuList: [
                    /*********************  Master  **********************************/
                    {
                        icon: 'el-icon-lx-home',
                        path: '/Center',
                        name: '个人中心',
                        childlist:[]
                    },
                    {
                        icon: 'el-icon-lx-recharge',
                        path: 'order',
                        name: '我的订单',
                        childlist:[
                            // {
                            //     path: 'order',
                            //     name: '全部订单',
                            //     childlist:[],
                            // },
                            // {
                            //     path: 'behalf',
                            //     name: '待付款(3)',
                            //     childlist:[],
                            // },
                            // {
                            //     path: 'shipped',
                            //     name: '待发货(1)',
                            //     childlist:[],
                            // },
                            // {
                            //     path: 'received',
                            //     name: '待收货(3)',
                            //     childlist:[],
                            // },
                            // {
                            //     path: 'refund',
                            //     name: '退款',
                            //     childlist:[],
                            // }
                        ]
                    },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: 'cart',
                    //     name: '我的购物车',
                    //     childlist:[]
                    // },
                    {
                        icon: 'el-icon-lx-scan',
                        path: 'equipment',
                        name: '我的设备',
                        childlist:[
                            // {
                            //     path: 'equipment',
                            //     name: '查看我的设备',
                            //     childlist:[],
                            // },
                            // {
                            //     path: 'records',
                            //     name: '查看设备维护记录',
                            //     childlist:[],
                            // },
                            // {
                            //     path: 'Replacement',
                            //     name: '查看配件更换记录',
                            //     childlist:[],
                            // }
                        ]
                    },
                    {
                        icon: 'el-icon-lx-favor',
                        path: 'Collection',
                        name: '我的收藏',
                        childlist:[]
                    },
                    {
                        icon: 'el-icon-lx-like',
                        path: 'Tracks',
                        name: '我的足迹',
                        childlist:[]
                    },
                    {
                        icon: 'el-icon-lx-like',
                        path: 'invo',
                        name: '我的发票',
                        childlist:[]
                    },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: 'Ticke',
                    //     name: '我的优惠券',
                    //     childlist:[]
                    // },
                    {
                        icon: 'el-icon-lx-settings',
                        path: '',
                        name: '设置中心',
                        childlist:[
                            {
                                icon: 'el-icon-lx-home',
                                path: 'information',
                                name: '我的资料',
                                childlist:[]
                            },
                            {
                                icon: 'el-icon-lx-home',
                                path: 'Address',
                                name: '我的收货地址',
                                childlist:[]
                            },
                            // {
                            //     path: 'Qualifications',
                            //     name: '新增我的收货地址',
                            //     childlist:[]
                            // },
                            // {
                            //     path: 'editQualifications',
                            //     name: '编辑我的收货地址',
                            //     childlist:[]
                            // },
                            {
                                icon: 'el-icon-lx-home',
                                path: 'security',
                                name: '账户安全',
                                childlist:[]
                            },
                            {
                                icon: 'el-icon-lx-home',
                                path: 'Taqua',
                                name: '增票资质',
                                childlist:[]
                            },
                            {
                                icon: 'el-icon-lx-home',
                                path: 'Ticke',
                                name: '增票审核',
                                childlist:[]
                            },
                            // {
                            //     icon: 'el-icon-lx-home',
                            //     path: 'Ticke2',
                            //     name: '不通过',
                            //     childlist:[]
                            // },
                            // {
                            //     icon: 'el-icon-lx-home',
                            //     path: 'Ticke3',
                            //     name: '待审核',
                            //     childlist:[]
                            // },
                        ]
                    },
                    // {
                    //     icon: 'el-icon-lx-copy',
                    //     path: 'tabs',
                    //     name: 'tab选项卡',
                    //     childlist:[]
                    // },
                    // {
                    //     icon: 'el-icon-lx-calendar',
                    //     path: '3',
                    //     name: '表单相关',
                    //     childlist: [
                    //         {
                    //             path: 'form',
                    //             name: '基本表单',
                    //             childlist:[]
                    //         },
                    //         {
                    //             path: '3-2',
                    //             name: '三级菜单',
                    //             childlist: [
                    //                 {
                    //                     path: 'editor',
                    //                     name: '富文本编辑器',
                    //                     childlist:[]
                    //                 },
                    //                 {
                    //                     path: 'markdown',
                    //                     name: 'markdown编辑器',
                    //                     childlist:[]
                    //                 },
                    //             ]
                    //         },
                    //         {
                    //             path: 'upload',
                    //             name: '文件上传',
                    //             childlist:[]
                    //         }
                    //     ]
                    // },
                    {
                        icon: 'el-icon-lx-emoji',
                        path: 'icon',
                        name: '自定义图标',
                        childlist:[]
                    },
                    // {
                    //     icon: 'el-icon-lx-favor',
                    //     path: '/charts',
                    //     name: 'schart图表',
                    //     childlist:[]
                    // },
                    // {
                    //     icon: 'el-icon-rank',
                    //     path: 'drag',
                    //     name: '拖拽列表',
                    //     childlist:[]
                    // },
                    // {
                    //     icon: 'el-icon-lx-warn',
                    //     path: '6',
                    //     name: '错误处理',
                    //     childlist: [
                    //         {
                    //             path: 'permission',
                    //             name: '权限测试',
                    //             childlist:[]
                    //         },
                    //         {
                    //             path: '404',
                    //             name: '404页面',
                    //             childlist:[]
                    //         }
                    //     ]
                    // }
                ]
            }
        },
        computed:{
            onRoutes(){
                // return this.$route.path.replace('/','');
            }
        },
        created(){
            // 通过 Event Bus 进行组件间通信，来折叠侧边栏
            bus.$on('collapse', msg => {
                this.collapse = msg;
            });
            // Sun.post({
            //     url: Http.common.getMenu,
            //     loading: true,
            //     success: (data) => {
            //         this.menuList = data;
            //         this.menuList.unshift({
            //             icon: 'el-icon-lx-home',
            //             path: 'welcome',
            //             name: '欢迎!',
            //             childlist:[]
            //         });
            //     }
            // })
        }
    }
</script>

<style scoped>
    .sidebar{
        display: block;
        position: absolute;
        /*left: 363px;*/
        top: 0;
        bottom:0;
        overflow-y: scroll;
        /*width: 254px;*/
        /*height: 100%;*/
        border: solid 1px #eaeaea;
    }
    .sidebar::-webkit-scrollbar{
        width: 0;
    }
    .sidebar-el-menu:not(.el-menu--collapse){
        width: 250px;
    }
    .sidebar > ul {
        height:100%;
    }
    .el-submenu .el-menu-item{
        padding: 0 60px!important;
    }
    .el-menu-item, .el-submenu__title *{
        font-family: MicrosoftYaHei;
        font-size: 18px!important;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0px;
        color: #666666!important;
    }
    .el-menu-item i{
        color: #666666!important;
    }
    .el-menu-item.is-active{
        color: red!important;
    }
</style>
