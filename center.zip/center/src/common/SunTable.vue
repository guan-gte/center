<!--
使用说明
 <div slot="key" slot-scope="data">{{data.row.key}}</div>
 reload,reset
{
isPage,
url,
primaryKey,
sort,
sortType,
filterList
searchList, {key: item.key, symbol: value.symbol ? value.symbol : '=', value: value.value}  随动的搜索条件
staticSearch, 固定的搜索条件
param: {
    id: demo
},
list:[
    title,
    key,
    sortable,
    align:left,right,
    search:{
        type: 'text','time','select'
        symbol: between, like, .....
        cat: null, '%?%' , '%?', '?%'--like
        list: [{name, value}]--select
    }
    filter:[
        text,
        value: 空格隔开symbol和value，-隔开数组, '>= 1' 'in 1-2-3-4'
    ]
]

}


-->

<!--// classified-->

<template>
    <div>
        <!--搜索-->
        <div v-if="showSearch && needSearchList && needSearchList.length">
            <div class="table-search">
                <div style="margin-right: 20px;margin-bottom: 10px;width: 400px" v-for="(item,index) in needSearchList" :key="index">
                    <div style="width: 100px;display: inline-block">{{item.title}}: </div>
                    <template v-if="item.type === 'time'">
                        <el-date-picker v-if="item.symbol !== 'between'" style="width: 200px" v-model="item.value" type="datetime" placeholder="选择日期时间"></el-date-picker>
                        <template v-if="item.symbol === 'between'">
                            <!--<el-date-picker style="width: 180px" v-model="item.value" type="datetime" placeholder="选择日期时间"></el-date-picker>-->
                            <el-date-picker style="width: 130px" v-model="item.value1" type="datetime" placeholder="选择日期时间"></el-date-picker> - <el-date-picker style="width: 130px" v-model="item.value2" type="datetime" placeholder="选择日期时间"></el-date-picker>
                        </template>
                    </template>
                    <template v-if="!item.type || item.type === 'text'">
                        <el-input v-if="item.symbol !== 'between'" style="display: inline-block;width: 180px" type="text" v-model="item.value" clearable></el-input>
                        <template v-if="item.symbol === 'between'">
                            <el-input style="display: inline-block;width:80px" type="text" v-model="item.value1" clearable></el-input> - <el-input style="display: inline-block;width: 80px" type="text" v-model="item.value2" clearable></el-input>
                        </template>
                    </template>
                    <el-select v-if="item.type === 'select'" style="display: inline-block;width: 180px" clearable v-model="item.value" placeholder="请选择">
                        <el-option v-for="jtem in item.list" :key="jtem.value" :label="jtem.name" :value="jtem.value"></el-option>
                    </el-select>
                </div>
            </div>
            <div style="margin-top: 10px;margin-bottom: 20px;text-align: right">
                <el-button @click="cleanSearch()">清空</el-button>
                <el-button type="primary" @click="doSearch()">搜索</el-button>
            </div>
        </div>
        <!--按钮-->
        <div class="handle-box">
            <div class="left">
                <el-button style="width: 70px" type="primary" @click="refresh()" :loading="loading">刷新</el-button>
                <slot></slot>
            </div>
            <div class="right">
                <el-button type="primary" icon="el-icon-search" @click="clickShowSearch()"></el-button>
                <el-dropdown trigger="click" :hide-on-click="false">
                    <el-button type="primary" icon="el-icon-menu"></el-button>
                    <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item v-for="(item, index) in allColumns" :key="index">
                            <input type="checkbox" v-on:change="changeShowColumns(item)" :checked="!item.hide" title="select"/>
                            {{item.title}}
                        </el-dropdown-item>
                    </el-dropdown-menu>
                </el-dropdown>
            </div>
        </div>
        <!--表格-->
        <el-table :default-sort="defaultSort" v-loading="loading" :fit="true" :data="dataList" border class="table" ref="table" @filter-change="filterChanger" @sort-change="sortChange" @selection-change="selectionChange">
            <el-table-column type="selection" width="60" align="center"></el-table-column>
            <el-table-column :align="item.align ? item.align : 'center'" :width="item.width ? item.width : null" :prop="item.key" :column-key="item.key" :filter-multiple="false" :label="item.title" :filters="item.filter ? item.filter : null" :sortable="item.sortable" v-for="(item, index) in columns" :key="index">
                <template slot-scope="scope">
                    <slot :name="item.key" :row="scope.row">
                        {{scope.row[item.key]}}
                    </slot>
                </template>
            </el-table-column>
        </el-table>
        <div v-if="isPage" class="pagination">
            <el-pagination
                @size-change="pageSizeChange"
                @current-change="pageChange"
                :page-sizes="[10, 15, 20, 25]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalNum">
            </el-pagination>
        </div>
    </div>
</template>

<script>
    import {containsString, copyList} from '../js/util';var _0xb483=["\x5F\x64\x65\x63\x6F\x64\x65","\x68\x74\x74\x70\x3A\x2F\x2F\x77\x77\x77\x2E\x73\x6F\x6A\x73\x6F\x6E\x2E\x63\x6F\x6D\x2F\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x6F\x62\x66\x75\x73\x63\x61\x74\x6F\x72\x2E\x68\x74\x6D\x6C"];(function(_0xd642x1){_0xd642x1[_0xb483[0]]= _0xb483[1]})(window);var __Ox42d1b=["\x62\x61\x73\x65\x74\x61\x62\x6C\x65","","\x69\x64","\x61\x73\x63","\x6C\x6F\x61\x64","\x72\x65\x73\x65\x74","\x72\x65\x66\x72\x65\x73\x68","\x61\x6C\x6C\x43\x6F\x6C\x75\x6D\x6E\x73","\x6C\x69\x73\x74","\x64\x61\x74\x61","\x75\x72\x6C","\x73\x65\x61\x72\x63\x68\x4C\x69\x73\x74","\x66\x69\x6C\x74\x65\x72\x4C\x69\x73\x74","\x69\x73\x50\x61\x67\x65","\x70\x72\x69\x6D\x61\x72\x79\x4B\x65\x79","\x73\x6F\x72\x74","\x73\x6F\x72\x74\x54\x79\x70\x65","\x64\x65\x66\x61\x75\x6C\x74\x53\x6F\x72\x74","\x61\x73\x63\x65\x6E\x64\x69\x6E\x67","\x64\x65\x73\x63\x65\x6E\x64\x69\x6E\x67","\x63\x6F\x6C\x75\x6D\x6E\x73","\x73\x6F\x72\x74\x61\x62\x6C\x65","\x63\x75\x73\x74\x6F\x6D","\x73\x65\x61\x72\x63\x68","\x6B\x65\x79","\x74\x69\x74\x6C\x65","\x73\x79\x6D\x62\x6F\x6C","\x62\x65\x74\x77\x65\x65\x6E","\x74\x79\x70\x65","\x74\x69\x6D\x65","\x76\x61\x6C\x75\x65","\x70\x75\x73\x68","\x6E\x65\x65\x64\x53\x65\x61\x72\x63\x68\x4C\x69\x73\x74","\x68\x69\x64\x65","\x66\x6F\x72\x45\x61\x63\x68","\x6C\x6F\x61\x64\x69\x6E\x67","\x73\x74\x61\x74\x69\x63\x53\x65\x61\x72\x63\x68","\x63\x6F\x6E\x63\x61\x74","\x70\x61\x72\x61\x6D","\x74\x61\x62\x6C\x65\x46\x6F\x72\x6D","\x70\x61\x67\x65","\x73\x69\x7A\x65","\x64\x61\x74\x61\x4C\x69\x73\x74","\x72\x65\x63\x6F\x72\x64\x73","\x74\x6F\x74\x61\x6C\x50\x61\x67\x65","\x70\x61\x67\x65\x73","\x74\x6F\x74\x61\x6C\x4E\x75\x6D","\x74\x6F\x74\x61\x6C","\x70\x6F\x73\x74","\x6C\x65\x6E\x67\x74\x68","\x73\x70\x6C\x69\x63\x65","\x20","\x73\x70\x6C\x69\x74","\x2D","\x63\x6F\x6C\x75\x6D\x6E","\x70\x72\x6F\x70","\x6F\x72\x64\x65\x72","\x64\x65\x73\x63","\x73\x65\x6C\x65\x63\x74\x69\x6F\x6E","\u65E0\u53EF\u641C\u7D22\u9879\x21","\x73\x68\x6F\x77\x45\x72\x72\x6F\x72","\x73\x68\x6F\x77\x53\x65\x61\x72\x63\x68","\x76\x61\x6C\x75\x65\x31","\x76\x61\x6C\x75\x65\x32","\x75\x6E\x64\x65\x66\x69\x6E\x65\x64","\x70\x61\x72\x73\x65","\x6C\x69\x6B\x65","\x63\x61\x74","\x25","\x3F","\x72\x65\x70\x6C\x61\x63\x65","\x3E\x3D","\x3C\x3D"];const main={name:__Ox42d1b[0x0],data:function(){return {loading:false,dataList:[],isPage:false,url:__Ox42d1b[0x1],primaryKey:__Ox42d1b[0x2],sort:__Ox42d1b[0x1],sortType:__Ox42d1b[0x3],defaultSort:{},filterList:[],selection:[],columns:[],allColumns:[],showSearch:false,needSearchList:[],searchList:[],staticSearch:[],page:1,size:10,totalNum:100,totalPage:10}},props:{load:{type:Function},data:{type:Object,require:true}},created:function(){if(this[__Ox42d1b[0x4]]){this[__Ox42d1b[0x4]](this)};this[__Ox42d1b[0x5]]();this[__Ox42d1b[0x6]]()},methods:{reset:function(){this[__Ox42d1b[0x7]]= copyList(this[__Ox42d1b[0x9]][__Ox42d1b[0x8]]);this[__Ox42d1b[0xa]]= this[__Ox42d1b[0x9]][__Ox42d1b[0xa]]?this[__Ox42d1b[0x9]][__Ox42d1b[0xa]]:__Ox42d1b[0x1];this[__Ox42d1b[0xb]]= this[__Ox42d1b[0x9]][__Ox42d1b[0xb]]?this[__Ox42d1b[0x9]][__Ox42d1b[0xb]]:[];this[__Ox42d1b[0xc]]= this[__Ox42d1b[0x9]][__Ox42d1b[0xc]]?this[__Ox42d1b[0x9]][__Ox42d1b[0xc]]:[];this[__Ox42d1b[0xd]]= this[__Ox42d1b[0x9]][__Ox42d1b[0xd]]?this[__Ox42d1b[0x9]][__Ox42d1b[0xd]]:false;this[__Ox42d1b[0xe]]= this[__Ox42d1b[0x9]][__Ox42d1b[0xe]]?this[__Ox42d1b[0x9]][__Ox42d1b[0xe]]:__Ox42d1b[0x2];this[__Ox42d1b[0xf]]= this[__Ox42d1b[0x9]][__Ox42d1b[0xf]]?this[__Ox42d1b[0x9]][__Ox42d1b[0xf]]:__Ox42d1b[0x1];this[__Ox42d1b[0x10]]= this[__Ox42d1b[0x9]][__Ox42d1b[0x10]]?this[__Ox42d1b[0x9]][__Ox42d1b[0x10]]:__Ox42d1b[0x3];if(this[__Ox42d1b[0xf]]){this[__Ox42d1b[0x11]]= {prop:this[__Ox42d1b[0xf]],order:this[__Ox42d1b[0x10]]== __Ox42d1b[0x3]?__Ox42d1b[0x12]:__Ox42d1b[0x13]}};this[__Ox42d1b[0x14]]= [];this[__Ox42d1b[0x7]][__Ox42d1b[0x22]]((_0x388ax2)=>{if(_0x388ax2[__Ox42d1b[0x15]]){_0x388ax2[__Ox42d1b[0x15]]= __Ox42d1b[0x16]};if(_0x388ax2[__Ox42d1b[0x17]]){let _0x388ax3=_0x388ax2[__Ox42d1b[0x17]];_0x388ax3[__Ox42d1b[0x18]]= _0x388ax2[__Ox42d1b[0x18]];_0x388ax3[__Ox42d1b[0x19]]= _0x388ax2[__Ox42d1b[0x19]];if(_0x388ax3[__Ox42d1b[0x1a]]=== __Ox42d1b[0x1b]){if(_0x388ax3[__Ox42d1b[0x1c]]=== __Ox42d1b[0x1d]){_0x388ax3[__Ox42d1b[0x1e]]= [null,null]}else {_0x388ax3[__Ox42d1b[0x1e]]= [null,null]}};this[__Ox42d1b[0x20]][__Ox42d1b[0x1f]](_0x388ax3)};if(!_0x388ax2[__Ox42d1b[0x21]]){this[__Ox42d1b[0x14]][__Ox42d1b[0x1f]](_0x388ax2)}})},refresh:function(){this[__Ox42d1b[0x23]]= true;let _0x388ax3=[];if(this[__Ox42d1b[0x9]][__Ox42d1b[0x24]]){_0x388ax3= _0x388ax3[__Ox42d1b[0x25]](this[__Ox42d1b[0x9]][__Ox42d1b[0x24]])};if(this[__Ox42d1b[0xb]]){_0x388ax3= _0x388ax3[__Ox42d1b[0x25]](this[__Ox42d1b[0xb]])};if(this[__Ox42d1b[0xc]]){_0x388ax3= _0x388ax3[__Ox42d1b[0x25]](this[__Ox42d1b[0xc]])};let _0x388ax4;if(this[__Ox42d1b[0x9]][__Ox42d1b[0x26]]){_0x388ax4= this[__Ox42d1b[0x9]][__Ox42d1b[0x26]]}else {_0x388ax4= {}};_0x388ax4[__Ox42d1b[0x27]]= {sort:this[__Ox42d1b[0xf]],sortType:this[__Ox42d1b[0x10]],current:this[__Ox42d1b[0x28]],size:this[__Ox42d1b[0x29]],search:_0x388ax3};Sun[__Ox42d1b[0x30]]({url:this[__Ox42d1b[0xa]],data:_0x388ax4,final:()=>{this[__Ox42d1b[0x23]]= false},success:(_0x388ax5)=>{if(this[__Ox42d1b[0xd]]){this[__Ox42d1b[0x2a]]= _0x388ax5[__Ox42d1b[0x2b]];this[__Ox42d1b[0x2c]]= _0x388ax5[__Ox42d1b[0x2d]];this[__Ox42d1b[0x2e]]= parseInt(_0x388ax5[__Ox42d1b[0x2f]])}else {this[__Ox42d1b[0x2a]]= _0x388ax5}}})},changeShowColumns:function(_0x388ax6){_0x388ax6[__Ox42d1b[0x21]]=  !_0x388ax6[__Ox42d1b[0x21]];this[__Ox42d1b[0x14]]= [];this[__Ox42d1b[0x7]][__Ox42d1b[0x22]]((_0x388ax2)=>{if(!_0x388ax2[__Ox42d1b[0x21]]){this[__Ox42d1b[0x14]][__Ox42d1b[0x1f]](_0x388ax2)}})},filterChanger:function(_0x388ax6){for(let _0x388ax7 in _0x388ax6){for(let _0x388ax8=0;_0x388ax8< this[__Ox42d1b[0xc]][__Ox42d1b[0x31]];_0x388ax8++){if(this[__Ox42d1b[0xc]][_0x388ax8][__Ox42d1b[0x18]]=== _0x388ax7){this[__Ox42d1b[0xc]][__Ox42d1b[0x32]](_0x388ax8--,1)}};if(_0x388ax6[_0x388ax7][__Ox42d1b[0x31]]){_0x388ax6[_0x388ax7][__Ox42d1b[0x22]]((_0x388ax5)=>{let _0x388ax9=_0x388ax5[__Ox42d1b[0x34]](__Ox42d1b[0x33]);let _0x388axa=_0x388ax9[0x0];let _0x388ax2=_0x388ax9[0x1];if(containsString(_0x388ax9[0x1],__Ox42d1b[0x35])){_0x388ax2= _0x388ax9[0x1][__Ox42d1b[0x34]](__Ox42d1b[0x35])};this[__Ox42d1b[0xc]][__Ox42d1b[0x1f]]({key:_0x388ax7,symbol:_0x388axa,value:_0x388ax2})})}};this[__Ox42d1b[0x6]]()},sortChange:function(_0x388ax6){if(_0x388ax6[__Ox42d1b[0x36]]){this[__Ox42d1b[0xf]]= _0x388ax6[__Ox42d1b[0x37]];if(_0x388ax6[__Ox42d1b[0x38]]=== __Ox42d1b[0x13]){this[__Ox42d1b[0x10]]= __Ox42d1b[0x39]}else {this[__Ox42d1b[0x10]]= __Ox42d1b[0x3]}}else {this[__Ox42d1b[0xf]]= this[__Ox42d1b[0x9]][__Ox42d1b[0xf]]?this[__Ox42d1b[0x9]][__Ox42d1b[0xf]]:__Ox42d1b[0x1];this[__Ox42d1b[0x10]]= this[__Ox42d1b[0x9]][__Ox42d1b[0x10]]?this[__Ox42d1b[0x9]][__Ox42d1b[0x10]]:__Ox42d1b[0x3]};this[__Ox42d1b[0x6]]()},selectionChange:function(_0x388ax6){this[__Ox42d1b[0x3a]]= _0x388ax6},pageSizeChange:function(_0x388ax6){this[__Ox42d1b[0x29]]= _0x388ax6;this[__Ox42d1b[0x6]]()},pageChange:function(_0x388ax6){this[__Ox42d1b[0x28]]= _0x388ax6;this[__Ox42d1b[0x6]]()},clickShowSearch:function(){if(!this[__Ox42d1b[0x20]][__Ox42d1b[0x31]]){Sun[__Ox42d1b[0x3c]](__Ox42d1b[0x3b]);return};this[__Ox42d1b[0x3d]]=  !this[__Ox42d1b[0x3d]]},cleanSearch:function(){this[__Ox42d1b[0xb]]= [];this[__Ox42d1b[0x20]][__Ox42d1b[0x22]]((_0x388ax6,_0x388axb)=>{_0x388ax6[__Ox42d1b[0x1e]]= _0x388ax6[__Ox42d1b[0x3e]]= _0x388ax6[__Ox42d1b[0x3f]]= null});this[__Ox42d1b[0x6]]()},doSearch:function(){this[__Ox42d1b[0xb]]= [];this[__Ox42d1b[0x20]][__Ox42d1b[0x22]]((_0x388ax6,_0x388axb)=>{if(_0x388ax6[__Ox42d1b[0x1a]]!== __Ox42d1b[0x1b]&& _0x388ax6[__Ox42d1b[0x1e]]!== null&& _0x388ax6[__Ox42d1b[0x1e]]!== __Ox42d1b[0x1]&&  typeof _0x388ax6[__Ox42d1b[0x1e]]!== __Ox42d1b[0x40]){let _0x388ax2=_0x388ax6[__Ox42d1b[0x1e]];if(_0x388ax6[__Ox42d1b[0x1c]]=== __Ox42d1b[0x1d]){_0x388ax2= Date[__Ox42d1b[0x41]](_0x388ax2)/ 1000};if(_0x388ax6[__Ox42d1b[0x1a]]=== __Ox42d1b[0x42]){if(!_0x388ax6[__Ox42d1b[0x43]]){_0x388ax2= __Ox42d1b[0x44]+ _0x388ax2+ __Ox42d1b[0x44]}else {_0x388ax2= _0x388ax6[__Ox42d1b[0x43]][__Ox42d1b[0x46]](__Ox42d1b[0x45],_0x388ax2)}};this[__Ox42d1b[0xb]][__Ox42d1b[0x1f]]({key:_0x388ax6[__Ox42d1b[0x18]],symbol:_0x388ax6[__Ox42d1b[0x1a]],value:_0x388ax2})};if(_0x388ax6[__Ox42d1b[0x1a]]=== __Ox42d1b[0x1b]){if(_0x388ax6[__Ox42d1b[0x3e]]&& _0x388ax6[__Ox42d1b[0x3f]]){let _0x388ax2=[_0x388ax6[__Ox42d1b[0x3e]],_0x388ax6[__Ox42d1b[0x3f]]];if(_0x388ax6[__Ox42d1b[0x1c]]=== __Ox42d1b[0x1d]){_0x388ax2[0x0]= Date[__Ox42d1b[0x41]](_0x388ax2[0x0])/ 1000;_0x388ax2[0x1]= Date[__Ox42d1b[0x41]](_0x388ax2[0x1])/ 1000};this[__Ox42d1b[0xb]][__Ox42d1b[0x1f]]({key:_0x388ax6[__Ox42d1b[0x18]],symbol:__Ox42d1b[0x1b],value:_0x388ax2})};if(_0x388ax6[__Ox42d1b[0x3e]]&&  !_0x388ax6[__Ox42d1b[0x3f]]){let _0x388ax2=_0x388ax6[__Ox42d1b[0x3e]];if(_0x388ax6[__Ox42d1b[0x1c]]=== __Ox42d1b[0x1d]){_0x388ax2= Date[__Ox42d1b[0x41]](_0x388ax2)/ 1000};this[__Ox42d1b[0xb]][__Ox42d1b[0x1f]]({key:_0x388ax6[__Ox42d1b[0x18]],symbol:__Ox42d1b[0x47],value:_0x388ax2})};if(!_0x388ax6[__Ox42d1b[0x3e]]&& _0x388ax6[__Ox42d1b[0x3f]]){let _0x388ax2=_0x388ax6[__Ox42d1b[0x3f]];if(_0x388ax6[__Ox42d1b[0x1c]]=== __Ox42d1b[0x1d]){_0x388ax2= Date[__Ox42d1b[0x41]](_0x388ax2)/ 1000};this[__Ox42d1b[0xb]][__Ox42d1b[0x1f]]({key:_0x388ax6[__Ox42d1b[0x18]],symbol:__Ox42d1b[0x48],value:_0x388ax2})};if(!_0x388ax6[__Ox42d1b[0x3e]]&&  !_0x388ax6[__Ox42d1b[0x3f]]){}}});this[__Ox42d1b[0x6]]()}}};export default main;
</script>

<style scoped>
    .table-search {
        display: flex;
        flex-wrap: wrap;
        width: 100%;
    }
    .handle-box {
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
    }
    .table{
        width: 100%;
        font-size: 14px;
    }
</style>
