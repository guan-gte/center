<template>
    <div class="header">
        <div class="collapse-btn">
            <img :src="logo" alt="">
        </div>

        <input class="input-inrigh" v-model="input" placeholder="梁玉玺为您提供解决方案">

        <el-button class="btn" type="primary" icon="el-icon-search"></el-button>

        <div class="input-inrigh" style="left: 50%;top: 34%" >
            <span style="padding: 0 20px 0 0; color: #505050" v-for="(item, index) in total">
                {{item.name}}
            </span>
        </div>

        <!--<div class="header-right">-->
            <!--<div class="header-user-con">-->
                <!--<div class="">上海</div>-->
                <!--&lt;!&ndash; 全屏显示 &ndash;&gt;-->
                <!--&lt;!&ndash;<div class="btn-fullscreen" @click="handleFullScreen">&ndash;&gt;-->
                    <!--&lt;!&ndash;<el-tooltip effect="dark" :content="fullscreen?`取消全屏`:`全屏`" placement="bottom">&ndash;&gt;-->
                        <!--&lt;!&ndash;<i class="el-icon-rank"></i>&ndash;&gt;-->
                    <!--&lt;!&ndash;</el-tooltip>&ndash;&gt;-->
                <!--&lt;!&ndash;</div>&ndash;&gt;-->
                <!--&lt;!&ndash; 消息中心 &ndash;&gt;-->
                <!--&lt;!&ndash;<div class="btn-bell">&ndash;&gt;-->
                <!--&lt;!&ndash;<el-tooltip effect="dark" :content="message?`有${message}条未读消息`:`消息中心`" placement="bottom">&ndash;&gt;-->
                <!--&lt;!&ndash;<router-link to="/tabs">&ndash;&gt;-->
                <!--&lt;!&ndash;<i class="el-icon-bell"></i>&ndash;&gt;-->
                <!--&lt;!&ndash;</router-link>&ndash;&gt;-->
                <!--&lt;!&ndash;</el-tooltip>&ndash;&gt;-->
                <!--&lt;!&ndash;<span class="btn-bell-badge" v-if="message"></span>&ndash;&gt;-->
                <!--&lt;!&ndash;</div>&ndash;&gt;-->
                <!--&lt;!&ndash; 用户头像 &ndash;&gt;-->
                <!--&lt;!&ndash;<div class="user-avator"><img :src="headPic ? headPic : imgBlank"></div>&ndash;&gt;-->
                <!--&lt;!&ndash; 用户名下拉菜单 &ndash;&gt;-->
                <!--&lt;!&ndash;<el-dropdown class="user-name" trigger="click" @command="handleCommand">&ndash;&gt;-->
                    <!--&lt;!&ndash;<span class="el-dropdown-link">&ndash;&gt;-->
                        <!--&lt;!&ndash;{{username}} <i class="el-icon-caret-bottom"></i>&ndash;&gt;-->
                    <!--&lt;!&ndash;</span>&ndash;&gt;-->
                    <!--&lt;!&ndash;<el-dropdown-menu slot="dropdown">&ndash;&gt;-->
                        <!--&lt;!&ndash;<el-dropdown-item divided  command="loginout">退出登录</el-dropdown-item>&ndash;&gt;-->
                    <!--&lt;!&ndash;</el-dropdown-menu>&ndash;&gt;-->
                <!--&lt;!&ndash;</el-dropdown>&ndash;&gt;-->
            <!--</div>-->
        <!--</div>-->
    </div>
</template>
<script>
    import bus from '../common/bus';
    import img_logo from '../assets/logo.jpg';
    export default {
        data() {
            return {
                input: '',
                collapse: false,
                fullscreen: false,
                name: 'linxin',
                message: 2,
                tagsList:[],
                showRelation: false,
                relationList: [],
                //
                logo: img_logo,
                total:{name:[
                        {ctiy:'上海'}
                    ],}
            }
        },
        // computed:{
        //     // username () {
        //     //     return '用户';
        //     // },
        //     // headPic () {
        //     //     return this.imgBlank;
        //     // }
        // },
        // created () {
        //     this.$router.push('/');
        // },
        // mounted () {
        // },
        methods:{
            // 用户名下拉菜单选择事件
            // handleCommand(command) {
            //     if(command == 'loginout'){
            //         Sun.logout();
            //     }
            // },
            // 侧边栏折叠
            // collapseChage(){
            //     this.collapse = !this.collapse;
            //     bus.$emit('collapse', this.collapse);
            // },
            // 全屏事件
            // handleFullScreen(){
            //     let element = document.documentElement;
            //     if (this.fullscreen) {
            //         if (document.exitFullscreen) {
            //             document.exitFullscreen();
            //         } else if (document.webkitCancelFullScreen) {
            //             document.webkitCancelFullScreen();
            //         } else if (document.mozCancelFullScreen) {
            //             document.mozCancelFullScreen();
            //         } else if (document.msExitFullscreen) {
            //             document.msExitFullscreen();
            //         }
            //     } else {
            //         if (element.requestFullscreen) {
            //             element.requestFullscreen();
            //         } else if (element.webkitRequestFullScreen) {
            //             element.webkitRequestFullScreen();
            //         } else if (element.mozRequestFullScreen) {
            //             element.mozRequestFullScreen();
            //         } else if (element.msRequestFullscreen) {
            //             // IE11
            //             element.msRequestFullscreen();
            //         }
            //     }
            //     this.fullscreen = !this.fullscreen;
            // }
        },
        mounted(){
            // if(document.body.clientWidth < 1500){
            //     this.collapseChage();
            // }
        }
    }
</script>
<style lang="less" scoped>
    @import "../assets/css/config.less";
    /*.cell {*/
        /*!*width: 100%;*!*/
        /*cursor: pointer;*/
        /*padding-left: 10px;*/
        /*height: 36px;*/
        /*line-height: 36px;*/
    /*}*/
    /*.cell:hover {*/
        /*background-color: @white-touch-color;*/
    /*}*/
    .input-inrigh{
        position:absolute;
        top: 30%;
        width: 358px;
        height: 42px;
        transform: translateY(-50%);
        font-size: 16px;
        margin-left: 73px;
        /*border: 1px solid red;*/
    }

    .btn{
        position:absolute;
        top: 26%;
        left: 48.4%;
        width: 60px;
        height: 32px;
        border-radius: 0;
        border: 0;
        background-color: red;
        padding: 0;
        font-size: 24px;
        transform: translateY(-50%);

    }

    .header {
        position: relative;
        box-sizing: border-box;
        width: 1194px;
        height: 120px;
        font-size: 22px;
        color: #fff;
        background-color: #eee;
        /*background-image: url("../assets/sh.gif");*/
        /*background-repeat: no-repeat;*/
    }
    .collapse-btn{
        width: 148px;
        height: 96px;
        float: left;
    }
    .collapse-btn img{
        width: 148px;
        height: 96px;
    }
    .header-right{
        float: right;
        padding-right: 50px;
    }
    .header-user-con{
        display: flex;
        height: 70px;
        align-items: center;
    }
    .btn-fullscreen{
        transform: rotate(45deg);
        margin-right: 5px;
        font-size: 24px;
    }
    .btn-bell, .btn-fullscreen{
        position: relative;
        width: 30px;
        height: 30px;
        text-align: center;
        border-radius: 15px;
        cursor: pointer;
    }
    .btn-bell-badge{
        position: absolute;
        right: 0;
        top: -2px;
        width: 8px;
        height: 8px;
        border-radius: 4px;
        background: #f56c6c;
        color: #fff;
    }
    .btn-bell .el-icon-bell{
        color: #fff;
    }
    .user-name{
        margin-left: 10px;
    }
    .user-avator{
        margin-left: 20px;
    }
    .user-avator img{
        display: block;
        width:40px;
        height:40px;
        border-radius: 50%;
    }
    .el-dropdown-link{
        color: #fff;
        cursor: pointer;
    }
    .el-dropdown-menu__item{
        text-align: center;
    }
</style>
