<template>
    <div class="sidebar">
        <el-menu class="sidebar-el-menu" :default-active="onRoutes" :collapse="collapse" background-color="#324157"
            text-color="#bfcbd9" active-text-color="#20a0ff" unique-opened router>
            <template v-for="item in menuList">
                <template v-if="item.childlist.length">
                    <el-submenu :index="item.path ? item.path : Math.random() + ''" :key="item.path ? item.path : Math.random()">
                        <template slot="title">
                            <i :class="item.icon"></i><span slot="title">{{ item.name }}</span>
                        </template>
                        <template v-for="subItem in item.childlist">
                            <el-submenu v-if="subItem.childlist.length" :index="subItem.path ? subItem.path : Math.random() + ''" :key="subItem.path ? subItem.path : Math.random()">
                                <template slot="title">{{ subItem.name }}</template>
                                <el-menu-item v-for="(threeItem,i) in subItem.childlist" :key="i" :index="threeItem.path ? threeItem.path : Math.random() + ''">
                                    {{ threeItem.name }}
                                </el-menu-item>
                            </el-submenu>
                            <el-menu-item v-else :index="subItem.path ? subItem.path : Math.random() + ''" :key="subItem.path ? subItem.path : Math.random()">
                                {{ subItem.name }}
                            </el-menu-item>
                        </template>
                    </el-submenu>
                </template>
                <template v-else>
                    <el-menu-item :index="item.path ? item.path : Math.random() + ''" :key="item.path">
                        <i :class="item.icon"></i><span slot="title">{{ item.name }}</span>
                    </el-menu-item>
                </template>
            </template>
        </el-menu>
    </div>
</template>

<script>
    import bus from '../common/bus';
    export default {
        data() {
            return {
                collapse: false,
                menuList: [
                    /*********************  Master  **********************************/
                    {
                        icon: 'el-icon-lx-home',
                        path: '/welcome',
                        name: '欢迎!',
                        childlist:[]
                    },
                    //  {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '基本信息维护',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/plat/base/members/grade',
                    //             name: '会员级别',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/plat/base/customer/customer',
                    //             name: '客户基本信息',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '基本信息维护(公司)',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/base/personalLabel/label',
                    //             name: '个人标签',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '客户服务',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/customer/myCustomer/myCustomer',
                    //             name: '经理客户列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/customer/groupCustomer/groupCustomer',
                    //             name: '组长客户列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/customer/instCustomer/instCustomer',
                    //             name: '总监客户列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/customer/comCustomer/comCustomer',
                    //             name: '公海客户列表',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '回访记录及订单',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/visitRecord/visitRecord',
                    //             name: '回访记录',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/orderRecord/orderRecord',
                    //             name: '订单记录',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/examByLeader/examineRecord',
                    //             name: '审批列表(销售总监)',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/exam/examineRecord',
                    //             name: '审批列表(销售组长)',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/saleClaim/saleClaim',
                    //             name: '认领申请列表(销售)',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/saleClaimLeader/saleClaimLeader',
                    //             name: '认领申请列表(销售总监)',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/refundExam/examRecords',
                    //             name: '退款审批列表(销售经理)',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/refundExamByLeader/examRecords',
                    //             name: '退款审批列表(销售组长)',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/visitAndOrder/refundExamByDirector/ExamRecords',
                    //             name: '退款审批列表(销售总监)',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '财务管理',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/financial/order/order',
                    //             name: '订单确认列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/financial/afterSales/afterSales',
                    //             name: '售后退款打款',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // // 
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '仓管业务管理',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/plat/store/customerOrder/order',
                    //             name: '客户订单列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/plat/store/storeGoods/storeGoods',
                    //             name: '仓库管理',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/plat/store/storeIn/storeIn',
                    //             name: '入库管理',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '业务统计',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/statistics/myBusiness/myBusiness',
                    //             name: '我的业务统计',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/statistics/teamBusiness/teamBusiness',
                    //             name: '小组业务统计',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/statistics/deployBusiByLeader/deployBusiness',
                    //             name: '总监业务部署',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/statistics/deployBusi/deployBusi',
                    //             name: '组长业务部署',
                    //             childlist: []
                    //         }
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '后勤总务管理',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/logistics/store/storeGoods',
                    //             name: '仓库商品列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/logistics/purchase/purchaseOrder',
                    //             name: '采购列表',
                    //             childlist: []
                    //         }
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '仓库管理',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/store/customerOrder/customerOrder',
                    //             name: '客户订单列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/store/storeGoods/storeGoods',
                    //             name: '仓库商品列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/store/storeIn/storeIn',
                    //             name: '入库单列表',
                    //             childlist: []
                    //         }
                    //     ]
                    // },
                    // // 商城管理
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '用户管理',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/mall/user/user',
                    //             name: '用户列表',
                    //             childlist: []
                    //         },
                    //         {
                    //             icon: '',
                    //             path: '/inst/mall/order/order',
                    //             name: '订单记录',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '财务管理',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/mall/financial/invoice/invoiceApply',
                    //             name: '发票申请记录',
                    //             childlist: []
                    //         }
                    //     ]
                    // },
                    // --------------------------- New -------------------------------
                    // ---------------------------销售端-------------------------------
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '客户管理',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/inst/salesDepart/client/myClient/Client',
                    //             name: '我的客户',
                    //             childlist: []
                    //         }
                    //     ]
                    // },
                    // --------------------------- New -------------------------------
                    // ---------------------------供应链端-----------------------------
                    {
                        icon: 'el-icon-lx-home',
                        path: '',
                        name: '商品分类及场景',
                        childlist:[
                            {
                                icon: '',
                                path: '/plat/supplyDepart/classifyAndScene/commonTab',
                                name: '商品分类及场景',
                                childlist: []
                            }
                        ]
                    },
                    {
                        icon: 'el-icon-lx-home',
                        path: '',
                        name: '供应链管理',
                        childlist:[
                            {
                                icon: '',
                                path: '/plat/supplyDepart/supplyChain/brand/brand',
                                name: '品牌管理',
                                childlist: []
                            },
                            {
                                icon: '',
                                path: '/plat/supplyDepart/supplyChain/goods/supplier/supplier',
                                name: '供应商管理',
                                childlist: []
                            },
                            {
                                icon: '',
                                path: '/plat/supplyDepart/supplyChain/goods/goods',
                                name: '产品管理',
                                childlist: []
                            }
                        ]
                    }, 
                    {
                        icon: 'el-icon-lx-home',
                        path: '',
                        name: '库存产品管理',
                        childlist:[
                            {
                                icon: '',
                                path: '/plat/supplyDepart/storeGoods/storeGoods/goods',
                                name: '库存产品列表',
                                childlist: []
                            }
                        ]
                    },
                    {
                        icon: 'el-icon-lx-home',
                        path: '',
                        name: '我的审批',
                        childlist:[
                            {
                                icon: '',
                                path: '/plat/supplyDepart/supplyChain/goods/uploadList/upload',
                                name: '我的产品上传列表(专员)',
                                childlist: []
                            },
                            {
                                icon: '',
                                path: '/plat/supplyDepart/supplyChain/auditFirst/audit',
                                name: '产品上传审批列表(主管)',
                                childlist: []
                            },
                            {
                                icon: '',
                                path: '/plat/supplyDepart/supplyChain/auditSecond/audit',
                                name: '产品上传审批列表(总监)',
                                childlist: []
                            }
                        ]
                    },
                    // ---------------------------网销端-----------------------------
                    {
                        icon: 'el-icon-lx-cascades',
                        path: '/',
                        name: '网络销售端',
                        childlist:[
                            {
                                path:'',
                                name:'基本信息管理',
                                childlist:[{
                                    path:'/plat/netSalesDepart/BIManagement/CPManagement',
                                    name:'分类图片管理',
                                    childlist:[],
                                },
                                    {
                                        path:'/plat/netSalesDepart/BIManagement/CStatus',
                                        name:'分类开启状态管理',
                                        childlist:[],
                                    },
                                    {
                                        path:'/DTManagement',
                                        name:'详情模板管理',
                                        childlist:[],
                                    }
                                ],
                            },
                            {
                                path:'',
                                name:'商品管理',
                                childlist:[{
                                    path:'/ProductList',
                                    name:'产品列表',
                                    childlist:[
                                        {
                                            path:'/ProductList',
                                            name:'产品列表',
                                            childlist:[],
                                        },
                                    ],
                                },
                                    {
                                        path:'/MPList',
                                        name:'商城产品列表',
                                        childlist:[],
                                    }
                                ],
                            }
                        ]
                    },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: 'ckEditor',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/ckEditor',
                    //             name: 'ckEditor',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: 'ckEditor',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/Screat',
                    //             name: 'Screat',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: 'ckEditor',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/ckEditor',
                    //             name: 'ckEditor',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-home',
                    //     path: '',
                    //     name: '/test',
                    //     childlist:[
                    //         {
                    //             icon: '',
                    //             path: '/test',
                    //             name: 'ckEditor',
                    //             childlist: []
                    //         },
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-cascades',
                    //     path: 'table',
                    //     name: '基础表格',
                    //     childlist:[]
                    // },
                    // {
                    //     icon: 'el-icon-lx-copy',
                    //     path: 'tabs',
                    //     name: 'tab选项卡',
                    //     childlist:[]
                    // },
                    // {
                    //     icon: 'el-icon-lx-calendar',
                    //     path: '3',
                    //     name: '表单相关',
                    //     childlist: [
                    //         {
                    //             path: 'form',
                    //             name: '基本表单',
                    //             childlist:[]
                    //         },
                    //         {
                    //             path: '3-2',
                    //             name: '三级菜单',
                    //             childlist: [
                    //                 {
                    //                     path: 'editor',
                    //                     name: '富文本编辑器',
                    //                     childlist:[]
                    //                 },
                    //                 {
                    //                     path: 'markdown',
                    //                     name: 'markdown编辑器',
                    //                     childlist:[]
                    //                 },
                    //             ]
                    //         },
                    //         {
                    //             path: 'upload',
                    //             name: '文件上传',
                    //             childlist:[]
                    //         }
                    //     ]
                    // },
                    // {
                    //     icon: 'el-icon-lx-emoji',
                    //     path: 'icon',
                    //     name: '自定义图标',
                    //     childlist:[]
                    // },
                    // {
                    //     icon: 'el-icon-lx-favor',
                    //     path: '/charts',
                    //     name: 'schart图表',
                    //     childlist:[]
                    // },
                    // {
                    //     icon: 'el-icon-rank',
                    //     path: 'drag',
                    //     name: '拖拽列表',
                    //     childlist:[]
                    // },
                    // {
                    //     icon: 'el-icon-lx-warn',
                    //     path: '6',
                    //     name: '错误处理',
                    //     childlist: [
                    //         {
                    //             path: 'permission',
                    //             name: '权限测试',
                    //             childlist:[]
                    //         },
                    //         {
                    //             path: '404',
                    //             name: '404页面',
                    //             childlist:[]
                    //         }
                    //     ]
                    // }
                ]
            }
        },
        computed:{
            onRoutes(){
                // return this.$route.path.replace('/','');
            }
        },
        created(){
            // 通过 Event Bus 进行组件间通信，来折叠侧边栏
            bus.$on('collapse', msg => {
                this.collapse = msg;
            });
            // Sun.post({
            //     url: Http.common.getMenu,
            //     loading: true,
            //     success: (data) => {
            //         this.menuList = data;
            //         this.menuList.unshift({
            //             icon: 'el-icon-lx-home',
            //             path: 'welcome',
            //             name: '欢迎!',
            //             childlist:[]
            //         });
            //     }
            // })
        }
    }
</script>

<style scoped>
    .sidebar{
        display: block;
        position: absolute;
        left: 0;
        top: 70px;
        bottom:0;
        overflow-y: scroll;
    }
    .sidebar::-webkit-scrollbar{
        width: 0;
    }
    .sidebar-el-menu:not(.el-menu--collapse){
        width: 250px;
    }
    .sidebar > ul {
        height:100%;
    }
</style>
