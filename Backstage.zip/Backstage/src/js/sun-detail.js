
import {getTime, containsObject, containsString, copyMap} from './util';
import setting from '../config/setting';
import axios from 'axios';
import CryptoJS from 'crypto-js';
import desKey from '../config/key';
let Device = {
    ios: 1,
    android: 2,
    wap: 3,
    web: 4,
    wx:5,
    wxMin: 6,
    aliMin: 7
};
let App = {
    userData: setting.userKey
};
export default {
    init (to, from, next) {
        let data = Sun.readData(App.userData);
        if (data) {
            Sun.isLogin = true;
            Sun.user = data;
        }
        if (setting.init) {
            setting.init(to, from, next, data);
        } else {
            next();
        }
    },
    post(param) {
        requestHttp(param, 'post');
    },
    get(param) {
        requestHttp(param, 'get');
    },
    checkLogin(needReplace) {
        if (!Sun.isLogin) {
            if (needReplace) {
                Sun.replace({path: setting.loginPath, query: {path: Sun.path}});
            } else {
                Sun.push(setting.loginPath);
            }
            return false;
        }
        return true;
    },
    logout() {
        Sun.deleteData(App.userData);
        Sun.isLogin = false;
        Sun.temp = {};
        Sun.requestQueen = [];
        Sun.user = null;
        Sun.push(setting.loginPath);
        setTimeout(() => {
            location.reload();
        }, 100);
    },
    checkBtnAuth (url, callback) {
        Sun.post({
            url: url,
            hideShow: true,
            fail: (msg, code) => {
                if (code == setting.noAuthCode) {
                    callback();
                }
            }
        })
    },
    setLogin(user) {
        Sun.saveData(App.userData, user);
        Sun.user = user;
        Sun.isLogin = true;
    },
    hideActivity(loading) {
        if (loading) {
            loading.close();
            loading = null;
        }
    },
    showActivity() {
        let loading = Sun.vue.$loading();
        setTimeout(() => {
            if (loading) {
                loading.close();
                loading = null;
            }
        }, setting.timeout);
        return loading;
    },
    showMsg(text) {
        Sun.vue.$message({
            message: text,
            type: 'success',
            showClose: true,
            duration: 3000
        });
    },
    showError(text) {
        Sun.vue.$message({
            message: text,
            type: 'error',
            showClose: true,
            duration: 3000
        });
    },
    confirm(title, content, confirm, cancel) {
        Sun.vue.$confirm(content, title, {
            distinguishCancelAndClose: true,
            confirmButtonText: '确定',
            cancelButtonText: '取消'
        }).then(() => {
            if (confirm) {
                confirm();
            }
        }).catch(action => {
            if (cancel) {
                cancel();
            }
        });
    },
    push(path, param) {
        // Sun.vuePage.name = 'push' + Math.floor(Math.random() * 1000000);
        if (param) {
            Sun.vue.$router.push({path: path, query: param});
        } else {
            Sun.vue.$router.push(path);
        }
    },  
    // 添加路由随机name
    randomName () {
      return 'push' + Math.floor(Math.random() * 1000000);
    },
    parseImg(img, option) {
        if (!img) return img;
        let src = img;
        if (option) {
            if (option.x || option.y) {
                if (containsString(src, '?')) {
                    src = src + '&x-oss-process=image/resize,m_fill';
                } else {
                    src = src + '?x-oss-process=image/resize,m_fill';
                }
                if (option.x) {
                    src = src + ',w_' + option.x;
                }
                if (option.y) {
                    src = src + ',h_' + option.y;
                }
            }
        }
        return src;
    },
    getQuery(key) {
        return Sun.vue.$route.query[key];
    },
    deleteData(key) {
        return localStorage.removeItem(key);
    },
    readData(key) {
        return JSON.parse(localStorage.getItem(key));
    },
    saveData(key, value) {
        return localStorage.setItem(key, JSON.stringify(value));
    },
    vuePage: {
        methods: {
            parseImg(img, option) {
                return Sun.parseImg(img, option);
            },
        },
        created() {
            Sun.vue = this;
        },
        activated() {
            Sun.vue = this;
        }
    }
}

function requestHttp(param, method) {
    let data = copyMap(param.data);
    let url = param.url;
    let header = param.header;
    if (!data) {
        data = {};
    }
    data.device = Device.web;
    data.time = getTime();
    if (setting.formatUrl) {
        url = setting.formatUrl(url, data);
    }
    if (setting.formatHeader) {
        header = setting.formatHeader(header);
    }
    if (setting.formatData) {
        data = setting.formatData(data);
    }
    if (!containsString(url, 'http')) {
        if (process.env.NODE_ENV === 'production') {
            url = setting.http + setting.api + url;
            // console.log('pro', url);
        } else {
            url = '/testing' + setting.api + url;
            // console.log('dev', url);
        }
    }
    if (param.loading) {
        param.loading = Sun.showActivity();
    }
    let config = {
        url: url,
        method: method,
        data: data,
        timeout: setting.timeout,
        headers: header,
        transformResponse: [function (data) {
            return JSON.parse(longToString(data));
        }],
    };
    axios(config).then((response) => {
        handleResponse(response.data, param.final, param.success, param.fail, param.hideShow, param.loading);
    }).catch((error) => {
        console.log(error);
        if (param.loading) {
            param.loading.close();
            param.loading = null;
        }
        Sun.showError('网络连接失败，请检查网络状态后再试。');
    });
}

function longToString(string) {
    let s = true;
    while (s) {
        s = string.match(/:[\d]*\d{18}/);
        if (s) {
            let t = s[0].replace(':', ':"') + '"';
            string = string.replace(s, t);
        }
    }
    return string;
}

function handleResponse(data, final, success, fail, hideShow, loading) {
    if (loading) {
        loading.close();
        loading = null;
    }
    if (final) {
        final();
    }
    if (data.code == setting.successCode) {
        if (success) {
            success(data.data);
        }
    } else if (containsObject(setting.err_login_code, data.code)) {
        Sun.showError('登录信息失效，请重新登录。');
        if (process.env.NODE_ENV === 'production') {
            setTimeout(() => {
                Sun.logout();
            }, 500);
        }
    } else {
        if (fail) {
            fail(data.msg, data.code, data);
        }
        if (!hideShow) {
            Sun.showError(data.msg);
        }
    }
}

function encrypt(string, key = desKey.desKey, iv = desKey.iv) {
    let keyHex = CryptoJS.enc.Utf8.parse(key);
    let ivHex = CryptoJS.enc.Utf8.parse(iv);
    let encrypted = CryptoJS.DES.encrypt(string, keyHex, {
            iv: ivHex,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        }
    );
    return encrypted.ciphertext.toString();
}

function decrypt(string, key = desKey.desKey, iv = desKey.iv) {
    let keyHex = CryptoJS.enc.Utf8.parse(key);
    let ivHex = CryptoJS.enc.Utf8.parse(iv);
    let decrypted = CryptoJS.DES.decrypt({
        ciphertext: CryptoJS.enc.Hex.parse(string)
    }, keyHex, {
        iv: ivHex,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    return decrypted.toString(CryptoJS.enc.Utf8);
}


