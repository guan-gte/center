global.Http = {
    common: {
        login: '/admin/admin/admin/common/login',
        changePassword: '/admin/admin/admin/common/changePassword',
        getMenu: '/admin/admin/auth/common/getMenu',
        // 用户等级
        getUserLevelList: '/user/admin/level/common/getUserLevelList',
        // 客户标签列表
        getUserLabelList: '/crm/admin/info/common/getUserLabelList',
        // 客户行业列表
        getUserTradeList: '/crm/admin/info/common/getUserTradeList',
        // 客户来源列表
        getUserFromList: '/crm/admin/info/common/getUserFromList',
        // 搜索商品 name 模糊查询
        searchGoodsList: '/shop/admin/goods/common/searchGoodsList',  
    },
    master: {
        // 管理员
        getAdminPage: '/admin/admin/admin/master/getAdminPage',
        addAdmin: '/admin/admin/admin/master/addAdmin',
        editAdmin: '/admin/admin/admin/master/editAdmin',
        delAdmin: '/admin/admin/admin/master/delAdmin',
        getAuthGroupList: '/admin/admin/auth/master/getAuthGroupList',
        // 权限
        getAuthPage: '/admin/admin/auth/master/getAuthPage',
        addAuth: '/admin/admin/auth/master/addAuth',
        editAuth: '/admin/admin/auth/master/editAuth',
        delAuth: '/admin/admin/auth/master/delAuth',
        getMenuListByAuth: '/admin/admin/auth/master/getMenuListByAuth',
        // 权限组
        getAuthGroupPage: '/admin/admin/auth/master/getAuthGroupPage',
        addAuthGroup: '/admin/admin/auth/master/addAuthGroup',
        editAuthGroup: '/admin/admin/auth/master/editAuthGroup',
        delAuthGroup: '/admin/admin/auth/master/delAuthGroup',
        getChooseAuthList: '/admin/admin/auth/master/getChooseAuthList',
        // 菜单
        getMenuTreeList: '/admin/admin/auth/master/getMenuTreeList',
        addMenu: '/admin/admin/auth/master/addMenu',
        editMenu: '/admin/admin/auth/master/editMenu',
        delMenu: '/admin/admin/auth/master/delMenu',
        getSelectMenuTreeList: '/admin/admin/auth/master/getSelectMenuTreeList'
    },
    plat: {
        // 会员基本信息  type=1标签，2行业，3客户来源
        getLabelPage: '/crm/admin/info/plat/getLabelPage',
        editLabel: '/crm/admin/info/plat/editLabel',
        addLabel: '/crm/admin/info/plat/addLabel',
        delLabel: '/crm/admin/info/plat/delLabel',
        // 添加会员等级
        addLevel: '/user/admin/level/plat/addLevel',
        // banner列表 
        getBannerPage: '/shop/admin/banner/plat/getBannerPage',    
        addBanner: '/shop/admin/banner/plat/addBanner',   
        editBanner: '/shop/admin/banner/plat/editBanner',   
        deleteBanner: '/shop/admin/banner/plat/deleteBanner',
        // 分公司列表
        getInstPage: '/admin/admin/inst/plat/getInstPage',  
        addInst: '/admin/admin/inst/plat/addInst',
        // 分公司列表 用于筛选
        getInstList: '/admin/inst/admin/common/getInstList', 
        // 权限组列表 
        getGroupListByAuthType: '/admin/admin/admin/plat/getGroupListByAuthType', 
        // 员工列表
        getAdminPage: '/admin/admin/admin/plat/getAdminPage',
        addAdmin: '/admin/admin/admin/plat/addAdmin',   
        editAdmin: '/admin/admin/admin/plat/editAdmin',
        // 分类管理 
        getCatList: '/shop/admin/cat/plat/getCatList',
        getCatListById: '/shop/admin/cat/plat/getCatListById',
        addCat: '/shop/admin/cat/plat/addCat',  
        editCat: '/shop/admin/cat/plat/editCat', 
        deleteCat: '/shop/admin/cat/plat/deleteCat',   
        deleteCat: '/shop/admin/cat/plat/deleteCat',   
        // 供应链  
        // 我的采购订单
        mySupplyOrderPage: '/shop/admin/supply/plat/mySupplyOrderPage',
        // 创建采购订单   goodsList={id,num,price数量乘以价格}
        createSupplyOrder: '/shop/admin/supply/plat/createSupplyOrder',   
        // 审核采购单列表
        allSupplyOrderPage: '/shop/admin/supply/plat/allSupplyOrderPage',   
        // 审核驳回 
        denySupplyOrder: '/shop/admin/supply/plat/denySupplyOrder',    
        // 审核通过
        passSupplyOrder: '/shop/admin/supply/plat/passSupplyOrder',
        // 仓库管理 use
        getGoodsListPage: '/shop/admin/goods/common/getGoodsListPage',
        // 库存管理 unuse
        getStorePage: '/shop/admin/store/plat/getStorePage', 
        // 集团入库 筛选status只有1和3，1是未入库，3是已入库
        storeOrderPage: '/shop/admin/store/plat/storeOrderPage',
        //  入库操作
        completeStore: '/shop/admin/store/plat/completeStore',  
        // ********************************** New Start **********************************
        // 供应链端  ----------------------->> 
        // 应用场景列表             参数 pid: 0
        getGoodsDataListByPid: '/products/admin/goodsData/plat/getGoodsDataListByPid',
        // 应用场景新增             参数 pid  name
        addGoodsData: '/products/admin/goodsData/plat/addGoodsData',
        // 应用场景子集批量新增      参数 pid  nameList 批量添加
        addGoodsDataList: '/products/admin/goodsData/plat/addGoodsDataList',
        // 应用场景删除             参数 id
        deleteGoodsDataById: '/products/admin/goodsData/plat/deleteGoodsDataById',
        // 应用场景编辑             参数 id name
        editGoodsData: '/products/admin/goodsData/plat/editGoodsData',
        // 设备分类管理             参数 pid: 0 一级分类：(type: (1: 设备, 2: 配件、耗材)) 
        getCatPageByPidAndType: '/products/admin/cat/plat/getCatPageByPidAndType',
        // 设备分类新增             参数 pid  name  img  一级分类：(type: (1: 设备, 2: 配件、耗材)) 
        addCat: '/products/admin/cat/plat/addCat',  
        // 设备分类编辑             参数 pid  name  img  id   
        editCat: '/products/admin/cat/plat/editCat', 
        // 设备分类删除             参数 id   
        deleteCat: '/products/admin/cat/plat/deleteCat', 
        // 分类SPU属性列表          参数 catId
        getCatParamDataByCatId: '/products/admin/cat/plat/getCatParamDataByCatId',
        // 分类SPU属性新增          参数 pid:(spu分类类别) catId: 分类Id  nameList:(spu属性名, 集合)  
        addCatParamData: '/products/admin/cat/plat/addCatParamData',
        // 分类SPU属性编辑          参数 goodsParamDataId  name
        editCatParamData: 'products/admin/cat/plat/editCatParamData',
        // 分类SPU属性删除          参数 id  catId
        deleteCatParamData: '/products/admin/cat/plat/deleteCatParamData',
        // SPU分类新增              参数 name
        addCatParamDataPname: '/products/admin/cat/plat/addCatParamDataPname',
        // SPU分类列表
        getGoodsParamDataByPid: '/products/admin/cat/plat/getGoodsParamDataByPid',
        // 产品品牌列表
        brandGetBrandList: '/products/admin/brand/plat/getBrandList',
        // 产品品牌新增             参数 name intro
        addBrand: '/products/admin/brand/plat/addBrand',
        // 产品品牌编辑             参数 name intro id
        updateBrand: '/products/admin/brand/plat/updateBrand',
        // 产品品牌删除             参数 id
        deleteBrand: '/products/admin/brand/plat/deleteBrand',
        // 产品供应商列表
        getSupplierListPage: '/products/admin/supplier/plat/getSupplierListPage',
        // 产品供应商详情           参数 id
        getSupplierById: '/products/admin/supplier/plat/getSupplierById',
        // 产品供应商新增
        insertSupplier: '/products/admin/supplier/plat/insertSupplier',
        // 产品供应商编辑           参数 id
        updateSupplier: '/products/admin/supplier/plat/updateSupplier',
        // 产品供应商删除
        deleteSupplier: '/products/admin/supplier/plat/deleteSupplier', 
        // 产品新增    
        addGoodsPreInfo: '/products/admin/goodsPre/plat/addGoodsPreInfo', 
        // 产品详情(审核信息)        参数 goodsPreId
        getGoodsPreVfdByGoodsPreId: '/products/admin/goodsPreVfd/plat/getGoodsPreVfdByGoodsPreId',
        // 产品详情(上传产品详情)    参数 id 
        getGoodsPreInfoById: '/products/admin/goodsPre/plat/getGoodsPreInfoById',
        // 产品编辑
        editGoodsPreInfo: '/products/admin/goodsPre/plat/editGoodsPreInfo',
        // 产品删除                 参数 goodsPreId   
        delGoodsPreInfoById: '/products/admin/goodsPre/plat/delGoodsPreInfoById',  
        // 产品更改开启状态          参数 goodsPreId isOpen(0, 1) 
        updateIsOpenById: '/products/admin/goodsPre/plat/updateIsOpenById',      
        // 产品列表                
        getGoodsPrePage: '/products/admin/goodsPre/plat/getGoodsPrePage',
        // 我的产品上传列表    
        getMyGoodsPrePage: '/products/admin/goodsPre/plat/getMyGoodsPrePage',
        // 产品分类列表             筛选项(商品分类) 参数 pid(一级可不传或者0)   二级传(一级id)  三级传(二级id)
        getCatListByPid: '/products/admin/goodsPre/plat/getCatListByPid',
        // 分类下SPU列表            参数 catId
        getCatParamDataByCatIdGoodsPre: '/products/admin/goodsPre/plat/getCatParamDataByCatId',
        // 产品品牌列表             筛选项(商品品牌)
        getBrandList: '/products/admin/goodsPre/plat/getBrandList',
        // 产品供应商列表           筛选项(商品供应商)
        getSupplierList: '/products/admin/goodsPre/plat/getSupplierList',
        // 全模糊搜索返回产品       参数 goodsId  keywords
        getGoodByKeywordsOrGoodsId: '/products/admin/goodsPre/plat/getGoodByKeywordsOrGoodsId',    
        // 产品应用场景列表            
        getGoodsDataList: '/products/admin/goodsPre/plat/getGoodsDataList',
        // 产品审核(主管)           参数 gAuditStatus gRemark goodsPreId (未对接)
        updateGAuditStatus: '/products/admin/goodsPreVfd/plat/updateGAuditStatus',  
        // 产品审核(总监)           参数 mAuditStatus mRemark goodsPreId (未对接)
        updateMAuditStatus: '/products/admin/goodsPreVfd/plat/updateMAuditStatus',      
        // 我的产品审核列表            
        getMyVfdGoodsPrePage: '/products/admin/goodsPreVfd/plat/getMyVfdGoodsPrePage',
        // 库存产品列表
        getGoodsPreStockPage: '/products/admin/goodsPreStock/plat/getGoodsPreStockPage',
        // 各仓库数量展示列表        参数 goodsId   
        getCompanyStockPageByGoodsId: '/products/admin/goodsPreStock/plat/getCompanyStockPageByGoodsId',
        // 采购订单搜索产品及配件关联配件 参数 goodsId(id)  keywords(其他三个搜索条件共用)
        getGoodsInfoByKeyOrId: '/products/admin/goodsProcurement/plat/getGoodsInfoByKeyOrId',
        // 采购订单新增              参数 goodsListMap: [ goodsId, supplierId, totalNum ]
        addGoodsProcurement: '/products/admin/goodsProcurement/plat/addGoodsProcurement',
        // 网销端  ----------------------->>
        //分类图片列表
        getTwoCategoriesList:'/products/admin/cat/plat/getTwoCategoriesList',
        //查看分类详情   参数 id
        getTwoCategoriesById:'/products/admin/cat/plat/getTwoCategoriesById',
        //上传 更改图片 参数 id img
        updateCat:'/products/admin/cat/plat/updateCat',
        //分类开启状态修改 id 状态
        updateCat:'/products/admin/cat/plat/updateCat',
        //分类开启状态管理与搜素  搜索 参数id
        getCatStatusList:'/products/admin/cat/plat/getCatStatusList ',
        //获取所有模板
        getAllTemplate:'/products/admin/template/plat/getAllTemplate',
        //新增模板 所有参数
        insertTemplate:'/products/admin/template/plat/insertTemplate',
        //根据ID查看 id
        getTemplateById:'/products/admin/template/plat/getTemplateById',
        //修改 所有参数
        updateTemplate:'/products/admin/template/plat/updateTemplate',
        //删除 id
        deleteTemplate:'/products/admin/template/plat/deleteTemplate',
        //产品列表
        getGoodsAndCatNameList:'/products/admin/goods/plat/getGoodsAndCatNameList',
        //上传商品  商品上下架  1上架 参数 id
        updateUploading:'/products/admin/goods/plat/updateUploading',
        //商城产品列表筛选与分页
        getShopGoodsAndCatNameList:'/products/admin/goods/plat/getShopGoodsAndCatNameList',
        //查看商城产品 id 产品详情
        getGoodsById:'products/admin/goods/plat/getGoodsById',
        //查看 id 商城信息
        getGoodsInformationById:'products/admin/goods/plat/getGoodsInformationById',
        //获取所有模板信息 不分页
        getTemplateList:'products/admin/template/plat/getTemplateList',
        //编辑
        update:'products/admin/goods/plat/update',
        //单独的根据isOpen搜索
        getIsOpenSearch:'products/admin/goods/plat/getIsOpenSearch ',
        //获取所有配件及搜索
        getSearchAccessories:'products/admin/goods/plat/getSearchAccessories',
        // 获取所有看了又看热门关注 及搜索
        getSearchGoods:'products/admin/goods/plat/getSearchGoods',
        // ********************************** New End **********************************
    },
    inst: {
        //个人标签列表 
        getPersonLabelList: '/crm/admin/info/inst/getPersonLabelList',
        editPersonLabel: '/crm/admin/info/inst/editPersonLabel',
        addPersonLabel: '/crm/admin/info/inst/addPersonLabel',
        delPersonLabel: '/crm/admin/info/inst/delPersonLabel', 
        // 我的客户列表
        getMyUserPage: '/crm/admin/user/inst/getMyUserPage',
        getMyUserInfo: '/crm/admin/user/inst/getMyUserInfo', 
        editMyUserInfo: '/crm/admin/user/inst/editMyUserInfo',
        addMyUserInfo: '/crm/admin/user/inst/addMyUserInfo',
        // 客户服务人员变更记录
        getUserBelongChangeList: '/crm/admin/user/inst/getUserBelongChangeList',
        // 销售总监下属客户列表
        getInstUserPage: '/crm/admin/user/inst/getInstUserPage',
        getUserInfoWithoutContact: '/crm/admin/user/inst/getUserInfoWithoutContact',
        // 搜索我的用户  
        searchMyUser: '/crm/admin/user/inst/searchMyUser', 
        // 用户的回访记录 
        getUserVistPage: '/crm/admin/visit/inst/getUserVistPage', 
        addVisit: '/crm/admin/visit/inst/addVisit',   
        // 获取商品
        getGoodsListByType: '/shop/admin/goods/common/getGoodsListByType',   
        // 公海客户
        getCommonUserPage: '/crm/admin/user/common/getCommonUserPage', 
        addCommonUser: '/crm/admin/user/common/addCommonUser', 
        // 我的客户订单
        getMyCustomerOrderPage: '/shop/admin/order/inst/getMyCustomerOrderPage',  
        // 订单信息
        getOrderInfo: '/shop/admin/order/inst/getOrderInfo',
        // 销售开单页 客户信息 
        getUserInfoByCompany: '/crm/admin/user/inst/getUserInfoByCompany',
        // 销售开单 
        createPreOrder: '/shop/admin/order/inst/createPreOrder',
        // 待审核订单列表
        getMyCustomerOrderPrePage: '/shop/admin/order/inst/getMyCustomerOrderPrePage',   
        // --------------------------商城使用-------------------------------
        // 用户相关
        // 销售
        // 商城用户列表
        getAllUserPage: '/user/admin/user/common/getAllUserPage',
        // 获取用户详情 userId
        getUserInfoByUserId: '/user/admin/user/common/getUserInfoByUserId',
        // 获取用户订单列表 userId
        getOrderListByUserId: '/shop/admin/order/common/getOrderListByUserId',
        // 获取用户订单详情 orderNo userId    
        getOrderInfoByOrderNoAndUserId: '/shop/admin/order/common/getOrderInfoByOrderNoAndUserId',
        // 所有订单相关
        // 获取所有订单 （搜索：orderNo, type,status,name,phone）
        getOrderListPage: '/shop/admin/order/common/getOrderListPage', 
        // 获取线上订单详情 orderNo
        getOrderInfoByOrderNo: '/shop/admin/order/common/getOrderInfoByOrderNo',
        // 订单填入物流信息 （type,transNo,transName, transTime, orderNo）
        updateTransTime: '/shop/admin/order/common/updateTransTime',
        // 订单 完成 售后/退款  status orderNo userId
        updateAfterStatus: '/shop/admin/order/common/updateAfterStatus', 
        // 财务 
        // erp获取线上所有发票 搜索条件orderNo","nickName","phone","totalMoney   
        getInvoiceListPage: '/shop/admin/order/common/getInvoiceListPage',
        // erp填入发票物流信息  invoiceNo,transType,transName,transNo,invoiceId    
        updateInvoiceTrans: '/shop/admin/order/common/updateInvoiceTrans',
        // erp获取线上发票详情,物流信息   invoiceId,id,orderNo  
        getInvoiceInfo: '/shop/admin/order/common/getInvoiceInfo',              
    }
};
