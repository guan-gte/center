export default [
    {
        path: '/',
        redirect: '/welcome'
    },
    {
        path: '/login',
        component: resolve => require(['../view/login/Login.vue'], resolve)
    },
    {
        path: '/changePwd',
        component: resolve => require(['../view/login/ChangePwd.vue'], resolve)
    },
    {
        path: '/',
        component: resolve => require(['../common/Home.vue'], resolve),
        meta: { title: '自述文件' },
        children:[
            {
                path: '/welcome',
                component: resolve => require(['../view/Welcome.vue'], resolve),
                meta: { title: '欢迎!' }
            },
/*********************  Master  **********************************/
            {
                path: '/master/admin/masterAdmin',
                component: resolve => require(['../view/master/admin/MasterAdmin.vue'], resolve),
                meta: { title: '超级管理员' }
            },
            {
                path: '/master/auth/auth',
                component: resolve => require(['../view/master/auth/Auth.vue'], resolve),
                meta: { title: '权限管理' }
            },
            {
                path: '/master/authGroup/authGroup',
                component: resolve => require(['../view/master/authGroup/AuthGroup.vue'], resolve),
                meta: { title: '权限组管理' }
            },
            {
                path: '/master/menu/menu',
                component: resolve => require(['../view/master/menu/Menu.vue'], resolve),
                meta: { title: '菜单管理' }
            },
/*********************  Plat  **********************************/
            // 基本信息维护
            {
                path: '/plat/base/members/grade',
                component: resolve => require(['../view/plat/base/members/Grade.vue'], resolve),
                meta: { title: '会员级别' }
            },
            {
                path: '/plat/base/customer/customer',
                component: resolve => require(['../view/plat/base/customer/Customer.vue'], resolve),
                meta: { title: '客户基本信息' }
            },
            // 仓管业务管理
                // 客户订单列表
            {
                path: '/plat/store/customerOrder/order',
                component: resolve => require(['../view/plat/store/customerOrder/Order.vue'], resolve),
                meta: { title: '客户订单列表' }
            },
                //库存足够 订单详情
            {
                path: '/plat/store/customerOrder/orderDetail',
                component: resolve => require(['../view/plat/store/customerOrder/OrderDetail.vue'], resolve),
                meta: { title: '订单详情' }
            },
                // 单品类库存不足 订单详情
            {
                path: '/plat/store/customerOrder/supplierOrderDetail',
                component: resolve => require(['../view/plat/store/customerOrder/SupplierOrderDetail.vue'], resolve),
                meta: { title: '订单详情' }
            },
                // 供应商和仓库发货 订单详情
            {
                path: '/plat/store/customerOrder/mixOrderDetail',
                component: resolve => require(['../view/plat/store/customerOrder/MixOrderDetail.vue'], resolve),
                meta: { title: '订单详情' }
            },
                // 仓库管理
            {
                path: '/plat/store/storeGoods/storeGoods',
                component: resolve => require(['../view/plat/store/storeGoods/StoreGoods.vue'], resolve),
                meta: { title: '仓库管理' }
            },
                // 入库管理
            {
                path: '/plat/store/storeIn/storeIn',
                component: resolve => require(['../view/plat/store/storeIn/StoreIn.vue'], resolve),
                meta: { title: '入库管理' }
            },
            {
                path: '/plat/store/storeIn/storeInDetail',
                component: resolve => require(['../view/plat/store/storeIn/StoreInDetail.vue'], resolve),
                meta: { title: '入库详情' }
            },
            // 供应链管理
                //供应链采购订单列表
            {
                path: '/plat/supplyChain/purchaseOrder/purchaseOrder',
                component: resolve => require(['../view/plat/supplyChain/purchaseOrder/PurchaseOrder.vue'], resolve),
                meta: { title: '采购订单列表' }
            },
            {
                path: '/plat/supplyChain/purchaseOrder/purchaseAdd',
                component: resolve => require(['../view/plat/supplyChain/purchaseOrder/PurchaseAdd.vue'], resolve),
                meta: { title: '添加采购订单' }
            },
            {
                path: '/plat/supplyChain/purchaseOrder/purchaseDetail',
                component: resolve => require(['../view/plat/supplyChain/purchaseOrder/PurchaseDetail.vue'], resolve),
                meta: { title: '采购订单详情' }
            },
            
                //供应链采购订单审核管理（供应链主管）
            {
                path: '/plat/supplyChain/purchaseAudit/purchaseAudit',
                component: resolve => require(['../view/plat/supplyChain/purchaseAudit/PurchaseAudit.vue'], resolve),
                meta: { title: '采购订单审核列表' }
            },
            {
                path: '/plat/supplyChain/purchaseAudit/auditDetail',
                component: resolve => require(['../view/plat/supplyChain/purchaseAudit/AuditDetail.vue'], resolve),
                meta: { title: '采购订单审核详情' }
            },  
                // 线下订单采购列表
            {
                path: '/plat/supplyChain/offOrderPurchase/offOrderPurchase',
                component: resolve => require(['../view/plat/supplyChain/offOrderPurchase/OffOrderPurchase.vue'], resolve),
                meta: { title: '线下订单采购列表' }
            },
            {
                path: '/plat/supplyChain/offOrderPurchase/purchaseDetail',
                component: resolve => require(['../view/plat/supplyChain/offOrderPurchase/PurchaseDetail.vue'], resolve),
                meta: { title: '线下采购订单详情' }
            },
                // 仓库列表
            {
                path: '/plat/supplyChain/store/store',
                component: resolve => require(['../view/plat/supplyChain/store/Store.vue'], resolve),
                meta: { title: '仓库列表' }
            },
            {
                path: '/plat/supplyChain/store/storeGoodsEdit',
                component: resolve => require(['../view/plat/supplyChain/store/StoreGoodsEdit.vue'], resolve),
                meta: { title: '仓库产品详情' }
            },              
                //子公司采购订单确认管理（供应链主管）
            {
                path: '/plat/supplyChain/instOrderConfirm/instOrderConfirm',
                component: resolve => require(['../view/plat/supplyChain/instOrderConfirm/InstOrderConfirm.vue'], resolve),
                meta: { title: '子公司采购订单确认列表' }
            },
            {
                path: '/plat/supplyChain/instOrderConfirm/confirm',
                component: resolve => require(['../view/plat/supplyChain/instOrderConfirm/Confirm.vue'], resolve),
                meta: { title: '子公司采购订单确认' }
            },
            // app后台管理
                //banner
            {
                path: '/plat/model/banner/banner',
                component: resolve => require(['../view/plat/model/banner/Banner.vue'], resolve),
                meta: { title: 'banner管理' }
            },
                //分类管理
            {
                path: '/plat/classify/classify',
                component: resolve => require(['../view/plat/model/classify/Classify.vue'], resolve),
                meta: { title: '分类管理' }
            },
            {
                path: '/plat/classify/classifyDetail',
                component: resolve => require(['../view/plat/model/classify/ClassifyDetail.vue'], resolve),
                meta: { title: '分类详情' }
            },
            // 总管理员
                // 人事权限
            {
                path: '/plat/admin/personnelAuth/personnelAuth',
                component: resolve => require(['../view/plat/admin/personnelAuth/PersonnelAuth.vue'], resolve),
                meta: { title: '人事权限管理' }
            },
            // 分公司管理
            {
                path: '/plat/admin/inst/InstList',
                component: resolve => require(['../view/plat/admin/inst/InstList.vue'], resolve),
                meta: { title: '分公司列表' }
            },
            // 员工管理
            {
                path: '/plat/personnel/personnel/employees',
                component: resolve => require(['../view/plat/personnel/personnel/Employees.vue'], resolve),
                meta: { title: '员工列表' }
            },
            // 财务管理
                // 订单列表
            {
                path: '/plat/financial/order/order',
                component: resolve => require(['../view/plat/financial/order/Order.vue'], resolve),
                meta: { title: '订单列表' }
            },
/*********************  Inst  **********************************/
            // 基本信息维护
            {
                path: '/inst/base/personalLabel/label',
                component: resolve => require(['../view/inst/base/personalLabel/Label.vue'], resolve),
                meta: { title: '个人标签' }
            },
            // 客户服务
            {
                path: '/inst/customer/myCustomer/myCustomer',
                component: resolve => require(['../view/inst/customer/myCustomer/MyCustomer.vue'], resolve),
                meta: { title: '我的客户' }
            },
            {
                path: '/inst/customer/instCustomer/instCustomer',
                component: resolve => require(['../view/inst/customer/instCustomer/InstCustomer.vue'], resolve),
                meta: { title: '下属客户' }
            },
            {
                path: '/inst/customer/groupCustomer/groupCustomer',
                component: resolve => require(['../view/inst/customer/groupCustomer/GroupCustomer.vue'], resolve),
                meta: { title: '下属客户' }
            },
            {
                path: '/inst/customer/comCustomer/comCustomer',
                component: resolve => require(['../view/inst/customer/comCustomer/ComCustmer.vue'], resolve),
                meta: { title: '公海客户' }
            },
                // 销售经理客户详情
            {
                path: '/inst/customer/commonDetail/commonTab',
                component: resolve => require(['../view/inst/customer/commonDetail/CommonTab.vue'], resolve),
                meta: { title: '客户详情' }
            },
            {
                path: '/inst/customer/commonDetail/returnInfo/returnDetail',
                component: resolve => require(['../view/inst/customer/commonDetail/returnInfo/ReturnDetail.vue'], resolve),
                meta: { title: '回访记录详情' }
            },
            {
                path: '/inst/customer/commonDetail/orderInfo/orderDetail',
                component: resolve => require(['../view/inst/customer/commonDetail/orderInfo/OrderDetail.vue'], resolve),
                meta: { title: '订单信息详情' }
            },
            {
                path: '/inst/customer/commonDetail/testRecord/testRecoAdd',
                component: resolve => require(['../view/inst/customer/commonDetail/testRecord/TestRecoAdd.vue'], resolve),
                meta: { title: '新增试机单' }
            },
            {
                path: '/inst/customer/commonDetail/testRecord/testRecoDetail',
                component: resolve => require(['../view/inst/customer/commonDetail/testRecord/TestRecoDetail.vue'], resolve),
                meta: { title: '试机单详情' }
            },
                // 销售组长客户详情
            {
                path: '/inst/customer/groupDetail/commonTab',
                component: resolve => require(['../view/inst/customer/groupDetail/CommonTab.vue'], resolve),
                meta: { title: '客户详情' }
            },
            {
                path: '/inst/customer/groupDetail/returnInfo/returnDetail',
                component: resolve => require(['../view/inst/customer/groupDetail/returnInfo/ReturnDetail.vue'], resolve),
                meta: { title: '回访记录详情' }
            },
            {
                path: '/inst/customer/groupDetail/orderInfo/orderDetail',
                component: resolve => require(['../view/inst/customer/groupDetail/orderInfo/OrderDetail.vue'], resolve),
                meta: { title: '订单信息详情' }
            },
            {
                path: '/inst/customer/groupDetail/testRecord/testRecoAdd',
                component: resolve => require(['../view/inst/customer/groupDetail/testRecord/TestRecord.vue'], resolve),
                meta: { title: '新增试机单' }
            },
            {
                path: '/inst/customer/groupDetail/testRecord/testRecoDetail',
                component: resolve => require(['../view/inst/customer/groupDetail/testRecord/TestRecoDetail.vue'], resolve),
                meta: { title: '试机单详情' }
            },
                // 销售总监客户详情
            {
                path: '/inst/customer/instCustDetail/commonTab',
                component: resolve => require(['../view/inst/customer/instCustDetail/CommonTab.vue'], resolve),
                meta: { title: '客户详情' }
            },
            {
                path: '/inst/customer/instCustDetail/returnInfo/returnDetail',
                component: resolve => require(['../view/inst/customer/instCustDetail/returnInfo/ReturnDetail.vue'], resolve),
                meta: { title: '回访记录详情' }
            },
            {
                path: '/inst/customer/instCustDetail/orderInfo/orderDetail',
                component: resolve => require(['../view/inst/customer/instCustDetail/orderInfo/OrderDetail.vue'], resolve),
                meta: { title: '订单信息详情' }
            },
                // 公海客户详情
            {
                path: '/inst/customer/comCustDetail/commonTab',
                component: resolve => require(['../view/inst/customer/comCustDetail/CommonTab.vue'], resolve),
                meta: { title: '客户详情' }
            },
            {
                path: '/inst/customer/comCustDetail/returnInfo/returnDetail',
                component: resolve => require(['../view/inst/customer/comCustDetail/returnInfo/ReturnDetail.vue'], resolve),
                meta: { title: '回访记录详情' }
            },
            {
                path: '/inst/customer/comCustDetail/orderInfo/orderDetail',
                component: resolve => require(['../view/inst/customer/comCustDetail/orderInfo/OrderDetail.vue'], resolve),
                meta: { title: '订单信息详情' }
            },
            {
                path: '/inst/customer/comCustDetail/testRecord/testRecoDetail',
                component: resolve => require(['../view/inst/customer/comCustDetail/testRecord/TestRecoDetail.vue'], resolve),
                meta: { title: '试机单详情' }
            },
            // 商城管理（商城后台使用）!!!!!!!!!!!!!!!!!!!!!!!!!! start
                // 用户管理
            {
                path: '/inst/mall/user/user',
                component: resolve => require(['../view/inst/mall/user/User.vue'], resolve),
                meta: { title: '用户列表' }
            },
            {
                path: '/inst/mall/userDetail/commonTab',
                component: resolve => require(['../view/inst/mall/userDetail/CommonTab.vue'], resolve),
                meta: { title: '用户详情' }
            },
            {
                path: '/inst/mall/userDetail/orderInfo/orderDetail',
                component: resolve => require(['../view/inst/mall/userDetail/orderInfo/OrderDetail.vue'], resolve),
                meta: { title: '用户订单详情' }
            },
                //所有订单记录
            {
                path: '/inst/mall/order/order',
                component: resolve => require(['../view/inst/mall/order/Order.vue'], resolve),
                meta: { title: '订单列表' }
            },
            {
                path: '/inst/mall/order/orderDetail',
                component: resolve => require(['../view/inst/mall/order/OrderDetail.vue'], resolve),
                meta: { title: '订单详情' }
            },
                // 发票申请记录 （财务权限）
            {
                path: '/inst/mall/financial/invoice/invoiceApply',
                component: resolve => require(['../view/inst/mall/financial/invoice/InvoiceApply.vue'], resolve),
                meta: { title: '发票申请记录' }
            }, 
            {
                path: '/inst/mall/financial/invoice/invoiceDetail',
                component: resolve => require(['../view/inst/mall/financial/invoice/InvoiceDetail.vue'], resolve),
                meta: { title: '发票申请详情' }
            }, 
            // 商城管理（商城后台使用）!!!!!!!!!!!!!!!!!!!!!!!!!! end
            //回访及订单
                //回访记录
            {
                path: '/inst/visitAndOrder/visitRecord/visitRecord',
                component: resolve => require(['../view/inst/visitAndOrder/visitRecord/VisitRecord.vue'], resolve),
                meta: { title: '回访记录' }
            },
                // 订单记录
            {
                path: '/inst/visitAndOrder/orderRecord/orderRecord',
                component: resolve => require(['../view/inst/visitAndOrder/orderRecord/OrderRecord.vue'], resolve),
                meta: { title: '订单记录' }
            },
            {
                path: '/inst/visitAndOrder/orderRecord/orderAdd',
                component: resolve => require(['../view/inst/visitAndOrder/orderRecord/OrderAdd.vue'], resolve),
                meta: { title: '新增订单' }
            },
            {
                path: '/inst/visitAndOrder/orderRecord/onlineOrder',
                component: resolve => require(['../view/inst/visitAndOrder/orderRecord/OnlineOrder.vue'], resolve),
                meta: { title: '线上订单详情' }
            },
            {
                path: '/inst/visitAndOrder/orderRecord/offlineOrder',
                component: resolve => require(['../view/inst/visitAndOrder/orderRecord/OfflineOrder.vue'], resolve),
                meta: { title: '线下订单详情' }
            },
                // 退款审批列表（销售经理）
            {
                path: '/inst/visitAndOrder/refundExam/examRecords',
                component: resolve => require(['../view/inst/visitAndOrder/refundExam/ExamRecords.vue'], resolve),
                meta: { title: '退款审批列表' }
            },
            {
                path: '/inst/visitAndOrder/refundExam/examDetail',
                component: resolve => require(['../view/inst/visitAndOrder/refundExam/ExamDetail.vue'], resolve),
                meta: { title: '退款审批详情' }
            },
                // 退款审批列表（销售组长）
            {
                path: '/inst/visitAndOrder/refundExamByLeader/examRecords',
                component: resolve => require(['../view/inst/visitAndOrder/refundExamByLeader/ExamRecords.vue'], resolve),
                meta: { title: '退款审批列表' }
            },
            {
                path: '/inst/visitAndOrder/refundExamByLeader/examDetail',
                component: resolve => require(['../view/inst/visitAndOrder/refundExamByLeader/ExamDetail.vue'], resolve),
                meta: { title: '退款审批详情' }
            },
                // 退款审批列表（销售总监）
            {
                path: '/inst/visitAndOrder/refundExamByDirector/ExamRecords',
                component: resolve => require(['../view/inst/visitAndOrder/refundExamByDirector/ExamRecords.vue'], resolve),
                meta: { title: '退款审批列表' }
            },
            {
                path: '/inst/visitAndOrder/refundExamByDirector/examDetail',
                component: resolve => require(['../view/inst/visitAndOrder/refundExamByDirector/ExamDetail.vue'], resolve),
                meta: { title: '退款审批详情' }
            },
                // 订单审批列表（销售组长）
            {
                path: '/inst/visitAndOrder/exam/examineRecord',
                component: resolve => require(['../view/inst/visitAndOrder/exam/ExamineRecord.vue'], resolve),
                meta: { title: '审批列表' }
            },
            {
                path: '/inst/visitAndOrder/exam/examineDetail',
                component: resolve => require(['../view/inst/visitAndOrder/exam/ExamineDetail.vue'], resolve),
                meta: { title: '审批详情' }
            },
                // 订单审批列表（销售总监）
            {
                path: '/inst/visitAndOrder/examByLeader/examineRecord',
                component: resolve => require(['../view/inst/visitAndOrder/examByLeader/ExamineRecord.vue'], resolve),
                meta: { title: '审批列表' }
            },
            {
                path: '/inst/visitAndOrder/examByLeader/examineDetail',
                component: resolve => require(['../view/inst/visitAndOrder/examByLeader/ExamineDetail.vue'], resolve),
                meta: { title: '审批详情' }
            },
                // 认领申请列表（销售）
            {
                path: '/inst/visitAndOrder/saleClaim/saleClaim',
                component: resolve => require(['../view/inst/visitAndOrder/saleClaim/SaleClaim.vue'], resolve),
                meta: { title: '认领申请列表' }
            },
            {
                path: '/inst/visitAndOrder/saleClaim/saleClaimDetail',
                component: resolve => require(['../view/inst/visitAndOrder/saleClaim/SaleClaimDetail.vue'], resolve),
                meta: { title: '认领审批详情' }
            },
                // 认领申请列表（销售总监）
            {
                path: '/inst/visitAndOrder/saleClaimLeader/saleClaimLeader',
                component: resolve => require(['../view/inst/visitAndOrder/saleClaimLeader/SaleClaimLeader.vue'], resolve),
                meta: { title: '认领申请列表' }
            },
            {
                path: '/inst/visitAndOrder/saleClaimLeader/saleClaimDetail',
                component: resolve => require(['../view/inst/visitAndOrder/saleClaimLeader/SaleClaimDetail.vue'], resolve),
                meta: { title: '认领审批详情' }
            },
            // 财务管理
                //订单确认列表
            {
                path: '/inst/financial/order/order',
                component: resolve => require(['../view/inst/financial/order/Order.vue'], resolve),
                meta: { title: '订单确认列表' }
            },
            {
                path: '/inst/financial/order/orderDetail',
                component: resolve => require(['../view/inst/financial/order/OrderDetail.vue'], resolve),
                meta: { title: '订单确认' }
            },
                // 售后退款打款
            {
                path: '/inst/financial/afterSales/afterSales',
                component: resolve => require(['../view/inst/financial/afterSales/AfterSales.vue'], resolve),
                meta: { title: '售后退款打款' }
            },
            {
                path: '/inst/financial/afterSales/afterSalesDetail',
                component: resolve => require(['../view/inst/financial/afterSales/AfterSalesDetail.vue'], resolve),
                meta: { title: '退款详情' }
            },
            // 后勤总务管理
                //仓库商品管理
            {
                path: '/inst/logistics/store/storeGoods',
                component: resolve => require(['../view/inst/logistics/store/StoreGoods.vue'], resolve),
                meta: { title: '仓库商品列表' }
            },
            {
                path: '/inst/logistics/store/storeGoodsEdit',
                component: resolve => require(['../view/inst/logistics/store/StoreGoodsEdit.vue'], resolve),
                meta: { title: '仓库商品详情' }
            },
            {
                path: '/inst/logistics/store/purchaseOrderAdd',
                component: resolve => require(['../view/inst/logistics/store/PurchaseOrderAdd.vue'], resolve),
                meta: { title: '订单采购' }
            },
                //采购列表
            {
                path: '/inst/logistics/purchase/purchaseOrder',
                component: resolve => require(['../view/inst/logistics/purchase/PurchaseOrder.vue'], resolve),
                meta: { title: '采购列表' }
            },
            {
                path: '/inst/logistics/purchase/purchaseDetail',
                component: resolve => require(['../view/inst/logistics/purchase/PurchaseDetail.vue'], resolve),
                meta: { title: '采购详情' }
            },
            // 业务统计
                //我的业务
            {
                path: '/inst/statistics/myBusiness/myBusiness',
                component: resolve => require(['../view/inst/statistics/myBusiness/MyBusiness.vue'], resolve),
                meta: { title: '我的业务统计' }
            },
                //小组业务
            {
                path: '/inst/statistics/teamBusiness/teamBusiness',
                component: resolve => require(['../view/inst/statistics/teamBusiness/TeamBusiness.vue'], resolve),
                meta: { title: '小组业务统计' }
            },
                //业务部署（销售总监）
            {
                path: '/inst/statistics/deployBusiByLeader/deployBusiness',
                component: resolve => require(['../view/inst/statistics/deployBusiByLeader/DeployBusiness.vue'], resolve),
                meta: { title: '业务部署' }
            },
            {
                path: '/inst/statistics/deployBusiByLeader/deployDetail',
                component: resolve => require(['../view/inst/statistics/deployBusiByLeader/DeployDetail.vue'], resolve),
                meta: { title: '小组业务详情' }
            },
                //业务部署（销售组长）
            {
                path: '/inst/statistics/deployBusi/deployBusi',
                component: resolve => require(['../view/inst/statistics/deployBusi/DeployBusiness.vue'], resolve),
                meta: { title: '业务部署' }
            },
            // 仓库管理
                //客户订单列表
            {
                path: '/inst/store/customerOrder/customerOrder',
                component: resolve => require(['../view/inst/store/customerOrder/CustomerOrder.vue'], resolve),
                meta: { title: '客户订单列表' }
            },
            {
                path: '/inst/store/customerOrder/orderDetail',
                component: resolve => require(['../view/inst/store/customerOrder/OrderDetail.vue'], resolve),
                meta: { title: '客户订单详情' }
            },
                //仓库商品列表
            {
                path: '/inst/store/storeGoods/storeGoods',
                component: resolve => require(['../view/inst/store/storeGoods/StoreGoods.vue'], resolve),
                meta: { title: '仓库产品列表' }
            },
                //入库管理
            {
                path: '/inst/store/storeIn/storeIn',
                component: resolve => require(['../view/inst/store/storeIn/StoreIn.vue'], resolve),
                meta: { title: '入库单列表' }
            },
            {
                path: '/inst/store/storeIn/storeInDetail',
                component: resolve => require(['../view/inst/store/storeIn/StoreInDetail.vue'], resolve),
                meta: { title: '入库单详情' }
            },
            // 我的客户（售后）
                // 订单记录
            // {
            //     path: '/inst/afterSales/order/order',
            //     component: resolve => require(['../view/inst/afterSales/order/Order.vue'], resolve),
            //     meta: { title: '订单记录' }
            // },
            // ********************************** New Start **********************************
            // ********************************** inst Start *********************************
            // 销售端  ------------------------->>
            {
                path: '/inst/salesDepart/client/myClient/Client',
                component: resolve => require(['../view/inst/salesDepart/client/myClient/Client.vue'], resolve),
                meta: { title: '我的客户列表' }
            },
            {
                path: '/inst/salesDepart/client/myClient/commonTab',
                component: resolve => require(['../view/inst/salesDepart/client/myClient/CommonTab.vue'], resolve),
                meta: { title: '我的客户信息' }
            },
            // **********************************   inst End **********************************
            // **********************************  plat Start *********************************
            // 供应链端  ----------------------->>
                // 商品分类及场景
            {
                path: '/plat/supplyDepart/classifyAndScene/commonTab',
                component: resolve => require(['../view/plat/supplyDepart/classifyAndScene/CommonTab.vue'], resolve),
                meta: { title: '商品分类及场景' }
            },
            {
                path: '/plat/supplyDepart/classifyAndScene/scene/detail',
                component: resolve => require(['../view/plat/supplyDepart/classifyAndScene/scene/Detail.vue'], resolve),
                meta: { title: '应用场景详情' }
            },
            {
                path: '/plat/supplyDepart/classifyAndScene/equClassify/detail',
                component: resolve => require(['../view/plat/supplyDepart/classifyAndScene/equClassify/Detail.vue'], resolve),
                meta: { title: '设备一级分类详情' }
            },
            {
                path: '/plat/supplyDepart/classifyAndScene/equClassify/secDetail',
                component: resolve => require(['../view/plat/supplyDepart/classifyAndScene/equClassify/SecDetail.vue'], resolve),
                meta: { title: '设备二级分类详情' }
            },
            {
                path: '/plat/supplyDepart/classifyAndScene/partsClassify/detail',
                component: resolve => require(['../view/plat/supplyDepart/classifyAndScene/partsClassify/Detail.vue'], resolve),
                meta: { title: '配件一级分类详情' }
            },
                //供应商链管理
            {
                path: '/plat/supplyDepart/supplyChain/brand/brand',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/brand/Brand.vue'], resolve),
                meta: { title: '品牌管理' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/supplier/supplier',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/supplier/Supplier.vue'], resolve),
                meta: { title: '供应商管理' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/supplier/supplierAdd',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/supplier/SupplierAdd.vue'], resolve),
                meta: { title: '添加供应商' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/supplier/supplierEdit',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/supplier/SupplierEdit.vue'], resolve),
                meta: { title: '编辑供应商' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/equGoods/goodsAdd',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/equGoods/GoodsAdd.vue'], resolve),
                meta: { title: '新增设备' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/equGoods/goodsEdit',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/equGoods/GoodsEdit.vue'], resolve),
                meta: { title: '编辑设备' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/partsGoods/goodsAdd',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/partsGoods/GoodsAdd.vue'], resolve),
                meta: { title: '新增配件' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/partsGoods/goodsEdit',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/partsGoods/GoodsEdit.vue'], resolve),
                meta: { title: '编辑配件' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/goods',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/Goods.vue'], resolve),
                meta: { title: '产品管理' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/equGoods/equDetail',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/equGoods/EquDetail.vue'], resolve),
                meta: { title: '设备产品详情' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/partsGoods/partDetail',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/partsGoods/PartDetail.vue'], resolve),
                meta: { title: '配件产品详情' }
            },
                // 库存产品管理
            {
                path: '/plat/supplyDepart/storeGoods/storeGoods/goods',
                component: resolve => require(['../view/plat/supplyDepart/storeGoods/storeGoods/Goods.vue'], resolve),
                meta: { title: '库存产品列表' }
            },
            {
                path: '/plat/supplyDepart/storeGoods/storeGoods/purGoods',
                component: resolve => require(['../view/plat/supplyDepart/storeGoods/storeGoods/PurGoods.vue'], resolve),
                meta: { title: '采购商品' }
            },
            {
                path: '/plat/supplyDepart/storeGoods/storeGoods/equDetail',
                component: resolve => require(['../view/plat/supplyDepart/storeGoods/storeGoods/EquDetail.vue'], resolve),
                meta: { title: '库存产品设备详情' }
            },
            {
                path: '/plat/supplyDepart/storeGoods/storeGoods/partDetail',
                component: resolve => require(['../view/plat/supplyDepart/storeGoods/storeGoods/PartDetail.vue'], resolve),
                meta: { title: '库存产品配件详情' }
            },
                // 专员
            {
                path: '/plat/supplyDepart/supplyChain/goods/uploadList/upload',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/uploadList/Upload.vue'], resolve),
                meta: { title: '我的上传列表' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/uploadList/equDetail',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/uploadList/EquDetail.vue'], resolve),
                meta: { title: '上传产品设备详情' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/goods/uploadList/partDetail',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/goods/uploadList/PartDetail.vue'], resolve),
                meta: { title: '上传产品配件详情' }
            },
                // 主管
            {
                path: '/plat/supplyDepart/supplyChain/auditFirst/audit',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/auditFirst/Audit.vue'], resolve),
                meta: { title: '产品上传审批列表' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/auditFirst/equDetail',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/auditFirst/EquDetail.vue'], resolve),
                meta: { title: '设备产品审批详情' }
            },
            {
                path: '/plat/supplyDepart/supplyChain/auditFirst/partDetail',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/auditFirst/PartDetail.vue'], resolve),
                meta: { title: '配件产品审批详情' }
            },
                // 总监
            {
                path: '/plat/supplyDepart/supplyChain/auditSecond/audit',
                component: resolve => require(['../view/plat/supplyDepart/supplyChain/auditSecond/Audit.vue'], resolve),
                meta: { title: '产品上传审批列表' }
            },
            // 网销端  ----------------------->>
            {
                path: '/plat/netSalesDepart/BIManagement/CPDetails',
                component: resolve => require(['../view/plat/netSalesDepart/BIManagement/CPDetails.vue'], resolve),
                meta: { title: '分类图片详情' }
            },
            {
                path: '/plat/netSalesDepart/BIManagement/CPManagement',
                component: resolve => require(['../view/plat/netSalesDepart/BIManagement/CPManagement.vue'], resolve),
                meta: { title: '分类图片管理' }
            },
            {
                path: '/plat/netSalesDepart/BIManagement/CStatus',
                component: resolve => require(['../view/plat/netSalesDepart/BIManagement/Classificationstatus.vue'], resolve),
                meta: { title: '分类开启状态管理' }
            },
            {
                path: 'DTManagement',
                component: resolve => require(['../view/plat/netSalesDepart/BIManagement/DetailedTemplateManagement.vue'], resolve),
                meta: { title: '详情模板管理' }
            },
            {
                path: 'NTemplate',
                component: resolve => require(['../view/plat/netSalesDepart/BIManagement/NewTemplate.vue'], resolve),
                meta: { title: '新增模板' }
            },
            {
                path: 'TDetails',
                component: resolve => require(['../view/plat/netSalesDepart/BIManagement/TemplateDetails.vue'], resolve),
                meta: { title: '模板详情' }
            },
            {
                path: 'ProductList',
                component: resolve => require(['../view/plat/netSalesDepart/Commoditymanagement/ProductList/ProductList.vue'], resolve),
                meta: { title: '产品列表' }
            },
            {
                path: 'UploadMall',
                component: resolve => require(['../view/plat/netSalesDepart/Commoditymanagement/ProductList/UploadMall/UploadtoMall.vue'], resolve),
                meta: { title: '上传至商城' }
            },
            {
                path: 'MallInformation',
                component: resolve => require(['../view/plat/netSalesDepart/Commoditymanagement/ProductList/UploadMall/MallInformation.vue'], resolve),
                meta: { title: '商城信息' }
            },
            {
                path: 'MPList',
                component: resolve => require(['../view/plat/netSalesDepart/Commoditymanagement/MallProductList/MallProductList.vue'], resolve),
                meta: { title: '商城产品列表' }
            },
            {
                path: 'SeeDetails',
                component: resolve => require(['../view/plat/netSalesDepart/Commoditymanagement/MallProductList/SeeDetails.vue'], resolve),
                meta: { title: '商城产品详情' }
            },
            {
                path: 'BIMallProducts',
                component: resolve => require(['../view/plat/netSalesDepart/Commoditymanagement/ProductList/UploadMall/BIMallProducts.vue'], resolve),
                meta: { title: '商城产品基本信息' }
            },
            {
                path: 'opened',
                component: resolve => require(['../view/plat/netSalesDepart/Commoditymanagement/MallProductList/Opened.vue'], resolve),
                meta: { title: '已开启' }//开启状态
            },
            {

                path: 'Screat',
                component: resolve => require(['../view/Screat.vue'], resolve),
                meta: { title: '已开启' }//开启状态
            },

            // **********************************   plat End **********************************
            // **********************************   New  End **********************************

/*********************  Test  **********************************/
            {
                path: '/test',
                component: resolve => require(['../view/Test.vue'], resolve),
                meta: { title: 'hello world' }
            },
            {
                path: '/ckEditor',
                component: resolve => require(['../view/CkEditor.vue'], resolve),
                meta: { title: 'ckEditor' }
            },
            // base
            {
                path: '/icon',
                component: resolve => require(['../view/base/Icon.vue'], resolve),
                meta: { title: 'hello world' }
            },
            {
                path: '/table',
                component: resolve => require(['../view/base/BaseTable.vue'], resolve),
                meta: { title: '基础表格' }
            },
            {
                path: '/tabs',
                component: resolve => require(['../view/base/Tabs.vue'], resolve),
                meta: { title: 'tab选项卡' }
            },
            {
                path: '/form',
                component: resolve => require(['../view/base/BaseForm.vue'], resolve),
                meta: { title: '基本表单' }
            },
            {
                // 富文本编辑器组件
                path: '/editor',
                component: resolve => require(['../view/base/VueEditor.vue'], resolve),
                meta: { title: '富文本编辑器' }
            },
            {
                // markdown组件
                path: '/markdown',
                component: resolve => require(['../view/base/Markdown.vue'], resolve),
                meta: { title: 'markdown编辑器' }
            },
            {
                // 图片上传组件
                path: '/upload',
                component: resolve => require(['../view/base/Upload.vue'], resolve),
                meta: { title: '文件上传' }
            },
            {
                // vue-schart组件
                path: '/charts',
                component: resolve => require(['../view/base/BaseCharts.vue'], resolve),
                meta: { title: 'schart图表' }
            },
            {
                // 拖拽列表组件
                path: '/drag',
                component: resolve => require(['../view/base/DragList.vue'], resolve),
                meta: { title: '拖拽列表' }
            },
            {
                // 权限页面
                path: '/permission',
                component: resolve => require(['../view/base/Permission.vue'], resolve),
                meta: { title: '权限测试', permission: true }
            },
            {
                path: '/404',
                component: resolve => require(['../view/base/404.vue'], resolve),
                meta: { title: '404' }
            },
            {
                path: '/403',
                component: resolve => require(['../view/base/403.vue'], resolve),
                meta: { title: '403' }
            }
        ]
    },
    {
        path: '*',
        redirect: '/404'
    }
]
