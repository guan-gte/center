<template>
    <!-- <Page :title="'测试'">
        <textarea id="editor" rows="10" cols="80"></textarea>
    </Page> -->
    <div id="video">
        <textarea id="editor" rows="10" cols="80"></textarea>
        <el-upload
          action="http://118.31.248.209:8610/plugsUpload/"
          list-type="picture-card"
          :on-preview="handlePictureCardPreview"
          :on-success="a"
          :on-remove="handleRemove">
          <i class="el-icon-plus"></i>
        </el-upload>
        <el-dialog :visible.sync="dialogVisible">
          <img width="100%" :src="dialogImageUrl" alt="">
        </el-dialog>
        <!-- 多图demo -->
        <el-upload
            action=""
            :accept="'image/*'"
            :file-list="form.imgList"
            list-type="picture-card"
            :on-remove="removeImgList"
            :http-request="uploadImgList"
            :before-upload="beforeUpload"
            :before-remove="beforeRemoveImg">
            <i class="el-icon-plus"></i>
        </el-upload>
    </div>
</template>

<script>

    import { isNumber, getTime, formatTime, uuid, containsString } from '../js/util';
    import setting from "../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);

    export default {
        extends: Sun.vuePage,
        name: 'video',
        data() {
            return {
              setting: setting,
              dialogImageUrl: '',
              dialogVisible: false,
              form: {
                imgList: []
              }
            }
        },
        created() {
            
        },
        activated () {
           
        },
        mounted () {
            console.log(CKEDITOR);
            CKEDITOR.replace("editor", {height: "300px", width: "100%", toolbar: "Full", allowedContent: true});
            var editor = CKEDITOR.instances.editor2;
        },
        methods: {
          // demo
          handleRemove(file, fileList) {
            console.log(file, fileList);
          },
          handlePictureCardPreview(file) {
            this.dialogImageUrl = file.url;
            this.dialogVisible = true;
          },
          a (file, fileList) {
            console.log(file);
            console.log(fileList);
          },
          // 多图demo----------------------------------------------------
          removeImgList (item) {
            Sun.post({
                url: Http.delMedia,
                loading: true,
                data: {id: item.id},
                success: (data) => {
                    Sun.showMsg('已删除');
                    this.form.imgList.forEach((value, index) => {
                        if (value.path === item.path) {
                            this.form.imgList.splice(index, 1);
                        }
                    });
                },fail: () => {
                    Sun.showError('删除失败');
                    // 获取图片列表
                    // this.getImgList();
                }
            });
          },
          beforeRemoveImg (file, fileList) {
              return this.$confirm(`确定移除？`);
          },
          // 店铺图片
          uploadImgList (param) {
            let vue = this;
            let loading = Sun.showActivity();
            let suffix = param.file.type.toString();
            let poi = suffix.indexOf('/');
            suffix = suffix.substring(++poi, suffix.length);
            let path = 'shop/goods/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
            co(function* () {
                param.onSuccess();
                Sun.hideActivity(loading);
                yield client.put(path, param.file);
                vue.form.imgList.push({
                    status: 'success',
                    uid: getTime(true),
                    url: setting.oss_http + path,
                    path: path,
                    name: param.file.name
                });
                console.log(vue.form.imgList)
            }).catch(function (err) {
                Sun.hideActivity(loading);
                Sun.showError('图片上传失败');
            });
          },
          beforeUpload (file) {
            // if (file.size / 1024 / 1024 > 2) {
            //     this.$message.error('上传图片大小不能超过 2MB!');
            //     return false;
            // }
            return true;
          },
          beforeRemoveImg (file, fileList) {
            return this.$confirm(`确定移除？`);
          }
        },
        destroyed () {
         
        }
    }

</script>

<style scoped>
    
</style>
