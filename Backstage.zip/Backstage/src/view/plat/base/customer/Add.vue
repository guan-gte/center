<template>
    <el-dialog title="添加" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="100px">
            <el-form-item required :label="type == 1 ? '客户标签' : '客户行业'">
                <el-input v-model="form.name"></el-input>
            </el-form-item>
            <!-- <el-form-item required label="启用状态">
                <el-switch v-model="form.status" active-color="#13ce66" inactive-color="#ddd"></el-switch>
            </el-form-item> -->
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                form: {}
            }
        },
        methods: {
            open () {
                this.form = {};
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.name) {
                    Sun.showError(this.type == 1 ? '请输入客户标签' : '请输入客户行业');
                    return;
                }
                this.form.type = this.type;
                // 新增
                Sun.post({
                    url: this.url.add,
                    data: this.form,
                    success: () => {
                        Sun.showMsg('已添加');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['show', 'callBack', 'type', 'url'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
