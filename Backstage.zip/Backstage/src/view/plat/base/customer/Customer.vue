<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true; type = 1" type="primary">新增客户标签</el-button>
            <el-button v-show="auth.add" @click="showAdd = true; type = 2" type="primary">新增客户行业</el-button>
            <div slot="type" slot-scope="data">{{data.row.type | formatType}}</div>
            <!-- <div slot="status" slot-scope="data">
                <el-switch @change="change(data.row)" v-model="data.row.status" disabled
                    :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div> -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.del" class="opreate-del" type="text" size="mini" @click="del(data.row)">删除</el-button>
            </div>
        </SunTable>
        <!--add-->
        <Add :type="type" :url="url" :show="showAdd"
                    :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></Add>
        <!--edit-->
        <Edit :type="type" :url="url" :id="id" :show="showEdit" :data="editData"
                    :callBack="(flag)=>{showEdit = false;if (flag) table.el.refresh()}"></Edit>
    </Page>
</template>

<script>
    import Add from './Add';
    import Edit from './Edit';    
    const url = {
        table: Http.plat.getLabelPage,
        add: Http.plat.addLabel,
        edit: Http.plat.editLabel,
        del: Http.plat.delLabel
    };
    export default {
        extends: Sun.vuePage,
        components: {Add, Edit},
        data() {
            return {
                auth: {
                    add: true,
                    edit: true,
                    del: true
                },
                url: url,
                showAdd: false,
                showEdit: false,
                type: '',
                id: '',
                editData: {},
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [   
                            {
                                title: '名称',
                                key: 'name'
                            },
                            {
                                title: '基本信息',
                                key: 'type',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '客户标签', value: '1'},
                                        {name: '客户行业', value: '2'},
                                        // {name: '客户来源', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '客户标签', value: '= 1'},
                                    {text: '客户行业', value: '= 2'},
                                    // {text: '客户来源', value: '= 3'}
                                ]
                            },       
                            // {
                            //     title: '启用状态',
                            //     key: 'status'
                            // },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        methods: {
            created () {
                Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
                Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
                Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            },
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
                this.id = item.id;
                this.type = item.type;
            },
            // 删除
            del (item) {
                Sun.confirm('提示', '确定要删除吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: {id: item.id},
                        success: () => {
                            Sun.showMsg('已删除！');
                            this.table.el.refresh();
                        }
                    });
                });
            },
            // 更改状态
            change (item) {

            }
        },
        filters: { 
            formatType (type) {
                if (type == 1) {
                    return '客户标签'
                }
                if (type == 2) {
                    return '客户行业'
                }
                if (type == 3) {
                    return '客户来源'
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
