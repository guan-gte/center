<template>
    <el-dialog title="编辑" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px">
            <el-form-item required label="会员级别">
                <el-input v-model="form.grade"></el-input>
            </el-form-item>
            <el-form-item required label="最低消费金额">
                <el-input v-model="form.lowestMoney"></el-input>
            </el-form-item>
            <el-form-item required label="折扣">
                <el-input v-model="form.discount"></el-input>
            </el-form-item>
            <el-form-item required label="启用状态">
                <el-switch v-model="form.status" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap} from "../../../../js/util";

    export default {
        data() {
            return {
                form: {}
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.grade) {
                    Sun.showError('请输入会员级别');
                    return;
                }
                if (!this.form.lowestMoney) {
                    Sun.showError('请输入最低消费金额');
                    return;
                }
                if (!this.form.discount) {
                    Sun.showError('请输入折扣');
                    return;
                }
                // Sun.post({
                //     url: Http.,
                //     data: this.form,
                //     success: () => {
                //         if (this.callBack) {
                //             this.callBack(true);
                //         }
                //     }
                // });
            }
        },
        props: ['data', 'show', 'callBack'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
