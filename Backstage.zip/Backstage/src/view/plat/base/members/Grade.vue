<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true" type="primary">新增会员级别</el-button>
            <div slot="status" slot-scope="data">
                <el-switch @change="change(data.row)" v-model="data.row.status" disabled
                    :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div>
            <!-- 暂时不需要 编辑 删除 -->
            <!-- <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.del" class="opreate-del" type="text" size="mini" @click="del(data.row)">删除</el-button>
            </div> -->
        </SunTable>
        <!--add-->
        <GradeAdd :url="url" :show="showAdd"
                    :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></GradeAdd>
        <!--edit-->
        <!-- <GradeEdit :url="url" :show="showEdit" :data="editData"
                    :callBack="(flag)=>{showEdit = false;if (flag) table.el.refresh()}"></GradeEdit> -->
    </Page>
</template>

<script>
    import GradeAdd from './GradeAdd';
    // import GradeEdit from './GradeEdit';    
    const url = {
        table: Http.common.getUserLevelList,
        add: Http.plat.addLevel,
        // edit: Http.master.editAuth,
        // del: Http.master.delAuth
    };
    export default {
        extends: Sun.vuePage,
        components: {GradeAdd},
        data() {
            return {
                auth: {
                    add: true
                    // edit: true,
                    // del: true
                },
                url: url,
                showAdd: false,
                // showEdit: false,
                editData: {},
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: false,
                        list: [
                            {
                                title: '会员级别',
                                key: 'name'
                            },
                            {
                                title: '启用状态',
                                key: 'status'
                            },
                            {
                                title: '最低消费金额',
                                key: 'money'
                            },
                            {
                                title: '折扣',
                                key: 'discount'
                            }
                            // {
                            //     title: '操作',
                            //     key: 'opreate'
                            // }
                        ]
                    }
                }
            }
        },
        methods: {
            created () {
                Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
                // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
                // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            },
            // 编辑
            // edit (item) {
            //     this.editData = item;
            //     this.showEdit = true;
            // },
            // 删除
            // del (item) {
            //     Sun.confirm('提示', '确定要删除此会员级别吗?', () => {
            //         Sun.showMsg('已删除！');
            //         this.table.el.refresh();
            //     });
            // },
            // 更改状态
            change (item) {

            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
