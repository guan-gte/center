<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true" type="primary">添加banner</el-button>
            <div slot="source" slot-scope="data"><img class="img" :key="data.row.source" v-lazy="parseImg(data.row.source, {x: 60})"/></div>
            <div slot="type" slot-scope="data">
                <span :style="{color: data.row.type == 1 ? '#32CD32' : '#F56C6C'}">{{data.row.type == 1 ? 'APP' : 'PC'}}</span>
            </div>
            <div slot="jumpType" slot-scope="data">{{data.row.jumpType | famateJumpType}}</div>
            <!-- <div slot="status" slot-scope="data">
                <el-switch @change="change(data.row)" v-model="data.row.status" disabled
                    :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div> -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.del" class="opreate-del" type="text" size="mini" @click="del(data.row)">删除</el-button>
            </div>
        </SunTable>
        <!--add-->
        <BannerAdd :url="url" :show="showAdd" :data="editData"
                    :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></BannerAdd>
        <!--edit-->
        <BannerEdit :url="url" :show="showEdit" :data="editData"
                    :callBack="(flag)=>{showEdit = false;if (flag) table.el.refresh()}"></BannerEdit>
    </Page>
</template>

<script>
    import BannerEdit from './BannerEdit';    
    import BannerAdd from './BannerAdd';    
    const url = {
        table: Http.plat.getBannerPage,
        add: Http.plat.addBanner,
        del: Http.plat.deleteBanner,
        edit: Http.plat.editBanner,
        getGoodsListByType: Http.inst.getGoodsListByType
    };
    export default {
        extends: Sun.vuePage,
        components: {BannerEdit, BannerAdd},
        data() {
            return {
                auth: {
                    add: true,
                    edit: true,
                    del: true
                },
                url: url,
                showAdd: false,
                showEdit: false,
                editData: {},
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '编号',
                                key: 'id'
                            },
                            {
                                title: '位置',
                                key: 'type',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: 'APP', value: '1'},
                                        {name: 'PC', value: '2'}
                                    ]
                                },
                                filter:[
                                    {text: 'APP', value: '= 1'},
                                    {text: 'PC', value: '= 2'}
                                ]
                            },
                            {
                                title: '跳转类型',
                                key: 'jumpType',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: [
                                //         {name: '无', value: '0'},
                                //         {name: '产品', value: '1'}
                                //     ]
                                // },
                                // filter:[
                                //     {text: '无', value: '= 0'},
                                //     {text: '产品', value: '= 1'}
                                // ]
                            },
                            {
                                title: '缩略图',
                                key: 'source'
                            },
                            // {
                            //     title: '状态',
                            //     key: 'status'
                            // },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        methods: {
            created () {
                Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            },
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
            },
            del (item) {
                Sun.confirm('提示', '确定要删除此项吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: {id: item.id},
                        success: () => {
                            Sun.showMsg('已删除');
                            this.table.el.refresh();
                        }
                    });
                });
            },
            // 更改状态
            change (item) {

            }
        },
        filters: {
            famateJumpType (type) {
                type = parseInt(type);
                switch (type) {
                    case 0: return '无';
                    case 1: return '商品';
                    default: return '/';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
    .img {
        width: 60px;
        height: 60px;
    }
</style>
