<template>
    <el-dialog title="编辑" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px">
            <el-form-item required label="位置:">
                <el-select v-model="form.type" filterable placeholder="请选择">
                    <el-option label="APP" :value="1"></el-option>
                    <el-option label="PC" :value="2"></el-option>
                </el-select>
            </el-form-item>  
            <!-- 图片 -->
            <el-form-item required class="main-img" label="图片">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadMainImg"
                    :before-upload="beforeUpload">
                    <img v-if="form.source" :key="form.source" :src="containsString(form.source, setting.oss_http) ? form.source : setting.oss_http + form.source" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <div class="gray-color">APP位置建议图片长宽比例为750:320</div>
            </el-form-item>
            <el-form-item required label="跳转类型:">
                <el-select v-model="form.jumpType" filterable placeholder="请选择">
                    <el-option label="无" :value="0"></el-option>
                    <el-option label="商品" :value="1"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item v-if="form.jumpType == 1" label="已选择商品:">
                <!-- <p>{{form.jumpParam ? JSON.parse(form.jumpParam).goodsId : ''}}</p> -->
                <p>{{form.goodsName}}</p>
            </el-form-item>
            <el-form-item v-if="form.jumpType == 1" label="重新选择商品:"></el-form-item>
            <el-form-item v-if="form.jumpType == 1" required label="商品类型:">
                <el-select @change="getGoodsList(goodsType)" v-model="goodsType" filterable placeholder="请选择跳转商品类型">
                    <el-option label="设备" :value="1"></el-option>
                    <el-option label="耗材" :value="2"></el-option>
                    <el-option label="配件" :value="3"></el-option>
                    <el-option label="赠品" :value="4"></el-option>
                </el-select>
            </el-form-item> 
            <!-- 商品 -->
            <el-form-item required v-if="goodsType && form.jumpType == 1" label="搜索选择商品:">
                <el-select v-model="goodsId" filterable placeholder="请选择跳转商品">
                    <el-option v-for="(item, index) in equiList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <!-- <el-form-item required v-if="form.jumpType == 1" label="商品ID">
                <el-input v-model="form.goodsId"></el-input>
            </el-form-item>
            <el-form-item required v-if="form.jumpType == 1" label="商品名称">
                <el-input v-model="form.goodsName"></el-input>
            </el-form-item> -->
            <!-- <el-form-item required label="启用状态">
                <el-radio v-model="form.status" :label="1">启用</el-radio>
                <el-radio v-model="form.status" :label="0">关闭</el-radio>
            </el-form-item>  -->
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap, getTime, formatTime, uuid, containsString} from "../../../../js/util";
    import setting from "../../../../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);

    export default {
        extends: Sun.vuePage,
        data() {
            return {
                setting: setting,
                form: {},
                goodsId: '',
                goodsType: '',
                equiList: []
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
                if (this.data.jumpType == 1) {
                    let jumpParam = JSON.parse(this.data.jumpParam);
                    this.goodsId = jumpParam.goodsId;
                } else {
                    this.goodsId = '';
                }
                this.goodsType = '';
                this.equiList = [];
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },            
            getGoodsList (value) {
                if (!value) {
                    return;
                }
                Sun.post({
                    url: this.url.getGoodsListByType,
                    data: {type: value},
                    success: (data) => {
                        this.equiList = [];
                        this.goodsId = '';
                        this.equiList = data;
                    }
                })
            },
            submit() {
                if (!this.form.type) {
                    Sun.showError('请选择banner位置');
                    return;
                }
                if (this.form.jumpType === '') {
                    Sun.showError('请选择跳转类型');
                    return;
                }
                if (!this.form.source) {
                    Sun.showError('请上传图片');
                    return;
                }
                // 商品
                if (this.form.jumpType == 1 && !this.goodsId) {
                    Sun.showError('请选择跳转的商品');
                    return;
                }
                // if (this.form.status == '') {
                //     Sun.showError('请选择启用状态');
                //     return;
                // }
                if (this.form.jumpType == 1) {
                    this.form.jumpParam = JSON.stringify({goodsId: this.goodsId}); 
                } else {
                    this.form.jumpParam = '';
                }
                delete this.form.createTime;
                delete this.form.deleteTime;
                Sun.post({
                    url: this.url.edit,
                    data: this.form,
                    loading: true,
                    success: () => {
                        Sun.showMsg('编辑成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            },
            uploadMainImg (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'crm/model/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.form.source = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            beforeUpload (file) {
                if (file.size / 1024 / 1024 > 2) {
                    this.$message.error('上传图片大小不能超过 2MB!');
                    return false;
                }
                return true;
            },
            containsString (long, short) {
                return containsString(long, short);
            }
        },
        props: ['data', 'url', 'show', 'callBack'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
    .avatar-uploader .el-upload {
        width: 178px;
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>
