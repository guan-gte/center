<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true" type="primary">添加一级分类</el-button>
            <!-- <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div> -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.del" class="opreate-del" type="text" size="mini" @click="del(data.row)">删除</el-button>
            </div>
        </SunTable>
        <!--add-->
        <ClassifyAdd :url="url" :show="showAdd"
                       :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></ClassifyAdd>
        <!--edit-->
        <ClassifyEdit :url="url" :show="showEdit" :data="editData"
                       :callBack="(flag)=>{showEdit = false;if (flag) table.el.refresh()}"></ClassifyEdit>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    import ClassifyAdd from './ClassifyAdd';
    import ClassifyEdit from './ClassifyEdit';
    const url = {
        table: Http.plat.getCatList,
        add: Http.plat.addCat,
        edit: Http.plat.editCat,
        del: Http.plat.deleteCat
    };
    export default {
        extends: Sun.vuePage,
        components: {ClassifyAdd, ClassifyEdit},
        data() {
            return {
                url: url,
                auth: {
                    add: true,
                    edit: true,
                    query: true,
                    del: true
                },
                showAdd: false,
                showEdit: false,
                editData: {},
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: false,
                        list: [
                            {
                                title: '分类id',
                                key: 'id'
                            },
                            {
                                title: '一级分类名称',
                                key: 'name'
                            },
                            // {
                            //     title: '创建时间',
                            //     key: 'createTime'
                            // },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
            // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            // Sun.post({
            //     url: Http.plat.getCatListById,
            //     data: {id: 11},
            //     success: (data) => {
            //         console.log(data);
            //     }
            // });
        },
        methods: {
            // 详情
            query (item) {
                Sun.temp.classifyDetail = item;
                Sun.push('/plat/classify/classifyDetail');
            },
            // 删除
            del (item) {
                if (item.list.length) {
                    Sun.showError('不能删除有子分类的分类');
                    return;
                }
                Sun.confirm('提示', '确定要删除此分类吗?', () => {
                     Sun.post({
                        url: this.url.del,
                        data: {id: item.id},
                        success: () => {
                            Sun.showMsg('已删除');
                            this.table.el.refresh();
                        }
                    });
                });
            },
            edit (item) {
                this.editData = item;
                this.showEdit = true;
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
