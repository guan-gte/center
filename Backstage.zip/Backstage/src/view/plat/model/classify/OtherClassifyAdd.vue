<template>
    <el-dialog title="添加子分类" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px">
            <el-form-item required label="分类级别">
                <el-select v-model="classifyLevel" @change="getCatList(classifyLevel);" filterable placeholder="请选择">
                    <el-option label="二级分类" :value="2"></el-option>
                    <el-option label="三级分类" :value="3"></el-option>
                </el-select>
            </el-form-item>
            <!-- <el-form-item v-if="classifyLevel == 2" required label="选择父级分类">
                <el-select v-model="form.pid" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in catList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item> -->
            <el-form-item v-if="classifyLevel == 3" required label="选择父级分类">
                <el-select v-model="form.pid" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in secondCatList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item required label="请输入分类名称">
                <el-input placeholder="请输入分类名称" v-model="form.name"></el-input>
            </el-form-item>
            <el-form-item required class="main-img" label="请上传图片">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadMainImg"
                    :before-upload="beforeUpload">
                    <img v-if="form.img" :key="form.img" :src="setting.oss_http + parseImg(form.img)" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <div v-if="classifyLevel == 2" class="gray-color">二级分类建议图片长宽比例为156:150</div>
                <div v-if="classifyLevel == 3" class="gray-color">三级分类建议图片长宽比例为120:120</div>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>    
    import {copyMap, getTime, formatTime, uuid} from "../../../../js/util";
    import setting from "../../../../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);

    export default {
        extends: Sun.vuePage,
        data() {
            return {
                setting: setting,
                classifyLevel: '',
                form: {},
                catList: [],
                secondCatList: []
            }
        },
        methods: {
            open () {
                this.form = {
                    img: '',
                    pid: ''
                };
                this.classifyLevel = '';
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            getCatList (value) {
                if (!value) {
                    return;
                }
                console.log(this.form.pid)
                this.form.pid = '';
                Sun.post({
                    url: this.url.table,
                    data: {},
                    success: (data) => {
                        // this.catList = data;
                        if (data.length) {
                            data.forEach(item => {
                                if (item.id == this.detail.id) {
                                    this.secondCatList = item.list;
                                }
                            })
                        }
                    }
                })
            },
            submit() {
                if (!this.classifyLevel) {
                    Sun.showError('请选择分类级别');
                    return;
                }
                // if (this.classifyLevel == 2 && !this.form.pid) {
                //     Sun.showError('请选择父级分类');
                //     return;
                // }
                if (this.classifyLevel == 3 && !this.form.pid) {
                    Sun.showError('请选择父级分类');
                    return;
                }
                if (!this.form.name) {
                    Sun.showError('请输入分类名称');
                    return;
                }
                if (!this.form.img) {
                    Sun.showError('请上传图片');
                    return;
                }
                if (this.classifyLevel == 2) {
                    this.form.pid = this.detail.id;
                }
                Sun.post({
                    url: this.url.add,
                    data: this.form,
                    success: () => {
                        Sun.showMsg('添加成功');                 
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            },
            uploadMainImg (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/cat/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.form.img = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            beforeUpload (file) {
                if (file.size / 1024 / 1024 > 2) {
                    this.$message.error('上传图片大小不能超过 2MB!');
                    return false;
                }
                return true;
            }
        },
        props: ['url', 'show', 'callBack', 'detail'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
        .avatar-uploader .el-upload {
        width: 178px;
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>
