<template>
    <el-dialog title="编辑分类" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="130px">
            <el-form-item required label="分类级别">
                <el-select :disabled="hasChild" @change="changeCatList(classifyLevel);" v-model="classifyLevel" filterable placeholder="请选择">
                    <el-option label="二级分类" :value="2"></el-option>
                    <el-option label="三级分类" :value="3"></el-option>
                </el-select>
            </el-form-item>
            <!-- <el-form-item v-if="classifyLevel == 2" required label="选择父级分类">
                <el-select :disabled="hasChild" v-model="form.pid" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in catList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item> -->
            <el-form-item v-if="classifyLevel == 3" required label="选择父级分类">
                <el-select :disabled="hasChild" v-model="form.pid" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in secondCatList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item required label="请输入分类名称">
                <el-input placeholder="请输入分类名称" v-model="form.name"></el-input>
            </el-form-item>
            <el-form-item required class="main-img" label="请上传图片">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadMainImg"
                    :before-upload="beforeUpload">
                    <!-- <img v-if="form.img" :key="form.img" :src="setting.oss_http + parseImg(form.img)" class="avatar"> -->
                    <img v-if="form.img" :key="form.img" :src="containsString(form.img, setting.oss_http) ? form.img : setting.oss_http + form.img" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <div v-if="classifyLevel == 2" class="gray-color">二级分类建议图片长宽比例为156:150</div>
                <div v-if="classifyLevel == 3" class="gray-color">三级分类建议图片长宽比例为120:120</div>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap, getTime, formatTime, uuid, containsString} from "../../../../js/util";
    import setting from "../../../../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);

    export default {
        extends: Sun.vuePage,
        data() {
            return {
                setting: setting,
                classifyLevel: '',
                hasChild: false,
                form: {},
                catList: [],
                secondCatList: []
            }
        },
        methods: {
            open () {
                this.getCatList();
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            getCatList () {
                Sun.post({
                    url: this.url.table,
                    data: {},
                    success: (data) => {
                        // this.catList = data;
                        if (data.length) {
                            data.forEach(item => {
                                if (item.id == this.detail.id) {
                                    this.secondCatList = item.list;
                                }
                            })
                        }
                        this.form = copyMap(this.data);
                        // 初始话 父级分类
                        let length = this.form.id.toString().length;
                        if (length == 4) {
                            this.classifyLevel = 2;
                        } else if (length == 6) {
                            this.classifyLevel = 3;
                        }
                        // 分类如果有子集, 或在二级分类只有一项时，则不可以更换父级分类
                        if (this.form.list.length || this.detail.list.length == 1) {
                            this.hasChild = true;
                        } else {
                            this.hasChild = false;
                        }
                    }
                })
            },
            changeCatList (value) {
                if (!value) {
                    return;
                }
                this.form.pid = '';
                // 分类如果有子集, 或在二级分类只有一项时，则不可以更换父级分类
                if (this.form.list.length || this.detail.list.length == 1) {
                    this.hasChild = true;
                } else {
                    this.hasChild = false;
                }
            },
            submit() {
                if (!this.classifyLevel) {
                    Sun.showError('请选择分类级别');
                    return;
                }
                // if (this.classifyLevel == 2 && !this.form.pid) {
                //     Sun.showError('请选择父级分类');
                //     return;
                // }
                if (this.classifyLevel == 3 && !this.form.pid) {
                    Sun.showError('请选择父级分类');
                    return;
                }
                if (!this.form.name) {
                    Sun.showError('请输入分类名称');
                    return;
                }
                if (!this.form.img) {
                    Sun.showError('请上传图片');
                    return;
                }
                // 二级分类 改变成 三级分类，父级不能选择自己
                if (this.form.id == this.form.pid) {
                    Sun.showError('父级不能选择自己');
                    return;
                }
                this.del();
                Sun.post({
                    url: this.url.edit,
                    data: this.form,
                    success: () => {
                        Sun.showMsg('编辑成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            },
            del () {
                delete this.form.list;
            },
            uploadMainImg (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/cat/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.form.img = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            beforeUpload (file) {
                if (file.size / 1024 / 1024 > 2) {
                    this.$message.error('上传图片大小不能超过 2MB!');
                    return false;
                }
                return true;
            },
            containsString (long, short) {
                return containsString(long, short);
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        },
        props: ['data', 'url', 'show', 'callBack', 'detail'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
