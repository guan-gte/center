<template>
    <Page>
        <div style="margin-bottom: 20px;"><el-button v-show="auth.add" @click="showAdd = true" type="primary">添加子分类</el-button></div>
        <div class="cell" v-for="(item, index) in detail.list" :key="index">
            <ul class="table-head">
                <li style="flex: 2">分类ID</li>
                <li>分类名称</li>
                <!-- <li style="flex: 2">创建时间</li> -->
                <li style="flex: 2; border: none;">操作</li>
            </ul>
            <ul class="table-content" style="border-top: 0;">
                <li style="flex: 2" >
                    <span style="display: flex; justify-content: center; align-items: center;height: 100%;">{{item.id}}</span>
                </li>
                <li style="text-align: left;">
                    <img class="img" :key="item.img" :src="containsString(item.img, setting.oss_http) ? item.img : setting.oss_http + item.img"/>
                    <span style="margin-left: 10px;">二级分类：{{item.name}}</span>
                </li>
                <!-- <li style="flex: 2">{{item.createTime | formatTime}}</li> -->
                <li style="flex: 2;border: none;">
                    <div style="display: flex; justify-content: center; align-items: center;height: 100%;">
                        <span  @click="edit(item)" style="color: #409EFF;cursor: pointer;">{{auth.edit ? '编辑' : ''}}</span>
                        <span  @click="del(item, index)" style="color: #F56C6C;cursor: pointer;margin-left: 10px;">{{auth.del ? '删除' : ''}}</span>
                    </div>
                </li>
            </ul>
            <ul v-for="(ktem, kndex) in item.list" :key="kndex" class="table-content" style="border-top: 0;">
                <li style="flex: 2">
                    <span style="display: flex; justify-content: center; align-items: center;height: 100%;">{{ktem.id}}</span>
                </li>
                <li class="third-content">
                    <!-- <p style="margin-bottom: 10px;">三级分类： {{ktem.name}}</p>
                    <span style="display: inline-block;vertical-align: middle;">图片：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    <img class="img" :key="ktem.img" v-lazy="parseImg(ktem.img, {x: 60})"/> -->
                    <el-collapse v-model="activeNames">
                        <el-collapse-item :title="'三级分类：' + ktem.name" :name="ktem.id">
                            <div>
                                <!-- <p style="margin-bottom: 10px;">分类ID: {{ktem.id}}</p> -->
                                <span style="display: inline-block;vertical-align: middle;">图片：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                <img class="img" :key="ktem.img" :src="containsString(ktem.img, setting.oss_http) ? ktem.img : setting.oss_http + ktem.img"/>
                                <!-- <p>创建时间: {{ktem.createTime | formatTime}}</p> -->
                            </div>
                        </el-collapse-item>
                    </el-collapse>
                </li>
                <!-- <li style="flex: 2">{{item.createTime | formatTime}}</li> -->
                <li style="flex: 2;border: none;">
                    <div style="display: flex; justify-content: center; align-items: center;height: 100%;">
                        <span @click="editItem(ktem)" style="color: #409EFF;cursor: pointer;">{{auth.edit ? '编辑' : ''}}</span>
                        <span @click="delItem(ktem, index, kndex)" style="color: #F56C6C;cursor: pointer;margin-left: 10px;">{{auth.del ? '删除' : ''}}</span>
                    </div>
                </li>
            </ul>
        </div>
        <!--add-->
        <OtherClassifyAdd :url="url" :show="showAdd" :detail="detail"
                       :callBack="(flag)=>{showAdd = false; if (flag) refresh();}"></OtherClassifyAdd>
        <!--edit-->
        <OtherClassifyEdit :url="url" :show="showEdit" :detail="detail" :data="editData"
                       :callBack="(flag)=>{showEdit = false; if (flag) refresh();}"></OtherClassifyEdit>
    </Page>
</template>

<script>
    import {formatTime, containsString} from "../../../../js/util";
    import setting from "../../../../config/setting";
    import OtherClassifyAdd from './OtherClassifyAdd';
    import OtherClassifyEdit from './OtherClassifyEdit';
    const url = {
        table: Http.plat.getCatList,
        add: Http.plat.addCat,
        edit: Http.plat.editCat,
        del: Http.plat.deleteCat,
        getCatListById: Http.plat.getCatListById
    };
    export default {
        extends: Sun.vuePage,
        components: {OtherClassifyAdd, OtherClassifyEdit},
        data() {
            return {
                setting: setting,
                url: url,
                auth: {
                    add: true,
                    edit: true,
                    del: true
                },
                showAdd: false,
                showEdit: false,
                editData: {},
                activeNames: [],
                detail: {
                    name: '',
                    id: '',
                    createTime: '',
                    list: []
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            if (Sun.temp.classifyDetail) {
                this.detail = Sun.temp.classifyDetail;
            } else {
                setTimeout(() => {
                    Sun.closePage();
                }, 300)
            }
            if (this.detail.list.length) {
                this.activeNames = [];
                this.detail.list.forEach((item, index) => {
                    this.activeNames.push(item.id);
                })
            } else {
                this.activeNames = [];
            }
        },
        methods: {
            refresh () {
                Sun.post({
                    url: this.url.getCatListById,
                    data: {id: this.detail.id},
                    success: (res) => {
                        this.detail = res[0];
                        if (this.detail.list.length) {
                            this.activeNames = [];
                            this.detail.list.forEach((item, index) => {
                                this.activeNames.push(item.id);
                            })
                        } else {
                            this.activeNames = [];
                        }
                    }
                });
            },
            // 删除二级分类
            del (item, index) {
                let itemList = this.detail.list[index].list;
                if (itemList.length) {
                    Sun.showError('不能删除有子分类的二级分类');
                    return;
                } else {
                    Sun.confirm('提示', '确定要删除此分类吗?', () => {
                        Sun.post({
                            url: this.url.del,
                            data: {id: item.id},
                            success: () => {
                                this.refresh();
                                Sun.showMsg('已删除');
                            }
                        });
                    });
                }
            },
            // 删除三级分类
            delItem (ktem) {
                Sun.confirm('提示', '确定要删除此分类吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: {id: ktem.id},
                        success: () => {
                            Sun.showMsg('已删除');
                            this.refresh();
                        }
                    });
                });
            },
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
            },
            // 编辑
            editItem (ktem) {
                this.editData = ktem;
                this.showEdit = true;
            },
            containsString (long, short) {
                return containsString(long, short);
            }
        }, 
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>


<style lang="less" scoped>
    .cell {
        width: 100;
        margin-bottom: 20px;
        .img {
            width: 60px;
            height: 60px;
            vertical-align: middle;
        }
    }
    .table-head {
        width: 100%;
        display: flex;
        border: 1px solid #ebeef5;
        li {
            flex: 4;
            padding: 10px 20px;
            box-sizing: border-box;
            font-size: 14px;
            color: #909399;
            font-weight: 500;
            text-align: center;
            border-right: 1px solid #ebeef5;
        }
    }
    .table-content {
        width: 100%;
        display: flex;
        border: 1px solid #ebeef5;
        li {
            flex: 4;
            padding: 10px 20px;
            box-sizing: border-box;
            font-size: 14px;
            color: #606266;
            font-weight: 500;
            text-align: center;
            border-right: 1px solid #ebeef5;
        }
        .el-collapse {
            border: none;
        }
        .el-collapse-item__wrap {
            border: none;
        }
        .el-collapse-item__content {
            padding-bottom: 15px;
        }
        .third-content {
            text-align: left;
        }
    }
</style>
