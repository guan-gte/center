<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="img" slot-scope="data"><img class="img" :key="data.row.img" v-lazy="parseImg(data.row.img, {x: 60})"/></div>
            <div slot="status" slot-scope="data">
                <span :style="{color: data.row.status == 1 ? '#32CD32' : '#F56C6C'}">{{data.row.status == 1 ? '上架' : '下架'}}</span>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    const url = {
        table: Http.plat.getGoodsListPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '产品ID',
                                key: 'id',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },             
                            {
                                title: '缩略图',
                                key: 'img'
                            },             
                            {
                                title: '产品名称',
                                key: 'name',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品型号',
                                key: 'model'
                            },
                            {
                                title: '产品货号',
                                key: 'goodsNo'
                            },
                            {
                                title: '供应商',
                                key: 'supplyName'
                            },  
                            {
                                title: '品牌',
                                key: 'brandName'
                            },
                            {
                                title: '库存',
                                key: 'stock',
                                search:{
                                    type: 'text',
                                    symbol: 'between'
                                }
                            },
                            {
                                title: '状态',
                                key: 'status'
                            }
                            // {
                            //     title: '库存警报值',
                            //     key: 'trueName'
                            // }
                        ]
                    }
                }
            }
        },
        created () {
        },
        methods: {
        },
        filters: {
        }
    }
</script>

<style scoped>
    .img {
        width: 60px;
        height: 60px;
    }
</style>
