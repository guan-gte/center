<template>
    <Page>
        <div class="all">        
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>基本信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">打包分配状态: 
                        <span :style="baseInfo.status > 0 ? 'color: #67C23A' : 'color: #F56C6C'">{{baseInfo.status | formatStatus}}</span>
                    </div>
                    <div v-if="baseInfo.status > 0" class="text item">打包人员:{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status > 0" class="text item">分配时间:{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status == 2" class="text item">出库状态:{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status == 2" class="text item">出库时间:{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status == 3" class="text item">订单发货状态:{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status == 3" class="text item">发货时间:{{baseInfo.demo}}</div>
                </div>
            </el-card>
            <!-- 订单信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>订单信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">订单编号: {{order.demo}}</div>
                    <div class="text item">出库编号: {{order.demo}}</div>
                    <div class="text item">下单时间: {{order.demo}}</div>
                    <div class="text item">出库时间: {{order.demo}}</div>
                    <div class="text item">指定发货时间: {{order.demo}}</div>
                    <div class="text item">备注信息: {{order.demo}}</div>
                </div>
            </el-card>
            <!-- 收货人信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>收货人信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">公司信息: {{people.demo}}</div>
                    <div class="text item">联系人: {{people.demo}}</div>
                    <div class="text item">联系方式: {{people.demo}}</div>
                    <div class="text item">收货地址: {{people.demo}}</div>
                </div>
            </el-card>
            <!--商品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>商品信息:</span></div>
                <el-table :data="goodsList" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in goodsColumns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
            <!--出库信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>出库信息:</span>
                    <el-button v-if="baseInfo.status > 0" style="float: right;" round plain size="mini" type="primary">打印该订单</el-button>
                </div>
                <div v-if="baseInfo.status > 0" class="main clearfix">
                    <div class="text item">打包人员: {{baseInfo.demo}}</div>
                    <div class="text item">分配时间: {{baseInfo.demo}}</div>
                </div>
                <el-form class="el-form-add" ref="form" :model="form" label-width="130px">
                    <el-form-item v-if="!baseInfo.status" required label="请指定打包人员">
                        <el-select v-model="form.peopleId" filterable placeholder="未指定">
                            <el-option v-for="(item, index) in packagePeople" :key="index" :label="item.name"
                                    :value="item.id"></el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
                <el-table :data="outGoodsList" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in outGoodsColumns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
            <!--发货-->
            <el-card v-if="baseInfo.status == 2" class="box-card" shadow="hover">
                <div slot="header"><span>发货:</span></div>
                <div class="main clearfix">
                    <div class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="150px">
                            <el-form-item required label="请选择订单发货方式">
                                <el-select v-model="delivery.deliverType" filterable placeholder="请选择">
                                    <el-option label="快递物流" :value="1"></el-option>
                                    <el-option label="公司承运" :value="2"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                     <div v-if="delivery.deliverType == 1" class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                            <el-form-item required label="请选择物流公司">
                                <el-select v-model="form.demo" filterable placeholder="请选择">
                                    <el-option v-for="(item, index) in transList" :key="index" :label="item.name"
                                            :value="item.id"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div v-else class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                             <el-form-item required label="请选择承运人">
                                <el-select v-model="form.demo" filterable placeholder="请选择">
                                    <el-option v-for="(item, index) in dirverList" :key="index" :label="item.name"
                                            :value="item.id"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div v-if="delivery.deliverType == 1" class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                             <el-form-item required label="请填写物流编号">
                                <el-input v-model="form.demo"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <!-- 选择司机后自动获取联系方式，可以更改，必填 -->
                    <div v-else class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                        <el-form-item required label="联系方式">
                            <el-input v-model="form.demo"></el-input>
                        </el-form-item>
                        </el-form>
                    </div>
                </div>
            </el-card> 
            <!-- 发货信息 -->
            <el-card v-if="baseInfo.status == 3" class="box-card" shadow="hover">
                <div slot="header"><span>发货信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">发货方式: {{deliveryInfo.demo}}</div>
                    <div class="text item">快递公司: {{deliveryInfo.demo}}</div>
                    <div class="text item">快递编号: {{deliveryInfo.demo}}</div>
                </div>
            </el-card>
        </div>          
        <div class="footer-btn">
            <el-button class="button-edit">取消</el-button>
            <el-button class="button-edit" @click="submit" type="primary">确定</el-button>
        </div>  
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    edit: true
                },
                // 基本信息
                baseInfo: {
                    // 0 未指定人员 1 已指定 待确认 2 等待发货 3 已经完成
                    status: 2,
                    demo: '上海分公司'
                },
                // 订单信息
                order: {
                    demo: '上海分公司'
                },
                // 收货人信息
                people: {
                    demo: '上海分公司'
                },
                // 待指定的打包人
                packagePeople: [],
                form: {
                    peopleId: ''
                },
                // 发货
                transList: [],
                dirverList:[],
                delivery: {
                    deliverType: '',
                    tranCompany: '',
                    transNo: '',
                    dirver: '',
                    phone: '',
                    demo: ''  
                },
                // 商品信息
                goodsColumns: [
                    {
                        title: '商品ID',
                        key: 'trueName',
                    },
                    {
                        title: '商品名称',
                        key: 'trueName',
                    },
                    {
                        title: '适用机型',
                        key: 'trueName',
                    },
                    {
                        title: '规格型号',
                        key: 'trueName',
                    },
                    {
                        title: '所属供应商',
                        key: 'trueName',
                    },
                    {
                        title: '计量单位',
                        key: 'trueName',
                    },
                    {
                        title: '商品数量',
                        key: 'trueName',
                    },
                    {
                        title: '库存',
                        key: 'aa',
                    },
                ],
                goodsList: [],
                // 出库信息
                outGoodsColumns: [
                    {
                        title: '商品ID',
                        key: 'trueName',
                    },
                    {
                        title: '商品名称',
                        key: 'trueName',
                    },
                    {
                        title: '适用机型',
                        key: 'trueName',
                    },
                    {
                        title: '规格型号',
                        key: 'trueName',
                    },
                    {
                        title: '所属供应商',
                        key: 'trueName',
                    },
                    {
                        title: '计量单位',
                        key: 'trueName',
                    },
                    {
                        title: '商品数量',
                        key: 'trueName',
                    },
                    {
                        title: '库存',
                        key: 'aa',
                    },
                ],
                outGoodsList: [],
                // 发货信息
                deliveryInfo: {
                    demo: '韵达'
                }
            }
        },
        methods: {
            // submit
            submit () {
                let status = this.baseInfo.status;
                switch (status) {
                    case 0: 
                        // 指定 
                        this.assign();
                    return;
                    case 1: 
                        // 确认指定 
                        this.confirmAssign();
                    return;
                    case 2: 
                        // 发货 
                        this.deliver();
                    return;
                }
            },
            // 指定
            assign () {
                if (!this.form.peopleId) {
                    Sun.showError('请指定打包人员!');
                    return;
                }
            },
            // 确认指定
            confirmAssign () {
                // TODO
            },
            // 发货
            deliver() {
                // 快递物流
                // if (this.deliverType == 1) {
                //     if (!this.form.tranCompany) {
                //         Sun.showError('请指定打包人员!');
                //         return;
                //     }
                //     deliverType: '',
                //     tranCompany: '',
                //     transNo: '',
                //     dirver: '',
                //     phone: '',
                // }
            },

            // 总计
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },        
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未分配';
                    case 1: return '已分配';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
    }    
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
