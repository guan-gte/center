<template>
    <Page>
        <div class="all">        
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>基本信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">打包分配状态: 
                        <span :style="baseInfo.status > 0 ? 'color: #67C23A' : 'color: #F56C6C'">{{baseInfo.status | formatStatus}}</span>
                    </div>
                    <div v-if="baseInfo.status > 0" class="text item">指定时间:{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status == 2" class="text item">出库时间:{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status == 2" class="text item">订单发货状态:{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status == 2" class="text item">发货时间:{{baseInfo.demo}}</div>
                </div>
            </el-card>
            <!-- 订单信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>订单信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">订单编号: {{order.demo}}</div>
                    <div class="text item">出库编号: {{order.demo ? order.demo : '供应商发货'}}</div>
                    <div class="text item">出库时间: {{order.demo ? order.demo : '暂无'}}</div>
                    <div class="text item">下单时间: {{order.demo}}</div>
                    <div class="text item">指定发货时间: {{order.demo}}</div>
                    <div class="text item">备注信息: {{order.demo}}</div>
                </div>
            </el-card>
            <!-- 收货人信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>收货人信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">公司信息: {{people.demo}}</div>
                    <div class="text item">联系人: {{people.demo}}</div>
                    <div class="text item">联系方式: {{people.demo}}</div>
                    <div class="text item">收货地址: {{people.demo}}</div>
                </div>
            </el-card>
            <!--商品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>商品信息:</span></div>
                <el-table :data="goodsList" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in goodsColumns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
            <!--供应链采购信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>供应链采购信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">供应商信息: {{baseInfo.demo}}</div>
                </div>
                <el-table :data="supplierGoodsList" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in supplierGoodsColumns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
            <!-- 物流信息 -->
            <el-card v-if="baseInfo.status == 1" class="box-card" shadow="hover">
                <div slot="header"><span>物流信息:</span></div>
                <div class="main clearfix" v-if="!deliveryInfo.status">
                    <div class="text item">物流数据等待等待厂商返回</div>
                </div>
                <div class="main clearfix" v-else>
                    <div class="text item">发货方式: {{deliveryInfo.demo}}</div>
                    <div class="text item">快递公司: {{deliveryInfo.demo}}</div>
                    <div class="text item">快递编号: {{deliveryInfo.demo}}</div>
                </div>
            </el-card>
        </div>          
        <div class="footer-btn" v-if="!baseInfo.status">
            <el-button class="button-edit">取消</el-button>
            <el-button class="button-edit" @click="submit" type="primary">发送至供应链</el-button>
        </div>  
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    edit: true
                },
                // 基本信息
                baseInfo: {
                    // 0 未分配 1 已指定 2 已发货
                    status: 1,
                    demo: '上海分公司'
                },
                // 订单信息
                order: {
                    demo: '上海分公司'
                },
                // 收货人信息
                people: {
                    demo: '上海分公司'
                },
                // 商品信息
                goodsColumns: [
                    {
                        title: '商品ID',
                        key: 'trueName',
                    },
                    {
                        title: '商品名称',
                        key: 'trueName',
                    },
                    {
                        title: '适用机型',
                        key: 'trueName',
                    },
                    {
                        title: '规格型号',
                        key: 'trueName',
                    },
                    {
                        title: '所属供应商',
                        key: 'trueName',
                    },
                    {
                        title: '计量单位',
                        key: 'trueName',
                    },
                    {
                        title: '商品数量',
                        key: 'trueName',
                    },
                    {
                        title: '库存',
                        key: 'aa',
                    },
                ],
                goodsList: [],
                // 出库信息
                supplierGoodsColumns: [
                    {
                        title: '商品ID',
                        key: 'trueName',
                    },
                    {
                        title: '商品名称',
                        key: 'trueName',
                    },
                    {
                        title: '适用机型',
                        key: 'trueName',
                    },
                    {
                        title: '规格型号',
                        key: 'trueName',
                    },
                    {
                        title: '计量单位',
                        key: 'trueName',
                    },
                    {
                        title: '商品数量',
                        key: 'trueName',
                    },
                ],
                supplierGoodsList: [],
                // 物流信息
                deliveryInfo: {
                    demo: '韵达',
                    status: 0
                }
            }
        },
        methods: {
            // submit
            submit () {
                // 发送至供应链
            },
            // 总计
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },        
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未分配';
                    case 1: return '已经发送至供应链';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
    }    
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
