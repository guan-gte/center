<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>
            <div slot="status" slot-scope="data">
                <span v-show="data.row.status == 3" :style="{color: '#32CD32'}">{{data.row.status | formatStatus}}</span>
                <span v-show="data.row.status == 1" :style="{color: '#F56C6C'}">{{data.row.status | formatStatus}}</span>
            </div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.plat.storeOrderPage,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    query: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '入库单编号',
                                key: 'storeId',
                                sortable: true
                            },             
                            {
                                title: '下单时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '入库状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未入库', value: '1'},
                                        // {name: '入库未完', value: '2'},
                                        {name: '已入库', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '未入库', value: '= 1'},
                                    // {text: '入库未完', value: '= 2'},
                                    {text: '已入库', value: '= 3'}
                                ]
                            },             
                            {
                                title: '入库时间',
                                key: 'storeTime',
                                sortable: true
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query (item) {
                Sun.push('/plat/store/storeIn/storeInDetail');
                Sun.temp.storeInDetail = item;
            }
        },
        filters: {
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return '未入库';
                    // case 2: return '入库未完';
                    case 3: return '已入库';
                    default: return '/';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
