<template>
    <Page>
        <div class="all clearfix">   
            <!-- 入库详情 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>入库信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">采购订单编号: {{details.id}}</div>
                    <div class="text item">入库单编号: {{details.storeId}}</div>
                    <div class="text item">快递单号: {{details.transNo ? details.transNo : '暂无'}}</div>
                    <!-- 如果续发快递未填写编号显示为等待供应链填写编号 -->
                    <!-- <div class="text item" v-if="details.status == 2">续发快递单号: {{details.demo ? details.demo : '等待供应链填写编号'}}</div> -->
                </div>
            </el-card>     
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in details.goodsList" :key="index">
                <div slot="header">
                    <span class="header-title">采购产品{{++index}}:</span>
                    <!-- 未入库 填写到货数量 -->
                    <!-- <el-input v-if="details.status == 1" class="input-num" v-model="item.receiveNum" placeholder="到货数量"></el-input>
                    <span v-if="details.status == 1" class="input-label"><span style="color: #f56c6c;">* </span>请输入到货数量:</span> -->
                    <!-- 入库未完 到货数量小于采购数量  填写续发数量 -->
                    <!-- <el-input v-if="details.status == 2 && (item.demo < item.demo)" 
                                class="input-num" v-model="item.addNum" placeholder="请输入续发数量"></el-input>
                    <span v-if="details.status == 2 && (item.demo < item.demo)" class="input-label"><span style="color: #f56c6c;">* </span>请输入续发数量:</span> -->
                </div>
                <div class="main clearfix">
                    <div class="text item">产品ID：{{item.id}}</div>
                    <div class="text item">产品名称：{{item.name}}</div>
                    <div class="text item">产品类型：{{item.type | famateType}}</div>
                    <div class="text item">产品型号：{{item.model}}</div>
                    <div class="text item">产品货号：{{item.goodsNo}}</div>
                    <div class="text item">供应商：{{item.supplyName}}</div>
                    <div class="text item">品牌：{{item.brandNname ? item.brandNname : ''}}</div>
                    <div class="text item">计量单位：{{item.unit}}</div>
                    <div class="text item">当前库存数量：{{item.stock}}{{item.unit}}</div>
                    <div class="text item">采购数量：{{item.supplyNum}}</div>
                    <!-- 到货数量小于采购数量,字体异色 -->
                    <!-- <div class="text item" :style="item.demo < item.supplyNum ? 'color: #F56C6C;' : ''" 
                            v-if="details.status > 1">到货数量：{{item.demo}}</div> -->
                    <div class="text item">总价：{{item.supplyPrice}}元</div>    
                </div> 
            </el-card>
        </div>          
        <div class="footer-btn">
            <el-button class="button-edit" @click="cancel">返回</el-button>
            <el-button  v-show="auth.edit && details.status !== 3" class="button-edit" @click="submit" type="primary">确认入库</el-button>
        </div>  
    </Page>
</template>

<script>  
    const url = {
        edit: Http.plat.completeStore
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    edit: true
                },
                // 1 未入库 2 入库未完 3 已入库
                details: {}
            }
        },
        methods: {
            submit () {
                Sun.post({
                    url: this.url.edit,
                    data: {id: this.details.id},
                    loading: true,
                    success: (data) => {
                        Sun.showMsg('已确认');
                        Sun.closePage();
                        Sun.push('/plat/store/storeIn/storeIn');
                    }
                });
            },
            cancel () {
                Sun.closePage();
                Sun.push('/plat/store/storeIn/storeIn');
            }
        },        
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            if (Sun.temp.storeInDetail) {
                this.details = Sun.temp.storeInDetail;
                this.details.goodsList = Sun.temp.storeInDetail.goodsList;
                this.details.goodsList.forEach(element => {
                    element.receiveNum = '';
                    element.addNum = '';
                });
            }
        },
        filters: {  
             famateType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '耗材';
                    case 3: return '配件';
                    case 4: return '赠品';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            float: left;
            .header-title {
                height: 32px;
                display: inline-block;
                height: 32px;
                line-height: 32px;
            }
            .input-num {
                float: right;
                width: 15%;
                margin-left: 10px;
            }
            .input-label {
                float: right;
                height: 32px;
                line-height: 32px;
            }
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                    padding-right: 30px;
                    box-sizing: border-box;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
    }    
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
<style>
    .el-card__header {
        font-weight: bold;
        font-size: 15px;
    }
</style>

