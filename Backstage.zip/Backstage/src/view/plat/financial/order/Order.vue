<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>
            <div slot="type" slot-scope="data">{{data.row.type | formatType}}</div>
            <div slot="payStatus" slot-scope="data">{{data.row.payStatus | formatPayStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    add: true,
                    query: true
                },
                showAdd: false,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '订单编号',
                                key: 'trueName',
                                sortable: true
                            },  
                            {
                                title: '订单类型',
                                key: 'type',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '线上订单', value: '1'},
                                        {name: '线下订单', value: '2'},
                                    ]
                                },
                                filter:[
                                    {text: '线上订单', value: '= 1'},
                                    {text: '线下订单', value: '= 2'},
                                ]
                            },           
                            {
                                title: '所属销售',
                                key: 'trueName'
                            },
                            {
                                title: '所属公司',
                                key: 'trueName'
                            },
                            {
                                title: '下单时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '订单状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待支付', value: '0'},
                                        {name: '待发货', value: '1'},
                                        {name: '已取消', value: '2'},
                                        {name: '订单关闭', value: '3'},
                                        {name: '已发货', value: '4'},
                                        {name: '已收货', value: '5'},
                                        {name: '已完成', value: '6'},
                                    ]
                                },
                                filter:[
                                    {text: '待支付', value: '= 0'},
                                    {text: '待发货', value: '= 1'},
                                    {text: '已取消', value: '= 2'},
                                    {text: '订单关闭', value: '= 3'},
                                    {text: '已发货', value: '= 4'},
                                    {text: '已收货', value: '= 5'},
                                    {text: '已完成', value: '= 6'},
                                ]
                            },
                            {
                                title: '订单支付状态',
                                key: 'payStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '支付未完成', value: '0'},
                                        {name: '支付已完成', value: '1'},
                                    ]
                                },
                                filter:[
                                    {text: '支付未完成', value: '= 0'},
                                    {text: '支付已完成', value: '= 1'},
                                ]
                            },
                            {
                                title: '订单金额',
                                key: 'trueName',
                                sortable: true
                            },
                            {
                                title: '已支付金额',
                                key: 'trueName',
                                sortable: true
                            }
                        ]
                    }
                }
            }
        },
        created () {
        },
        methods: {
        },
        filters: {
            formatType(type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '线上订单';
                    case 2: return '线下订单';
                }
            },
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '待支付';
                    case 1: return '待发货';
                    case 2: return '已取消';
                    case 3: return '订单关闭';
                    case 4: return '已发货';
                    case 5: return '已收货';
                    case 6: return '已完成';
                }
            },
            formatPayStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '支付未完成';
                    case 1: return '支付已完成';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
