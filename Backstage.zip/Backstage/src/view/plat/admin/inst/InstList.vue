<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true" type="primary">添加分公司</el-button>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="status" slot-scope="data">
                <el-switch @change="change(data.row)" v-model="data.row.status"
                    :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">查看</el-button>
            </div>
        </SunTable>
        <!--add-->
        <InstAdd :url="url" :show="showAdd"
                    :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></InstAdd>
        <!--edit-->
        <InstEdit :url="url" :show="showEdit" :id="id" :data="editData"
                    :callBack="(flag)=>{showEdit = false;if (flag) table.el.refresh()}"></InstEdit>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    import InstAdd from './InstAdd';
    import InstEdit from './InstEdit';
    // import LabelEdit from './LabelEdit';    
    const url = {
        table: Http.plat.getInstPage,
        add: Http.plat.addInst,
        // edit: Http.master.editAuth,
    };
    export default {
        extends: Sun.vuePage,
        components: {InstAdd, InstEdit},
        data() {
            return {
                auth: {
                    add: true,
                    edit: true,
                    del: true
                },
                url: url,
                showAdd: false,
                showEdit: false,
                editData: {},
                id: '',
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '分公司ID',
                                key: 'id'
                            },
                            {
                                title: '分公司名称',
                                key: 'name'
                            },         
                            {
                                title: '创建时间',
                                key: 'createTime',
                                sortable: true
                            },
                            // {
                            //     title: '状态',
                            //     key: 'status'
                            // },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        methods: {
            created () {
                Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
                Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
                Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            },
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
                this.id = item.id;
            },
            // 更改状态
            change (item) {

            }
        },        
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
