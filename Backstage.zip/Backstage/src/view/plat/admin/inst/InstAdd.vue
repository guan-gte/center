<template>
    <el-dialog title="添加子公司" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="130px">
            <!-- <el-form-item label="子公司编号">
                <el-input disabled v-model="form.no"></el-input>
            </el-form-item> -->
            <el-form-item required label="子公司名称">
                <el-input v-model="form.name"></el-input>
            </el-form-item>            
            <el-form-item required label="公司地址:">
                <el-cascader placeholder="请选择" :options="cityList" :props="optionProps" v-model="comCodeList"></el-cascader>
            </el-form-item>
            <el-form-item required label="公司详细地址">
                <el-input v-model="form.detail"></el-input>
            </el-form-item> 
            <!-- <el-form-item required label="营业状态">
                <el-radio v-model="form.status" :label="1">营业</el-radio>
                <el-radio v-model="form.status" :label="0">关闭</el-radio>
            </el-form-item>  -->
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap} from "../../../../js/util";
    import cityList from "../../../../js/city";
    export default {
        data() {
            return {
                // 指定option
                optionProps: {
                    value: 'i',
                    label: 'n',
                    children: 'l'
                },
                cityList: cityList,
                form: {},
                comCodeList: []
            }
        },
        methods: {
            open () {
                this.form = {};
                this.comCodeList = [];
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            formatCity (id) {
                let idList = [];
                this.cityList.forEach((item) => {
                    if (item.l) {
                        item.l.forEach((jtem) => {
                            if (jtem.l) {
                                jtem.l.forEach((ktem) => {
                                    if (ktem.i == id) {
                                        idList = [item.i, jtem.i, ktem.i];
                                    }
                                });
                            } else {
                                if (jtem.i == id) idList = [item.i, jtem.i, ''];
                            }
                        });
                    } else {
                        if (item.i == id) idList = [item.i, '', ''];
                    }
                });
                return idList;
            },
            submit() {
                // if (!this.form.no) {
                //     Sun.showError('请输入子公司编号');
                //     return;
                // }
                if (!this.form.name) {
                    Sun.showError('请输入子公司名称');
                    return;
                }
                if (!this.comCodeList.length) {
                    Sun.showError('请选择公司地址');
                    return;
                }
                if (!this.form.detail) {
                    Sun.showError('请输入公司详细地址');
                    return;
                }
                // if (this.form.status == '') {
                //     Sun.showError('请选择营业状态');
                //     return;
                // }
                this.parseData(this.form);
                Sun.post({
                    url: this.url.add,
                    data: this.form,
                    success: () => {
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            },
            parseAddress (idList) {
                let address = '';
                this.cityList.forEach((item) => {
                   if (item.i == idList[0]) {
                       address += item.n;
                       if (item.l) {
                            item.l.forEach((jtem) => {
                                if (jtem.i == idList[1]) {
                                    address += jtem.n;
                                    if (jtem.l) {
                                        jtem.l.forEach((ktem) => {
                                            if (ktem.i == idList[2]) {
                                                address += ktem.n;
                                            }
                                        });
                                    }
                                }
                            });
                       }
                       
                   }
                });
                return address;
            },
            parseData() {
                this.form.address = this.parseAddress(this.comCodeList);
                this.form.cityId = this.comCodeList[this.comCodeList.length - 1];
            }
        },
        props: ['data', 'show', 'callBack', 'url'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
