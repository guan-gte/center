<template>
    <el-dialog title="新建账号" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px">
            <el-form-item label="员工工号">
                <el-input disabled v-model="form.demo"></el-input>
            </el-form-item>
            <el-form-item required label="员工姓名">
                <el-input v-model="form.name"></el-input>
            </el-form-item>
            <el-form-item required label="员工手机号">
                <el-input v-model="form.phone"></el-input>
            </el-form-item>
            <el-form-item required label="员工身份证号">
                <el-input required v-model="form.idCard"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">确认</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                form: {}
            }
        },
        methods: {
            open () {
                this.form = {};
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.name) {
                    Sun.showError('请输入员工姓名');
                    return;
                }
                if (!this.form.phone) {
                    Sun.showError('请输入员工手机号');
                    return;
                }
                if (!this.form.idCard) {
                    Sun.showError('请输入员工身份证号');
                    return;
                }
                Sun.post({
                    url: this.url.add,
                    data: this.form,
                    success: () => {
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['url', 'show', 'callBack'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
