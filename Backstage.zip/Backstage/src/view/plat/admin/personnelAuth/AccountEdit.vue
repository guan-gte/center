<template>
    <el-dialog title="人事权限调动" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="100px">
            <el-form-item required label="员工工号">
                <el-input v-model="form.no"></el-input>
            </el-form-item>
            <el-form-item required label="员工姓名">
                <el-input v-model="form.name"></el-input>
            </el-form-item>
            <el-form-item required label="员工手机号">
                <el-input v-model="form.phone"></el-input>
            </el-form-item>
            <!-- 人事调动权限可以通过搜索员工手机号，员工姓名或者工号进行调出，输入其中一个后，自动拉取其他信息。 -->
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap} from "../../../../js/util";

    export default {
        data() {
            return {
                form: {}
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.no) {
                    Sun.showError('请输入员工工号');
                    return;
                }
                if (!this.form.name) {
                    Sun.showError('请输入员工姓名');
                    return;
                }
                if (!this.form.phone) {
                    Sun.showError('请输入员工手机号');
                    return;
                }
                Sun.post({
                    url: this.url.edit,
                    data: this.form,
                    success: () => {
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['data', 'url', 'show', 'callBack'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
