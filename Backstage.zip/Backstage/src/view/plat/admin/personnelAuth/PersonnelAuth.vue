<template>
    <Page>
        <div class="all clearfix">       
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span class="header-title">当前人事权限: {{detail.demo ? detail.demo : '未拥有'}}</span>
                    <el-button v-show="auth.edit"  @click="showEdit = true" style="margin-left: 20px;" round plain size="mini" type="primary">更改该权限</el-button>
                </div>
                <div class="main clearfix">    
                    <div v-show="auth.add && detail.status" class="footer-btn">
                        <el-button class="button-edit">取消</el-button>
                        <el-button class="button-edit" @click="showAdd = true" type="primary">创建新账号</el-button>
                    </div> 
                </div> 
            </el-card>
        </div>          
        <!--add-->
        <AccountAdd :url="url" :show="showAdd"
                       :callBack="(flag)=>{showAdd = false;if (flag) this.getInfo()}"></AccountAdd>
        <!--edit-->
        <AccountEdit :url="url" :show="showEdit" :data="editData"
                       :callBack="(flag)=>{showEdit = false;}"></AccountEdit>
    </Page>
</template>

<script>  
    import AccountAdd from './AccountAdd';
    import AccountEdit from './AccountEdit';
    const url = {
        edit: Http.master.editAuth,
        add: Http.master.editAuth,
    };
    export default {
        extends: Sun.vuePage,
        components: {AccountAdd, AccountEdit},
        data() {
            return {
                url: url,
                showAdd: false,
                showEdit: false,
                editData: {},
                auth: {
                    edit: true,
                    add: true
                },
                detail: {
                    // 1 拥有权限 0 未拥有权限 
                    status: 1,
                    demo: '权限权限'
                }
            }
        },
        methods: {
            getInfo () {

            }
        },        
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
        },
        filters: {  
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            float: left;
            .header-title {
                height: 32px;
                display: inline-block;
                height: 32px;
                line-height: 32px;
            }
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                    padding-right: 30px;
                    box-sizing: border-box;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
    }      
    .footer-btn {
        width: 100%;
        text-align: center;
    } 
</style>

