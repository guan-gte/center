<template>
    <Page>
        <el-form ref="form" class="el-form" style="margin-top: 20px;" :model="postData" label-width="250px"> 
            <el-form-item required label="请输入供应商公司名称">
                <el-input clearable v-model="postData.name" placeholder="请输入供应商公司名称"></el-input>
            </el-form-item>
            <el-form-item required label="请输入供应商公司简称">
                <el-input clearable v-model="postData.abbreviation" placeholder="最多8个字符"></el-input>
            </el-form-item>
            <el-form-item required label="请输入供应商联系方式">
                <el-input clearable v-model="postData.mobile" placeholder="请输入供应商联系方式"></el-input>
            </el-form-item>
            <el-form-item required label="请选择地址">
                <el-cascader :options="cityListNew" :props="optionProps" v-model="shopCityCodeList"></el-cascader>
            </el-form-item>
            <el-form-item required label="请输入详细地址">
                <el-input clearable v-model="postData.addressDetail" placeholder="请输入详细地址"></el-input>
            </el-form-item>
            <el-form-item required label="请上传营业执照">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadShopLicence"
                    :before-upload="beforeUpload">
                    <img v-if="postData.certificateImg" :key="postData.certificateImg" :src="setting.oss_http + postData.certificateImg" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
            </el-form-item>
            <el-form-item required label="请输入营业执照统一社会信用代码">
                <el-input clearable placeholder="请输入营业执照统一社会信用代码" v-model="postData.certificateNumber"></el-input>
            </el-form-item>
            <el-form-item required label="请上传开户许可证:">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadOpenLicence"
                    :before-upload="beforeUpload">
                    <img v-if="postData.licenceImg" :key="postData.licenceImg" :src="setting.oss_http + postData.licenceImg" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
            </el-form-item>
            <el-form-item required label="请输入开户许可证编号">
                <el-input clearable placeholder="请输入开户许可证编号" v-model="postData.licenceNumber"></el-input>
            </el-form-item>
            <el-form-item required label="请输入法人姓名">
                <el-input clearable v-model="postData.contact" placeholder="请输入法人姓名"></el-input>
            </el-form-item>
            <el-form-item required label="请上传法人身份证正面照">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadIdCardImg"
                    :before-upload="beforeUpload">
                    <img v-if="postData.frontIDCard" :key="postData.frontIDCard" :src="setting.oss_http + postData.frontIDCard" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
            </el-form-item>
            <el-form-item required label="请上传法人身份证反面照">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadIdCardImg2"
                    :before-upload="beforeUpload">
                    <img v-if="postData.reverseIDCard" :key="postData.reverseIDCard" :src="setting.oss_http + postData.reverseIDCard" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
            </el-form-item>
            <el-form-item required label="请输入开户行名称">
                <el-input clearable v-model="postData.bankName" placeholder="请输入开户行名称"></el-input>
            </el-form-item>
            <el-form-item required label="请输入公户银行卡号">
                <el-input clearable placeholder="请输入公户银行卡号" v-model="postData.bankNumer"></el-input>
            </el-form-item>
            <!--btn-->
            <el-form-item style="text-align: center;">
                <el-button type="primary" @click="submit()">提交</el-button>
                <el-button @click="cancel()">取消</el-button>
            </el-form-item>
        </el-form>     
    </Page>
</template>

<script>
    import {copyMap, getTime, formatTime, uuid, checkPhone} from "../../../../../js/util";
    import newCity from '../../../../../js/city';
    import setting from "../../../../../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);

    const url = {
        add: Http.plat.insertSupplier
    };
    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            return {
                loading: false,
                setting: setting,
                url: url,
                // 指定option
                optionProps: {
                    value: 'i',
                    label: 'n',
                    children: 'l'
                },
                postData: {
                    name: '',
                    abbreviation: '',
                    mobile: '',
                    contact: '',
                    cityCode: '',
                    address: '',
                    addressDetail: '',
                    img: '',
                    certificateImg: '',
                    certificateNumber: '',
                    licenceImg: '',
                    licenceNumber: '',
                    frontIDCard: '',
                    reverseIDCard: '',
                    // bank
                    bankName: '',
                    bankNumer: ''
                },
                // 省市区
                cityListNew: newCity,
                // shop地址
                shopCityCodeList: []
            }
        },
        created() {
        },
        activated () { 
        },
        mounted() {
        },
        computed: {
        },
        methods: {
            // 提交
            submit () {
                this.parsePost();
                if (!this.verifyForm(this.postData)) {
                    return;
                }
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                Sun.post({
                    url: this.url.add,
                    data: this.postData,
                    loading: true,
                    success: (data) => {
                        Sun.showMsg('已成功提交');
                        Sun.closePage();
                        Sun.push('/plat/supplyDepart/supplyChain/goods/supplier/supplier');
                    }
                });
            },
            parsePost () {
                // base info
                // 省市区转字符串
                let address = '';
                this.cityListNew.forEach((item) => {
                   if (item.i == this.shopCityCodeList[0]) {
                       address += item.n;
                       if (item.l) {
                            item.l.forEach((jtem) => {
                                if (jtem.i == this.shopCityCodeList[1]) {
                                    address += jtem.n;
                                    if (jtem.l) {
                                        jtem.l.forEach((ktem) => {
                                            if (ktem.i == this.shopCityCodeList[2]) {
                                                address += ktem.n;
                                            }
                                        });
                                    }
                                }
                            });
                       }
                   }
                });
                this.postData.address = address;
                this.postData.cityCode = this.shopCityCodeList[this.shopCityCodeList.length - 1];
            },
            verifyForm (data) {
                if (!data.name) {
                    Sun.showError('请输入供应商公司名称');
                    return false;
                }
                if (!data.abbreviation) {
                    Sun.showError('请输入供应商公司简称');
                    return false;
                }
                if (!data.mobile) {
                    Sun.showError('请输入供应商联系方式');
                    return false;
                }
                if (!checkPhone(data.mobile)) {
                    Sun.showError('请输入正确的联系人手机号');
                    return;
                }
                if (!data.cityCode) {
                    Sun.showError('请选择地址');
                    return false;
                }
                if (data.addressDetail.length < 3) {
                    Sun.showError('请输入详细地址');
                    return false;
                }
                if (!data.certificateImg) {
                    Sun.showError('请上传营业执照');
                    return false;
                }
                if (!data.certificateNumber) {
                    Sun.showError('请输入营业执照统一社会信用代码');
                    return false;
                }
                if (!data.licenceImg) {
                    Sun.showError('请上传开户许可证');
                    return false;
                }
                if (!data.licenceNumber) {
                    Sun.showError('请输入开户许可证编号');
                    return false;
                }  
                if (!data.contact) {
                    Sun.showError('请输入法人姓名');
                    return false;
                }
                if (!data.frontIDCard) {
                    Sun.showError('请上传法人身份证正面照');
                    return false;
                }
                if (!data.reverseIDCard) {
                    Sun.showError('请上传法人身份证反面照');
                    return false;
                }
                if (!data.bankName) {
                    Sun.showError('请输入开户行名称');
                    return false;
                }
                if (!data.bankNumer) {
                    Sun.showError('请输入公户银行卡号');
                    return false;
                }
                return true;
            },
            cancel () {
                // back
            },
            // 身份证正面
            uploadIdCardImg (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/supplier/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.postData.frontIDCard = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            // 身份证反面
            uploadIdCardImg2 (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/supplier/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.postData.reverseIDCard = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            // 营业执照
            uploadShopLicence (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/supplier/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.postData.certificateImg = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            // 开户许可证
            uploadOpenLicence (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/supplier/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.postData.licenceImg = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            beforeUpload (file) {
                // if (file.size / 1024 / 1024 > 2) {
                //     this.$message.error('上传图片大小不能超过 2MB!');
                //     return false;
                // }
                return true;
            }
        }
    }
</script>
<style>
    
</style>
<style scoped>
    .infor p{
        color: #606266;
    }
    /* img */
    .avatar-uploader .el-upload {
        width: 178px;
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
    /* form */
    .el-form-item {
        width: 700px;
    }
</style>
