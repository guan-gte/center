<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <el-button icon="el-icon-circle-plus-outline" v-show="auth.add" @click="add" type="primary">新增供应商</el-button>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatDay}}</div>
            <!-- 操作 -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="primary" plain size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.del" type="danger" plain size="mini" @click="del(data.row)">删除</el-button>
            </div>
        </SunTable>
    </page>
</template>

<script>
    import { formatDay } from "../../../../../js/util"; 

    const url = {
        table: Http.plat.getSupplierListPage,
        add: Http.plat.insertSupplier,
        edit: Http.plat.updateSupplier,
        del: Http.plat.deleteSupplier
    };
    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            return {
                goodsType: '',
                auth: {
                    add: true,
                    edit: true,
                    del: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '供应商ID',
                                key: 'id',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '供应商名称',
                                key: 'name',
                                align: 'left',
                                width: 240,
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '供应商简称',
                                key: 'abbreviation',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '法人姓名',
                                key: 'contact',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '联系方式',
                                key: 'mobile',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 180
                            }
                        ]
                    }
                }
            }
        },
        methods: {
            created () {
                // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
                // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
                // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            },
            add () {
                Sun.push('/plat/supplyDepart/supplyChain/goods/supplier/supplierAdd');
            },
            // 编辑
            edit (item) {
                Sun.push('/plat/supplyDepart/supplyChain/goods/supplier/supplierEdit', { id: item.id});
            },
            // 删除
            del (item) {
                Sun.confirm('提示', '确定要删除此供应商吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: { id: item.id },
                        success: () => {
                            Sun.showMsg('已删除！');
                            this.table.el.refresh();
                        }
                    });
                });
            }
        },
        filters: {
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
</style>
