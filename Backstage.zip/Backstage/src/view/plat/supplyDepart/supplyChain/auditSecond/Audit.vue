<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <el-button icon="el-icon-notebook-2" type="primary" @click="goodsList">产品列表</el-button>
            <div slot="type" slot-scope="data">{{data.row.type | formatType}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="mAuditStatus" slot-scope="data">
                <el-button v-if="data.row.mAuditStatus == 1" type="success" plain round size="mini" @click="pass(data.row)">点击通过</el-button>
                <span v-else-if="data.row.mAuditStatus == 2" style="color: #F56C6C">{{data.row.mAuditStatus | formatAuditStatus}}</span>
                <span v-else-if="data.row.mAuditStatus == 3" style="color: #32CD32">{{data.row.mAuditStatus | formatAuditStatus}}</span>
                <span v-else>/</span>
            </div>
            <!-- 操作 -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </page>
</template>

<script>
    import { formatTime } from '../../../../../js/util';
    const url = {
        table: Http.plat.getMyVfdGoodsPrePage,
        getCatListByPid: Http.plat.getCatListByPid,
        updateMAuditStatus: Http.plat.updateMAuditStatus
    };

    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            return {
                auth: {
                    query: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        param: {
                            pid: 0  
                        },
                        list: [
                            {
                                title: '产品ID',
                                key: 'id',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '产品名称',
                                key: 'name',
                                align: 'left',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品类型',
                                key: 'type',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '设备', value: '1'},
                                        {name: '配件/耗材', value: '2'},
                                        // {name: '耗材', value: '3'},
                                        // {name: '赠品', value: '4'},
                                        // {name: '工具', value: '5'}
                                    ]
                                },
                                filter:[
                                    {text: '设备', value: '= 1'},
                                    {text: '配件/耗材', value: '= 2'},
                                    // {text: '耗材', value: '= 3'},
                                    // {text: '赠品', value: '= 4'},
                                    // {text: '工具', value: '= 5'}
                                ]
                            },
                            {
                                title: '产品分类',
                                key: 'catName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '发起人',
                                key: 'createAdminName', 
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '发起时间',
                                key: 'createTime'
                            },
                            {
                                title: '二级审核状态',
                                key: 'mAuditStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待审核', value: '1'},
                                        {name: '审核通过', value: '2'},
                                        {name: '审核不通过', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '待审核', value: '= 1'},
                                    {text: '审核通过', value: '= 2'},
                                    {text: '审核不通过', value: '= 3'}
                                ]
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 100
                            }
                        ]
                    }
                },
                catList: [],
            }
        },
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.query, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            this.getSearchList();
        },
        methods: {
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 获取搜索项数据
            getSearchList () {
                // 商品分类列表
                Sun.post({
                    url: this.url.getCatListByPid,
                    data: {},
                    success: (data) => {
                        this.catList = data;
                        this.addSearchFilter('catName', this.catList, 'search',  'filter', 'name', 'name');
                    }
                });
            },
            // 审核通过
            pass (item) {
                let obj = {
                    mAuditStatus: 3,
                    goodsPreId: item.id
                }
                Sun.post({
                    url: this.url.updateMAuditStatus,
                    data: obj,
                    success: () => {
                        Sun.showMsg('已通过');
                        this.table.el.refresh();
                    }
                });
            },
            // 查看
            query (item) {
            //    Sun.push('/plat/supplyDepart/classifyAndScene/scene/detail', { id: item.id, name: item.name, createTime: item.createTime});
            },
            // 产品列表
            goodsList () {
                Sun.push('/plat/supplyDepart/supplyChain/goods/goods');
            }
        },
        filters: {
            formatType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '配件/耗材';
                    // case 3: return '耗材';
                    // case 4: return '赠品';
                    // case 5: return '工具';
                }
            },
            formatAuditStatus (status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return '待审核';
                    case 2: return '审核未通过';
                    case 3: return '审核通过';
                }
            },
            formatTime (time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
    .selection {
        margin-left: 10px;
    }
</style>
