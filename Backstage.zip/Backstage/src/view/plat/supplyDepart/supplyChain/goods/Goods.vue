<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <el-button icon="el-icon-notebook-2" type="primary" @click="myUploadList">我的上传列表</el-button>
            <el-select class="selection" v-show="auth.add" v-model="goodsType"  placeholder="请选择新增商品类型">
                <el-option label="设备" value="1"></el-option>
                <el-option label="配件/耗材" value="2"></el-option>
            </el-select>
            <el-button class="selection" icon="el-icon-circle-plus-outline" v-show="auth.add" @click="add" type="primary">新增商品</el-button>
            <div slot="type" slot-scope="data">{{data.row.type | formatType}}</div>
            <div slot="isOpen" slot-scope="data">
                <el-switch @change="change(data.row)" v-model="data.row.isOpen"
                    :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div>
            <!-- 操作 -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button>
                <el-button v-show="auth.edit" type="primary" plain size="mini" @click="edit(data.row)">编辑</el-button>
                <!-- <el-button v-show="auth.del" type="danger" plain size="mini" @click="del(data.row)">删除</el-button> -->
            </div>
        </SunTable>
    </page>
</template>

<script>
    import { formatDay } from "../../../../../js/util"; 

    const url = {
        table: Http.plat.getGoodsPrePage,
        getCatListByPid: Http.plat.getCatListByPid,
        getBrandList: Http.plat.getBrandList,
        getSupplierList: Http.plat.getSupplierList,
        del: Http.plat.delGoodsPreInfoById,
        updateIsOpenById: Http.plat.updateIsOpenById
    };
    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            return {
                goodsType: '',
                auth: {
                    add: true,
                    query: true,
                    edit: true,
                    del: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '产品ID',
                                key: 'id',
                                // hide: true,
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '产品名称',
                                key: 'name',
                                align: 'left',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品类型',
                                key: 'type',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '设备', value: '1'},
                                        {name: '配件/耗材', value: '2'},
                                        // {name: '耗材', value: '3'},
                                        // {name: '赠品', value: '4'},
                                        // {name: '工具', value: '5'}
                                    ]
                                },
                                filter:[
                                    {text: '设备', value: '= 1'},
                                    {text: '配件/耗材', value: '= 2'},
                                    // {text: '耗材', value: '= 3'},
                                    // {text: '赠品', value: '= 4'},
                                    // {text: '工具', value: '= 5'}
                                ]
                            },
                            {
                                title: '产品分类',
                                key: 'catName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '产品货号',
                                key: 'goodsNo',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '规格型号',
                                key: 'model',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '品牌',
                                key: 'brandName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '供应商',
                                key: 'supplyName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '提交人',
                                key: 'createAdminName',
                                search: {
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '开启状态',
                                key: 'isOpen',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '关闭', value: '0'},
                                        {name: '开启', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '关闭', value: '= 0'},
                                    {text: '开启', value: '= 1'}
                                ]
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 240
                            }
                        ]
                    }
                },
                catList: [],
                brandList: [],
                supplyList: []
            }
        },
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.query, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            this.getSearchList();
        },
        methods: {
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 获取搜索项数据
            getSearchList () {
                // 商品分类列表
                Sun.post({
                    url: this.url.getCatListByPid,
                    data: {},
                    success: (data) => {
                        this.catList = data;
                        this.addSearchFilter('catName', this.catList, 'search',  'filter', 'name', 'name');
                    }
                });
                // 商品品牌列表
                Sun.post({
                    url: this.url.getBrandList,
                    data: {},
                    success: (data) => {
                        this.brandList = data;
                        this.addSearchFilter('brandName', this.brandList, 'search',  'filter', 'name', 'name');
                    }
                });
                // 商品供应商列表
                Sun.post({
                    url: this.url.getSupplierList,
                    data: {},
                    success: (data) => {
                        this.supplyList = data;
                        this.addSearchFilter('supplyName', this.supplyList, 'search',  'filter', 'name', 'name');
                    }
                });
            },
            // 更改状态
            change (item) {
                Sun.post({
                    url: this.url.updateIsOpenById,
                    data: {goodsPreId: item.goodsPreId, isOpen: item.isOpen},
                    loading: true,
                    success: (res) => {
                        Sun.showMsg("修改成功");
                        this.table.el.refresh();
                    }
                });
            },
            // 新增商品
            add () {
                if (!this.goodsType) {
                    Sun.showError('请选择新增商品类型!');
                    return;
                } else {
                    switch (parseInt(this.goodsType)) {
                        case 1: 
                            Sun.push('/plat/supplyDepart/supplyChain/goods/equGoods/goodsAdd');
                        break;
                        case 2: 
                            Sun.push('/plat/supplyDepart/supplyChain/goods/partsGoods/goodsAdd');
                        break;
                    }
                }
            },
            // 查看
            query (item) {
                if (item.type == 1) {
                    Sun.push('/plat/supplyDepart/supplyChain/goods/equGoods/equDetail', { id: item.goodsPreId, goodsId: item.id});
                } else if (item.type == 2) {
                    Sun.push('/plat/supplyDepart/supplyChain/goods/partsGoods/partDetail', { id: item.goodsPreId, goodsId: item.id});
                }
            },
            // 编辑
            edit (item) {
               switch (parseInt(item.type)) {
                    case 1: 
                        Sun.push('/plat/supplyDepart/supplyChain/goods/equGoods/goodsEdit', {goodsPreId: item.goodsPreId});
                    break;
                    case 2: 
                        Sun.push('/plat/supplyDepart/supplyChain/goods/partsGoods/goodsEdit', {goodsPreId: item.goodsPreId});
                    break;
                }
            },
            // 删除
            del (item) {
                Sun.confirm('提示', '确定要删除此产品吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: { goodsPreId: item.goodsPreId },
                        success: () => {
                            Sun.showMsg('已删除！');
                            this.table.el.refresh();
                        }
                    });
                });
            },
            // 我的上传列表
            myUploadList () {
                Sun.push('/plat/supplyDepart/supplyChain/goods/uploadList/upload');
            }
        },
        filters: {
            formatType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '配件/耗材';
                    // case 3: return '耗材';
                    // case 4: return '赠品';
                    // case 5: return '工具';
                }
            },
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
    .selection {
        margin-left: 10px;
    }
</style>
