<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <el-button icon="el-icon-notebook-2" type="primary" @click="goodsList">产品列表</el-button>
            <div slot="type" slot-scope="data">{{data.row.type | formatType}}</div>
            <div slot="auditStatus" slot-scope="data">
                <span v-if="data.row.auditStatus == 1" style="color: #606266">{{data.row.auditStatus | formatAuditStatus}}</span>
                <span v-else-if="data.row.auditStatus == 2" style="color: #F56C6C">{{data.row.auditStatus | formatAuditStatus}}</span>
                <span v-else-if="data.row.auditStatus == 3" style="color: #32CD32">{{data.row.auditStatus | formatAuditStatus}}</span>
                <span v-else>/</span>
            </div>
            <!-- 操作 -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </page>
</template>

<script>
    import { formatTime } from '../../../../../../js/util';
    const url = {
        table: Http.plat.getMyGoodsPrePage,
        getCatListByPid: Http.plat.getCatListByPid,
        getBrandList: Http.plat.getBrandList,
        getSupplierList: Http.plat.getSupplierList
    };

    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            return {
                auth: {
                    query: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '产品ID',
                                key: 'IdOrGoodsId',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                },
                                hide: true
                            },
                            {
                                title: '产品名称',
                                key: 'name',
                                align: 'left',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品类型',
                                key: 'type',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '设备', value: '1'},
                                        {name: '配件/耗材', value: '2'},
                                        // {name: '耗材', value: '3'},
                                        // {name: '赠品', value: '4'},
                                        // {name: '工具', value: '5'}
                                    ]
                                },
                                filter:[
                                    {text: '设备', value: '= 1'},
                                    {text: '配件/耗材', value: '= 2'},
                                    // {text: '耗材', value: '= 3'},
                                    // {text: '赠品', value: '= 4'},
                                    // {text: '工具', value: '= 5'}
                                ]
                            },
                            {
                                title: '产品分类',
                                key: 'catName', 
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '产品货号',
                                key: 'goodsNo',
                                search: {
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '规格型号',
                                key: 'model',
                                search: {
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '品牌',
                                key: 'brandName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '供应商',
                                key: 'supplyName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '审核状态',
                                key: 'auditStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待审核', value: '1'},
                                        {name: '审核不通过', value: '2'},
                                        {name: '审核通过', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '待审核', value: '= 1'},
                                    {text: '审核不通过', value: '= 2'},
                                    {text: '审核通过', value: '= 3'}
                                ]
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 100
                            }
                        ]
                    }
                },
                catList: [],
                brandList: [],
                supplyList: []
            }
        },
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.query, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            this.getSearchList();
        },
        methods: {
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 获取搜索项数据
            getSearchList () {
                // 商品分类列表
                Sun.post({
                    url: this.url.getCatListByPid,
                    data: {},
                    success: (data) => {
                        this.catList = data;
                        this.addSearchFilter('catName', this.catList, 'search',  'filter', 'name', 'name');
                    }
                });
                // 商品品牌列表
                Sun.post({
                    url: this.url.getBrandList,
                    data: {},
                    success: (data) => {
                        this.brandList = data;
                        this.addSearchFilter('brandName', this.brandList, 'search',  'filter', 'name', 'name');
                    }
                });
                // 商品供应商列表
                Sun.post({
                    url: this.url.getSupplierList,
                    data: {},
                    success: (data) => {
                        this.supplyList = data;
                        this.addSearchFilter('supplyName', this.supplyList, 'search',  'filter', 'name', 'name');
                    }
                });
            },
            // 查看
            query (item) {
                if (item.type == 1) {
                    Sun.push('/plat/supplyDepart/supplyChain/goods/uploadList/equDetail', { id: item.id, goodsId: item.goodsId});
                } else if (item.type == 2) {
                    Sun.push('/plat/supplyDepart/supplyChain/goods/uploadList/partDetail', { id: item.id, goodsId: item.goodsId});
                }
            },
            // 产品列表
            goodsList () {
                Sun.push('/plat/supplyDepart/supplyChain/goods/goods');
            }
        },
        filters: {
            formatType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '配件/耗材';
                    // case 3: return '耗材';
                    // case 4: return '赠品';
                    // case 5: return '工具';
                }
            },
            formatAuditStatus (status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return '待审核';
                    case 2: return '审核不通过';
                    case 3: return '审核通过';
                }
            },
            formatTime (time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
    .selection {
        margin-left: 10px;
    }
</style>
