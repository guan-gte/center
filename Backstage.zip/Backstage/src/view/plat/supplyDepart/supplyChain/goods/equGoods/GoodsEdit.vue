<template>
    <page>
        <!-- 编辑 -->
        <!-- 产品基本信息 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 产品基本信息</el-divider>
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="15vw" class="demo-ruleForm">
            <el-form-item label="请输入产品名称" prop="name">
                <el-input clearable v-model="ruleForm.name"></el-input>
            </el-form-item>
            <!-- 图片 -->
            <el-form-item required class="main-img" label="图片" prop="img">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadMainImg"
                    :before-upload="beforeUpload">
                    <!-- <img v-if="ruleForm.img" :key="ruleForm.img" :src="setting.oss_http + ruleForm.img" class="avatar"> -->
                    <img v-if="ruleForm.img" :key="ruleForm.img" :src="containsString(ruleForm.img, setting.oss_http) ? ruleForm.img : setting.oss_http + ruleForm.img" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <!-- <div class="gray-color">建议图片长宽比例为750:320</div> -->
            </el-form-item>
            <el-form-item label="请输入产品货号" prop="goodsNo">
                <el-input placeholder="不得超过10个字符" clearable v-model="ruleForm.goodsNo"></el-input>
            </el-form-item>
            <el-form-item label="请输入规格型号" prop="model">
                <el-input placeholder="不得超过20个字符" clearable v-model="ruleForm.model"></el-input>
            </el-form-item>
            <el-form-item label="请选择产品品牌" prop="brandId">
                <el-select v-model="ruleForm.brandId" filterable>
                    <el-option v-for="(item, index) in brandList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="请选择产品供应商" prop="supplyId">
                <el-select v-model="ruleForm.supplyId" filterable>
                    <el-option v-for="(item, index) in supplyList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="请输入计量单位" prop="unit">
                <el-input placeholder="不得超过4个字符" clearable v-model="ruleForm.unit"></el-input>
            </el-form-item>
            <el-form-item label="请输入进货价" prop="stockPrice">
                <el-input placeholder="数字" clearable v-model.number="ruleForm.stockPrice"></el-input>
            </el-form-item>
            <el-form-item label="请输入调拨比例(%)" prop="allotProportion">
                <el-input placeholder="0% ~ 100%" clearable v-model.number="ruleForm.allotProportion"></el-input>
            </el-form-item>
            <el-form-item label="请输入产品原价" prop="oldPrice">
                <el-input placeholder="数字" clearable v-model.number="ruleForm.oldPrice"></el-input>
            </el-form-item>
            <el-form-item label="请输入产品零售价" prop="price">
                <el-input placeholder="数字" clearable v-model.number="ruleForm.price"></el-input>
            </el-form-item>
            <el-form-item label="请输入工作时长(天)" prop="workDuration">
                <el-input placeholder="数字" clearable v-model.number="ruleForm.workDuration"></el-input>
            </el-form-item>
            <el-form-item label="请输入设备有效期(月)" prop="indate">
                <el-input placeholder="数字" clearable v-model.number="ruleForm.indate"></el-input>
            </el-form-item>
            <!-- 参数信息 -->
                <!-- cat -->
            <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 产品参数信息</el-divider>
            <el-form-item label="请选择产品一级分类" prop="catId">
                <el-select @change="changeFirstCat" v-model="ruleForm.catId" filterable>
                    <el-option v-for="(item, index) in firstCatList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item v-if="secCatList.length" label="请选择产品二级分类" prop="secCatIdList">
                <el-checkbox-group v-model="ruleForm.secCatIdList">
                    <el-checkbox @change="changeSecCat(cat)" v-for="(cat, index) in secCatList" :key="index" :label="cat.id">{{cat.name}}</el-checkbox>
                </el-checkbox-group>
            </el-form-item>
            <el-form-item v-if="thirdCatList.length" label="请选择产品三级分类" prop="thirdCatIdList">
                <div v-for="(pitem, index) in thirdCatList" :key="index">
                    <span style="color: #303133;">{{pitem.pName}}：</span>
                    <el-checkbox-group style="display: inline-block;" v-model="ruleForm.thirdCatIdList">
                        <el-checkbox v-for="(item, cindex) in pitem.list" :key="cindex" :label="item.id">{{item.name}}</el-checkbox>
                    </el-checkbox-group>
                </div>
            </el-form-item>
                <!-- spu -->
            <el-form-item v-if="ruleForm.spuList.length" label="请输入产品SPU参数" prop="spuList">
                <el-table :data="ruleForm.spuList" border style="width: 100%">
                    <el-table-column align="center" label="所属产品二级分类">
                        <template slot-scope="scope">
                            <i class="el-icon-menu"></i>
                            <span style="margin-left: 10px">{{ scope.row.catName }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="SPU分类名称">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.pName }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="SPU属性名称">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.name }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="SPU属性值">
                        <template slot-scope="scope">
                            <el-input placeholder="SPU属性值" clearable v-model="scope.row.value"></el-input>
                        </template>
                    </el-table-column>
                </el-table>
            </el-form-item>

            <!-- 应用场景 -->
            <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 产品应用场景</el-divider>
            <el-form-item label="请勾选应用场景" prop="sceneIdList">
                <div v-for="(pitem, index) in sceneList" :key="index">
                    <span style="color: #303133;">{{pitem.name}}：</span>
                    <el-checkbox-group style="display: inline-block;" v-model="ruleForm.sceneIdList">
                        <el-checkbox  v-for="(item, cindex) in pitem.list" :key="cindex" :label="item.id">{{item.name}}</el-checkbox>
                    </el-checkbox-group>
                </div>
            </el-form-item>

            <!-- 整机配件 -->
            <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 产品整机配件</el-divider>
            <el-form-item label="添加整机配件" prop="partList">
                <div style="text-align: right; margin-bottom: 10px;"><el-button @click="showAdd = true" type="primary" plain round size="mini">添加新配件</el-button></div>
                <el-table :data="ruleForm.partList" border style="width: 100%">
                    <el-table-column align="center" label="产品ID">
                        <template slot-scope="scope">
                            <i class="el-icon-menu"></i>
                            <span style="margin-left: 10px">{{ scope.row.id }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="产品名称">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.brandName }}{{ scope.row.name }}{{ scope.row.model }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="数量">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.num }}</span>
                            <!-- <el-input placeholder="数量" clearable v-model="scope.row.num"></el-input> -->
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="操作">
                        <template slot-scope="scope">
                            <el-button type="danger" plain size="mini" @click="delSelectedGoods(scope.row,)">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-form-item>
            <!-- 新增商品 -->
            <el-dialog title="添加新配件" :visible.sync="showAdd" @open="open" top="12vh" width="600px">
                <el-form size="mini" class="el-form-add" ref="form" :model="selectedGoods" label-width="150px">
                    <el-form-item label="请输入搜索产品名称">
                        <el-select @change="selcetedGoods" v-model="selcetedGoodsId" filterable :filter-method="searchGoods" placeholder="请搜索并选择产品">
                            <el-option v-for="ktem in searchGoodsList" 
                                        :key="ktem.id" 
                                        :label="(ktem.brandName ? ktem.brandName : '') + ktem.name + ktem.model" 
                                        :value="ktem.id">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item required label="请输入数量">
                        <el-input v-model="selectedGoods.num"></el-input>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <div class="el-line-add"></div>
                    <el-button class="el-button-add" :loading="loading" type="primary" @click="addParts()">确认</el-button>
                    <el-button class="el-button-add" @click="close">取消</el-button>
                </div>
            </el-dialog>
            <el-form-item style="text-align: center;">
                <el-button @click="back">返回列表</el-button>
                <el-button @click="resetForm('ruleForm')">重置</el-button>
                <el-button type="primary" @click="submitForm('ruleForm')">提交修改</el-button>
            </el-form-item>
        </el-form>
    </page>
</template>

<script>
    import { isNumber, getTime, formatTime, uuid, containsString } from '../../../../../../js/util';
    import setting from "../../../../../../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);
    const url = {
        getBrandList: Http.plat.getBrandList,
        getSupplierList: Http.plat.getSupplierList,
        getCatListByPid: Http.plat.getCatListByPid,
        getGoodsDataList: Http.plat.getGoodsDataList,
        getCatParamDataByCatIdGoodsPre: Http.plat.getCatParamDataByCatIdGoodsPre,
        getGoodByKeywordsOrGoodsId: Http.plat.getGoodByKeywordsOrGoodsId,
        editGoodsPreInfo: Http.plat.editGoodsPreInfo,
        getGoodsPreInfoById: Http.plat.getGoodsPreInfoById,
    };
    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            var checkRate = (rule, value, callback) => {
                setTimeout(() => {
                    if (!isNumber(value)) {
                        callback(new Error('请输入数字值'));
                    } else {
                        if (value < 0 || value > 100) {
                            callback(new Error('调拨比例请输入1-100'));
                        } else {
                            callback();
                        }
                    }
                }, 1000);
            };
            return {
                setting: setting,
                url: url,
                loading: false,
                // listData
                brandList: [], // 品牌
                supplyList: [], // 供应商
                firstCatList: [], // 一级分类
                secCatList: [], // 二级分类
                thirdCatList: [], // 三级分类
                sceneList: [], // 应用场景
                // 添加商品相关
                showAdd: false,
                selcetedGoodsId: '',
                searchGoodsName: '',
                searchGoodsList: [],
                selectedGoods: {},
                // postData
                ruleForm: {
                    // 基本信息
                    name: '',
                    img: '',
                    goodsNo: '',
                    model: '',
                    brandId: '',
                    supplyId: '',
                    unit: '',
                    stockPrice: '',
                    allotProportion: '',
                    oldPrice: '',
                    price: '',
                    workDuration: '',
                    indate: '',
                    // 参数信息
                    catId: '',
                    secCatIdList: [],
                    thirdCatIdList: [],
                    spuList: [],

                    // 应用场景
                    sceneIdList: [],
                    // 整机配件
                    partList: []
                },
                rules: {
                    // 基本信息
                    name: [
                        { required: true, message: '请输入产品名称', trigger: 'blur' }
                    ],
                    img: [
                        { required: true, message: '请上传图片', trigger: 'blur' }
                    ],
                    goodsNo: [
                        { required: true, message: '请输入产品货号', trigger: 'blur' },
                        { min: 1, max: 10, message: '长度在 1 到 10 个字符', trigger: 'blur' }
                    ],
                    model: [
                        { required: true, message: '请输入规格型号', trigger: 'blur' },
                        { min: 1, max: 20, message: '长度在 1 到 20 个字符', trigger: 'blur' }
                    ],
                    brandId: [
                        { required: true, message: '请选择产品品牌', trigger: 'change' }
                    ],
                    supplyId: [
                        { required: true, message: '请选择产品供应商', trigger: 'change' }
                    ],
                    unit: [
                        { required: true, message: '请输入计量单位', trigger: 'blur' },
                        { min: 1, max: 4, message: '长度在 1 到 4 个字符', trigger: 'blur' }
                    ],
                    stockPrice: [
                        { required: true, message: '请输入进货价', trigger: 'blur' },
                        { type: 'number', message: '价格必须为数字值'}
                    ],
                    allotProportion: [
                        { required: true, message: '请输入调拨比例', trigger: 'blur' },
                        { validator: checkRate, trigger: 'blur' }
                    ],
                    oldPrice: [
                        { required: true, message: '请输入原价', trigger: 'blur' },
                        { type: 'number', message: '价格必须为数字值'}
                    ],
                    price: [
                        { required: true, message: '请输入产品零售价', trigger: 'blur' },
                        { type: 'number', message: '价格必须为数字值'}
                    ],
                    workDuration: [
                        { required: true, message: '请输入工作时长', trigger: 'blur' },
                        { type: 'number', message: '价格必须为数字值'}
                    ],
                    indate: [
                        { required: true, message: '请输入设备有效期', trigger: 'blur' },
                        { type: 'number', message: '价格必须为数字值'}
                    ],
                    // 参数信息
                    catId: [
                        { required: true, message: '请选择产品一级分类', trigger: 'change' }
                    ],
                    // secCatIdList: [
                    //     { type: 'array', required: true, message: '请至少选择一个二级分类', trigger: 'change' }
                    // ],
                },
                goodsId: ''
            }
        },
        created () {
            this.getBrandList();
            this.getSupplierList();
            this.getSceneList();
            let goodsId = Sun.getQuery('goodsPreId');
            if (goodsId) {
                this.goodsId = goodsId;
                this.getGoods(this.goodsId);
            }
        },
        methods: {
            submitForm (formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        // 产品基础信息
                        let goodsPreMapList = {
                            "id": this.goodsId,
                            "type": 1,
                            "img": this.ruleForm.img,
                            "name": this.ruleForm.name,
                            "goodsNo": this.ruleForm.goodsNo,
                            "model": this.ruleForm.model,
                            "brandId": this.ruleForm.brandId,
                            "supplyId": this.ruleForm.supplyId,
                            "unit": this.ruleForm.unit,
                            "stockPrice": this.ruleForm.stockPrice,
                            "allotProportion": this.ruleForm.allotProportion,
                            "oldPrice": this.ruleForm.oldPrice,
                            "price": this.ruleForm.price,
                            "workDuration": this.ruleForm.workDuration,
                            "indate": this.ruleForm.indate,
                            "catId": this.ruleForm.catId,
                        }
                        // 二级分类
                        let catTwoIdList = this.ruleForm.secCatIdList;
                        // 三级分类
                        let catThreeIdList = [];
                        if (this.ruleForm.thirdCatIdList.length) {
                            this.ruleForm.thirdCatIdList.forEach(item => {
                                catThreeIdList.push(item)
                            })
                        }
                        // spu
                        let goodsParamPreList = [];
                        let isNull = false;
                        if (this.ruleForm.spuList.length) {
                            this.ruleForm.spuList.forEach(item => {
                                goodsParamPreList.push({
                                    id: item.paramDataId,
                                    pid: item.pid,
                                    value: item.value
                                })
                                if (item.value === ''){
                                    isNull = true;
                                }
                            })
                        }
                        if (isNull) {
                            Sun.showError('请填写完整SPU参数信息!');
                            return;
                        }
                        // 场景
                        let goodsDataPreList = [];
                        if (this.ruleForm.sceneIdList.length) {
                            this.ruleForm.sceneIdList.forEach(item => {
                                goodsDataPreList.push(item)
                            })
                        }
                        // 配件
                        let goodsPartsPreList = [];
                        if (this.ruleForm.partList.length) {
                            this.ruleForm.partList.forEach(item => {
                                goodsPartsPreList.push({
                                    id: item.id,
                                    num: item.num
                                })
                            })
                        }
                        Sun.post({
                            url: this.url.editGoodsPreInfo,
                            data: {
                                goodsPreMapList: goodsPreMapList,
                                catTwoIdList: catTwoIdList,
                                catThreeIdList: catThreeIdList,
                                goodsParamPreList: goodsParamPreList,
                                goodsDataPreList: goodsDataPreList,
                                goodsPartsPreList: goodsPartsPreList
                            },
                            loading: true,
                            success: (data) => {
                                Sun.showMsg('编辑成功，可以进入我的产品上传列表进行查看');
                                Sun.closePage();
                                Sun.push('/plat/supplyDepart/supplyChain/goods/goods');
                            }
                        });
                    } else {
                        Sun.showError('填写内容有误');
                        return false;
                    }
                });
            },
            resetForm (formName) {
                this.$refs[formName].resetFields();            
                // reset
                this.secCatList = [];
                this.ruleForm.secCatIdList = [];

                this.thirdCatList = [];
                this.ruleForm.thirdCatIdList = [];

                this.ruleForm.spuList = [];
                this.ruleForm.sceneIdList = [];
                this.ruleForm.partList = [];
            },
            // 获取商品详情
            getGoods (goodsId) {
                Sun.post({
                    url: this.url.getGoodsPreInfoById,
                    data: {id: goodsId},
                    success: (data) => {
                        this.parseData(data);
                    }
                });
            },
            parseData (data) {
                // 基本信息
                this.ruleForm.name = data.goodsPreMapList.name;
                this.ruleForm.img = data.goodsPreMapList.img;
                this.ruleForm.goodsNo = data.goodsPreMapList.goodsNo;
                this.ruleForm.model = data.goodsPreMapList.model;
                this.ruleForm.brandId = data.goodsPreMapList.brandId;
                this.ruleForm.supplyId = data.goodsPreMapList.supplyId;
                this.ruleForm.unit = data.goodsPreMapList.unit;
                this.ruleForm.stockPrice = data.goodsPreMapList.stockPrice;
                this.ruleForm.allotProportion = data.goodsPreMapList.allotProportion;
                this.ruleForm.oldPrice = data.goodsPreMapList.oldPrice;
                this.ruleForm.price = data.goodsPreMapList.price;
                this.ruleForm.workDuration = data.goodsPreMapList.workDuration;
                this.ruleForm.indate = data.goodsPreMapList.indate;
                // 一级分类
                this.getFirstCat(0, data.goodsPreMapList.catId);
                // 二级分类
                this.getSecCat(data.goodsPreMapList.catId, data.catTwoIdList, data.catThreeIdList);
                // spu
                if (data.goodsParamPreList.length) {
                    data.goodsParamPreList.forEach(item => {
                        this.ruleForm.spuList.push({
                            paramDataId: item.paramId,
                            catId: item.catId,
                            catName: item.catName,
                            pName: item.pname,
                            name: item.name,
                            value: item.value,
                        });
                    })
                }
                // 场景
                if (data.goodsDataPreList.length) {
                    data.goodsDataPreList.forEach(item => {
                        this.ruleForm.sceneIdList.push(item.goodsDataId);
                    })
                }
                // 配件
                this.ruleForm.partList = [];
                if (data.goodsPartsPreList.length) {
                    data.goodsPartsPreList.forEach(item => {
                        this.ruleForm.partList.push({
                            id: item.partsId,
                            num: item.number,
                            name: item.name,
                            model: item.model,
                            brandName: item.brandName,
                        })
                    })
                }
            },
            // 一级分类back
            getFirstCat (pid, catId) {
                Sun.post({
                    url: this.url.getCatListByPid,
                    data: { pid: pid },
                    success: (data) => {
                        this.firstCatList = data;
                        this.ruleForm.catId = catId;
                    }
                });
            },
            // 二级分类back
            getSecCat (pid, catTwoIdList, catThreeIdList) {
                Sun.post({
                    url: this.url.getCatListByPid,
                    data: { pid: pid },
                    success: (data) => {
                        this.secCatList = data;
                        this.ruleForm.secCatIdList = [];
                        if (catTwoIdList.length) {
                            catTwoIdList.forEach(item => {
                                this.ruleForm.secCatIdList.push(item.id);
                            })
                        }
                        // 三级分类
                        this.getTirCat(catTwoIdList, catThreeIdList);
                    }
                });
            },
            //三级分类back
            getTirCat (catTwoIdList, catThreeIdList){
                if (!catTwoIdList.length) {
                    return;
                }
                this.thirdCatList = [];
                this.ruleForm.thirdCatIdList = [];
                // 是否加载完
                let flag = 0;
                catTwoIdList.forEach(item => {
                    let arr = [];
                    Sun.post({
                        url: this.url.getCatListByPid,
                        data: { pid: item.id },
                        success: (data) => {
                            // 加载次数++
                            ++flag;
                            if (data.length) {
                                arr.push({
                                    pid: item.id,
                                    pName: item.name,
                                    list: data
                                })
                            }
                            this.thirdCatList = this.thirdCatList.concat(arr);
                            // 加载完后 再对选中三级分类id赋值
                            if (flag == catTwoIdList.length) {
                                if (catThreeIdList.length) {
                                    catThreeIdList.forEach(simi => {
                                        if (this.thirdCatList.length) {
                                            this.thirdCatList.forEach(ele => {
                                                if (ele.list.length) {
                                                    ele.list.forEach(childEle => {
                                                        if (simi.id == childEle.id) {
                                                            // 三级分类选中id
                                                            this.ruleForm.thirdCatIdList.push(simi.id);
                                                        }
                                                    })
                                                }
                                            })
                                        }
                                    })
                                }
                                this.$forceUpdate();
                            }
                        }
                    });
                    
                })
            },
            // 获取品牌列表
            getBrandList () {
                Sun.post({
                    url: this.url.getBrandList,
                    data: {},
                    success: (data) => {
                        this.brandList = data;
                    }
                });
            },
            // 获取供应商列表
            getSupplierList () {
                Sun.post({
                    url: this.url.getSupplierList,
                    data: {},
                    success: (data) => {
                        this.supplyList = data;
                    }
                });
            },
            // 产品一级分类修改 获取二级分类列表
            changeFirstCat () {
                // reset
                this.secCatList = [];
                this.ruleForm.secCatIdList = [];
                this.thirdCatList = [];
                this.ruleForm.thirdCatIdList = [];
                this.ruleForm.spuList = [];
                // 二级分类列表
                this.getCatList(this.ruleForm.catId, 2);
            },
            // 产品二级分类修改
            changeSecCat (cat) {
                // 更改
                let isChecked = false;
                if (this.ruleForm.secCatIdList.length) {
                    this.ruleForm.secCatIdList.forEach((ele, eindex) => {
                        if (ele == cat.id) {
                            isChecked = true;
                            if (isChecked) {
                                // 三级分类
                                let isHas = false;
                                this.thirdCatList.forEach((item, index) => {
                                    if (item.pName == cat.name) {
                                        isHas = true;
                                    }
                                })
                                // 获取三级分类
                                if (!isHas) {
                                    this.getCatList(cat.id, 3, cat.name, cat.id);
                                }
                            }
                        }
                    })
                } else {
                    // reset 
                    this.thirdCatList = []; 
                    this.thirdCatIdList = []; 
                }
                if (!isChecked) {
                    // 二级分类按钮取消选择 删除 其下三级分类
                    this.thirdCatList.forEach((item, index) => {
                        if (item.pName == cat.name) {
                            this.thirdCatList.splice(index, 1);
                        }
                    })
                    // 二级分类按钮取消选择 删除 其下选中三级分类 id
                    let thirdIdList = this.ruleForm.thirdCatIdList;
                    for (let i = 0; i < thirdIdList.length; i++) {
                        // 截取三级分类父级 id 作为pid
                        let pid = thirdIdList[i].toString().substring(0, 4);
                        if (pid == cat.id) {
                            this.ruleForm.thirdCatIdList.splice(i, 1);
                            i--;
                        }
                    }
                    //spu
                    if (this.ruleForm.spuList.length) {
                        for ( let i = 0; i < this.ruleForm.spuList.length; i++) {
                            if (this.ruleForm.spuList[i].catId == cat.id) {
                                this.ruleForm.spuList.splice(i, 1);
                                i--;
                            }
                        }
                    }
                } else {
                    // spu
                    this.getSpu(cat.id, cat.name);
                }
            },
            // 获取二级分类下spu
            getSpu (catId, catName) {
                Sun.post({
                    url: this.url.getCatParamDataByCatIdGoodsPre,
                    data: { catId: catId },
                    success: (data) => {
                        if (data.length) {
                            data.forEach(item => {
                                item.catName = catName;
                                item.value = '';
                            })
                            this.ruleForm.spuList = this.ruleForm.spuList.concat(data);
                        }
                    }
                });
            },
            // 产品分类列表
            getCatList (pid, level, pName, secId) {
                Sun.post({
                    url: this.url.getCatListByPid,
                    data: { 
                        pid: pid,
                        type: level == 1 ? 1 : ''
                    },
                    success: (data) => {
                        switch (level) {
                            case 1: return this.firstCatList = data;
                                break;
                            case 2: return this.secCatList = data;
                                break;
                            case 3: 
                                let arr = [];
                                // simi
                                let isHas = false;
                                if (this.thirdCatList.length) {
                                    this.thirdCatList.forEach(item => {
                                        if (pName == item.pName) {
                                            isHas = true;
                                        }
                                    })
                                }
                                // 三级分类
                                if (data.length && !isHas) {
                                    arr.push({
                                        pid: secId,
                                        pName: pName,
                                        list: data
                                    })
                                }
                                this.thirdCatList = this.thirdCatList.concat(arr);
                                break;
                        }
                    }
                });
            },
            // 产品应用场景列表
            getSceneList () {
                Sun.post({
                    url: this.url.getGoodsDataList,
                    data: {},
                    success: (data) => {
                        if (data.length) {
                            data.forEach((item, index) => {
                                if (!item.list.length) {
                                    data.splice(index, 1);
                                }
                            })
                        }
                        this.sceneList = data;
                    }
                });
            },
            // 添加整机配件
            open () {
                this.loading = false;
                this.selectedGoods = {};
                this.selcetedGoodsId = '';
                this.searchGoodsName = '';
                this.searchGoodsList = [];
            },
            close () {
                this.showAdd = false;
                this.selectedGoods = {};
                this.selcetedGoodsId = '';
                this.searchGoodsName = '';
                this.searchGoodsList = [];
            },
            // 搜索商品
            searchGoods (val) {
                this.searchGoodsName = val;
                this.searchGoodsList = [];
                Sun.post({
                    url: this.url.getGoodByKeywordsOrGoodsId,
                    data: {
                        goodsId: '',
                        keywords: this.searchGoodsName
                    },
                    loading: true,
                    success: (data) => {
                        this.searchGoodsList = data;
                        this.searchGoodsName = '';
                    }
                });
            },
            // 选中一个商品
            selcetedGoods () {
                this.searchGoodsList.forEach(ele => {
                    if (this.selcetedGoodsId == ele.id) {
                        this.selectedGoods = ele;
                    }
                })
            },
            // 确认添加一个配件
            addParts () {   
                if (!this.selectedGoods.id) {
                    Sun.showError('请选择产品!');
                    return;
                }
                if (!this.selectedGoods.num) {
                    Sun.showError('请设置数量!');
                    return;
                }
                // 
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                this.ruleForm.partList.push(this.selectedGoods);
                this.showAdd = false;
                this.selectedGoods = {};
            },
            // 删除已添加配件
            delSelectedGoods (item) {
                this.ruleForm.partList.forEach((ele, index) => {
                    if (ele.id == item.id) {
                        this.ruleForm.partList.splice(index, 1);
                    }
                })
            },
            uploadMainImg (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/goods/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.ruleForm.img = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            beforeUpload (file) {
                if (file.size / 1024 / 1024 > 2) {
                    this.$message.error('上传图片大小不能超过 2MB!');
                    return false;
                }
                return true;
            },
            containsString (long, short) {
                return containsString(long, short);
            },
            back () {
                Sun.closePage();
                Sun.push('/plat/supplyDepart/supplyChain/goods/goods');
            }
        }
    }
</script>

<style scoped>
    /* form */
    .el-form-item {
        /* width: 700px; */
        margin-bottom: 25px;
    }
    /* divider */
    .el-divider__text{
        color: #67C23A;
    }
    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }
    /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
    /* 上传 */
    .avatar-uploader .el-upload {
        width: 178px;
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>
