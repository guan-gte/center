<template>
    <page>
        <!-- 产品列表配件详情 -->
        <!-- 产品基本信息 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 分类信息</el-divider>
        <el-row class="row-box" :gutter="10">
            <el-col :md="12" :lg="8" :xl="6">商品ID:{{goodsId}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">产品名称:{{goods.goodsPreMapList.name}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">产品货号:{{goods.goodsPreMapList.goodsNo}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">规格型号:{{goods.goodsPreMapList.model}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">产品品牌:{{goods.goodsPreMapList.brandName}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">产品供应商:{{goods.goodsPreMapList.supplyName}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">计量单位:{{goods.goodsPreMapList.unit}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">进货价:{{goods.goodsPreMapList.stockPrice}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">调拨比例:{{goods.goodsPreMapList.allotProportion}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">实际进货价格:{{goods.goodsPreMapList.stockPrice}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">产品原价:{{goods.goodsPreMapList.oldPrice}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">产品零售价:{{goods.goodsPreMapList.price}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">工作时长:{{goods.goodsPreMapList.workDuration ? `${goods.goodsPreMapList.workDuration}天` : '/'}}</el-col>
            <el-col :md="12" :lg="8" :xl="6">设备有效期:{{goods.goodsPreMapList.indate ? `${goods.goodsPreMapList.indate}个月` : '/'}}</el-col>
        </el-row>
        <!-- 参数信息 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 参数信息</el-divider>
        <el-row class="row-box" :gutter="10">
            <el-col :md="12" :lg="12" :xl="12">产品类型:
                <span>{{goods.goodsPreMapList.type | formatType}}</span>
            </el-col>
            <el-col :md="12" :lg="12" :xl="12">产品一级分类:
                <el-tag type="info">{{goods.goodsPreMapList.catName}}</el-tag>
            </el-col>
            <el-col v-if="goods.catTwoIdList.length" :md="12" :lg="12" :xl="12">产品二级分类:
                <el-tag v-for="(item, index) in goods.catTwoIdList" :key="index" type="info">{{item.name}}</el-tag>
            </el-col>
            <el-col v-if="0" :md="24" :lg="24" :xl="24">产品三级分类:
                <el-table border :data="goods.catThreeIdList" style="width: 100%;margin-top: 15px;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in catThreeColumns" :key="index">
                        <template slot-scope="scope">
                            <slot v-if="item.key == 'name'" :name="item.key" :row="scope.row">
                                <el-tag type="info">{{scope.row[item.key]}}</el-tag>
                            </slot>
                            <slot v-else :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-row>
        <!-- SPU参数 -->
        <el-divider v-if="goods.goodsParamPreList.length" class="divider" content-position="left"><i class="el-icon-collection-tag"></i> SPU参数</el-divider>
        <el-table v-if="goods.goodsParamPreList.length" border :data="goods.goodsParamPreList" style="width: 100%;">
            <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in paramColumns" :key="index">
                <template slot-scope="scope">
                    <slot :name="item.key" :row="scope.row">
                        {{scope.row[item.key]}}
                    </slot>
                </template>
            </el-table-column>
        </el-table>
        <!-- 应用场景 -->
        <el-divider v-if="goods.goodsDataPreList.length" class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 应用场景</el-divider>
        <el-table v-if="goods.goodsDataPreList.length" border :data="goods.goodsDataPreList" style="width: 100%;">
            <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in sceneColumns" :key="index">
                <template slot-scope="scope">
                    <slot :name="item.key" :row="scope.row">
                        {{scope.row[item.key]}}
                    </slot>
                </template>
            </el-table-column>
        </el-table>
        <!-- 适用机型 -->
        <el-divider v-if="goods.goodsPartsPreList.length" class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 适用机型</el-divider>
        <el-table v-if="goods.goodsPartsPreList.length" border :data="goods.goodsPartsPreList" style="width: 100%;">
            <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in partsColumns" :key="index">
                <template slot-scope="scope">
                    <slot v-if="item.key == 'name'" :name="item.key" :row="scope.row">
                        {{scope.row['name']}}
                    </slot>
                    <slot v-else-if="item.key == 'brandName'" :name="item.key" :row="scope.row">
                        {{scope.row['brandName'] ? scope.row['brandName'] : '/'}}
                    </slot>
                    <slot v-else :name="item.key" :row="scope.row">
                        {{scope.row[item.key]}}
                    </slot>
                </template>
            </el-table-column>
        </el-table> 
        
        <div class="footer">
            <el-button class="button-edit" @click="back" type="primary" plain>返回产品列表</el-button>
        </div>  
    </page>
</template>

<script>   

    const url = {
        getGoodsPreInfoById: Http.plat.getGoodsPreInfoById
    };

    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            return {
                url: url,
                id: '',
                goodsId: '',
                goods: {
                    goodsPreMapList: {},
                    catTwoIdList: [],
                    catThreeIdList: [],
                    goodsParamPreList: [],
                    goodsDataPreList: [],
                    goodsPartsPreList: [],
                },
                partsColumns: [
                    {
                        title: '产品ID',
                        key: 'partsId',
                    },
                    {
                        title: '产品品牌',
                        key: 'brandName',
                    },
                    {
                        title: '产品名称',
                        key: 'name',
                    },
                    {
                        title: '产品型号',
                        key: 'model',
                    },
                    {
                        title: '产品货号',
                        key: 'goodsNo',
                    },
                    {
                        title: '数量',
                        key: 'number',
                    }
                ],
                paramColumns: [
                    {
                        title: '所属产品一级分类',
                        key: 'catName',
                    },
                    {
                        title: 'SPU分类名称',
                        key: 'pname',
                    },
                    {
                        title: 'SPU属性名称',
                        key: 'name',
                    },
                    {
                        title: 'SPU属性值',
                        key: 'value',
                    }
                ],
                sceneColumns: [
                    {
                        title: '所属应用场景分类',
                        key: 'pname',
                    },
                    {
                        title: '适用场景',
                        key: 'name',
                    },
                ],
                catThreeColumns: [
                    {
                        title: '所属二级分类',
                        key: 'pname',
                    },
                    {
                        title: '三级分类',
                        key: 'name',
                    },
                ]
            }
        },
        created () {
            let id = Sun.getQuery('id');
            let goodsId = Sun.getQuery('goodsId');
            if (id) {
                this.id = id;
                this.goodsId = goodsId;
                this.getGoods(this.id);
            }
        },
        methods: {
            getGoods (id) {
                Sun.post({
                    url: this.url.getGoodsPreInfoById,
                    data: { id: id },
                    success: (data) => {
                        this.goods = data;
                    }
                });
            },
            back () {
                Sun.closePage();
                Sun.push('/plat/supplyDepart/supplyChain/goods/goods');
            }
        },
        filters: {
            formatType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '配件/耗材';
                    // case 3: return '耗材';
                    // case 4: return '赠品';
                    // case 5: return '工具';
                }
            },
        }
    }
</script>

<style lang="less" scoped>
    @import url('../../../../../../assets/css/config.less');
    .row-box {
        padding: 20px 20px;
        padding-bottom: 0;
        box-sizing: border-box;
    }
    .el-col {
        margin-bottom: 20px;
        color: #606266;
        padding-right: 20px !important;
        span {
            margin-left: 15px;
        }
    }
    /* divider */
    .el-divider__text{
        color: #67C23A;
    }   
    .footer {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }
</style>

