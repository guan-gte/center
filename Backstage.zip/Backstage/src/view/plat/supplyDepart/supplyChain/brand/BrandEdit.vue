<template>
    <el-dialog title="编辑品牌" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" size="mini" label-width="150px">
            <el-form-item required label="请输入品牌名称">
                <el-input clearable v-model="form.name" placeholder="请输入品牌名称"></el-input>
            </el-form-item>
             <el-form-item label="请输入品牌简介">
                <el-input :rows="5" type="textarea" placeholder="最多120个字符" v-model="form.intro"></el-input>
                <div class="input-limit" :style="{color:(form.intro.length/120 > 1 ? '#F56C6C' : '#67C23A')}">{{form.intro.length}}/120</div>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import { copyMap } from "../../../../../js/util";

    export default {
        data() {
            return {
                loading: false,
                form: {
                    name: '',
                    intro: ''
                }
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
                console.log(this.form)
                this.loading = false;
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.name) {
                    Sun.showError('请输入品牌名称');
                    return;
                }
                // if (!this.form.intro) {
                //     Sun.showError('请输入品牌简介');
                //     return;
                // }
                // if (this.form.intro.length > 120) {
                //     Sun.showError('品牌简介不得超过120个字符!');
                //     return;
                // }
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                // 
                let obj = {
                    name: this.form.name,
                    intro: this.form.intro,
                    id: this.form.id,
                }
                Sun.post({
                    url: this.url.edit,
                    data: obj,
                    success: () => {
                        Sun.showMsg('编辑成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['data', 'show', 'callBack', 'url'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
