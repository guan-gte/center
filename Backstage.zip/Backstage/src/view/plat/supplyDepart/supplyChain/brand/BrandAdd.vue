<template>
    <el-dialog title="新增品牌" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" size="mini" label-width="150px">
            <el-form-item required label="请输入品牌名称">
                <el-input clearable v-model="form.name" placeholder="请输入品牌名称"></el-input>
            </el-form-item>
            <el-form-item label="请输入品牌简介">
                <el-input :rows="5" type="textarea" placeholder="最多120个字符" v-model="form.intro"></el-input>
                <div class="input-limit" :style="{color:(form.intro.length/120 > 1 ? '#F56C6C' : '#67C23A')}">{{form.intro.length}}/120</div>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                loading: false,
                form: {
                    name: '',
                    intro: ''
                }
            }
        },
        methods: {
            open () {
                this.form = {
                    name: '',
                    intro: ''
                };
                this.loading = false;
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.name) {
                    Sun.showError('请输入品牌名称');
                    return;
                }
                // if (!this.form.intro) {
                //     Sun.showError('请输入品牌简介');
                //     return;
                // }
                // if (this.form.intro.length > 120) {
                //     Sun.showError('品牌简介不得超过120个字符!');
                //     return;
                // }
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                Sun.post({
                    url: this.url.add,
                    data: this.form,
                    success: () => {
                        Sun.showMsg('添加成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['url', 'show', 'callBack'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
    
    /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
    /* textarea */
    .input-limit {
        text-align: right;
    }
</style>
