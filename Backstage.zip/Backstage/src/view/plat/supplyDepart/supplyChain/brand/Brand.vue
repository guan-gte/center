<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <el-button icon="el-icon-circle-plus-outline" v-show="auth.add" @click="showAdd = true" type="primary">新增品牌</el-button>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatDay}}</div>
            <!-- 操作 -->
            <div slot="opreate" slot-scope="data">
                <!-- <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button> -->
                <el-button v-show="auth.edit" type="primary" plain size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.del" type="danger" plain size="mini" @click="del(data.row)">删除</el-button>
            </div>
        </SunTable>
        <!-- add -->
        <BrandAdd :url="url" :show="showAdd"
                    :callBack="(flag)=>{ showAdd = false; if (flag) table.el.refresh(); }"></BrandAdd>
        <!--edit-->
        <BrandEdit :url="url" :show="showEdit" :data="editData"
                    :callBack="(flag)=>{ showEdit = false; if (flag) table.el.refresh()}"></BrandEdit>
    </page>
</template>

<script>
    import { formatDay } from "../../../../../js/util"; 
    import BrandAdd from './BrandAdd';
    import BrandEdit from './BrandEdit';

    const url = {
        table: Http.plat.brandGetBrandList,
        add: Http.plat.addBrand,
        edit: Http.plat.updateBrand,
        del: Http.plat.deleteBrand
    };
    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        components: { 
            BrandAdd,
            BrandEdit 
        },
        data() {
            return {
                goodsType: '',
                auth: {
                    add: true,
                    query: true,
                    edit: true,
                    del: true
                },
                url: url,
                showAdd: false,
                showEdit: false,
                editData: {},
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: false,
                        list: [
                            {
                                title: '品牌ID',
                                key: 'id'
                            },
                            {
                                title: '品牌名称',
                                key: 'name',
                                align: 'left'
                            },
                            {
                                title: '简介',
                                key: 'intro',
                                align: 'left'
                            },
                            {
                                title: '创建时间',
                                key: 'createTime'
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 180
                            }
                        ]
                    }
                }
            }
        },
        methods: {
            created () {
                // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
                // Sun.checkBtnAuth(url.query, () => {this.auth.add = false});
                // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
                // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            },
            // 查看
            query (item) {
            //    Sun.push('/plat/supplyDepart/classifyAndScene/scene/detail', { id: item.id, name: item.name, createTime: item.createTime});
            },
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
            },
            // 删除
            del (item) {
                Sun.confirm('提示', '确定要删除此品牌吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: { id: item.id },
                        success: () => {
                            Sun.showMsg('已删除！');
                            this.table.el.refresh();
                        }
                    });
                });
            }
        },
        filters: {
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
</style>
