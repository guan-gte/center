<template>
    <el-dialog title="拒绝审核" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" size="mini" label-width="120px">
            <el-form-item label="请输入拒绝原因">
                <el-input :rows="5" type="textarea" placeholder="最多120个字符" v-model="form.gRemark"></el-input>
                <div class="input-limit" :style="{color:(form.gRemark.length/120 > 1 ? '#F56C6C' : '#67C23A')}">{{form.gRemark.length}}/120</div>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                loading: false,
                form: {
                    gRemark: ''
                }
            }
        },
        methods: {
            open () {
                this.form = {
                    gRemark: ''
                };
                this.loading = false;
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                this.form.gAuditStatus = 2;
                this.form.goodsPreId = this.id;
                // if (!this.form.gRemark) {
                //     Sun.showError('请输入拒绝原因');
                //     return;
                // }
                // if (this.form.gRemark.length > 120) {
                //     Sun.showError('拒绝原因不得超过120个字符!');
                //     return;
                // }
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                Sun.post({
                    url: this.url.updateGAuditStatus,
                    data: this.form,
                    success: () => {
                        Sun.showMsg('已拒绝');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['url', 'show', 'callBack', 'id'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
    
    /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
    /* textarea */
    .input-limit {
        text-align: right;
    }
</style>
