<template>
    <el-dialog title="编辑场景" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" size="mini" label-width="120px">
            <el-form-item required label="请输入编辑名称">
                <el-input clearable v-model="form.name" placeholder="名称不得超过8个字符"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap} from "../../../../../js/util";

    export default {
        data() {
            return {
                loading: false,
                form: {}
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
                this.loading = false;
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.name) {
                    Sun.showError('请输入编辑名称');
                    return;
                }
                if (this.form.name.length > 8) {
                    Sun.showError('名称不得超过8个字符');
                    return;
                }
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                // 
                let obj = {
                    id: this.form.id,
                    name: this.form.name
                }
                Sun.post({
                    url: this.url.edit,
                    data: obj,
                    success: () => {
                        Sun.showMsg('编辑成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['data', 'show', 'callBack', 'url'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
