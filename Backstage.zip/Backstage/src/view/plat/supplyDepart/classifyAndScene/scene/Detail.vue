<template>
    <page>
        <!-- title -->
        <el-divider class="divider" content-position="left">
            <i class="el-icon-collection-tag"></i> 
            场景名称: {{name}}
            &nbsp;&nbsp;&nbsp;
            <i class="el-icon-time"></i>
            创建时间: {{createTime | formatDay}}
        </el-divider>
        <!--table btn-->
        <div class="handle-box">
            <div class="left">
                <el-button style="width: 70px" type="primary" @click="refresh(id)" :loading="loading">刷新</el-button>
                <el-button icon="el-icon-circle-plus-outline" @click="showAdd = true" type="primary">新增</el-button>
            </div>
             <div class="right">
                <el-button style="width: 70px" type="primary" @click="back()">返回</el-button>
            </div>
        </div>
        <!-- table -->
        <el-table v-loading="loading" :data="list" border  style="width: 100%;">
            <el-table-column :align="item.align ? item.align : 'center'" :width="item.width ? item.width : null"  :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                <template slot-scope="scope">
                    <slot v-if="item.key == 'opreate'" :name="item.key" :row="scope.row">
                        <el-button type="primary" plain size="mini" @click="edit(scope.row)">编辑</el-button>
                        <el-button type="danger" plain size="mini" @click="del(scope.row)">删除</el-button>
                    </slot>
                    <slot v-else-if="item.key == 'createTime'" :name="item.key" :row="scope.row">
                        {{scope.row[item.key] | formatDay}}
                    </slot>
                    <slot v-else :name="item.key" :row="scope.row">
                        <el-tag type="info" size="medium">{{scope.row[item.key]}}</el-tag>
                    </slot>
                </template>
            </el-table-column>
        </el-table>
        <!-- page -->
        <div class="pagination">
            <el-pagination
                @size-change="pageSizeChange"
                @current-change="pageChange"
                :page-sizes="[10, 15, 20, 25]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalNum">
            </el-pagination>
        </div>
        <!-- add -->
        <DetailAdd :url="url" :show="showAdd" :pid="id"
                    :callBack="(flag)=>{ showAdd = false; if (flag) refresh(id); }"></DetailAdd>
        <!--edit-->
        <DetailEdit :url="url" :show="showEdit" :data="editData"
                    :callBack="(flag)=>{showEdit = false; if (flag) refresh(id);}"></DetailEdit>
    </page>
</template>

<script>
    import { formatDay } from "../../../../../js/util";

    import DetailAdd from './DetailAdd';
    import DetailEdit from './DetailEdit';    

    const url = {
        query: Http.plat.getGoodsDataListByPid,
        add: Http.plat.addGoodsDataList,
        edit: Http.plat.editGoodsData,
        del: Http.plat.deleteGoodsDataById
    };
    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        components: { 
            DetailAdd,
            DetailEdit
        },
        data() {
            return {
                loading: false,
                auth: {
                    add: true,
                    edit: true,
                    del: true
                },
                url: url,
                showAdd: false,
                showEdit: false,
                editData: {},
                columns: [
                    {
                        title: '名称',
                        key: 'name'
                    },
                    {
                        title: '创建时间',
                        key: 'createTime',
                    },
                    {
                        title: '操作',
                        key: 'opreate',
                        width: 175
                    },
                ],
                list: [],
                // 分页
                page: 1,
                size: 10,
                totalNum: 100,
                totalPage: 10,
                // url param
                id: '',
                name: '',
                createTime: ''
            }
        },
        created () {
            let id = Sun.getQuery('id');
            let name = Sun.getQuery('name');
            let createTime = Sun.getQuery('createTime');
            if (id) {
                this.id = id;
                this.name = name;
                this.createTime = createTime;
                this.refresh(this.id);
            }
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
        },
        methods: {
            back () {
                Sun.closePage();
                Sun.push('/plat/supplyDepart/classifyAndScene/commonTab', { activeName: '0'});
            },
            refresh (id) {
                this.loading = true;
                let tableForm = {
                    sort: '',
                    sortType: "asc",
                    current: this.page,
                    size: this.size,
                    search: []
                };
                Sun.post({
                    url: this.url.query,
                    data: {
                        pid: id,
                        tableForm: tableForm
                    },
                    final: () => {
                        this.loading = false;
                    },
                    success: (data) => {
                        this.list = data.records;
                        this.totalPage = data.pages;
                        this.totalNum = parseInt(data.total);
                    }
                })
            },
            // 分页
            pageSizeChange (item) {
                this.size = item;
                this.refresh(this.id);
            },
            pageChange (item) {
                this.page = item;
                this.refresh(this.id);
            },
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
            },
            // 删除
            del (item) {
                Sun.confirm('提示', '确定要删除此场景吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: { id: item.id },
                        success: () => {
                            Sun.showMsg('已删除！');
                            this.refresh(this.id);
                        }
                    });
                });
            }
        },
        filters: {
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
    .handle-box {
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
    }
    /* divider */
    .el-divider__text{
        color: #67C23A;
    }
</style>
