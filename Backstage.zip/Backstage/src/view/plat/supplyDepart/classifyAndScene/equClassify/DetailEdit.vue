<template>
    <el-dialog title="编辑二级分类" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" size="mini" label-width="150px">
            <el-form-item required label="请输入二级分类名称">
                <el-input clearable v-model="form.name" placeholder="名称不得超过8个字符"></el-input>
            </el-form-item>
            <!-- <el-form-item required class="main-img" label="请上传图片">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadMainImg"
                    :before-upload="beforeUpload">
                    <img v-if="form.img" :key="form.img" :src="containsString(form.img, setting.oss_http) ? form.img : setting.oss_http + form.img" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <div class="gray-color">二级分类建议图片长宽比例为156:150</div>
            </el-form-item> -->
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import { copyMap, getTime, formatTime, uuid, containsString} from "../../../../../js/util";
    import setting from "../../../../../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);

    export default {
        data() {
            return {
                setting: setting,
                loading: false,
                form: {}
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
                console.log(this.form)
                this.loading = false;
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.name) {
                    Sun.showError('请输入二级分类名称!');
                    return;
                }
                if (this.form.name.length > 8) {
                    Sun.showError('名称不得超过8个字符');
                    return;
                }
                // if (!this.form.img) {
                //     Sun.showError('请上传图片');
                //     return;
                // }
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                // 
                let obj = {
                    pid: this.form.pid,
                    name: this.form.name,
                    img: this.form.img,
                    id: this.form.id
                }
                Sun.post({
                    url: this.url.edit,
                    data: obj,
                    success: () => {
                        Sun.showMsg('编辑成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            },
            uploadMainImg (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/cat/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                console.log(path)
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    console.log(path)
                    vue.form.img = path;
                    console.log(vue.form)
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            beforeUpload (file) {
                if (file.size / 1024 / 1024 > 2) {
                    this.$message.error('上传图片大小不能超过 2MB!');
                    return false;
                }
                return true;
            },
            containsString (long, short) {
                return containsString(long, short);
            }
        },
        props: ['data', 'show', 'callBack', 'url'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
    /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
    /* img */
    .avatar-uploader .el-upload {
        width: 178px;
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>
