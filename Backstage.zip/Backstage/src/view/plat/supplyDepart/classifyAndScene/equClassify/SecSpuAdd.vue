<template>
    <!-- 二级分类 -->
    <el-dialog title="新增SPU属性" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" size="mini" label-width="150px">
            <el-form-item required label="请选择SPU分类">
                <el-select v-model="form.id" filterable placeholder="请选择SPU分类">
                    <el-option v-for="(item, index) in spuClassifyList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item required label="请输入SPU属性名称">
                <el-tag style="margin-bottom: 10px;" type="success" effect="dark" size="medium" :key="index" v-for="(tag, index) in tagList" closable :disable-transitions="false" @close="tagClose(tag)">{{tag}}</el-tag>
                <el-input class="input-new-tag" ref="saveTagInput" size="small"  
                    v-model="newTag" 
                    v-if="inputVisible"
                    @keyup.enter.native="newTagConfirm" 
                    @blur="newTagConfirm">
                </el-input>
                <el-button v-else class="button-new-tag" size="small" @click="showInput">+ 添加</el-button>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                loading: false,
                form: {},
                tagList: [],
                inputVisible: false,
                newTag: '',
                spuClassifyList: []
            }
        },
        methods: {
            open () {
                this.loading = false;
                this.tagList = [];
                this.inputVisible = false;
                this.newTag = '';
                this.form = {};
                this.spuClassifyList = [];
                Sun.post({
                    url: this.url.querySpuClassify,
                    success: (data) => {
                        this.spuClassifyList = data;
                    }
                });
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            // 删除单个标签
            tagClose(tag) {
                this.tagList.splice(this.tagList.indexOf(tag), 1);
            },
            // 显示输入框
            showInput() {
                this.inputVisible = true;
                this.$nextTick(_ => {
                    this.$refs.saveTagInput.$refs.input.focus();
                });
            },
            // 新增一个标签
            newTagConfirm() {
                let newTag = this.newTag;
                if (newTag && newTag.length > 8) {
                    Sun.showError('名称不得超过8个字符');
                    return;
                }
                if (newTag) {
                    this.tagList.push(newTag);
                }
                this.inputVisible = false;
                this.newTag = '';
            },
            submit() {
                if (!this.form.id && this.form.id !== 0) {
                    Sun.showError('请选择SPU分类!');
                    return;
                }
                if (!this.tagList.length) {
                    Sun.showError('请输入内容!');
                    return;
                }
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                // 
                let obj = {
                    nameList: this.tagList,
                    pid: this.form.id,
                    catId: this.pid,
                }
                Sun.post({
                    url: this.url.addSpu,
                    data: obj,
                    success: () => {
                        Sun.showMsg('添加成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['url', 'show', 'callBack', 'url', 'pid'],
    }
</script>

<style scoped>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }
    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }
    
    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
    /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
    /* tag */
    .el-tag + .el-tag {
        margin-left: 10px;
    }
    .button-new-tag {
        margin-left: 10px;
        height: 28px;
        line-height: 28px;
        padding-top: 0;
        padding-bottom: 0;
    }
    .input-new-tag {
        width: 90px;
        margin-left: 10px;
        vertical-align: bottom;
    }
</style>
