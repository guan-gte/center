<template>
    <page>
        <el-divider class="divider" content-position="left">
            <i class="el-icon-collection-tag"></i> 
            一级分类名称: {{name}}
            &nbsp;&nbsp;&nbsp;
            <i class="el-icon-time"></i>
            创建时间: {{createTime | formatDay}}
        </el-divider>
        <el-tabs v-model="activeName"  @tab-click="handleClick">
            <!-- **************************************************SPU******************************************************** -->
            <el-tab-pane label="SPU属性" name="0">
                <!--table btn-->
                <div class="handle-box">
                    <div class="left">
                        <el-button style="width: 70px" type="primary" @click="refreshSpu(id)" :loading="spuLoading">刷新</el-button>
                        <el-button icon="el-icon-circle-plus-outline" @click="showAddSpu = true" type="primary">新增SPU属性</el-button>
                    </div>
                    <div class="right">
                        <el-button style="width: 70px" type="primary" @click="back()">返回</el-button>
                    </div>
                </div>
                <!-- table -->
                <el-table v-loading="spuLoading" :data="spuList" border  style="width: 100%;">
                    <el-table-column :align="item.align ? item.align : 'center'" :width="item.width ? item.width : null"  :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in spuColumns" :key="index">
                        <template slot-scope="scope">
                            <slot v-if="item.key == 'opreate'" :name="item.key" :row="scope.row">
                                <el-button type="primary" plain size="mini" @click="spuEdit(scope.row)">编辑</el-button>
                                <el-button type="danger" plain size="mini" @click="spuDel(scope.row)">删除</el-button>
                            </slot>
                            <slot v-else-if="item.key == 'name'" :name="item.key" :row="scope.row">
                                <el-tag type="info" size="medium">{{scope.row[item.key]}}</el-tag>
                            </slot>
                            <slot v-else-if="item.key == 'createTime'" :name="item.key" :row="scope.row">
                                {{scope.row[item.key] | formatDay}}
                            </slot>
                            <slot v-else :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
                <!-- page -->
                <div class="pagination">
                    <el-pagination
                        @size-change="pageSizeChangeSpu"
                        @current-change="pageChangeSpu"
                        :page-sizes="[10, 15, 20, 25]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="spuTotalNum">
                    </el-pagination>
                </div>
            </el-tab-pane>
            <!-- **************************************************分类******************************************************** -->
            <el-tab-pane label="二级分类" name="1">
                <!--table btn-->
                <div class="handle-box">
                    <div class="left">
                        <el-button style="width: 70px" type="primary" @click="refresh(id)" :loading="loading">刷新</el-button>
                        <el-button icon="el-icon-circle-plus-outline" @click="showAdd = true" type="primary">新增二级分类</el-button>
                    </div>
                    <div class="right">
                        <el-button style="width: 70px" type="primary" @click="back()">返回</el-button>
                    </div>
                </div>
                <!-- table -->
                <el-table v-loading="loading" :data="list" border  style="width: 100%;">
                    <el-table-column :align="item.align ? item.align : 'center'" :width="item.width ? item.width : null"  :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                        <template slot-scope="scope">
                            <slot v-if="item.key == 'opreate'" :name="item.key" :row="scope.row">
                                <el-button type="primary" plain size="mini" @click="edit(scope.row)">编辑</el-button>
                                <el-button type="danger" plain size="mini" @click="del(scope.row)">删除</el-button>
                            </slot>
                            <slot v-else-if="item.key == 'createTime'" :name="item.key" :row="scope.row">
                                {{scope.row[item.key] | formatDay}}
                            </slot>
                            <slot v-else-if="item.key == 'img'" :name="item.key" :row="scope.row">
                                <img class="img" :key="scope.row[item.key]" v-lazy="parseImg(scope.row[item.key], {x: 30})"/>
                            </slot>
                            <slot v-else :name="item.key" :row="scope.row">
                                <el-tag type="info" size="medium">{{scope.row[item.key]}}</el-tag>
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
                <!-- page -->
                <div class="pagination">
                    <el-pagination
                        @size-change="pageSizeChange"
                        @current-change="pageChange"
                        :page-sizes="[10, 15, 20, 25]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="totalNum">
                    </el-pagination>
                </div>
            </el-tab-pane>
        </el-tabs>
        <!-- add -->
        <DetailAdd :url="url" :show="showAdd" :pid="id"
                    :callBack="(flag)=>{ showAdd = false; if (flag) refresh(id); }"></DetailAdd>
        <!--edit-->
        <DetailEdit :url="url" :show="showEdit" :data="editData"
                    :callBack="(flag)=>{showEdit = false; if (flag) refresh(id);}"></DetailEdit>
        <!-- add spu -->
        <SpuAdd :url="url" :show="showAddSpu" :pid="id"
                    :callBack="(flag)=>{ showAddSpu = false; if (flag) refreshSpu(id); }"></SpuAdd>
        <!--edit spu-->
        <SpuEdit :url="url" :show="showEditSpu" :data="spuEditData"
                    :callBack="(flag)=>{ showEditSpu = false; if (flag) refreshSpu(id);}"></SpuEdit>
    </page>
</template>

<script>
    import { formatDay } from "../../../../../js/util";

    import DetailAdd from './DetailAdd';
    import DetailEdit from './DetailEdit';   
    // spu 
    import SpuAdd from './SpuAdd';   
    import SpuEdit from './SpuEdit';   

    const url = {
        // classify
        query: Http.plat.getCatPageByPidAndType,
        add: Http.plat.addCat,
        edit: Http.plat.editCat,
        del: Http.plat.deleteCat,
        // spu
        querySpu: Http.plat.getCatParamDataByCatId,
        addSpu: Http.plat.addCatParamData,
        editSpu: Http.plat.editCatParamData,
        delSpu: Http.plat.deleteCatParamData,
        querySpuClassify: Http.plat.getGoodsParamDataByPid 
    };
    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        components: { 
            DetailAdd,
            DetailEdit,
            SpuAdd,
            SpuEdit
        },
        data() {
            return {
                activeName: '0',
                loading: false,
                auth: {
                    add: true,
                    query: true,
                    edit: true,
                    del: true
                },
                url: url,
                // url param
                id: '',
                name: '',
                createTime: '',
                showAdd: false,
                showEdit: false,
                editData: {},
                columns: [
                    {
                        title: '名称',
                        key: 'name'
                    },
                    {
                        title: '缩略图',
                        key: 'img'
                    },
                    {
                        title: '创建时间',
                        key: 'createTime',
                    },
                    {
                        title: '操作',
                        key: 'opreate',
                        width: 240
                    },
                ],
                list: [],
                // 分页
                page: 1,
                size: 10,
                totalNum: 100,
                totalPage: 10,
                // spu
                spuLoading: false,
                showAddSpu: false,
                showEditSpu: false,
                spuEditData: {},
                spuColumns: [
                    {
                        title: 'SPU分类',
                        key: 'pName'
                    },
                    {
                        title: 'SPU属性',
                        key: 'name'
                    },
                    {
                        title: '创建时间',
                        key: 'createTime',
                    },
                    {
                        title: '操作',
                        key: 'opreate',
                        width: 240
                    },
                ],
                spuList: [],
                // 分页
                spuPage: 1,
                spuSize: 10,
                spuTotalNum: 100,
                spuTotalPage: 10,
            }
        },
        created () {
            let id = Sun.getQuery('id');
            let name = Sun.getQuery('name');
            let createTime = Sun.getQuery('createTime');
            if (id) {
                this.id = id;
                this.name = name;
                this.createTime = createTime;
                if (this.activeName == '0') {
                    this.refreshSpu(this.id);
                } else {
                    this.refresh(this.id);
                }
            }
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            // Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
        },
        methods: {
            handleClick(tab, event) {
                if (this.activeName == '0') {
                    this.refreshSpu(this.id);
                } else {
                    this.refresh(this.id);
                }
            },
            back () {
                Sun.closePage();
                Sun.push('/plat/supplyDepart/classifyAndScene/commonTab', { activeName: '2'});
            },
            // 分类
            refresh (id) {
                this.loading = true;
                let tableForm = {
                    sort: '',
                    sortType: "asc",
                    current: this.page,
                    size: this.size,
                    search: []
                };
                Sun.post({
                    url: this.url.query,
                    data: {
                        pid: id,
                        tableForm: tableForm
                    },
                    final: () => {
                        this.loading = false;
                    },
                    success: (data) => {
                        this.list = data.records;
                        this.totalPage = data.pages;
                        this.totalNum = parseInt(data.total);
                    }
                })
            },
            // 分页
            pageSizeChange (item) {
                this.size = item;
                this.refresh(this.id);
            },
            pageChange (item) {
                this.page = item;
                this.refresh(this.id);
            },
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
            },
            // 删除
            del (item) {
                Sun.confirm('提示', '确定要删除此二级分类吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: { id: item.id },
                        success: () => {
                            Sun.showMsg('已删除！');
                            this.refresh(this.id);
                        }
                    });
                });
            },
            // spu
            refreshSpu (id) {
                this.spuLoading = true;
                let tableForm = {
                    sort: '',
                    sortType: "asc",
                    current: this.spuPage,
                    size: this.spuSize,
                    search: []
                };
                Sun.post({
                    url: this.url.querySpu,
                    data: {
                        catId: id,
                        tableForm: tableForm
                    },
                    final: () => {
                        this.spuLoading = false;
                    },
                    success: (data) => {
                        this.spuList = data.records;
                        this.spuTotalPage = data.pages;
                        this.spuTotalNum = parseInt(data.total);
                    }
                })
            },
            // 分页
            pageSizeChangeSpu (item) {
                this.spuSize = item;
                this.refreshSpu(this.id);
            },
            pageChangeSpu (item) {
                this.spuPage = item;
                this.refreshSpu(this.id);
            },
            // 编辑
            spuEdit (item) {
                this.spuEditData = item;
                this.showEditSpu = true;
            },
            // 删除
            spuDel (item) {
                Sun.confirm('提示', '确定要删除此SPU吗?', () => {
                    Sun.post({
                        url: this.url.delSpu,
                        data: { 
                            id: item.id,  
                            catId: item.catId
                        },
                        success: () => {
                            Sun.showMsg('已删除！');
                            this.refreshSpu(this.id);
                        }
                    });
                });
            },
        },
        filters: {
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .img {
        width: 30px;
    }
    .content-table {
        margin-top: 10px;
    }
    .handle-box {
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
    }
    /* divider */
    .el-divider__text{
        color: #67C23A;
    }
</style>
