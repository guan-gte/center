<template>
    <Page>
        <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="应用场景管理" name="0">
                <Scene v-if="activeName == 0"></Scene>
            </el-tab-pane>
            <el-tab-pane label="设备分类管理" name="1">
                <equClassify v-if="activeName == 1"></equClassify>
            </el-tab-pane>
            <el-tab-pane label="配件分类管理" name="2">
                <partsClassify v-if="activeName == 2"></partsClassify>
            </el-tab-pane>
        </el-tabs>
    </Page>
</template>

<script>
    import partsClassify from './partsClassify/Classify';
    import equClassify from './equClassify/Classify';
    import Scene from './scene/Scene';

    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        components: {
            partsClassify,
            equClassify,
            Scene
        },
        data() {
            return {
                activeName: '0'
            }
        },
        created () {
            let activeName = Sun.getQuery('activeName');
            if (activeName) {
                this.activeName = activeName.toString();
            }
        },
        methods: {
            handleClick(tab, event) {
                // console.log(tab, event);
            }
        },
        filters: {
        }
    }
</script>

<style scoped>

</style>
