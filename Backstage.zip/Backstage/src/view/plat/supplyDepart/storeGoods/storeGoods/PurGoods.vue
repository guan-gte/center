<template>
    <page>
        <!-- 已添加产品 -->
        <div v-for="(item, index) in addGoodsList" :key="index">
            <el-divider class="divider" content-position="right">
                <i class="el-icon-circle-check"></i> 
                <span style="margin-right: 10px;">产品{{ item.id }}</span>
                <i class="el-icon-edit"></i>
                <span>请输入采购数量:</span>
                <el-input style="width: 130px;margin-right: 10px;" size="mini" v-model="item.num" @keyup.native="changeNum(item, index)" placeholder="请输入采购数量"></el-input>
                <el-button type="danger" plain round size="mini" @click="delGoods(index)">删除该条</el-button>
            </el-divider>
            <el-row class="row-box" :gutter="10">
                <el-col :md="12" :lg="8" :xl="4">产品ID:{{item.id}}</el-col>
                <el-col :md="12" :lg="8" :xl="4">产品名称:{{item.name}}</el-col>
                <el-col :md="12" :lg="8" :xl="4">产品规格型号:{{item.model}}</el-col>
                <el-col :md="12" :lg="8" :xl="4">产品货号:{{item.goodsNo}}</el-col>
                <el-col :md="12" :lg="8" :xl="4">产品单价:{{item.costPrice + '元'}}</el-col>
                <el-col :md="12" :lg="8" :xl="4">采购数量:{{item.num ? item.num : '请输入采购数量'}}</el-col>
                <el-col :md="12" :lg="8" :xl="4">产品总价:{{item.totalPrice ? item.totalPrice + '元' : '请输入采购数量'}}</el-col>
                <el-col :md="12" :lg="8" :xl="4">产品供应商:
                    <el-select v-model="item.supplyId" filterable>
                        <el-option v-for="(item, index) in item.suppliList" :key="index" :label="item.supplyName"
                                :value="item.supplyId"></el-option>
                    </el-select>
                </el-col>
                <el-col v-if="item.partsListMap.length" :md="24" :lg="24" :xl="24">相关配件:
                    <el-table  border :data="item.partsListMap" style="width: 100%;margin-top: 15px;">
                        <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in partColumns" :key="index">
                            <template slot-scope="scope">
                                <slot :name="item.key" :row="scope.row">
                                    {{scope.row[item.key]}}
                                </slot>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
            </el-row>
        </div>
        <!-- 搜索产品 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-zoom-in"></i> 搜索添加产品</el-divider>
        <el-row class="row-box" :gutter="10">
            <el-col :md="12" :lg="8" :xl="6">
                请输入产品ID:
                <el-input clearable v-model="form.goodsId" placeholder="请输入产品ID"></el-input>
            </el-col>
            <el-col :md="12" :lg="8" :xl="6">
                请输入产品信息:
                <el-input clearable v-model="form.keywords" placeholder="请输入产品名称，型号，货号"></el-input>
            </el-col>
            <el-col :md="12" :lg="8" :xl="6">
                <el-button @click="showGoods" type="primary" plain round size="mini"><i class="el-icon-search"></i> 搜索产品</el-button>
            </el-col>
        </el-row>
         <!--搜索结果  -->
        <el-dialog title="搜索结果" :visible.sync="showAdd" @open="open" top="30vh" width="600px">
            <el-form  class="el-form-add" ref="form" :model="selectedGoods" label-width="120px">
                <el-form-item required label="请选择产品">
                    <el-select style="width: 100%;" @change="selcetedGoods" v-model="selcetedGoodsId" filterable placeholder="请选择产品">
                        <el-option v-for="ktem in searchGoodsList" 
                                    :key="ktem.id" 
                                    :label="(ktem.brandName ? `品牌: ${ktem.brandName}；` : '') + `名称: ${ktem.name}；` + `型号: ${ktem.model}；` + `货号: ${ktem.goodsNo}；`" 
                                    :value="ktem.id">
                        </el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <div class="el-line-add"></div>
                <el-button class="el-button-add" :loading="loading" type="primary" @click="addGoods()">确认</el-button>
                <el-button class="el-button-add" @click="close">取消</el-button>
            </div>
        </el-dialog>
        <!-- 提交 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-check"></i> 提交</el-divider>
        <div class="footer">
            <el-button type="primary" plain @click="back">返回库存产品列表</el-button>
            <el-button type="primary" @click="submit">提交</el-button>
        </div>
    </page>
</template>

<script>   
    import { isNumber } from '../../../../../js/util';
    const url = {
        getGoodsInfoByKeyOrId: Http.plat.getGoodsInfoByKeyOrId,
        addGoodsProcurement: Http.plat.addGoodsProcurement
    };

    export default {
        extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            return {
                loading: false,
                url: url,
                showAdd: false,
                // search
                form: {
                    goodsId: '',
                    keywords: ''
                },
                selcetedGoodsId: '',
                selectedGoods: {},
                searchGoodsList: [],
                // 添加的产品列表
                addGoodsList: [],
                // 配件
                partColumns: [
                    {
                        title: '产品ID',
                        key: 'partsId',
                    },
                    {
                        title: '产品名称',
                        key: 'name',
                    },
                    {
                        title: '规格型号',
                        key: 'model',
                    },
                    {
                        title: '产品货号',
                        key: 'goodsNo',
                    },
                    {
                        title: '整机包含数量',
                        key: 'number',
                    },
                    {
                        title: '采购总数',
                        key: 'totalNum',
                    }
                ],
            }
        },
        created () {
            
        },
        methods: {
            // 删除一条产品
            delGoods (index) {
                this.addGoodsList.splice(index, 1);
            },
            // 搜索结果
            showGoods () {
                this.showAdd = true;
                Sun.post({
                    url: this.url.getGoodsInfoByKeyOrId,
                    data: {
                        goodsId: this.form.goodsId,
                        keywords: this.form.keywords
                    },
                    loading: true,
                    success: (data) => {
                        if (!data.goodsMap.length) {
                            Sun.showError('未搜索到相关产品信息');
                            return;
                        }
                        this.searchGoodsList = data.goodsMap;
                    }
                });
            },
            // 添加产品
            open () {
                this.loading = false;
                this.selcetedGoodsId = '';
                this.selectedGoods = {};
                this.searchGoodsList = [];
            },
            close () {
                this.showAdd = false;
                this.selcetedGoodsId = '';
                this.selectedGoods = {};
                this.searchGoodsList = [];
            },
            // 选中一个商品
            selcetedGoods () {
                this.searchGoodsList.forEach(ele => {
                    if (this.selcetedGoodsId == ele.id) {
                        this.selectedGoods = ele;
                    }
                })
            },
            // 确认添加
            addGoods () { 
                console.log(this.selectedGoods)
                if (!this.selectedGoods.id) {
                    Sun.showError('请选择产品!');
                    return;
                }
                // 
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                if (!this.selectedGoods.partsListMap) {
                    this.selectedGoods.partsListMap = [];
                }
                this.addGoodsList.push(this.selectedGoods);
                this.showAdd = false;
                this.resetData();
            },
            // 输入采购数量
            changeNum (item, index) {
                // rule
                let isNum = isNumber(item.num);
                if (!isNumber(item.num)) {
                    Sun.showError('请输入数字');
                    this.addGoodsList[index].num = '';
                    this.addGoodsList[index].totalPrice = '';
                    this.$forceUpdate();
                    return;
                }
                // 总价
                this.addGoodsList[index].totalPrice = item.num * item.costPrice;
                if (item.partsListMap && item.partsListMap.length) {
                    item.partsListMap.forEach(ele => {
                        ele.totalNum = item.num * ele.number;
                    })
                    this.$set(this.addGoodsList, index ,item);
                    console.log(this.addGoodsList)
                }
                this.$forceUpdate();
            },
            // 清空搜索相关
            resetData () {
                this.selcetedGoodsId = '';
                this.selectedGoods = {};
                this.form = {
                    goodsId: '',
                    keywords: ''
                }
            },
            // 提交
            submit () {
                if (!this.addGoodsList.length) {
                    Sun.showError('请添加产品!');
                    return;
                }
                // 采购数量
                let notNum = false;
                this.addGoodsList.forEach(ele => {
                    if (!ele.num) {
                        notNum = true;
                    }
                })
                if (notNum) {
                    Sun.showError('请设置产品采购数量');
                    return;
                }
                // 产品供应商
                let notSupply = false;
                this.addGoodsList.forEach(ele => {
                    if (!ele.supplyId) {
                        notSupply = true;
                    }
                })
                if (notSupply) {
                    Sun.showError('请选择产品供应商');
                    return;
                }
                // 
                let goodsListMap = [];
                this.addGoodsList.forEach(child => {
                    goodsListMap.push({
                        goodsId: child.id,
                        supplierId: child.supplyId,
                        totalNum: child.num
                    });
                })
                Sun.post({
                    url: this.url.addGoodsProcurement,
                    data: { goodsListMap: goodsListMap},
                    loading: true,
                    success: (data) => {
                        Sun.showMsg('添加成功');
                        Sun.closePage();
                        Sun.push('/plat/supplyDepart/storeGoods/storeGoods/goods');
                    }
                });
            },
            // id
            // name
            // model
            // goodsNo
            // price
            // totalPrice
            back () {
                Sun.closePage();
                Sun.push('/plat/supplyDepart/storeGoods/storeGoods/goods');
            }
        },
        filters: {
            formatType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '配件/耗材';
                    // case 3: return '耗材';
                    // case 4: return '赠品';
                    // case 5: return '工具';
                }
            },
        }
    }
</script>

<style lang="less" scoped>
    @import url('../../../../../assets/css/config.less');
    .row-box {
        padding: 20px 20px;
        padding-bottom: 0;
        box-sizing: border-box;
    }
    .el-col {
        margin-bottom: 20px;
        color: #606266;
        padding-right: 20px !important;
        .el-input {
            width: auto;
        }
    }
    /* divider */
    .el-divider__text{
        color: #67C23A;
    }   
    .footer {
        width: 100%;
        text-align: center;
    }
</style>

