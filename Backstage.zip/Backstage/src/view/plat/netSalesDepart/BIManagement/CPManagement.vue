<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <!--<el-button icon="el-icon-notebook-2" type="primary" @click="myUploadList">我的上传列表</el-button>-->
            <div slot="source" slot-scope="data" style="position: relative">
                    <el-popover
                        placement="right"
                        title=""
                        popper-class="parImg"
                        @show="myhover(data.row)"
                        trigger="hover">
                        <img class="img" :key="data.row.img" v-lazy="parseImg(data.row.img, {x: 140})">
                        <el-button slot="reference">
                            <img class="img" :key="data.row.img"
                                 v-lazy="parseImg(data.row.img, {x: 60})">
                        </el-button>
                    </el-popover>
            </div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="primary" plain size="medium" @click="query(data.row)">查看</el-button>
                <el-button v-show="auth.edit" type="primary" plain size="medium" @click="edit(data.row)">编辑</el-button>
            </div>
        </SunTable>
    </page>
</template>

<script>
    const url = {
        table: Http.plat.getTwoCategoriesList,
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                showimg:false,
                auth: {
                    // add: true,
                    query: true,
                    edit: true,
                    // del: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '二级分类名称',
                                key: 'name',
                                align: 'left',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },

                            {
                                title: '所属一级分类',
                                key: 'bName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '缩略图',
                                key: 'source',
                                // search:{
                                //     type: 'text',
                                //     symbol: 'like',
                                //     cat: '%?%'
                                // }
                                // hide: true
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 240
                            }
                        ]
                    }
                },
            }
        },
        computed:{

        },
        created () {

        },
        methods: {
            myhover(row){
                // console.log(row.img)
                let alist = document.getElementsByClassName("parImg")
                alist.style = 'background:red'
            },
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 查看
            query (item) {
                // console.log(item)
                Sun.push('/plat/netSalesDepart/BIManagement/CPDetails',{details:item.id ,Jurisdiction:0})
            },
            // 编辑
            edit (item) {
                Sun.push('/plat/netSalesDepart/BIManagement/CPDetails',{details:item.id})
            },

        },
        filters: {
        }
    }
</script>
<style scoped>
    .imgdata{
        position: absolute;
        display: inline-block;
        width: 120px;
        height: 120px;
        background:#fff;
        /*left: 50%;*/
        /*top: 50%;*/
        border: 1px solid#00a0e9;
        /*!*z-index: 999;*!*/
        /*transform: translate(-50%,-50%);*/
    }
    .content-table .el-button{
        border: 0;
        /*background: none;*/
    }
    .content-table {
        margin-top: 10px;
    }
    .selection {
        margin-left: 10px;
    }
</style>

