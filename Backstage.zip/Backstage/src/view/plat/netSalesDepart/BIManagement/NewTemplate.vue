<template>
    <div class="box">
        <!--导航-->
        <div class="Crumbs">
            <span>新增模板</span>
        </div>
        <div>
            <div class="box-list">
                <div class="box-list-div">请输入模板名称:</div>
                <el-input  v-model="name" placeholder="请输入内容" class="box-box-list-el-input"></el-input>
            </div>
            <div class="box-list">
                <div class="box-list-div">请输入模板快捷码:</div>
                <el-input  v-model="Shortcutcode" placeholder="限英文字母及数字20字以内" class="box-box-list-el-input"></el-input>
            </div>
            <div class="box-list">
                <div class="box-list-div">请输入模板内容:</div>
                <el-input
                    type="textarea"
                    :rows="2"
                    placeholder="请输入内容"
                    v-model="textarea"
                    class="box-box-list-el-input"
                    >
                </el-input>
            </div>
            <!--<div class="box-list">-->
                <!--<div class="box-list-div">排序:</div>-->
                <!--<el-input  v-model="Shortcutcode" placeholder="限数字20" class="box-box-list-el-input"></el-input>-->
            <!--</div>-->
        </div>
        <el-button size="medium" class="box-el-button" @click="confirm()">确认</el-button>
        <el-button size="medium" @click="cancel()" class="box-el-button query">取消</el-button>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                textarea:'',
                Shortcutcode:'',
                name:'',
            }
        },
        methods: {
            confirm(){
                Sun.post({
                    url: Http.plat.insertTemplate,
                    data: {
                        detail:this.textarea,
                        reg:this.Shortcutcode,
                        name:this.name,
                        // id:Sun.getQuery("list"),
                    },
                    success: (data) => {
                        Sun.closePage();
                        Sun.push('/DTManagement');
                    }
                })
            },
            cancel(){
                Sun.closePage();
                Sun.push('/DTManagement');
            }
    }
    }

</script>
<style scoped>
    .box{
        background: #fff;
        height: 100%;
    }
    .box-list{
        /*display: inline-block;*/
        display: flex;
        line-height: 2;
        padding: 10px 4px;
        margin-left: 10px;
        margin-top: 6px;
    }
    .box-list-div{
        width: 240px;
        text-align: right;
        margin-right: 8px;
    }
    .box-box-list-el-input{
        width: 320px;
    }
    .box-el-button{
        position: absolute;
        top: 80%;
        left: 36%;
        transform: translate(-10%,-20%);
    }
    .query{
        left: 26%;
    }
</style>
<style>
    .box-box-list-el-input .el-textarea__inner{
        height: 300px!important;
    }
</style>
