<template>
    <Page>
            <div class="box-list">
                <div class="box-list-div">请输入模板名称:</div>
                <el-input v-model="name" :disabled="available" placeholder="请输入内容" class="box-box-list-el-input"></el-input>
            </div>
            <div class="box-list">
                <div class="box-list-div">请输入模板快捷码:</div>
                <el-input v-model="Shortcutcode" :disabled="available" placeholder="限英文字母及数字20字以内" class="box-box-list-el-input"></el-input>
            </div>
            <div class="box-list">
                <div class="box-list-div" style="padding-left: 94px">请输入模板内容:</div>
                <!--<el-input-->
                    <!--type="textarea"-->
                    <!--:rows="2"-->
                    <!--:disabled="available"-->
                    <!--placeholder="请输入内容"-->
                    <!--v-model="textarea"-->
                    <!--class="box-box-list-el-input"-->
                <!--&gt;-->
                <!--</el-input>-->
                <div id="video">
                    <textarea id="detail" name="detail" rows="10" cols="80"></textarea>
                </div>
        </div>
        <div style="text-align: center;position: relative;right: 200px">
            <el-button  size="medium" @click="confirm()" >确认</el-button>
            <el-button  size="medium" @click="cancel()" >取消</el-button>
        </div>

    </Page>
</template>
<script>
    export default {
        // name: 'video',
        // extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            return {
                template:'',
                Shortcutcode:'',
                name:'',
                available:true,
                alable:false
            }
        },
        created(){
            // console.log( Sun.getQuery("Jurisdiction"))
            if(Sun.getQuery("Jurisdiction") == 0){
                this.available = false
            }
           this.Obtain()
        },
        mounted () {
            // console.log(CKEDITOR);
            CKEDITOR.replace("detail",{height: "300px", width: "80%", toolbar: "Full",allowedContent: true});
        },
        methods: {
            //获取详情
            Obtain(){
                // console.log(Sun.getQuery("list"))
                Sun.post({
                    url: Http.plat.getTemplateById,
                    data: {
                        id:Sun.getQuery("list")
                    },
                    success: (data) => {
                        // console.log(data[0].detail)
                        // console.log(123)
                        CKEDITOR.instances.detail.setData(data[0].detail)
                        this.name = data[0].name
                        //, {height: "300px", width: "80%", toolbar: "Full",allowedContent: true}
                        this.Shortcutcode=data[0].reg
                    }
                })
            },
            //取消
            cancel(){
                Sun.closePage();
                Sun.push('/DTManagement');
            },
            //确认
            confirm(){
                if(Sun.getQuery("Jurisdiction") == 0){
                    Sun.post({
                        url: Http.plat.updateTemplate,
                        data: {
                            detail:CKEDITOR.instances.detail.getData(),
                            reg:this.Shortcutcode,
                            name:this.name,
                            id:Sun.getQuery("list"),
                        },
                        success: (data) => {
                            Sun.closePage();
                            Sun.push('/DTManagement');
                        }
                    })
                }else {
                    Sun.closePage();
                    Sun.push('/DTManagement');
                }
            }
        },
    }

</script>
<style scoped>
    .box-list{
        /*display: inline-block;*/
        display: flex;
        line-height: 2;
        padding: 10px 4px;
        margin-left: 10px;
        margin-top: 6px;
    }
    .box-list-div{
        width: 240px;
        text-align: right;
        margin-right: 8px;
    }
    .box-box-list-el-input{
        width: 320px;
    }
</style>
<style>
    .box-box-list-el-input .el-textarea__inner{
        height: 300px!important;
    }
</style>
