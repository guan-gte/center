<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">

            <div slot="isOpen" slot-scope="data">
                <el-switch  @change="change(data.row)" v-model="data.row.isOpen"
                           :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div>
        </SunTable>
    </page>
</template>

<script>
    const url = {
        table: Http.plat.getCatStatusList,
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                goodsType: '',
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        param: {
                            pid: 0
                        },
                        list: [
                            {
                                title: '三级分类名称',
                                key: 'name',
                                align: 'left',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '所属二级分类',
                                key: 'secondStageName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '所属一级分类',
                                key: 'firstOrderName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },



                            {
                                title: '开启状态',
                                key: 'isOpen',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '关闭', value: '0'},
                                        {name: '开启', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '关闭', value: '= 0'},
                                    {text: '开启', value: '= 1'}
                                ]
                            },

                        ]
                    }
                },

            }
        },
        created () {
        },
        methods: {
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 更改状态
            change (item) {
                console.log(item.isOpen)
                Sun.post({
                    url: Http.plat.updateCat,
                    data: {
                        id: item.id,
                        isOpen:item.isOpen,
                    },
                    success: (data) => {

                    }
                })
            },
        },
        filters: {
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
    .selection {
        margin-left: 10px;
    }
</style>
