<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <el-button class="selection" icon="el-icon-circle-plus-outline" v-show="auth.add" @click="add" type="primary">新增模板</el-button>
            <div slot="type" slot-scope="data">{{data.row.type | formatType}}</div>
            <div slot="isOpen" slot-scope="data">
                <el-switch disabled @change="change(data.row)" v-model="data.row.isOpen"
                           :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div>
            <!-- 操作 -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button>
                <el-button v-show="auth.edit" type="primary" plain size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.del" type="danger" plain size="mini" @click="del(data.row)">删除</el-button>
            </div>
        </SunTable>
    </page>
</template>

<script>
    // import { formatDay } from "../../../../js/util";

    const url = {
        table: Http.plat.getAllTemplate,
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    add: true,
                    query: true,
                    edit: true,
                    del: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        param: {
                            pid: 0
                        },
                        list: [
                            {
                                title: '模板名称',
                                key: 'name',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '模板快捷码',
                                key: 'reg',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 240
                            }
                        ]
                    }
                },

            }
        },
        created () {

        },
        methods: {
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 新增商品
            add () {
                Sun.push('/NTemplate')
            },
            // 查看
            query (item) {
                // console.log(item)
                Sun.push('/TDetails',{list:item.id})
            },
            // 编辑
            edit (item) {
                Sun.push('/TDetails',{list:item.id,Jurisdiction:0})
            },
            // 删除
            del (item) {
                Sun.confirm('提示', '确定要删除此模板吗?', () => {
                    Sun.post({
                        url: Http.plat.deleteTemplate,
                        data: { id: item.id },
                        success: () => {
                            Sun.showMsg('已删除！');
                            this.table.el.refresh();
                        }
                    });
                });
            },
        },
        filters: {
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
    .selection {
        margin-left: 10px;
    }
</style>
