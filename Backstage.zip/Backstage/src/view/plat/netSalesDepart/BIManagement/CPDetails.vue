<template>
    <div class="box">
        <div class="box-banner">
            <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{ path: '/plat/netSalesDepart/BIManagement/CPManagement' }">分类图片管理</el-breadcrumb-item>
                <el-breadcrumb-item>
                    <span>分类图片详情</span>
                </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="box-tex-conter">
            <div class="text-one">
                <span class="oneclass">二级分类名称:</span>
                <span class="text-name">{{details.name}}</span>
            </div>
            <div class="text-two">
                <span class="oneclass">所属一级分类名称:</span>
                <span>{{details.bName}}</span>
            </div>
            <div class="text-swe">
                <span class="oneclass">二级分类图片:</span>
                <div class="text-swe-img">
                    <img :src="details.img" style="width: 156px;height: 150px;">
                    <el-upload
                        class="avatar-uploader"
                        action=""
                        :accept="'image/*'"
                        :show-file-list="false"
                        :http-request="uploadMainImg"
                        :before-upload="beforeUpload">
                        <img v-if="form.source" :key="form.source" :src="setting.oss_http + form.source" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </div>
            </div>
        </div>

        <div class="box-footr">
            <el-button size="medium" @click="cancel()">取消</el-button>
            <el-button size="medium" @click="UploadPictures()">确定</el-button>
        </div>
    </div>
</template>
<script>
    import setting from "../../../../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);
    import {getTime, formatTime, uuid} from "../../../../js/util";
    export default {
        data() {
            return {
                details:[],
                setting: setting,
                form: {
                    source: ''
                },
            }
        },
        created(){
            this.Picturedetails()
        },
        methods: {
            cancel(){
                Sun.closePage();
                Sun.push('/plat/netSalesDepart/BIManagement/CPManagement');
            },
            uploadMainImg (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/banner/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.form.source = path;
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            beforeUpload (file) {
                if (file.size / 1024 / 1024 > 2) {
                    this.$message.error('上传图片大小不能超过 2MB!');
                    return false;
                }
                return true;
            },
            //获取详情
            Picturedetails(){
                Sun.post({
                    url: Http.plat.getTwoCategoriesById,
                    data: {
                        id:Sun.getQuery("details")
                    },
                    success: (data) => {
                        // this.details=data
                        data.forEach(value=>{
                            this.details=value
                        })
                        // console.log(this.details)

                    },
                    fail: (data) => {

                    }
                })
            },
            //上传图片
            UploadPictures(){
                if(Sun.getQuery("Jurisdiction") == 0){
                    Sun.showError('无权限');
                }else {
                    if (this.form.source == ''){
                        Sun.showError('上传的图片为空');
                    }else {
                        Sun.post({
                            url: Http.plat.updateCat,
                            data: {
                                id:Sun.getQuery("details"),
                                img:this.form.source
                            },
                            success: (data) => {
                                // console.log(data)
                                this.Picturedetails()
                                Sun.showMsg('图片已上传');
                                Sun.closePage();
                                Sun.push('/plat/netSalesDepart/BIManagement/CPManagement');
                            },
                            fail: (data) => {

                            }
                        })
                    }
                }
            }
        }
    }
</script>
<style scoped>
    .oneclass{
        line-height: 3;
        padding-right: 6px;
        color: #505050;
    }
    .box{
        background: #fff;
        height: 100%;
    }
    .box-banner{
        padding: 20px 0 20px 20px;
    }
    .box-tex-conter{
        margin-left: 60px;
        padding: 10px 0 10px 0;
    }
    .text-swe-img{
        border: 1px solid#eee;
        box-sizing: border-box;
        width: 156px;
        height: 150px;
        position: relative;
        margin-left: 110px;
    }
    .box-footr{
        display: flex;
        width: 140px;
        margin-top: 20px;
        margin-left: 170px;
    }
</style>
<style>
    .text-name{
       
        color:#666666;
    }
    .text-swe-img .el-upload--text{
        width: 156px;
        height: 150px;
        position: absolute;
        top: 0;
        border-radius: 0;
        background-color:rgba(255,255,255,0)!important;
    }
    .text-swe-img .avatar-uploader-icon{
        font-size: 30px;
        position: absolute;
        /*color: #fff;*/
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%);
    }
</style>
