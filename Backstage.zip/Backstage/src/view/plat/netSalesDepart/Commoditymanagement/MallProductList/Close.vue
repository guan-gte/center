<template>
    <div>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <div slot="type" slot-scope="data">{{data.row.type | formatType}}</div>
            <div slot="status" slot-scope="data">
                <el-switch disabled @change="change(data.row)" v-model="data.row.status"
                           :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div>
            <!-- 操作 -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button>
                <!--<el-button v-show="auth.edit" type="primary" plain size="mini" @click="edit(data.row)">编辑</el-button>-->
                <!--<el-button v-show="auth.del" type="danger" plain size="mini" @click="del(data.row)">删除</el-button>-->
            </div>
        </SunTable>
    </div>
</template>

<script>
    const url = {
        table: Http.plat.getShopGoodsAndCatNameList,
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                goodsType: '',
                auth: {
                    // add: true,
                    query: true,
                    edit: true,
                    del: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        param: {
                            isOpen: 0
                        },
                        list: [
                            {
                                title: '产品ID',
                                key: 'id',
                                // hide: true,
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '产品名称',
                                key: 'name',
                                align: 'left',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品类型',
                                key: 'type',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '产品分类',
                                key: 'catName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '主标题',
                                key: 'heading',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '上传人',
                                key: 'admin',
                                search: {
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '上下架',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '下架', value: '0'},
                                        {name: '上架', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '下架', value: '= 0'},
                                    {text: '上架', value: '= 1'}
                                ]
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 240
                            }
                        ]
                    }
                },
            }
        },
        created () {
            console.log(this.activeName)

        },
        props: ['activeName'],
        methods: {
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 获取搜索项数据
            // getSearchList () {
            //     // 商品分类列表
            //     Sun.post({
            //         url: this.url.getCatListByPid,
            //         data: {},
            //         success: (data) => {
            //             this.catList = data;
            //             this.addSearchFilter('catName', this.catList, 'search',  'filter', 'name', 'name');
            //         }
            //     });
            //     // 商品品牌列表
            //     Sun.post({
            //         url: this.url.getBrandList,
            //         data: {},
            //         success: (data) => {
            //             this.brandList = data;
            //             this.addSearchFilter('brandName', this.brandList, 'search',  'filter', 'name', 'name');
            //         }
            //     });
            //     // 商品供应商列表
            //     Sun.post({
            //         url: this.url.getSupplierList,
            //         data: {},
            //         success: (data) => {
            //             this.supplyList = data;
            //             this.addSearchFilter('supplyName', this.supplyList, 'search',  'filter', 'name', 'name');
            //         }
            //     });
            // },
            // 更改上下架
            change (item) {
                // console.log(this.callBack)
                Sun.post({
                    url: Http.plat.updateUploading,
                    data: {
                        status:item.status,
                        id:item.id
                    },
                    success: (data) => {
                        // console.log(data)
                        let activeName=1
                        Sun.push('/MPList',{activeName:activeName})
                    }
                })
            },
            // 新增商品
            // add () {
            //
            // },
            // 查看
            query (item) {
                console.log(item.id)
                window.open('http://test.shop.lyxyun.cn/products/lyx' + item.id + '.html');

            },
            // 编辑
            edit (item) {

            },
            // 删除
            del (item) {
                // Sun.confirm('提示', '确定要删除此应用场景吗?', () => {
                //     Sun.post({
                //         url: this.url.del,
                //         data: { id: item.id },
                //         success: () => {
                //             Sun.showMsg('已删除！');
                //             this.table.el.refresh();
                //         }
                //     });
                // });
            },
            // 我的上传列表
            // myUploadList () {
            //     Sun.push('/plat/supplyDepart/supplyChain/goods/uploadList/upload');
            // }
        },
        filters: {
            formatType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '耗材';
                    case 3: return '配件';
                    case 4: return '赠品';
                    case 5: return '工具';
                }
            },
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
    .selection {
        margin-left: 10px;
    }
</style>
