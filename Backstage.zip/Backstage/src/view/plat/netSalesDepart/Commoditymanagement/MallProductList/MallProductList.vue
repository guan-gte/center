<template>
    <Page>
        <el-tabs v-model="activeName" @tab-click="handleClick(activeName)">
            <el-tab-pane label="已开启商品" name="0">
                <Scene :activeName="activeName" v-if="activeName == 0"></Scene>
            </el-tab-pane>
            <el-tab-pane  label="未开启商品" name="1">
                <equClassify :activeName="activeName" v-if="activeName == 1"></equClassify>
            </el-tab-pane>
        </el-tabs>
    </Page>
</template>

<script>
    import Scene from '../MallProductList/Opened';
    import equClassify from '../MallProductList/Close';

    export default {
        extends: Sun.vuePage,
        components: {
            equClassify,
            Scene
        },
        data() {
            return {
                activeName: '0'
            }
        },
        created () {

        },
        methods: {
            handleClick(tab, event,activeName) {
            }
        },
        filters: {
        }
    }
</script>

<style scoped>

</style>
