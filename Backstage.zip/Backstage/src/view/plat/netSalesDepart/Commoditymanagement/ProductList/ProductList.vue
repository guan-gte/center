<template>
    <page>
        <!--table-->
        <SunTable class="content-table" :load="(that) => { table.el = that }" :data="table.data">
            <div slot="isOpen" slot-scope="data">{{data.row.isOpen | state}}</div>
            <div slot="type" slot-scope="data">{{data.row.type | formatType}}</div>
            <div slot="uploading" slot-scope="data">{{data.row.uploading | Upperandlowerracks}}</div>
            <!-- 操作 -->
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button>
                <el-button v-show="data.row.uploading == 0" type="primary" plain size="mini" @click="edit(data.row)">上传到商城</el-button>
            </div>
        </SunTable>
    </page>
</template>

<script>
    const url = {
        table: Http.plat.getGoodsAndCatNameList,
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    // add: true,
                    query: true,
                    edit: true,
                    // del: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        // param: {
                        //     pid: 0
                        // },
                        list: [
                            {
                                title: '产品ID',
                                key: 'id',
                                // hide: true,
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '产品名称',
                                key: 'name',
                                align: 'left',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品类型',
                                key: 'type',
                                align: 'left',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品分类',
                                key: 'catName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                                // hide: true
                            },
                            {
                                title: '开启状态',
                                key: 'isOpen',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '关闭', value: '0'},
                                        {name: '开启', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '关闭', value: '= 0'},
                                    {text: '开启', value: '= 1'}
                                ]
                            },
                            {
                                title: '是否上传到商城',
                                key: 'uploading',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '下架', value: '0'},
                                        {name: '上架', value: '1'}
                                    ]
                                },
                                filter:[
                                    {name: '下架', value: '0'},
                                    {name: '上架', value: '1'}
                                ]
                                // hide: true
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 240
                            }
                        ]
                    }
                },
            }
        },
        created () {
        },
        methods: {
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },

            // 更改状态updateStatus
            change (item) {

            },
            // 新增商品
            add () {

            },
            // 查看
            query (item) {
                // console.log(item)
                Sun.push('/SeeDetails',{id:item.id,uploading:item.uploading})
            },
            // 上传到商城
            edit (item) {
                // console.log(item)
                Sun.push('/UploadMall',{id:item.id,upload:'upload'})
            },
            // 删除
            del (item) {
            },

        },
        filters: {
            formatType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '耗材';
                    case 3: return '配件';
                    case 4: return '赠品';
                    case 5: return '工具';
                }
            },
            state (isOpen) {
                isOpen = parseInt(isOpen);
                switch (isOpen) {
                    case 0: return '关闭';
                    case 1: return '开启';
                }
            },
            Upperandlowerracks (uploading){
                uploading = parseInt(uploading);
                switch (uploading) {
                    case 0: return '否';
                    case 1: return '是';
                }
            }
        }
    }
</script>

<style scoped>
    .content-table {
        margin-top: 10px;
    }
    .selection {
        margin-left: 10px;
    }
</style>
