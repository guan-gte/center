<template>
    <Page>
        <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 产品基本信息</el-divider>
        <el-form ref="form" :rules="rules"  class="el-form" style="margin-top: 20px;" :model="postData" label-width="250px">
            <el-form-item label="请输入主标题" prop="heading">
                <el-input clearable :disabled=Prohibit v-model="postData.heading"></el-input>
            </el-form-item>
            <el-form-item label="请输入副标题" prop="subhead">
                <el-input clearable :disabled=Prohibit v-model="postData.subhead"></el-input>
            </el-form-item>
            <el-form-item label="请输入关键字" prop="keywords">
                <el-input clearable :disabled=Prohibit v-model="postData.keywords"></el-input>
            </el-form-item>
            <el-form-item label="请输入描述" prop="des">
                <el-input
                    type="textarea"
                    :disabled=Prohibit
                    :rows="4"
                    placeholder="请输入内容"
                    v-model="postData.des">
                </el-input>
            </el-form-item>
            <div style="display:flex">
                <el-form-item label="请输入商城排序" prop="sort">
                    <el-input clearable :disabled=Prohibit v-model="postData.sort"></el-input>
                </el-form-item>
                <el-form-item label="请选择上下架状态">
                    <!--<el-radio-group :disabled=Prohibit v-model="postData.status">-->
                        <!--<el-radio  label="0">下架</el-radio>-->
                        <!--<el-radio label="1">上架</el-radio>-->
                    <!--</el-radio-group>-->
                    <el-radio-group v-model="postData.status">
                        <el-radio :label="1">上架</el-radio>
                        <el-radio :label="2">下架</el-radio>
                    </el-radio-group>
                </el-form-item>
            </div>
            <el-form-item required label="请上传视频:">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :disabled=Prohibit
                    :accept="'video/*'"
                    :show-file-list="false"
                    :http-request="uploadIdCardImg"
                   >
                    <video v-if="postData.imgDetail" class="video avatar"
                           :src="containsString(postData.imgDetail, setting.oss_http) ? postData.imgDetail : setting.oss_http + postData.imgDetail"></video>
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
            </el-form-item>

            <el-form-item required label="请上传产品主图" style="width: 900px">
                <el-upload
                    class="avatar-uploader"
                    action=""
                    :accept="'image/*'"
                    :show-file-list="false"
                    :http-request="uploadShopLicence">
                    <img v-if="postData.img" :key="postData.img"
                         :src="containsString(postData.img, setting.oss_http) ? postData.img : setting.oss_http + postData.img" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
            </el-form-item>

            <el-form-item required label="请上传产品副图" style="width: 900px">
                <el-upload
                    action="http://118.31.248.209:8610/plugsUpload/"
                    list-type="picture-card"
                    :file-list="imgsList"
                    :on-preview="CardPreview"
                    :on-remove="handle"
                    :on-success="haveurl2">
                    <i class="el-icon-plus"></i>
                </el-upload>
            </el-form-item>
            <!--推广信息-------------------------------------------------------->
            <el-divider class="divider" content-position="left">
                <i class="el-icon-collection-tag"></i>推广信息</el-divider>
            <!--相关配件------------------------------------------------------------------------>
            <div>
                <span class="parts-text">相关配件</span>
                <el-select v-model="value" @change="changes" filterable placeholder="请选择相关配件" style="width: 300px">
                    <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.name"
                        :value="item.id"
                    >
                    </el-option>
                </el-select>
                <div class="input-box">
                    <div v-for="item in parts.domains" class="class-input">
                        <span>产品名称:</span><el-input v-model="item.name" class="line-input"></el-input>
                        <span>产品型号:</span><el-input v-model="item.model" class="line-input"></el-input>
                        <span>产品编号:</span><el-input v-model="item.goodsNo" class="line-input"></el-input>
                        <el-button @click="detparts(item)">删除</el-button>
                    </div>
                </div>
            </div>
            <!--看来又看------------------------------------------------------------------------>
            <div >
                <span class="parts-text">看了又看</span>
                <el-select v-model="net" @change="seechanges" filterable placeholder="请选择" style="width: 300px">
                    <el-option
                        v-for="item in Lookandsee"
                        :key="item.value"
                        :label="item.name"
                        :value="item.id"
                    >
                    </el-option>
                </el-select>
                <div class="input-box">
                    <div v-for="item in Lookandseea.domains" class="class-input">
                        <span>产品名称:</span><el-input v-model="item.name" class="line-input"></el-input>
                        <span>产品型号:</span><el-input v-model="item.model" class="line-input"></el-input>
                        <span>产品编号:</span><el-input v-model="item.goodsNo" class="line-input"></el-input>
                        <el-button @click="detsee(item)">删除</el-button>
                    </div>
                </div>
            </div>

            <!--&lt;!&ndash;热门关注&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#4;-->

            <div >
                <span class="parts-text">热门关注</span>
                <el-select v-model="eict" @change="hotchanges" filterable placeholder="请选择" style="width: 300px">
                    <el-option
                        v-for="item in Populare"
                        :key="item.value"
                        :label="item.name"
                        :value="item.id"
                    >
                    </el-option>
                </el-select>
                <div class="input-box">
                    <div v-for="item in Hotattention.domains" class="class-input">
                        <span>产品名称:</span><el-input v-model="item.name" class="line-input"></el-input>
                        <span>产品型号:</span><el-input v-model="item.model" class="line-input"></el-input>
                        <span>产品编号:</span><el-input v-model="item.goodsNo" class="line-input"></el-input>
                        <el-button @click="dethot(item)">删除</el-button>
                    </div>
                </div>
            </div>
            <!--图文详情-------------------------------------------------------->
            <el-divider class="divider" content-position="left">
                <i class="el-icon-collection-tag"></i>图文详情</el-divider>
            <span>应用模板</span>
            <div style="display: flex;width: 1100px;margin: auto">
                <el-table :data="template" border style="width: 50%;">
                    <el-table-column label="模板名称" width="220" align="center">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.name }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="模板代码" width="240" align="center">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.reg }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作" width="88" align="center">
                        <template slot-scope="scope">
                        <span
                            class="copy-btn"
                            @click="copy"
                            :data-clipboard-text="scope.row.reg"
                        >复制
                        </span>
                        </template>
                    </el-table-column>
                </el-table>
                <el-table :data="template2" border style="width: 50%;margin: auto">
                    <el-table-column label="模板名称" width="220" align="center">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.name }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="模板代码" width="240" align="center">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.reg }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作" width="88" align="center">
                        <template slot-scope="scope">
                       <span
                           class="copy-btn"
                           @click="copy"
                           :data-clipboard-text="scope.row.reg"
                       >复制</span>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <span>商品详情</span>
            <div id="Commodity">
                <textarea id="details" rows="10" cols="80"></textarea>
            </div>
            <span>售后服务</span>
            <div id="video">
                <textarea id="service" rows="10" cols="80"></textarea>
            </div>

            <!--btn-->
            <el-form-item style="text-align: center;" v-if="Submission">
                <el-button type="primary" @click="submit()">提交</el-button>
                <el-button @click="cancel()" v-if="upload">取消</el-button>
                <el-button @click="cancels()" v-if="uploads">返回</el-button>
            </el-form-item>
            <el-form-item style="text-align: center;" v-if="edit">
                <el-button type="primary" @click="editthis()">编辑</el-button>
                <el-button @click="cancel()">取消</el-button>
            </el-form-item>
        </el-form>
    </Page>
</template>

<script>
    import Clipboard from 'clipboard';
    import {containsString, getTime, formatDayNotSym, uuid, formatTime} from "../../../../../../js/util";
    import setting from "../../../../../../config/setting";
    let co = require('co');
    let OSS = require('ali-oss');
    let client = new OSS(setting.oss_config);

    const url = {
        add: Http.plat.insertSupplier
    };
    export default {
        // extends: Sun.vuePage,
        name: Sun.randomName(),
        data() {
            var validatePass = (rule, value, callback) => {
                if (!Number(value)) {
                    callback(new Error('请输入数字值'));
                } else {
                    callback();
                }
            }
            return {
                Submission:true,
                edit:false,
                Prohibit:false,
                upload:true,
                uploads:false,
                restaurants:'',
                loading: false,
                setting: setting,
                url: url,
                // img:[],//主图片img
                dialogVisible: false,
                disabled: false,
                imgs:[],//副图imgs
                postData: {
                    heading:'',//主标题
                    subhead:'',//副标题subhead
                    keywords:'',//关键字keywords
                    des:'',//描述des
                    sort:'',//排序sort
                    img:'',
                    uploading:1,
                    status:1,//上下架status
                    imgDetail:'',//视频imgDetail
                },
                imgsList:[],//图片回显
                // videoList:[],//视频回显
                template:[],//模板
                template2:[],
                total:'',//数量
                details:'',//售后服务
                service:'',//商品详情
                options:[],//相关配件
                Populare:[],//热门关注
                Lookandsee:[],//看了又看
                value:'',
                eict:'',
                net:'',
                parts:{
                    domains:[],
                },
                Hotattention: {
                    domains:[]
                },
                Lookandseea:{
                    domains:[]
                },
                //////////////
                rules:{
                    sort: [
                        { validator: validatePass,  trigger: 'change' }
                    ],
                }


            }
        },
        created() {
            /////模糊搜索获取的 配件
            let list = []
            Sun.post({
                url: Http.plat.getSearchAccessories,//获取的所有配件列表
                data: {},
                success: (data) => {
                    // console.log(data)
                    data.forEach(value => {
                        list.push({
                            name:value.name+value.model+value.goodsNo,
                            id: value.id,
                            model:value.model,
                            goodsNo:value.goodsNo,
                            bName:value.bName
                        })
                    })
                    this.options = list; //获取的所有配件列表赋值给 this.restaurants
                    // console.log(this.restaurants)
                },
            })
            /////模糊搜索获取的 热门 看了又看
            let fist = []
            Sun.post({
                url: Http.plat.getSearchGoods,//获取热门 看了看
                data: {},
                success: (data) => {
                    data.forEach(value => {
                        fist.push({
                            name:value.name+value.model+value.goodsNo,
                            id: value.id,
                            model:value.model,
                            goodsNo:value.goodsNo,
                            bName:value.bName
                        })
                    })
                    this.Populare = fist;
                    this.Lookandsee = fist

                },
            })
            ////////编辑时的回显
            if(Sun.getQuery('Jurisdiction') == '0'){
            }else if(
                Sun.getQuery('Jurisdiction') == '1'){
                // console.log("编辑")
                this.Submission=false
                this.edit=true
                Sun.post({
                    url: Http.plat.getGoodsInformationById,
                    data: {
                        id:Sun.getQuery('id')
                    },
                    success: (data) => {
                        // console.log(data)
                        let pota=[]
                        data.goodsList.forEach(value=>{
                            pota=value
                        })
                        this.postData=pota
                        this.imgsList=[] //图片
                        data.imgs.forEach(value => {
                            this.imgsList.push({
                                id:value.id,
                                url:value,
                                path: value.src
                            })
                        })
                        let g=[]
                        this.imgsList.forEach(are=>{
                            // console.log(are.url)
                            g.push({url:are.url})
                        })
                        // console.log(g)
                        this.imgs=g
                        // console.log(this.imgs)
                        // console.log(this.imgsList)
                        CKEDITOR.instances.details.setData(data.dateil.detail)//富文本
                        CKEDITOR.instances.service.setData(data.dateil.service)//富文本
                        // console.log(data.dateil.service)

                        // console.log(data.GoodsRecommendList)//看  热门
                        // console.log(data.goodsPartsList)//配件
                        this.parts.domains=data.goodsPartsList
                        let i=[]
                        let e=[]
                        data.GoodsRecommendList.forEach(veid =>{
                            if(veid.relevantType == 1){
                                i.push(veid)
                                // console.log(i)
                                this.Lookandseea.domains=i
                            }else {
                                e.push(veid)
                                // console.log(e)
                                this.Hotattention.domains=e
                            }
                        })
                    }
                })
            }
            ////////////////////////
            if(Sun.getQuery('upload')=='upload'){
                this.upload=false
                this.uploads=true
            }
            this.gteTemplate()
        },
        activated () {
        },
        mounted () {
            //富文本编辑器
            CKEDITOR.replace("details", {height: "300px", width: "99.6%",allowedContent: true, toolbar: "Full"});
            // var details = CKEDITOR.instances.details;
            // CKEDITOR.instances.details.setData(this.Aftersaleservice);//拿数据

            CKEDITOR.replace("service", {height: "300px", width: "99.6%",allowedContent: true, toolbar: "Full"});
            // var service = CKEDITOR.instances.service;
            //查询

        },
        computed: {
        },
        methods: {
            //删除配件
            detparts(item){
                let index = this.parts.domains.indexOf(item)
                if (index !== -1) {
                    this.parts.domains.splice(index, 1)
                }
            },
            //删除看了看
            detsee(item){
                let index = this.Lookandseea.domains.indexOf(item)
                if (index !== -1) {
                    this.Lookandseea.domains.splice(index, 1)
                }
            },
            //删除热门
            dethot(item){
                // console.log(item)
                let index = this.Hotattention.domains.indexOf(item)
                if (index !== -1) {
                    this.Hotattention.domains.splice(index, 1)
                }
            },
            //配件
            changes(item){
                // console.log(item)
                this.options.forEach(value => {
                    if(item == value.id){
                        // console.log(value.name)
                        this.parts.domains.push({
                            name:value.name,
                            partsId: value.id,
                            model:value.model,
                            goodsNo:value.goodsNo,
                            bName:value.bName
                        })
                    }
                })
            },
            //热门
            hotchanges(item){
                // console.log(item)
                this.Populare.forEach(value => {
                    if(item == value.id){
                        // console.log(value)
                        this.Hotattention.domains.push({
                            name:value.name,
                            relevantGoodsId: value.id,
                            model:value.model,
                            goodsNo:value.goodsNo,
                            bName:value.bName
                        })

                    }
                })
            },
            //看了又看
            seechanges(item){
                // console.log(item)
                this.Lookandsee.forEach(value => {
                    if(item == value.id){
                        // console.log(value)
                        this.Lookandseea.domains.push({
                            name:value.name,
                            relevantGoodsId: value.id,
                            model:value.model,
                            goodsNo:value.goodsNo,
                            bName:value.bName
                        })
                    }
                })
            },
            //编辑update
            editthis(){
                // console.log(this.imgs)
                this.details=CKEDITOR.instances.details.getData();
                this.service=CKEDITOR.instances.service.getData();
                Sun.post({
                    url: Http.plat.update,
                    data: {
                        id: Sun.getQuery('id'),
                        postData:this.postData,
                        parts:this.parts.domains,
                        lookandsee:this.Lookandseea.domains,
                        lotattention:this.Hotattention.domains,
                        // img:this.img,
                        // uploading:1,
                        imgs:this.imgs,
                        details:this.details,
                        service:this.service,
                    },
                    success: (data) => {
                        Sun.closePage();
                        Sun.push('/MPList');
                    }
                })
            },
            //配件
            //上传图片
            uploadShopLicence (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/supplier/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    vue.postData.img = path;
                    console.log(vue.postData.img)
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('图片上传失败');
                });
            },
            containsString (long, short) {
                return containsString(long, short);
            },
            handle(file, fileList) {
                // console.log(fileList[0])
                let index = this.imgs.indexOf(fileList[0])
                if (index !== -1) {
                    this.imgs.splice(index, 1)
                }
                // console.log(this.imgs)
            },//删除

            CardPreview(file) {
                this.imgs = file.url;
                this.dialogVisible = true;
            },//查看

            haveurl2(response,file, fileList){
                // console.log(fileList)
                // this.dialogImageUrl = file.url;
                //http://download.liangyuxi.com.cn
                let list=[]
                // list="url:{http://download.liangyuxi.com.cn}"+response.data[0]
                list.push({
                    url:"http://download.liangyuxi.com.cn"+response.data[0]
                })
                if (file.url !== '') {
                    this.imgs = this.imgs.concat(list)
                }
                // console.log(this.imgs)
            },//上传成功回调

            //上传视屏
            uploadIdCardImg (param) {
                let vue = this;
                let loading = Sun.showActivity();
                let suffix = param.file.type.toString();
                let poi = suffix.indexOf('/');
                suffix = suffix.substring(++poi, suffix.length);
                let path = 'shop/supplier/' + formatTime(getTime(), 'YMD') + '/' + uuid() + '.' + suffix;
                co(function* () {
                    param.onSuccess();
                    Sun.hideActivity(loading);
                    yield client.put(path, param.file);
                    Sun.showMsg('视频上传完成');
                    vue.postData.imgDetail = path;
                    console.log(vue.postData.imgDetail)
                    // this.postData.imgDetail='https://lyxclean.oss-cn-shanghai.aliyuncs.com/'+vue.postData.imgDetail
                }).catch(function (err) {
                    Sun.hideActivity(loading);
                    Sun.showError('视频上传失败');
                });
            },


            //截取第一帧

            //获取模板
            gteTemplate(){
                Sun.post({
                    url: Http.plat.getTemplateList,
                    data: {
                    },
                    success: (data) => {
                        if(data.length !==0){
                            this.total= data.length//
                            let lest = 0
                            let  list = []
                            while(lest < data.length) {
                                list.push(data.slice(lest, lest+=this.total/2))
                            }
                            this.template= list[0]
                            this.template2=list[1]
                        }else {

                        }
                    }
                })
            },
            //复制代码
            copy() {
                var clipboard = new Clipboard(".copy-btn");
                clipboard.on("success", e => {
                    // Toast("复制成功");
                    Sun.showMsg('复制成功');
                    // 释放内存
                    clipboard.destroy();
                });
                clipboard.on("error", e => {
                    // 不支持复制该浏览器不支持自动复制
                    Sun.showError('该浏览器不支持自动复制');
                    // 释放内存
                    clipboard.destroy();
                });
            },
            // 提交getGoodsInformationById
            submit() {
                Sun.post({
                    url: Http.plat.updateUploading,
                    data: {
                        id: Sun.getQuery('id'),
                        postData:this.postData,
                        parts:this.parts.domains,
                        lookandsee:this.Lookandseea.domains,
                        lotattention:this.Hotattention.domains,
                        // img:this.img,
                        imgs:this.imgs,
                        uploading:1,
                        detail:CKEDITOR.instances.details.getData(),
                        service:CKEDITOR.instances.service.getData(),
                    },
                    success: (data) => {
                        Sun.push('/ProductList')
                    }
                })
            },

            cancel () {
                Sun.closePage();
                Sun.push('/MPList');
            },
            cancels () {
                Sun.closePage();
                Sun.push('/ProductList');
            },
        }
    }
</script>
<style>

</style>
<style scoped>
    .in-input .el-input{
        width: 300px;
    }
    .parts-text{
        padding: 2px 4px 8px 14px;
        font-size: 16px;
        color: #000000b8;
    }
    .line-input{
        width: 280px;
        padding: 6px 0;
        padding-left: 4px;
    }
    .class-input{
        padding-left: 10px;
    }
    .class-input span{
        color: #505050;
        padding-left: 20px;
    }
    .input-box{
        padding: 6px 0 8px 0;
    }
    .infor p{
        color: #606266;
    }
    /* img */
    .avatar-uploader .el-upload {
        width: 178px;
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
    /* form */
    .el-form-item {
        width: 700px;
    }
</style>

