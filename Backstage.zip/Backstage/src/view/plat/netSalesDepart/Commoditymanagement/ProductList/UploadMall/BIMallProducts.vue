<template>
    <div>
        <el-divider class="divider" content-position="left">
            <i class="el-icon-collection-tag"></i> 产品基本信息</el-divider>
        <el-form ref="form" class="el-form" style="margin-top: 20px;" label-width="250px">
            <el-form-item label="产品ID:" prop="name">
                <span>{{ProductInformation.id}}</span>
            </el-form-item>
            <el-form-item label="产品名称:" prop="goodsNo">
                <span>{{ProductInformation.name}}</span>
            </el-form-item>
            <el-form-item label="产品排序" prop="goodsNo">
                <span>{{ProductInformation.sort}}</span>
            </el-form-item>
            <el-form-item label="产品货号" prop="model">
                <span>{{ProductInformation.goodsNo}}</span>
            </el-form-item>
            <el-form-item label="规格型号" prop="model">
                <span>{{ProductInformation.model}}</span>
            </el-form-item>
            <el-form-item label="产品品牌" prop="model">
                <span>{{ProductInformation.bName}}</span>
            </el-form-item>
            <el-form-item label="产品供应商" prop="model">
                <span>{{ProductInformation.sName}}</span>
            </el-form-item>
            <el-form-item label="计量单位" prop="model">
                <span>{{ProductInformation.unit}}</span>
            </el-form-item>
            <el-form-item label="产品原价" prop="model" >
                <span>{{ProductInformation.oldPrice}}</span>
            </el-form-item>
            <el-form-item label="产品零售价" prop="model">
                <span>{{ProductInformation.price}}</span>
            </el-form-item>
            <el-form-item label="工作时长" prop="model">
                <span>{{ProductInformation.workDuration}}</span>
            </el-form-item>
            <el-form-item label="设备有效期" prop="model">
                <span>{{ProductInformation.indate}}</span>
            </el-form-item>

            <!--参数信息-------------------------------------------------------->
            <el-divider class="divider" content-position="left">
                <i class="el-icon-collection-tag"></i>参数信息</el-divider>
            <!--<span>应用模板</span>-->
            <el-form ref="form" class="el-form" style="margin-top: 20px;" label-width="250px">
                <el-form-item label="产品类型:" prop="name">
                    <span v-for="(item, foe in producttype" :key="foe">{{item.type}}</span>
                </el-form-item>
                <el-form-item label="产品一级分类:" prop="name">
                    <span>{{ClassificationI}}</span>
                </el-form-item>
                <el-form-item label="产品二级分类:" prop="name">
                    <span v-for="(item, index) in Secondaryclassification" :key="index"><label style="padding: 0 2px">{{item.name}}</label></span>
                </el-form-item>
                <el-form-item label="产品三级分类:" prop="name">
                    <span v-for="(item, fob) in Threelevelclassification" :key="fob">{{item.name}}</span>
                </el-form-item>
                <el-form-item label="产品SPU参数:" >
                    <div v-for="(item, lien) in Otherspecifications">
                        <label>{{item.name}}:</label>
                        <el-table border :data="item.list" style="width: 100%">
                            <el-table-column label="SpuID" width="180" align="center">
                                <template slot-scope="scope">
                                    <span style="margin-left: 10px">{{ scope.row.id}}</span>
                                </template>
                            </el-table-column>
                            <el-table-column label="Spu名称" width="180" align="center">
                                <template slot-scope="scope">
                                    <span style="margin-left: 10px">{{ scope.row.name}}</span>
                                </template>
                            </el-table-column>
                            <el-table-column label="Spu描述" align="center">
                                <template slot-scope="scope">
                                    <span style="margin-left: 10px">1{{ scope.row.value}}</span>
                                </template>
                            </el-table-column>
                        </el-table>
                    </div>
                </el-form-item>
            </el-form>
            <!--应用场景-------------------------------------------------------->
            <el-divider class="divider" content-position="left">
                <i class="el-icon-collection-tag"></i>应用场景</el-divider>
            <div v-for="(item, ked) in Applicationscenarios" :key="ked">
                <el-form-item :label="item.name+':'"  prop="name">
                         <span v-for="(name, into) in item.list" :key="into">
                             {{name.name}}
                         </span>
                </el-form-item>
            </div>
            <!--整机配件-------------------------------------------------------->
            <el-divider class="divider" content-position="left">
                <i class="el-icon-collection-tag"></i>整机配件</el-divider>
            <div style="margin-left: 250px">
                <el-table border :data="aotwmachine" style="width: 60%;">
                    <el-table-column label="产品ID" width="180" align="center">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.id}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="产品名称" width="260" align="center">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.name}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="数量" align="center">
                        <template slot-scope="scope">
                            <span style="margin-left: 10px">{{ scope.row.number}}</span>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <!--其他规格-------------------------------------------------------->
            <el-divider class="divider" content-position="left">
                <i class="el-icon-collection-tag"></i>其他规格
            </el-divider>
            <!--<span>应用模板</span>-->

            <!--btn-->
            <div class="Button-eic">
                <el-button class="el-butt" @click="submit()">取消</el-button>
                <el-button class="el-butt" @click="cancel()">确认</el-button>
            </div>
        </el-form>
    </div>
</template>

<script>
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                dynamicValidateForm: {
                    domains: [{
                        value: ''
                    }],
                    email: ''
                },
                ProductInformation:{},//产品基本信息
                ClassificationI:{},//一级分类
                Secondaryclassification:{},//2级分类
                Threelevelclassification:{},//3级分类
                producttype:{},//产品类型
                Applicationscenarios:{},//应用场景
                aotwmachine:[],//整机配件
                Otherspecifications:[],//其他规格
                uploading:false,//是否上传
                dialogImageUrl: '',
                dialogVisible: false,
                disabled: false,
                // 指定option
                postData: {

                },
            }
        },
        created() {
            if(Sun.getQuery('uploading') == 0){
                this.uploading=true
            }
        },
        activated () {
        },
        mounted() {
            // console.log(Sun.getQuery('id'))
            this.pickUpInformation()
        },
        computed: {
        },
        methods: {
            //跳转上传页
            // edit () {
            //     Sun.push('/UploadMall')
            // },
            //获取详情getGoodsById
            pickUpInformation(){
                Sun.post({
                    url:Http.plat.getGoodsById,
                    data:{
                        id:Sun.getQuery('id')
                    },
                    success: (data) => {
                        console.log(data)
                        this.producttype=data.goodsList//产品类型
                        this.ProductInformation=data.goodsList[0]//产品基本信息
                        data.catList.forEach(value => {
                            this.ClassificationI=value.name//一级分类
                            this.Secondaryclassification=value.list//二级分类
                            value.list.forEach(Threelevelclassification=>{
                                this.Threelevelclassification=Threelevelclassification.list//三级分类
                            })
                        })
                        this.Applicationscenarios=data.goodsDataNames//场景
                        this.aotwmachine=data.goodsPartsList//整机配件
                        this.Otherspecifications=data.goodsParamValues//spu
                        console.log(this.Otherspecifications)
                    }
                })
            },
            //取消

            // 提交
            submit () {
                Sun.closePage();
                Sun.push('/MPList');
            },
            cancel () {
                // back
                Sun.closePage();
                Sun.push('/MPList');
            },
        }
    }
</script>
<style>

</style>
<style scoped>
    .Button-uploading{
        margin-left: 66%;
    }
    .Button-eic{
        text-align: center;
        margin-top: 80px;
    }
    .Button-eic .el-butt{
        width: 100px;
        line-height: 20px;
    }
    .infor p{
        color: #606266;
    }
    /* img */
    .avatar-uploader .el-upload {
        width: 178px;
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
    /* form */
    .el-form-item {
        width: 1000px;
    }
</style>

