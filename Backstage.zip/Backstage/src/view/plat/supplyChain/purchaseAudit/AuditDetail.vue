<template>
    <Page>
        <div class="all">        
            <!-- 采购订单状态状态 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>采购订单状态:</span></div>
                <el-steps class="order-status" finish-status="success" :active="baseInfo.status | formatType" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.adminName}}</p></div></div>
                            <p class="status-desc">{{baseInfo.status === 0 ? '发起申请' : '发起申请'}}</p>
                            <p class="status-time" v-if="baseInfo.createTime">{{baseInfo.createTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.supplyChainImg ? baseInfo.supplyChainImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">供应链总监</p><p class="name">{{baseInfo.verifyName}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 2 ? 'dinger-color' : ': #303133'">
                                {{baseInfo.status == 1 ? '审核通过' : (baseInfo.status == 2 ? '审核拒绝' : '等待审核')}}</p>
                            <p class="status-time" v-if="baseInfo.verifyTime"
                                :class="baseInfo.status == 2 ? 'dinger-color' : ''">
                                {{baseInfo.verifyTime | formatTime}}</p>
                            <el-button v-if="baseInfo.status == 2" @click="open" round size="mini" type="danger" plain>查看原因</el-button>
                        </div>
                    </el-step>
                    <el-step title="仓管入库">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.confirmImg ? baseInfo.confirmImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">仓库管理</p><p class="name">{{baseInfo.confirmName}}</p></div></div>
                            <p class="status-desc" v-if="baseInfo.status == 1">未入库</p>
                            <p class="status-desc" v-if="baseInfo.status == 4">已入库</p>
                            <p class="status-desc" v-if="baseInfo.status == 5">入库未完</p>
                            <p class="status-time" v-if="baseInfo.confirmTime">{{baseInfo.confirmTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="完成">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="img.imgBlank" alt="">
                            </div>
                            <p class="status-desc">{{baseInfo.status == 4 ? '完成' : ''}}</p>
                        </div>
                    </el-step>
                </el-steps>
                <div class="main clearfix">
                    <div v-if="baseInfo.id" style="margin: 20px 0 0 0;" class="text item">采购订单编号: {{baseInfo.id}}</div>
                    <div v-if="baseInfo.status > 2" style="margin: 20px 0 0 0;"  class="text item">入库单编号: {{baseInfo.storeId ? baseInfo.storeId : '未填写'}}</div>
                    <div v-if="baseInfo.status == 4" style="margin: 20px 0 0 0;"  class="text item">快递单号: {{baseInfo.transNo}}</div>
                    <!-- <div v-if="baseInfo.status == 5" style="margin: 20px 0 0 0;"  class="text item">续发快递单号: {{baseInfo.storeId}}</div> -->
                </div>
            </el-card>
            <!-- 采购商品信息 -->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in goodsList" :key="index">
                <div slot="header">
                    <span class="header-title">采购产品{{++index}}:</span></div>
                <div class="main clearfix">
                    <div class="text item">产品名称：{{item.name}}</div>
                    <div class="text item">产品ID：{{item.id}}</div>
                    <div class="text item">产品类型：{{item.type | famateType}}</div>
                    <div class="text item">产品型号：{{item.model}}</div>
                    <div class="text item">产品货号：{{item.goodsNo}}</div>
                    <div class="text item">供应商：{{item.supplyId}}</div>
                    <div class="text item">品牌：{{item.brandNname}}</div>
                    <div class="text item">计量单位：{{item.unit}}</div>
                    <div class="text item">进货价：{{item.costPrice}}元</div>
                    <div class="text item">原价：{{item.oldPrice}}元</div>
                    <div class="text item">销售价：{{item.price}}元</div>
                    <!-- <div class="text item">调度比例：{{item.demo}}</div> -->
                    <div class="text item">当前库存数量：{{item.stock}}</div>
                    <div class="text item">采购数量：{{item.supplyNum}}</div>
                    <!-- 到货数量小于采购数量,字体异色 -->
                    <!-- <div class="text item" :style="item.demo < item.demo ? 'color: #F56C6C;' : ''" 
                            v-if="baseInfo.status > 3">入库数量：{{item.demo}}</div> -->
                    <div class="text item">总价：{{item.supplyPrice}}元</div>    
                </div> 
            </el-card>
        </div>          
        <div v-show="auth.edit && baseInfo.status === 0" class="footer-btn">
            <el-button class="button-edit" @click="cancel">取消</el-button>
            <el-button class="button-edit" type="danger" @click="submit(2)">驳回</el-button>
            <el-button class="button-edit" type="primary" @click="submit(1)">通过</el-button>
        </div> 
        <!--add-->
        <AuditReject :url="url" :show="showEdit" :detail="baseInfo"
                       :callBack="(flag)=>{showEdit = false;if (flag) init()}"></AuditReject> 
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    import img_blank from '../../../../assets/head.png';
    import AuditReject from './AuditReject';
    const url = {
        denySupplyOrder: Http.plat.denySupplyOrder,
        passSupplyOrder: Http.plat.passSupplyOrder
    };
    export default {
        extends: Sun.vuePage,
        components: {AuditReject},
        data() {
            return {
                url: url,
                img: {
                    imgBlank: img_blank
                },
                auth: {
                    edit: true
                },
                showEdit: false,
                baseInfo: {
                    id: '',
                    storeId: '',
                    // 申请时间
                    adminName: '',
                    createTime: '',
                    applyImg: '',
                    // 一级通过审批时间
                    verifyName: '',
                    verifyTime: '',
                    supplyChainImg: '',
                    // 仓管
                    confirmTime: '',
                    confirmName: '',
                    confirmImg: '',
                    // 订单状态 0发起申请 待审批 1 审批通过 (未入库) 2 审批驳回   4 已入库 5 入库未完
                    status: 0,
                    transSn: ''
                },
                // detail: {},
                // 采购商品信息
                goodsList: [],
            }
        },
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            if (Sun.temp.auditDetail) {
                this.goodsList = Sun.temp.auditDetail.goodsList;
                this.addKey(Sun.temp.auditDetail);
            } else {
                Sun.closePage();
            }
        },
        activated () {
            
        },
        methods: {
            addKey (data) {
                data.applyImg = '';
                data.supplyChainImg = '';
                data.confirmImg = '';
                data.confirmTime = '';
                data.confirmName = '';
                this.baseInfo = data;
            },
            // 驳回原因
            open() {
                this.$alert(this.baseInfo.remark, '驳回原因', {
                    confirmButtonText: '确定',
                    callback: action => {}
                });
            },
            // 通过 驳回
            submit (type) {
                if (type == 1) {
                    Sun.confirm('提示', '确认通过?', () => {
                        console.log(this.baseInfo)
                        Sun.post({
                            url: this.url.passSupplyOrder,
                            data: {id: this.baseInfo.id},
                            loading: true,
                            success: (data) => {
                                Sun.showMsg('已通过');
                                Sun.closePage();
                                Sun.push('/plat/supplyChain/purchaseAudit/purchaseAudit');
                            }
                        });
                    });
                } else if (type == 2){
                    this.showEdit = true;
                }
            },
            //
            init() {
                Sun.showMsg('已驳回');
                Sun.closePage();
                Sun.push('/plat/supplyChain/purchaseAudit/purchaseAudit');
            },
            cancel () {
                Sun.closePage();
                Sun.push('/plat/supplyChain/purchaseAudit/purchaseAudit');
            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 进度条 状态
            formatType(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return 1;
                    case 1: return 2;
                    case 2: return 2;
                    case 4: return 4;
                    case 5: return 2;
                }
            },
            famateType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '耗材';
                    case 3: return '配件';
                    case 4: return '赠品';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
    }
    .footer-btn {
        text-align: center;
        margin-top: 20px;
    }
</style>
