<template>
    <Page>
        <div class="all">         
            <!-- 子公司信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span class="header-title">子公司信息</span>
                </div>
                <div class="main clearfix">
                    <div class="text item">子公司名称：{{baseInfo.demo}}</div>
                    <div class="text item">发起人：{{baseInfo.demo}}</div>  
                    <div class="text item">发起时间：{{baseInfo.demo}}</div>  
                    <div class="text item">子公司收货地址：{{baseInfo.demo}}</div>  
                </div> 
            </el-card> 
            <!-- 采购编号 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span class="header-title">采购信息</span>
                </div>
                <div class="main clearfix">
                    <div class="text item">采购编号：{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status > 1" class="text item">入库编号：{{baseInfo.demo}}</div>
                    <div v-if="baseInfo.status > 1 && baseInfo.storeInStatus" class="text item">入库状态：{{baseInfo.storeInStatus | formatStatus}}</div>
                </div>
            </el-card> 
            <!-- 采购商品信息 -->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in goodsList" :key="index">
                <div slot="header">
                    <span class="header-title">采购产品{{++index}}:</span>
                </div>
                <div class="main clearfix">
                    <div class="text item">产品ID：{{item.demo}}</div>
                    <div class="text item">产品名称：{{item.demo}}</div>
                    <div class="text item">产品类型：{{item.demo}}</div>
                    <div class="text item">产品型号：{{item.demo}}</div>
                    <div class="text item">产品货号：{{item.demo}}</div>
                    <div class="text item">供应商：{{item.demo}}</div>
                    <div class="text item">品牌：{{item.demo}}</div>
                    <div class="text item">计量单位：{{item.demo}}</div>
                    <div class="text item">进货价：{{item.demo}}</div>
                    <div class="text item">原价：{{item.demo}}</div>
                    <div class="text item">销售价：{{item.demo}}</div>
                    <div class="text item">调度比例：{{item.demo}}</div>
                    <div class="text item">当前库存数量：{{item.demo}}</div>
                    <div class="text item">总价：{{item.totalPrice}}元</div>    
                </div> 
            </el-card>
            <!-- 快递单号 -->
            <el-card  v-if="baseInfo.status > 1" class="box-card" shadow="hover">
                <div class="main clearfix">
                    <!-- 已确认 未填写快递单号 -->
                    <div v-if="baseInfo.status == 2 && !baseInfo.transSn" class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="130px">
                            <el-form-item required label="请填写物流编号:">
                                <el-input type="text" placeholder="请填写物流编号" v-model="form.transSn"></el-input>
                            </el-form-item> 
                        </el-form>  
                    </div>
                    <div v-if="baseInfo.status == 2 && !baseInfo.transSn" class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="10px">
                            <el-form-item label="">
                                <el-button type="primary" plain round size="mini">提交</el-button>
                            </el-form-item> 
                        </el-form>  
                    </div>
                    <!-- 未入库 已填写快递单号 -->
                    <div v-if="baseInfo.status > 1 && baseInfo.storeInStatus"  class="text item" style="margin: 0;">快递编号：{{baseInfo.transSn}}</div>
                    <!-- 入库数量 -->
                    <div v-if="baseInfo.status > 1 && baseInfo.storeInStatus > 1"  class="text item" style="margin: 0;">入库数量：{{baseInfo.demo}}</div>
                    <div class="text item" style="height: 20px;"></div>
                    <!-- 入库未完 补发快递单号 -->
                    <div v-if="baseInfo.status > 1 && baseInfo.storeInStatus == 2" class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="160px">
                            <el-form-item required label="请填写补发快递编号:">
                                <el-input type="text" placeholder="请填写补发快递编号" v-model="form.transSnAgain"></el-input>
                            </el-form-item> 
                        </el-form>  
                    </div>
                    <div v-if="baseInfo.status == 2 && baseInfo.storeInStatus == 2" class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="10px">
                            <el-form-item label="">
                                <el-button type="primary" plain round size="mini">提交</el-button>
                            </el-form-item> 
                        </el-form>  
                    </div>
                </div>
            </el-card>  
        </div>          
        <div v-show="auth.edit && baseInfo.status == 1" class="footer-btn">
            <el-button class="button-edit">取消</el-button>
            <el-button class="button-edit" @click="submit" type="primary">确认</el-button>
        </div>  
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    edit: true
                },
                form: {
                    transSn: '',
                    transSnAgain: ''
                },
                baseInfo: {
                    demo: '上海分公司',
                    // 订单状态 1待确认2 已确认 
                    status: 2,
                    // 入库状态 1 未入库 2 入库未完 3 入库完成
                    storeInStatus: 2,
                    transSn: 'DJ7777777'
                },
                // 采购商品信息
                goodsList: [
                    {demo: '商品详情', totalPrice: 4563, receiveNum: '', addNum: ''}
                ],
            }
        },
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        methods: {
            submit() {

            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 入库 状态
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return '未入库';
                    case 2: return '入库未完';
                    case 3: return '入库完成';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
    }
    .footer-btn {
        text-align: center;
        margin-top: 20px;
    }
</style>
