<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="add" type="primary">发起采购</el-button>
            <div slot="status" slot-scope="data">
                <span :style="{color: data.row.status ? '#32CD32' : '#F56C6C'}">{{data.row.status ? '开启' : '关闭'}}</span>
            </div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.add" type="text" size="mini" @click="add(data.row)">发起采购</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    const url = {
        table: Http.master.getAdminPage,
        add: Http.master.editAuth,
        edit: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    add: true,
                    edit: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '产品ID',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },             
                            {
                                title: '产品名称',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },             
                            {
                                title: '产品型号',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },             
                            {
                                title: '产品货号',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },             
                            {
                                title: '供应商',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },             
                            {
                                title: '品牌',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },              
                            {
                                title: '库存',
                                key: 'createTime',
                                sortable: true
                            },  
                            {
                                title: '库存警报值',
                                key: 'createTime',
                                sortable: true
                            },  
                            {
                                title: '状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '关闭', value: '0'},
                                        {name: '开启', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '关闭', value: '= 0'},
                                    {text: '开启', value: '= 1'}
                                ]
                            },  
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
        },
        methods: {
            // 添加采购订单
            add () {
                Sun.push('/plat/supplyChain/purchaseOrder/purchaseAdd');
            },
            // 编辑
            edit () {
                Sun.push('/plat/supplyChain/store/storeGoodsEdit');
            }
        },
        filters: {
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '关闭';
                    case 1: return '开启';
                    default: return '/';
                }
            }
        }
    }
</script>

<style scoped>

</style>
