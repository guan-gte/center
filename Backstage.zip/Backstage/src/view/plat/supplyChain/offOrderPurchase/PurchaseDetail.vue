<template>
    <Page>
        <div class="all">     
            <!-- 订单信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>订单信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">订单编号: {{order.demo}}</div>
                    <div class="text item">下单时间: {{order.demo}}</div>
                    <div class="text item">指定发货时间: {{order.demo}}</div>
                    <div class="text item">备注信息: {{order.demo}}</div>
                </div>
            </el-card>   
            <!-- 收货人信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>收货人信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">公司信息: {{people.demo}}</div>
                    <div class="text item">联系人: {{people.demo}}</div>
                    <div class="text item">联系方式: {{people.demo}}</div>
                    <div class="text item">收货地址: {{people.demo}}</div>
                </div>
            </el-card>
             <!--供应链采购信息-->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in purchaseList" :key="index">
                <div slot="header"><span>供应链采购信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">供应商信息: {{item.supplierName}}</div>
                </div>
                <el-table :data="item.list" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in supplierGoodsColumns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>  
                <!-- 有快递信息 -->
                <div v-if="item.transId && baseInfo.status" class="main clearfix" style="margin-top: 20px;">
                    <div class="text item">快递方式: {{item.transName}}</div>
                    <div class="text item">出库时间: {{item.outTime | formatTime}}</div>
                    <div class="text item">快递编号: {{item.transSn}}</div>
                </div>   
                <div v-if="!item.transId && baseInfo.status" class="main clearfix" style="margin-top: 20px;">
                    <div class="text item">
                        <el-form class="el-form-add" ref="form" :model="item" label-width="130px">
                            <el-form-item required label="请选择物流公司">
                                <el-select v-model="item.transId" filterable placeholder="请选择">
                                    <el-option v-for="(ktem, index) in transList" :key="index" :label="ktem.name"
                                            :value="ktem.id"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text item">
                        <el-form  ref="form" :model="item" label-width="130px">
                            <el-form-item required label="请填写出库时间:">
                                <el-date-picker v-model="item.outTime" type="datetime" placeholder="请填写出库时间"></el-date-picker>
                            </el-form-item> 
                        </el-form>   
                    </div> 
                    <div class="text item">
                        <el-form class="el-form-add" ref="form" :model="item" label-width="130px">
                             <el-form-item required label="请填写快递编号">
                                <el-input v-model="item.transSn"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>               
                    <div class="footer-btn">
                        <el-button type="primary" plain round size="mini" @click="submitTrans(item)">确认提交</el-button>
                    </div> 
                </div> 
            </el-card>
        </div>          
        <!-- 确认采购 -->
        <div v-if="!baseInfo.status" class="footer-btn">
            <el-button class="button-edit" @click="submit" type="primary">确认采购</el-button>
        </div>  
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    edit: true
                },
                // 基本信息
                baseInfo: {
                    // 0 待确认 
                    status: 1,
                    demo: '上海分公司'
                },
                // 订单信息
                order: {
                    demo: '上海分公司'
                },
                // 收货人信息
                people: {
                    demo: '上海分公司'
                },
                // 物流公司
                transList: [],
                // 供应链采购信息
                supplierGoodsColumns: [
                    {
                        title: '商品ID',
                        key: 'trueName',
                    },
                    {
                        title: '商品名称',
                        key: 'trueName',
                    },
                    {
                        title: '适用机型',
                        key: 'trueName',
                    },
                    {
                        title: '规格型号',
                        key: 'trueName',
                    },
                    {
                        title: '计量单位',
                        key: 'trueName',
                    },
                    {
                        title: '商品数量',
                        key: 'trueName',
                    },
                ],
                // 供应链采购信息
                purchaseList: [
                    {
                        list: [],
                        supplierName: '和广泛大概',
                        outTime: new Date(1561085162000),
                        transId: '',
                        transName: '韵达',
                        transSn: '1212212726212'
                    }, 
                    {
                        list: [],
                        supplierName: '和广泛大概',
                        outTime: new Date(1561085162000),
                        transId: '2',
                        transName: '韵达',
                        transSn: '1212212726212'
                    }
                ]
            }
        },
        methods: {
            // 确认采购
            submit () {
            },
            // 确认提交 发货信息
            submitTrans(item) {
                if (!item.transId) {
                    Sun.showError('请选择物流公司');
                    return;
                }
                if (!item.outTime) {
                    Sun.showError('请选择出库时间!');
                    return;
                }
                if (!item.transSn) {
                    Sun.showError('请填写快递编号!');
                    return;
                }
            },
            // 总计
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },        
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
    }    
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
<style>
    .el-card__header {
        font-weight: bold;
        font-size: 15px;
    }
</style>

