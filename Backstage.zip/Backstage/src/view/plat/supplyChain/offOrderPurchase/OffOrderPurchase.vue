<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>
            <div slot="isWrite" slot-scope="data">
                <span :style="{color: data.row.isWrite ? '#32CD32' : '#F56C6C'}">{{data.row.isWrite ? '是' : '否'}}</span>
            </div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.master.getAdminPage,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    query: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '线下采购单编号',
                                key: 'trueName',
                                sortable: true
                            },             
                            {
                                title: '订单编号',
                                key: 'trueName',
                                sortable: true
                            },             
                            {
                                title: '发起时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '确认状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待确认', value: '0'},
                                        {name: '已确认', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '待确认', value: '= 0'},
                                    {text: '已确认', value: '= 1'}
                                ]
                            },             
                            {
                                title: '快递编号是否填写',
                                key: 'isWrite',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '否', value: '0'},
                                        {name: '是', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '否', value: '= 0'},
                                    {text: '是', value: '= 1'}
                                ]
                            },  
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query () {
                Sun.push('/plat/supplyChain/offOrderPurchase/purchaseDetail');
            }
        },
        filters: {
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '待确认';
                    case 1: return '已确认';
                    default: return '/';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
