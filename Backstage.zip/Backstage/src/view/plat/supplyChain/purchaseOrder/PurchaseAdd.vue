<template>
    <Page>
        <div class="all">        
            <!-- 采购订单状态状态 -->
            <el-card class="box-card" shadow="hover">
                <el-steps class="order-status" finish-status="success" :active="0" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                                <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.applyName}}</p></div>
                            </div>
                            <p class="status-desc">发起申请</p>
                        </div>
                    </el-step>
                    <el-step title="审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.supplyChainImg ? baseInfo.supplyChainImg : img.imgBlank" alt="">
                                <div class="user-info"><p class="position">供应链总监</p><p class="name">{{baseInfo.supplyChain}}</p></div>
                            </div>
                        </div>
                    </el-step>
                    <el-step title="仓管入库">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.confirmImg ? baseInfo.confirmImg : img.imgBlank" alt="">
                                <div class="user-info"><p class="position">仓库管理</p><p class="name">{{baseInfo.confirmName}}</p></div>
                            </div>
                        </div>
                    </el-step>
                    <el-step title="完成">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="img.imgBlank" alt="">
                            </div>
                        </div>
                    </el-step>
                </el-steps>
            </el-card>
            <!-- 采购商品信息 -->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in goodsList" :key="index">
                <div slot="header">
                    <span class="header-title">采购产品{{goodsList.length}}:</span>
                </div>
                <div class="main clearfix">
                    <div style="margin: 0;height: 50px;" class="text item">
                        已选商品: {{item.name}}
                    </div>
                    <!-- 搜索产品 -->
                    <div style="margin: 0;" class="text item">
                         <el-form label-position="left" ref="form" :model="item" label-width="160px">
                            <el-form-item required label="请输入搜索产品名称:">
                                <el-select @focus="searchGoods" @clear="clearGoods(index)" @change="selcetedGoods(index)" clearable v-model="item.searchId" filterable :filter-method="searchGoods" placeholder="请搜索并选择产品">
                                    <el-option v-for="ktem in searchGoodsList" :key="ktem.id" :label="(ktem.brandNname ? ktem.brandNname : '') + ktem.name + ktem.model" :value="ktem.id">
                                    </el-option>
                                </el-select>
                            </el-form-item> 
                        </el-form> 
                    </div>
                    <div style="margin: 0;" class="text item">
                         <el-form label-position="left" ref="form" :model="item" label-width="130px">
                            <el-form-item required label="请输入采购数量:">
                                <el-input @focus="calcTotal(index)" @blur="calcTotal(index)" v-model="item.addNum"></el-input>
                            </el-form-item> 
                        </el-form> 
                    </div>
              
                    <!-- 商品详情 -->
                    <div class="text item">产品类型：{{item.type | famateType}}</div>
                    <div class="text item">产品型号：{{item.model}}</div>
                    <div class="text item">产品货号：{{item.goodsNo}}</div>
                    <div class="text item">供应商：{{item.supplyName}}</div>
                    <div class="text item">品牌：{{item.brandNname}}</div>
                    <div class="text item">计量单位：{{item.unit}}</div>
                    <div class="text item">进货价：{{item.costPrice}} 元</div>
                    <div class="text item">原价：{{item.oldPrice}} 元</div>
                    <div class="text item">销售价：{{item.price}} 元</div>
                    <!-- <div class="text item">调度比例：{{item.rate}}</div> -->
                    <div class="text item">当前库存数量：{{item.stock}}{{item.unit}}</div>
                    <div class="text item">总价：{{item.totalPrice ? item.totalPrice + '元' : ''}}</div>    
                </div>     
                <div class="item-footer-btn">
                    <el-button type="danger" plain round size="mini" @click="delItem(item, index)">删除该条目</el-button>
                    <el-button type="primary" plain round size="mini" @click="addItem(item, index)">新增条目</el-button>
                </div> 
            </el-card>   
        </div>          
        <div v-show="auth.edit" class="footer-btn">
            <el-button class="button-edit" @click="cancel">取消</el-button>
            <el-button class="button-edit" @click="submit" type="primary">发起申请</el-button>
        </div>  
    </Page>
</template>

<script>
    import {formatTime, Calc} from "../../../../js/util";  
    import img_blank from '../../../../assets/head.png';
    const url = {
        table: Http.master.getAdminPage,
        add: Http.plat.createSupplyOrder,
        searchGoodsList: Http.common.searchGoodsList
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },
                auth: {
                    edit: true
                },
                url: url,
                // 搜索结果
                searchGoodsList: [],
                searchId: '',
                searchName: '',
                addItemDetail: {},
                // 
                baseInfo: {
                    demo: '上海分公司',
                    purchaseSn: 'SH331231',
                    storeInSn: 'DJ7777777',
                    // 申请时间
                    applyTime: 1560734591,
                    applyName: '张三',
                    applyImg: '',
                    // 一级通过审批时间
                    firstPassTime: '',
                    supplyChain: '',
                    supplyChainImg: '',
                    // 仓管
                    confirmTime: '',
                    confirmName: '',
                    confirmImg: '',
                    transSn: '1221'
                },
                // 采购商品信息
                goodsList: [
                    {
                        id: '',
                        name: '',
                        type: '',
                        model: '',
                        goodsNo: '',
                        supplyName: '',
                        brandNname: '',
                        unit: '',
                        costPrice: '',
                        oldPrice: '',
                        price: '',
                        stock: '',
                        addNum: '',
                        searchId: '',
                        searchName: '',
                        totalPrice: ''
                    }
                ]
            }
        },
        
        created () {
            this.baseInfo.applyName = Sun.user.trueName;
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        methods: {
            // 发起申请
            submit () {
                // check
                let list = this.goodsList;
                let flag = false;
                list.forEach((value, jndex) => {
                    if (!value.addNum) {
                        Sun.showError('请输入采购数量');
                        return flag = true;
                    }
                    if (!value.id) {
                        Sun.showError('请选择商品');
                        return flag = true;
                    }
                });
                if (flag) {
                    return;
                }
                // post data
                console.log(this.goodsList);
                let postList = [];
                this.goodsList.forEach(ele => {
                    let item = {
                        id: ele.id,
                        num: ele.addNum,
                        price: ele.totalPrice
                    }
                    postList.push(item);
                })
                console.log(postList);
                // submit
                Sun.post({
                    url: this.url.add,
                    data: {goodsList: postList},
                    success: () => {
                        Sun.showMsg('添加成功');
                        Sun.closePage();
                        Sun.push('/plat/supplyChain/purchaseOrder/purchaseOrder');
                    }
                });
            },
            // 删除一条
            delItem (item, index) {
                // console.log(this.goodsList); 
                //只有一项不删除
                let length = this.goodsList.length;
                if (length == 1) {
                    return;
                } else {
                    Sun.confirm('提示', '删除此条?', () => {
                        this.goodsList.splice(index, 1);
                    });
                }
            },
            // 增加一条
            addItem (item) {
                // console.log(this.goodsList);
                // 如果数组有未填 则不增加
                let list = this.goodsList;
                let flag = false;
                list.forEach((value, jndex) => {
                    if (!value.addNum) {
                        Sun.showError('请输入采购数量');
                        return flag = true;
                    }
                    if (!value.id) {
                        Sun.showError('请选择商品');
                        return flag = true;
                    }
                });
                if (flag) {
                    return;
                }
                // 添加一项
                this.goodsList.push({
                    id: '',
                    name: '',
                    type: '',
                    model: '',
                    goodsNo: '',
                    supplyName: '',
                    brandNname: '',
                    unit: '',
                    costPrice: '',
                    oldPrice: '',
                    price: '',
                    stock: '',
                    addNum: '',
                    searchId: '',
                    searchName: '',
                    totalPrice: ''
                });
                // 重置
                this.searchName = '';
                this.searchGoodsList = [];
            },
            // 搜索商品
            searchGoods (val) {
                if (typeof val == 'string') {
                    this.searchName = val;
                } else {
                    this.searchName = '';
                }
                this.searchGoodsList = [];
                Sun.post({
                    url: this.url.searchGoodsList,
                    data: {name: this.searchName},
                    loading: true,
                    success: (data) => {
                        this.searchGoodsList = data;
                        this.searchName = '';
                    }
                });
            },
            // 选中一个商品
            selcetedGoods (index) {
                let item = this.goodsList[index];
                this.searchGoodsList.forEach(ele => {
                    if (item.searchId == ele.id) {
                        this.goodsList[index].id = item.searchId;
                        this.goodsList[index].type = ele.type;
                        this.goodsList[index].name = ele.name;
                        this.goodsList[index].model = ele.model;
                        this.goodsList[index].goodsNo = ele.goodsNo;
                        this.goodsList[index].supplyName = ele.supplyName;
                        this.goodsList[index].brandNname = ele.brandNname;
                        this.goodsList[index].unit = ele.unit;
                        this.goodsList[index].costPrice = ele.costPrice;
                        this.goodsList[index].price = ele.price;
                        this.goodsList[index].stock = ele.stock;
                    }
                })
            },
            // 计算商品总价
            calcTotal (index) {
                this.goodsList[index].totalPrice = Calc.Mul(this.goodsList[index].addNum, this.goodsList[index].costPrice);
            },
            // 编辑 清除  
            clearGoods (index) {
                this.goodsList[index].searchId = '';
                this.goodsList[index].id = '';
                this.goodsList[index].type = '';
                this.goodsList[index].name = '';
                this.goodsList[index].model = '';
                this.goodsList[index].goodsNo = '';
                this.goodsList[index].supplyName = '';
                this.goodsList[index].brandNname = '';
                this.goodsList[index].unit = '';
                this.goodsList[index].costPrice = '';
                this.goodsList[index].price = '';
                this.goodsList[index].stock = '';
            },
            cancel () {
                Sun.closePage();
                Sun.push('/plat/supplyChain/purchaseOrder/purchaseOrder');
            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            famateType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '耗材';
                    case 3: return '配件';
                    case 4: return '赠品';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                    padding-right: 20px;
                    box-sizing: border-box;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
    }
    .item-footer-btn {
        text-align: right;
        // text-align: center;
        margin-top: 20px;
    }
    .footer-btn {
        // text-align: right;
        text-align: center;
        margin-top: 20px;
    }
</style>
