<template>
    <Page>
        <div class="all">        
            <!-- 采购订单状态状态 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>采购订单状态:</span></div>
                <el-steps class="order-status" finish-status="success" :active="baseInfo.status | formatType" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.adminName}}</p></div></div>
                            <p class="status-desc">{{!baseInfo.status ? '发起申请' : '发起申请'}}</p>
                            <p class="status-time" v-if="baseInfo.createTime">{{baseInfo.createTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.supplyChainImg ? baseInfo.supplyChainImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">供应链总监</p><p class="name">{{baseInfo.verifyName}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 2 ? 'dinger-color' : ': #303133'">
                                {{baseInfo.status == 1 ? '审核通过' : (baseInfo.status == 2 ? '审核拒绝' : '等待审核')}}</p>
                            <p class="status-time" v-if="baseInfo.verifyTime"
                                :class="baseInfo.status == 2 ? 'dinger-color' : ''">
                                {{baseInfo.verifyTime | formatTime}}</p>
                            <el-button v-if="baseInfo.status == 2" @click="open" round size="mini" type="danger" plain>查看原因</el-button>
                        </div>
                    </el-step>
                    <el-step title="仓管入库">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.confirmImg ? baseInfo.confirmImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">职位</p><p class="name">{{baseInfo.confirmName}}</p></div></div>
                            <p class="status-desc" v-if="baseInfo.status == 1">等待入库</p>
                            <p class="status-desc" v-if="baseInfo.status == 4">确认入库</p>
                            <p class="status-desc" v-if="baseInfo.status == 5">入库未完</p>
                            <p class="status-time" v-if="baseInfo.confirmTime">{{baseInfo.confirmTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="完成">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="img.imgBlank" alt="">
                            </div>
                            <p class="status-desc">{{baseInfo.status == 4 ? '完成' : ''}}</p>
                        </div>
                    </el-step>
                </el-steps>
                <div class="main clearfix">
                    <div v-if="baseInfo.id" style="margin: 20px 0 0 0;" class="text item">采购订单编号: {{baseInfo.id}}</div>
                    <div v-if="baseInfo.storeId" style="margin: 20px 0 0 0;"  class="text item">入库单编号: {{baseInfo.storeId}}</div>
                </div>
            </el-card>
            <!-- 采购商品信息 -->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in goodsList" :key="index">
                <div slot="header">
                    <span class="header-title">采购产品{{++index}}:</span>
                </div>
                <div class="main clearfix">
                    <div class="text item">产品ID：{{item.id}}</div>
                    <div class="text item">产品名称：{{item.name}}</div>
                    <div class="text item">产品类型：{{item.type | famateType}}</div>
                    <div class="text item">产品型号：{{item.model}}</div>
                    <div class="text item">产品货号：{{item.goodsNo}}</div>
                    <div class="text item">供应商：{{item.supplyId}}</div>
                    <div class="text item">品牌：{{item.brandId}}</div>
                    <div class="text item">计量单位：{{item.unit}}</div>
                    <div class="text item">进货价：{{item.costPrice}}元</div>
                    <div class="text item">原价：{{item.oldPrice}}元</div>
                    <div class="text item">销售价：{{item.price}}元</div>
                    <!-- <div class="text item">调度比例：{{item.demo}}</div> -->
                    <div class="text item">当前库存数量：{{item.stock}}</div>
                    <div class="text item">采购数量：{{item.supplyNum}}</div>
                    <!-- 到货数量小于采购数量,字体异色 -->
                    <!-- <div class="text item" :style="item.demo < item.demo ? 'color: #F56C6C;' : ''" 
                            v-if="baseInfo.status > 3">实际到货数量：{{item.demo}}</div>
                    <div class="text item" v-if="item.demo < item.demo">请联系商家续发该产品</div> -->
                    <div class="text item">总价：{{item.supplyPrice}}元</div>    
                </div> 
            </el-card>
            <!-- 未填写快递单号 -->
            <el-card v-if="baseInfo.status == 1 && !baseInfo.transNo" class="box-card" shadow="hover">
                <div class="main clearfix">
                    <div class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="130px">
                            <el-form-item required label="请输入快递单号:">
                                <el-input type="text" placeholder="请输入快递单号" v-model="form.sn"></el-input>
                            </el-form-item> 
                        </el-form>  
                    </div>
                    <div class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="20px">
                            <el-form-item label="">
                                <el-button type="primary" plain round size="mini" @click="submitTrans">确认快递单号</el-button>
                            </el-form-item> 
                        </el-form>  
                    </div>
                </div>
            </el-card>  
            <!-- 已填写快递单号 -->
            <el-card v-if="baseInfo.status > 2 && baseInfo.transNo" class="box-card" shadow="hover">
                <div class="main clearfix">
                    <div class="text item" style="margin: 0;">快递单号：{{baseInfo.transNo}}</div>
                    <!-- 续发快递单号 -->
                    <div v-if="baseInfo.status == 5" class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="160px">
                            <el-form-item required label="请输入续发快递单号:">
                                <el-input type="text" placeholder="请输入续发快递单号" v-model="form.snAgain"></el-input>
                            </el-form-item> 
                        </el-form>  
                    </div>
                    <div v-if="baseInfo.status == 5" class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="20px">
                            <el-form-item label="">
                                <el-button type="primary" plain round size="mini" @click="submitAgainTrans">确认快递单号</el-button>
                            </el-form-item> 
                        </el-form>  
                    </div>
                </div>
            </el-card>  
        </div> 
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    import img_blank from '../../../../assets/head.png';
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },
                auth: {
                    edit: true
                },
                form: {
                    sn: '',
                    snAgain: ''
                },
                baseInfo: {
                    demo: '',
                    id: '',
                    storeId: '',
                    // 申请时间
                    createTime: 1560734591,
                    adminName: '张三',
                    applyImg: '',
                    // 一级通过审批时间
                    verifyTime: '',
                    verifyName: '',
                    supplyChainImg: '',
                    // 仓管
                    confirmTime: '',
                    confirmName: '',
                    confirmImg: '',
                    // 订单状态 0发起申请 待审批 1 审批通过 (未入库) 2 审批驳回   4 已入库 5 入库未完
                    status: '',
                    transNo: ''
                },
                // 采购商品信息
                goodsList: [],
            }
        },
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            if (Sun.temp.purchaseDetail) {
                this.goodsList = Sun.temp.purchaseDetail.goodsList;
                this.addKey(Sun.temp.purchaseDetail);
            } else {
                Sun.closePage();
            }
        },
        methods: {
            addKey (data) {
                data.applyImg = '';
                data.supplyChainImg = '';
                data.confirmImg = '';
                data.confirmTime = '';
                data.confirmName = '';
                this.baseInfo = data;
            },
            // 驳回原因
            open() {
                this.$alert(this.baseInfo.remark, '驳回原因', {
                    confirmButtonText: '确定',
                    callback: action => {}
                });
            },
            // 确认快递单号
            submitTrans () {
                if (!this.form.sn) {
                    Sun.showError('请输入快递单号');
                    return;
                }
            },
            // 确认续发快递单号
            submitAgainTrans () {
                if (!this.form.sn) {
                    Sun.showError('请输入续发快递单号');
                    return;
                }
            },
            cancel () {
                Sun.closePage();
                Sun.push('/plat/supplyChain/purchaseOrder/purchaseOrder');
            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 进度条 状态
            formatType(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return 1;
                    case 1: return 2;
                    case 2: return 2;
                    case 4: return 4;
                    case 5: return 2;
                }
            },
            famateType (type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '设备';
                    case 2: return '耗材';
                    case 3: return '配件';
                    case 4: return '赠品';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
    }
    .footer-btn {
        text-align: center;
        margin-top: 20px;
    }
</style>
