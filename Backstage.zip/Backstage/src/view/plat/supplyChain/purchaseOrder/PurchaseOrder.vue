<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="addPurchase" type="primary">发起采购订单</el-button>
            <div slot="status" slot-scope="data">
                <span v-show="!data.row.status " :style="{color: '#606266' }">{{data.row.status | formatStatus}}</span>
                <span v-show="data.row.status == 1" :style="{color: '#32CD32'}">{{data.row.status | formatStatus}}</span>
                <span v-show="data.row.status == 2" :style="{color: '#F56C6C'}">{{data.row.status | formatStatus}}</span>
                <span v-show="data.row.status == 3" :style="{color: '#32CD32'}">{{data.row.status | formatStatus}}</span>
            </div>
            <div slot="storeInStatus" slot-scope="data">{{data.row.storeInStatus | formatStoreInStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.plat.mySupplyOrderPage,
        // query: Http.plat.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    add: true,
                    query: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '采购订单编号',
                                key: 'id'
                            },             
                            {
                                title: '发起人',
                                key: 'adminName'
                            },             
                            {
                                title: '发起时间',
                                key: 'createTime',
                                sortable: true
                            },            
                            {
                                title: '审核人',
                                key: 'verifyName'
                            }, 
                            {
                                title: '审核状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待审核', value: '0'},
                                        {name: '审核通过', value: '1'},
                                        {name: '审核不通过', value: '2'},
                                        {name: '完成', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '待审核', value: '= 0'},
                                    {text: '审核通过', value: '= 1'},
                                    {text: '审核不通过', value: '= 2'},
                                    {text: '完成', value: '= 3'}
                                ]
                            },             
                            // {
                            //     title: '入库状态',
                            //     key: 'storeInStatus',
                            //     search:{
                            //         type: 'select',
                            //         symbol: '=',
                            //         list: [
                            //             {name: '未入库', value: '0'},
                            //             {name: '入库未完', value: '1'},
                            //             {name: '已入库', value: '2'}
                            //         ]
                            //     },
                            //     filter:[
                            //         {text: '未入库', value: '= 0'},
                            //         {text: '入库未完', value: '= 1'},
                            //         {text: '已入库', value: '= 2'}
                            //     ]
                            // },
                            {
                                title: '入库编号',
                                key: 'storeId'
                            },  
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
        },
        methods: {
            // 添加采购订单
            addPurchase () {
                Sun.push('/plat/supplyChain/purchaseOrder/purchaseAdd');
            },
            query (item) {
                Sun.push('/plat/supplyChain/purchaseOrder/purchaseDetail');
                Sun.temp.purchaseDetail = item;
            }
        },
        filters: {
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '待审核';
                    case 1: return '审核通过';
                    case 2: return '审核不通过';
                    case 3: return '完成';
                    default: return '/';
                }
            },
            formatStoreInStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未入库';
                    case 1: return '入库未完';
                    case 2: return '已入库';
                    default: return '/';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
