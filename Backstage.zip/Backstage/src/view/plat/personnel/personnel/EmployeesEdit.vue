<template>
    <el-dialog title="员工详情" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="130px">
            <el-form-item label="员工编号">
                <el-input disabled v-model="form.workId"></el-input>
            </el-form-item>
            <el-form-item label="员工姓名">
                <el-input disabled v-model="form.trueName"></el-input>
            </el-form-item>            
            <el-form-item required label="员工手机号">
                <el-input v-model="form.phone"></el-input>
            </el-form-item>    
            <!-- 不填则不修改密码 -->
            <el-form-item label="密码">
                <el-input disabled placeholder="不可编辑" v-model="form.password"></el-input>
            </el-form-item>        
            <el-form-item label="员工身份证号">
                <el-input v-model="form.idCard"></el-input>
            </el-form-item>
            <!-- 员工职位所属公司可以为无，职位也可以为无，但是如果想任命职位，必须先选择公司 -->
             <el-form-item label="选择员工所属公司">
                <el-select  @change="getGroupListByAuthType(form.instId)"  v-model="form.instId" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in instList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="选择员工职位">
                <el-select v-model="form.groupId" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in groupList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
                <!-- <el-button style="margin-left: 20px;" icon="el-icon-circle-plus-outline" type="primary" round plain size="mini" @click="showNew = true">增添新职位</el-button> -->
            </el-form-item>
            <!-- 一个人只能有一个职位 -->
            <!-- <el-form-item v-show="showNew" label="增加职位">
                <el-select v-model="form.jobAgain" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in instList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
                <el-button style="margin-left: 20px;" icon="el-icon-remove-outline" type="danger" round plain size="mini" @click="delJob()">删除</el-button>
            </el-form-item> -->
            <el-form-item label="入职时间">
                <p>{{form.createTime | formatTime}}</p>
            </el-form-item>
            <el-form-item label="员工状态">
                <el-radio v-model="form.status" :label="1">在职</el-radio>
                <el-radio v-model="form.status" :label="0">离职</el-radio>
            </el-form-item> 
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap, formatTime} from "../../../../js/util";

    export default {
        data() {
            return {
                showNew: false,
                form: {},
                groupList: [],
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
                this.form.password = '';
                Sun.post({
                    url: this.url.getGroupListByAuthType,
                    data: {type: this.form.instId === 0 ? 2 : 3},
                    success: (data) => {
                        this.groupList = data;
                    }
                });
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            delJob () {
                this.showNew = false;
            },
            getGroupListByAuthType () {
                Sun.post({
                    url: this.url.getGroupListByAuthType,
                    data: {type: this.form.instId === 0 ? 2 : 3},
                    success: (data) => {
                        this.form.groupId = '';
                        this.groupList = data;
                    }
                });
            },
            submit() {
                if (!this.form.phone || this.form.phone.length != 11) {
                    Sun.showError('请输入员工手机号');
                    return;
                }
                if (this.form.password && this.form.password.length < 6 && this.form.password.length > 16) {
                    Sun.showError('请输入6-16位密码');
                    return;
                }
                console.log(this.form.groupId)
                console.log(this.form.instId)
                if (this.form.groupId && !this.form.instId && this.form.instId !== 0) {
                    Sun.showError('请选择所属公司');
                    return;
                }
                if (this.form.status === '') {
                    Sun.showError('请设置员工状态');
                    return;
                }
                this.del();
                Sun.post({
                    url: this.url.edit,
                    data: this.form,
                    success: () => {
                        Sun.showMsg('编辑成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            },
            del () {
                delete this.form.createTime;
                delete this.form.idCard;
                delete this.form.instName;
                delete this.form.trueName;
                delete this.form.workId;
                if (!this.form.password) {
                    this.form.password = '';
                }
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        },
        props: ['data', 'url', 'show', 'callBack', 'id', 'instList'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
