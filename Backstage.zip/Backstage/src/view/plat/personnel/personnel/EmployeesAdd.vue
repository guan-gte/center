<template>
    <el-dialog title="新增员工" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="130px">
            <el-form-item required label="员工姓名">
                <el-input v-model="form.trueName"></el-input>
            </el-form-item>            
            <el-form-item required label="员工手机号">
                <el-input v-model="form.phone"></el-input>
            </el-form-item>            
            <el-form-item required label="员工身份证号">
                <el-input v-model="form.idCard"></el-input>
            </el-form-item>
            <el-form-item required label="密码">
                <el-input v-model="form.password"></el-input>
            </el-form-item>
            <!-- 员工职位所属公司可以为无，职位也可以为无，但是如果想任命职位，必须先选择公司 -->
             <el-form-item label="选择员工所属公司">
                <el-select @change="getGroupListByAuthType(form.instId)" v-model="form.instId" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in instList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
             <el-form-item label="选择员工职位">
                <el-select v-model="form.groupId" filterable clearable placeholder="请选择">
                    <el-option v-for="(item, index) in groupList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap} from "../../../../js/util";
    export default {
        data() {
            return {
                form: {},
                groupList: [],
                type: ''
            }
        },
        // trueName, phone, idCard, password, instId, groupId
        methods: {
            open () {
                this.form = {
                    trueName: '',
                    phone: '',
                    idCard: '',
                    groupId: '',
                    instId: ''
                };
                this.type = '',
                this.groupList = [];
                this.groupList.unshift({id: 0, name: '无'});
            },
            getGroupListByAuthType () {
                Sun.post({
                    url: this.url.getGroupListByAuthType,
                    data: {type: this.form.instId === 0 ? 2 : 3},
                    success: (data) => {
                        this.groupList = [];
                        this.form.groupId = '';
                        this.groupList = data;
                    }
                });
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },

            submit() {
                if (!this.form.trueName) {
                    Sun.showError('请输入员工名称');
                    return;
                }
                if (!this.form.phone || this.form.phone.length != 11) {
                    Sun.showError('请输入员工手机号');
                    return;
                }
                if (!this.form.idCard) {
                    Sun.showError('请输入员工身份证号');
                    return;
                }
                if (this.form.idCard.length !== 18 ) {
                    Sun.showError('请输入18位身份证号');
                    return;
                }
                if (!this.form.password || this.form.password.length < 6 || this.form.password.length > 16) {
                    Sun.showError('请输入6-16位密码');
                    return;
                }
                if (this.form.groupId && !this.form.instId && this.form.instId !== 0) {
                    Sun.showError('请选择所属公司');
                    return;
                }
                Sun.post({
                    url: this.url.add,
                    data: this.form,
                    success: () => {
                        Sun.showMsg('添加成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            }
        },
        props: ['data', 'show', 'callBack', 'url', 'instList'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
