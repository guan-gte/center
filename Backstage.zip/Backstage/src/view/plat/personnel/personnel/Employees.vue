<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true" type="primary">新增员工</el-button>
            <div slot="status" slot-scope="data">
                <span :style="{color: data.row.status ? '#32CD32' : '#F56C6C'}">{{data.row.status ? '在职' : '离职'}}</span>
            </div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">编辑</el-button>
            </div>
        </SunTable>
        <!--add-->
        <EmployeesAdd :url="url" :show="showAdd" :instList="instList" 
                    :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></EmployeesAdd>
        <!--edit-->
        <EmployeesEdit :url="url" :show="showEdit" :id="id" :data="editData" :instList="instList" 
                    :callBack="(flag)=>{showEdit = false;if (flag) table.el.refresh()}"></EmployeesEdit>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    import EmployeesAdd from './EmployeesAdd';
    import EmployeesEdit from './EmployeesEdit';   
    const url = {
        table: Http.plat.getAdminPage,
        add: Http.plat.addAdmin,
        edit: Http.plat.editAdmin,
        getInstList: Http.plat.getInstList,
        getGroupListByAuthType: Http.plat.getGroupListByAuthType
    };
    export default {
        extends: Sun.vuePage,
        components: {EmployeesAdd, EmployeesEdit},
        data() {
            return {
                auth: {
                    add: true,
                    edit: true,
                    del: true
                },
                url: url,
                showAdd: false,
                showEdit: false,
                editData: {},
                id: '',
                instList: [],
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '员工编号',
                                key: 'workId'
                            },
                            {
                                title: '员工姓名',
                                key: 'trueName'
                            },         
                            {
                                title: '所属公司',
                                key: 'instName',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: []
                                // },
                                // filter:[]
                            },         
                            {
                                title: '职位',
                                key: 'groupName'
                            },         
                            {
                                title: '手机号',
                                key: 'phone'
                            },         
                            {
                                title: '身份证号',
                                key: 'idCard'
                            }, 
                            {
                                title: '员工状态',
                                key: 'status'
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },            
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            this.getSearchList();
        },
        methods: {
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
                this.id = item.id;
            },
            // 更改状态
            change (item) {

            },
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 获取搜索项数据
            getSearchList () {
                // 分公司列表
                Sun.post({
                    url: this.url.getInstList,
                    data: {},
                    success: (data) => {
                        this.instList = data;
                        this.addSearchFilter('instName', this.instList, 'search',  'filter', 'name', 'id');
                    }
                });
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
