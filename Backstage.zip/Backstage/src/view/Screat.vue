<!--<template>-->
<!--<div>-->
<!--<div v-for="(item,i) of items" v-model="items" :key="i">-->
<!--<el-select v-model="value"@change="addDomain"  filterable placeholder="请选择">-->
<!--<el-option-->
<!--v-for="item in restaurants"-->
<!--:key="item.id"-->
<!--:value="item.value">-->
<!--</el-option>-->
<!--</el-select>-->
<!--<el-input v-model="item.id" placeholder="请输入内容" v-for="(item, index) in input" :key="index" style="width: 160px"></el-input>-->

<!--</div>-->
<!--<button @click="onAdd">添加</button>-->
<!--</div>-->
<!--</template>-->

<!--<style>-->
<!--.my-autocomplete {-->
<!--li {-->
<!--line-height: normal;-->
<!--padding: 7px;-->

<!--.name {-->
<!--text-overflow: ellipsis;-->
<!--overflow: hidden;-->
<!--}-->
<!--.addr {-->
<!--font-size: 12px;-->
<!--color: #b4b4b4;-->
<!--}-->

<!--.highlighted .addr {-->
<!--color: #ddd;-->
<!--}-->
<!--}-->
<!--}-->
<!--</style>-->

<!--<script>-->
<!--export default {-->
<!--data() {-->
<!--return {-->
<!--items: [],-->
<!--options:[],-->
<!--restaurants: [],//所有选项-->
<!--value: '',-->
<!--parts: {-->
<!--domains: [{-->
<!--partsId: '',-->
<!--name:'',-->
<!--heading:'',-->
<!--}],-->
<!--},-->
<!--state: '',-->
<!--input:'',-->
<!--};-->
<!--},-->
<!--methods: {-->
<!--onAdd() {-->
<!--this.items.push('')-->
<!--},-->
<!--addDomain(value){-->
<!--console.log(value)-->
<!--let list=[]-->
<!--this.restaurants.forEach(value1 => {-->
<!--if(value == value1.value){-->
<!--console.log(value1)-->
<!--list.push({-->
<!--id:value1.id,-->
<!--name:value1.value-->
<!--})-->
<!--}-->
<!--})-->
<!--console.log(list)-->
<!--this.input=list-->
<!--}-->
<!--},-->

<!--})-->

<!--}-->
<!--}-->
<!--</script>-->


<template>
    <Page>
        <!--<el-form :model="parts" ref="parts" label-width="100px" class="demo-dynamic">-->
            <!--<el-form-item-->
                <!--v-for="(domain, index) in parts.domains"-->
                <!--:key="domain.key">-->
                <!--<div style="display: flex">-->
                    <!--<div style="width: 40px">请输入产品ID:</div>-->
                    <!--&lt;!&ndash;<el-input v-model="domain.value"></el-input>&ndash;&gt;-->
                    <!--<el-autocomplete-->
                        <!--popper-class="my-autocomplete"-->
                        <!--v-model="domain.name"-->
                        <!--:fetch-suggestions="querySearch"-->
                        <!--placeholder="请输入内容"-->
                        <!--@select="handleSelect">-->
                        <!--<template slot-scope="{ item }">-->
                            <!--<div class="name">{{ item.name }}</div>-->
                        <!--</template>-->
                    <!--</el-autocomplete>-->
                <!--</div>-->
                <!--<div style="display: flex">-->
                    <!--<div style="width: 40px">id:</div>-->
                    <!--<el-input v-model="domain.id" style="width: 200px"></el-input>-->
                <!--</div>-->
                <!--<el-button @click.prevent="removeDomain(domain)" style="position: absolute;left: 250px;bottom: 15px">删除</el-button>-->
            <!--</el-form-item>-->
            <!--<el-form-item>-->
                <!--<el-button @click="addDomain">新增</el-button>-->
            <!--</el-form-item>-->
        <!--</el-form>-->
        <!--<el-button @click="butt">提交</el-button>-->

        <el-select v-model="value" @change="changes" filterable placeholder="请选择">
            <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.name"
                :value="item.id"
                >
            </el-option>
        </el-select>
            <div v-for="item in linuax.eat">
                <el-input v-model="item.id"></el-input>
                <el-input v-model="item.name"></el-input>
            </div>
    </Page>
</template>

<script>
    export default {
        extends: Sun.vuePage,
        data() {

            return {
                // restaurants: [],
                // parts: {
                //     domains: [{
                //         name: '',
                //     }],
                // },
                // list:[],
                options:[],
                value:'',
                linuax:{
                    eat:[],
                },
                list:[],
            };
        },
        created() {
            let list = []
            Sun.post({
                url: Http.plat.getSearchAccessories,//获取的所有配件列表
                data: {},
                success: (data) => {
// console.log(data)
                    data.forEach(value => {
                        list.push({
                            name: value.name + value.model,
                            id: value.id
                        })
                    })
                    this.options = list; //获取的所有配件列表赋值给 this.restaurants
                    // console.log(this.restaurants)
                },
            })
        },
        methods: {
            // butt(){
            //     console.log(this.parts.domains)
            // },
            // removeDomain(item) {
            //     var index = this.parts.domains.indexOf(item)
            //     if (index !== -1) {
            //         this.parts.domains.splice(index, 1)
            //     }
            // },
            // addDomain() {
            //     this.parts.domains.push({
            //         value: '',
            //         key: Date.now(),
            //     });
            //     console.log(this.parts.domains)
            // },
            //
            //
            // querySearch(queryString, cb) {
            //     var restaurants = this.restaurants;
            //     var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
            //     // 调用 callback 返回建议列表的数据
            //     cb(results);
            // },
            // createFilter(queryString) {
            //     return (restaurant) => {
            //         return (restaurant.name.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
            //     };
            // },
            // handleSelect(item) {
            //     this.parts.domains.forEach(value => {
            //         if(this.parts.domains.length > 1){
            //             this.$set(this.parts.domains[this.parts.domains.length-1],"id",+item.id+"")
            //         }else {
            //             this.$set(value,"id",+item.id+"")
            //         }
            //
            //     })
            // },
            changes(item){
                // this.id=item
                console.log(item)
                // let list=[]
                 this.options.forEach(value => {
                    if(item == value.id){
                        // console.log(value)
                        this.linuax.eat.push({
                            name:value.name,
                            id:value.id,
                        })
                        console.log(this.linuax.eat)
                    }
                })
            },
        }
    }
</script>
