<template>
    <el-dialog title="新增收货人" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px" size="mini">   
            <el-form-item required label="收货人:">
                <el-input v-model="form.contactName" placeholder="请输入收货人姓名"></el-input>
            </el-form-item>
            <el-form-item required label="手机号:">
                <el-input v-model="form.telPhone" placeholder="请输入收货人手机号"></el-input>
            </el-form-item>        
            <el-form-item required label="收货地址:">
                <el-cascader placeholder="请选择收货地址" :options="cityList" :props="optionProps" v-model="codeList"></el-cascader>
            </el-form-item>
            <el-form-item required label="详细地址:">
                <el-input v-model="form.addressDetail" placeholder="请输入详细地址"></el-input>
            </el-form-item> 
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import { checkPhone } from "../../../../../../js/util";
    import cityList from "../../../../../../js/city";
    export default {
        data() {
            return {
                loading: false,
                // 指定option
                optionProps: {
                    value: 'i',
                    label: 'n',
                    children: 'l'
                },
                cityList: cityList,
                form: {},
                codeList: [],
                // 添加
                addData: {
                    cityId: '',
                    address: '',
                    addressDetail: '',
                    contactName: '',
                    telPhone: '',
                }  
            }
        },
        methods: {
            open () {
                this.form = {};
                // cityCode
                this.codeList = [];
            },
            formatCity (id) {
                let idList = [];
                this.cityList.forEach((item) => {
                    if (item.l) {
                        item.l.forEach((jtem) => {
                            if (jtem.l) {
                                jtem.l.forEach((ktem) => {
                                    if (ktem.i == id) {
                                        idList = [item.i, jtem.i, ktem.i];
                                    }
                                });
                            } else {
                                if (jtem.i == id) idList = [item.i, jtem.i, ''];
                            }
                        });
                    } else {
                        if (item.i == id) idList = [item.i, '', ''];
                    }
                });
                return idList;
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                this.parseData(this.form);
                // 
                if (!this.addData.contactName) {
                    Sun.showError('请输入收货人姓名');
                    return;
                }
                if (!this.addData.telPhone) {
                    Sun.showError('请输入收货人手机号');
                    return;
                }
                if (!checkPhone(this.addData.telPhone)) {
                    Sun.showError('请输入正确的手机号格式');
                    return;
                }
                if (!this.addData.cityId) {
                    Sun.showError('请选择地址');
                    return;
                }
                if (!this.addData.addressDetail || this.addData.addressDetail.length < 6) {
                    Sun.showError('请输入详细地址');
                    return;
                }
                // 
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                return;
                // Sun.post({
                //     url: this.url.add,
                //     data: this.addData,
                //     success: () => {
                //         Sun.showMsg('添加成功');
                //         if (this.callBack) {
                //             this.callBack(true);
                //         }
                //     }
                // });
            },
            parseAddress (idList) {
                let address = '';
                this.cityList.forEach((item) => {
                   if (item.i == idList[0]) {
                       address += item.n;
                       if (item.l) {
                            item.l.forEach((jtem) => {
                                if (jtem.i == idList[1]) {
                                    address += jtem.n;
                                    if (jtem.l) {
                                        jtem.l.forEach((ktem) => {
                                            if (ktem.i == idList[2]) {
                                                address += ktem.n;
                                            }
                                        });
                                    }
                                }
                            });
                       }
                   }
                });
                return address;
            },
            parseData() {
                this.form.address = this.parseAddress(this.codeList);
                this.form.cityId = this.codeList[this.codeList.length - 1];
                // addData
                this.addData.contactName = this.form.contactName;
                this.addData.telPhone = this.form.telPhone;
                this.addData.cityId = this.form.cityId;
                this.addData.address = this.form.address;
                this.addData.addressDetail = this.form.addressDetail;
            }
        },
        props: ['show', 'callBack', 'url'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }
    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }
    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }
    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
     /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
</style>
