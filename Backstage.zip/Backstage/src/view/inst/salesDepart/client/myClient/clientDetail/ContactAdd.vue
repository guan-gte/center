<template>
    <el-dialog title="新增次要联系人" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" size="mini" label-width="120px">
            <el-form-item required label="姓名">
                <el-input clearable v-model="form.name" placeholder="请输入姓名"></el-input>
            </el-form-item>
            <el-form-item required label="职位">
                <el-input clearable v-model="form.work" placeholder="请输入职位"></el-input>
            </el-form-item>
            <el-form-item required label="手机号">
                <el-input clearable v-model="form.phone" placeholder="请输入手机号"></el-input>
            </el-form-item>
            <el-form-item label="微信">
                <el-input clearable v-model="form.wx" placeholder="请输入微信"></el-input>
            </el-form-item>
            <el-form-item label="QQ">
                <el-input clearable v-model="form.qq" placeholder="请输入QQ"></el-input>
            </el-form-item>
            <el-form-item label="邮箱">
                <el-input clearable v-model="form.email" placeholder="请输入邮箱"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {checkPhone} from "../../../../../../js/util";

    export default {
        data() {
            return {
                loading: false,
                form: {}
            }
        },
        methods: {
            open () {
                this.loading = false;
                this.form = {};
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.name) {
                    Sun.showError('请输入姓名!');
                    return;
                }
                if (!this.form.work) {
                    Sun.showError('请输入职位!');
                    return;
                }
                if (!this.form.phone) {
                    Sun.showError('请输入手机号!');
                    return;
                }
                if (!checkPhone(this.form.phone)) {
                    Sun.showError('请输入正确的手机号');
                    return;
                }
                // this.loading = true;
                // setTimeout(() =>{
                //     this.loading = false
                // },1000)
                // // 
                // let obj = {
                //     nameList: this.tagList,
                //     pid: this.pid
                // }
                // Sun.post({
                //     url: this.url.add,
                //     data: obj,
                //     success: () => {
                //         Sun.showMsg('添加成功');
                //         if (this.callBack) {
                //             this.callBack(true);
                //         }
                //     }
                // });
            }
        },
        props: ['url', 'show', 'callBack'],
    }
</script>

<style scoped>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }
    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }
    
    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
    /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
    /* tag */
    .el-tag + .el-tag {
        margin-left: 10px;
    }
    .button-new-tag {
        margin-left: 10px;
        height: 28px;
        line-height: 28px;
        padding-top: 0;
        padding-bottom: 0;
    }
    .input-new-tag {
        width: 90px;
        margin-left: 10px;
        vertical-align: bottom;
    }
    /* textarea */
    .input-limit {
        text-align: right;
    }
</style>
