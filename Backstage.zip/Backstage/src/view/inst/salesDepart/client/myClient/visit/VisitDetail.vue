<template>
    <el-dialog title="回访记录详情" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="700px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px" size="mini">
            <el-form-item label="公司名称:"><span>公司名称</span></el-form-item>
            <el-form-item label="公司简称:"><span>公司简称</span></el-form-item>
            <el-form-item label="联系人:"><span>联系人</span></el-form-item>
            <el-form-item label="回访时间:"><span>{{23456 | formatTime}}</span></el-form-item>
            <el-form-item label="下次回访时间:"><span>{{23456 | formatTime}}</span></el-form-item>
            <el-form-item label="回访人员:"><span>回访人员</span></el-form-item>
            <el-form-item label="所属部门:"><span>上海分公司 ---> 销售部---> 销售一组</span></el-form-item>
            <el-form-item label="附加商品信息:"></el-form-item>
            <el-table :data="form.goodsList" border style="width: 100%; margin-bottom: 20px;">
                <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in contactColumns" :key="index">
                    <template slot-scope="scope">
                        <slot v-if="item.key == 'status'" :name="item.key" :row="scope.row">
                            {{scope.row[item.key] | formatStatus}}
                        </slot>
                        <slot v-else :name="item.key" :row="scope.row">
                            {{scope.row[item.key]}}
                        </slot>
                    </template>
                </el-table-column>
            </el-table>   
            <el-form-item label="产品满意度:">满意</el-form-item>
            <el-form-item label="产品满意度备注:">备注备注备注备注备注备注备注备注备注备注备注备注备注备注备注备注</el-form-item>
            <el-form-item label="客户反馈问题:">客户反馈问题客户反馈问题客户反馈问题客户反馈问题客户反馈问题客户反馈问题</el-form-item>
            <el-form-item label="处理意见:">处理意见处理意见处理意见处理意见处理意见处理意见处理意见处理意见处理意见</el-form-item>
            <el-form-item label="继续购买意向:">有</el-form-item>
            <el-form-item label="备注信息:">备注信息备注信息备注信息备注信息备注信息</el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" @click="close">关闭</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import { copyMap, formatTime } from "../../../../../../js/util";

    export default {
        data() {
            return {
                form: {},
                contactColumns: [
                    {
                        title: '商品ID',
                        key: 'id',
                    },
                    {
                        title: '商品名称',
                        key: 'name',
                    },
                    {
                        title: '型号',
                        key: 'goodsNo',
                    },
                    {
                        title: '数量',
                        key: 'num',
                    },
                    {
                        title: '运行状态',
                        key: 'status',
                    },
                    {
                        title: '备注信息',
                        key: 'remark',
                    }
                ],
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
                this.form.goodsList = [
                    {
                        id: 1,
                        name: '2',
                        goodsNo: '3',
                        num: '4',
                        status: 1,
                        remark: '6',
                    }
                ]
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '/';
                }
            },
            formatStatus (status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return '正常';
                    case 2: return '故障';
                }
            },
        },
        props: ['url', 'show', 'callBack', 'data'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
