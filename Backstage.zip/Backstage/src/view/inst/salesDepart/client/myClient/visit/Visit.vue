<template>
    <div>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button icon="el-icon-circle-plus-outline" v-show="auth.add" @click="showAdd = true" type="primary">新增回访记录</el-button>
            <div slot="degree" slot-scope="data">{{data.row.degree | formatDegree}}</div>
            <div slot="purpose" slot-scope="data">{{data.row.purpose | formatPurpose}}</div>
            <div slot="visitTime" slot-scope="data">{{data.row.visitTime | formatTime}}</div>
            <div slot="nextVisitTime" slot-scope="data">{{data.row.nextVisitTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>        
        <!--add-->
        <VisitAdd :url="url" :show="showAdd"
                       :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></VisitAdd>
        <!--detail-->
        <VisitDetail :url="url" :show="showQuery" :data="queryData"
                       :callBack="(flag)=>{showQuery = false;}"></VisitDetail>
    </div>
</template>

<script>
    import {formatTime} from "../../../../../../js/util"; 
    import VisitAdd from './VisitAdd';   
    import VisitDetail from './VisitDetail';   

    const url = {
        table: Http.inst.getAllUserPage,
        add: Http.inst.addVisit,
        getGoodsListByType: Http.inst.getGoodsListByType,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        components: {
            VisitAdd, 
            VisitDetail
        },
        data() {
            return {
                auth: {
                    add: true,
                    query: true
                },
                url: url,
                showAdd: false,
                showQuery: false,
                queryData: {},
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        sort: 1,
                        param: {
                            userId: ''
                        },
                        list: [
                            {
                                title: '回访记录编号',
                                key: 'id',
                                // search:{
                                //     type: 'text',
                                //     symbol: '='
                                // }
                            },
                            {
                                title: '回访时间',
                                key: 'visitTime',
                                // sortable: true,
                                // search: {
                                //     type: 'time',
                                //     symbol: 'between'
                                // }
                            },
                            {
                                title: '关联设备信息',
                                key: 'goodsName'
                            },
                            {
                                title: '下次回访时间',
                                key: 'nextVisitTime',
                                // sortable: true,
                                // search: {
                                //     type: 'time',
                                //     symbol: 'between'
                                // }
                            },
                            {
                                title: '回访人员',
                                key: 'trueName'
                            },
                            {
                                title: '产品满意度',
                                key: 'degree',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: [
                                //         {name: '不满意', value: '0'},
                                //         {name: '满意', value: '1'},
                                //         {name: '非常满意', value: '2'},
                                //     ]
                                // },
                                // filter:[
                                //     {text: '不满意', value: '= 0'},
                                //     {text: '满意', value: '= 1'},
                                //     {text: '非常满意', value: '= 2'}
                                // ]
                            },
                            {
                                title: '继续购买意向',
                                key: 'purpose',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: [
                                //         {name: '无', value: '0'},
                                //         {name: '有', value: '1'},
                                //         {name: '继续跟进', value: '2'}
                                //     ]
                                // },
                                // filter:[
                                //     {text: '无', value: '= 0'},
                                //     {text: '有', value: '= 1'},
                                //     {text: '继续跟进', value: '= 2'}
                                // ]
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 100
                            }
                        ]
                    }
                }
            }
        },
        created () {
            this.table.data.param.userId = Sun.getQuery('userId');
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query (item) {
                this.queryData = item;
                this.showQuery = true;
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            formatDegree (degree) {
                degree = parseInt(degree);
                switch (degree) {
                    case 0: return '不满意';
                    case 1: return '满意';
                    case 1: return '非常满意';
                }
            },
            formatPurpose (purpose) {
                purpose = parseInt(purpose);
                switch (purpose) {
                    case 0: return '无意向';
                    case 1: return '有意向';
                    case 2: return '继续跟进';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
