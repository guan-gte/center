<template>
    <el-dialog title="添加客户" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="150px" size="mini">
            <el-form-item required label="公司名称:">
                <el-input v-model="form.company" placeholder="请输入公司名称"></el-input>
            </el-form-item>            
            <el-form-item required label="公司简称:">
                <el-input v-model="form.companyAlias" placeholder="请输入公司简称"></el-input>
            </el-form-item>            
            <el-form-item required label="公司地址:">
                <el-cascader placeholder="请选择公司地址" :options="cityList" :props="optionProps" v-model="comCodeList"></el-cascader>
            </el-form-item>
            <el-form-item required label="公司详细地址:">
                <el-input v-model="form.companyAddressDetail" placeholder="请输入公司详细地址"></el-input>
            </el-form-item> 
            <el-form-item required label="首要联系人姓名:">
                <el-input v-model="form.contactName" placeholder="请输入首要联系人姓名"></el-input>
            </el-form-item>
            <el-form-item required label="首要联系人手机号:">
                <el-input v-model="form.telPhone" placeholder="请输入首要联系人手机号"></el-input>
            </el-form-item>
            <el-form-item label="行业信息:">
                <el-select v-model="form.tradeId" filterable placeholder="请选择行业信息">
                    <el-option v-for="(item, index) in tradeList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="客户标签:">
                <el-select v-model="form.labelId" filterable placeholder="请选择客户标签">
                    <el-option v-for="(item, index) in userLabelList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="个人标签:">
                <el-select v-model="form.personLabelId" filterable placeholder="请选择个人标签">
                    <el-option v-for="(item, index) in personLabelList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import { checkPhone } from "../../../../../js/util";
    import cityList from "../../../../../js/city";
    export default {
        data() {
            return {
                loading: false,
                // 指定option
                optionProps: {
                    value: 'i',
                    label: 'n',
                    children: 'l'
                },
                cityList: cityList,
                form: {},
                comCodeList: [],
                // 下拉
                personLabelList: [],
                userLabelList: [],
                levelList: [],
                tradeList: [],
                // 添加
                addData: {
                    company: '',
                    companyAlias: '',
                    companyCityId: '',
                    companyAddress: '',
                    companyAddressDetail: '',
                    contactName: '',
                    telPhone: '',
                    labelId: '',
                    tradeId: '',
                    personLabelId: ''
                }  
            }
        },
        methods: {
            open () {
                this.form = {};
                // cityCode
                this.comCodeList = [];
                // 下拉
                this.personLabelList = [];
                this.userLabelList = [];
                this.levelList = [];
                this.tradeList = [];
                this.getList();
            },
            formatCity (id) {
                let idList = [];
                this.cityList.forEach((item) => {
                    if (item.l) {
                        item.l.forEach((jtem) => {
                            if (jtem.l) {
                                jtem.l.forEach((ktem) => {
                                    if (ktem.i == id) {
                                        idList = [item.i, jtem.i, ktem.i];
                                    }
                                });
                            } else {
                                if (jtem.i == id) idList = [item.i, jtem.i, ''];
                            }
                        });
                    } else {
                        if (item.i == id) idList = [item.i, '', ''];
                    }
                });
                return idList;
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                this.parseData(this.form);
                // 
                if (!this.form.company) {
                    Sun.showError('请输入公司名称');
                    return;
                }
                if (!this.form.companyAlias) {
                    Sun.showError('请输入公司简称');
                    return;
                }
                if (!this.form.companyCityId) {
                    Sun.showError('请选择公司地址');
                    return;
                }
                if (!this.form.companyAddressDetail || this.form.companyAddressDetail.length < 6) {
                    Sun.showError('请输入公司详细地址');
                    return;
                }
                if (!this.form.contactName) {
                    Sun.showError('请输入首要联系人姓名');
                    return;
                }
                if (!checkPhone(this.form.telPhone)) {
                    Sun.showError('请输入正确的联系人手机号');
                    return;
                }
                // 
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                return;
                Sun.post({
                    url: this.url.add,
                    data: this.addData,
                    success: () => {
                        Sun.showMsg('添加成功');
                        if (this.callBack) {
                            this.callBack(true);
                        }
                    }
                });
            },
            parseAddress (idList) {
                let address = '';
                this.cityList.forEach((item) => {
                   if (item.i == idList[0]) {
                       address += item.n;
                       if (item.l) {
                            item.l.forEach((jtem) => {
                                if (jtem.i == idList[1]) {
                                    address += jtem.n;
                                    if (jtem.l) {
                                        jtem.l.forEach((ktem) => {
                                            if (ktem.i == idList[2]) {
                                                address += ktem.n;
                                            }
                                        });
                                    }
                                }
                            });
                       }
                   }
                });
                return address;
            },
            parseData() {
                this.form.companyAddress = this.parseAddress(this.comCodeList);
                this.form.companyCityId = this.comCodeList[this.comCodeList.length - 1];
                // addData
                this.addData.contactName = this.form.contactName;
                this.addData.telPhone = this.form.telPhone;
                this.addData.labelId = this.form.labelId;
                this.addData.tradeId = this.form.tradeId;
                this.addData.personLabelId = this.form.personLabelId;
                this.addData.company = this.form.company;
                this.addData.companyAlias = this.form.companyAlias;
                this.addData.companyCityId = this.form.companyCityId;
                this.addData.companyAddress = this.form.companyAddress;
                this.addData.companyAddressDetail = this.form.companyAddressDetail;
            },
            getList () {
                // 个人标签列表
                Sun.post({
                    url: this.url.getPersonLabelList,
                    data: {},
                    success: (data) => {
                        this.personLabelList = data;
                    }
                });
                // 客户标签列表
                Sun.post({
                    url: this.url.getUserLabelList,
                    data: {},
                    success: (data) => {
                        this.userLabelList = data;
                    }
                });
                // 会员级别列表
                Sun.post({
                    url: this.url.getUserLevelList,
                    data: {},
                    success: (data) => {
                        this.levelList = data;
                    }
                });
                // 客户行业列表
                Sun.post({
                    url: this.url.getUserTradeList,
                    data: {},
                    success: (data) => {
                        this.tradeList = data;
                    }
                });
            }
        },
        props: ['show', 'callBack', 'url'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }
    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }
    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }
    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
     /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
</style>
