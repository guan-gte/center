<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true" type="primary">新增客户</el-button>
            <div slot="from" slot-scope="data">{{data.row.from | formatVal}}</div>
            <div slot="tradeName" slot-scope="data">{{data.row.tradeName | formatVal}}</div>
            <div slot="labelName" slot-scope="data">{{data.row.labelName | formatVal}}</div>
            <div slot="personLabelName" slot-scope="data">{{data.row.personLabelName | formatVal}}</div>
            <div slot="levelName" slot-scope="data">{{data.row.levelName | formatVal}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="success" plain size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
        <!--add-->
        <AddClient :url="url" :show="showAdd" 
                    :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></AddClient>
    </Page>
</template>

<script>
    import AddClient from './AddClient';  
    const url = {
        table: Http.inst.getAllUserPage,
        query: Http.inst.getMyUserInfo,
        add: Http.inst.addMyUserInfo,
        getUserLabelList: Http.common.getUserLabelList,
        getUserLevelList: Http.common.getUserLevelList,
        getUserTradeList: Http.common.getUserTradeList,
        getPersonLabelList: Http.inst.getPersonLabelList
    };
    export default {
        extends: Sun.vuePage,
        components: { AddClient },
        data() {
            return {
                auth: {
                    query: true,
                    add: true
                },
                showAdd: false,
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '客户ID',
                                key: 'userId',
                                // search:{
                                //     type: 'text',
                                //     symbol: 'like',
                                //     cat: '%?%'
                                // }
                            },
                            {
                                title: '公司名称',
                                key: 'company',
                                // search:{
                                //     type: 'text',
                                //     symbol: 'like',
                                //     cat: '%?%'
                                // }
                            },
                            {
                                title: '公司简称',
                                key: 'company',
                                // search:{
                                //     type: 'text',
                                //     symbol: 'like',
                                //     cat: '%?%'
                                // }
                            },
                            {
                                title: '首要联系人',
                                key: 'telPhone',
                                // search:{
                                //     type: 'text',
                                //     symbol: 'like',
                                //     cat: '%?%'
                                // }
                            },
                            {
                                title: '联系电话',
                                key: 'telPhone',
                                // search:{
                                //     type: 'text',
                                //     symbol: 'like',
                                //     cat: '%?%'
                                // }
                            },
                            {
                                title: '客户来源',
                                key: 'from',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: []
                                // },
                                // filter:[]
                            },
                            {
                                title: '客户行业',
                                key: 'tradeName',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: []
                                // },
                                // filter:[]
                            },
                            {
                                title: '客户标签',
                                key: 'labelName',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: []
                                // },
                                // filter:[]
                            },
                            {
                                title: '个人标签',
                                key: 'personLabelName',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: []
                                // },
                                // filter:[]
                            },
                            {
                                title: '会员级别',
                                key: 'levelName',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: []
                                // },
                                // filter:[]
                            },
                            {
                                title: '操作',
                                key: 'opreate',
                                width: 100
                            }
                        ]
                    }
                },
                userLabelList: [],
                personLabelList: [],
                levelList: [],
                tradeList: []
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
            // this.getSearchList();
        },
        methods: {
            query (item) {
                Sun.push('/inst/salesDepart/client/myClient/commonTab', {activeName: 1});
            },
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 获取搜索项数据
            getSearchList () {
                // 个人标签列表
                Sun.post({
                    url: this.url.getPersonLabelList,
                    data: {},
                    success: (data) => {
                        this.personLabelList = data;
                        this.addSearchFilter('personLabelName', this.personLabelList, 'search',  'filter', 'name', 'id');
                    }
                });
                // 客户标签列表
                Sun.post({
                    url: this.url.getUserLabelList,
                    data: {},
                    success: (data) => {
                        this.userLabelList = data;
                        this.addSearchFilter('labelName', this.userLabelList, 'search',  'filter', 'name', 'id');
                    }
                });
                // 会员级别列表
                Sun.post({
                    url: this.url.getUserLevelList,
                    data: {},
                    success: (data) => {
                        this.levelList = data;
                        this.addSearchFilter('levelName', this.levelList, 'search',  'filter', 'name', 'id');
                    }
                });
                // 客户行业列表
                Sun.post({
                    url: this.url.getUserTradeList,
                    data: {},
                    success: (data) => {
                        this.tradeList = data;
                        this.addSearchFilter('tradeName', this.tradeList, 'search',  'filter', 'name', 'id');
                    }
                });
            }
        },
        filters: {
            formatVal (v) {
                if (v) {
                    return v;
                } else {
                    return '/';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
