<template>
    <el-dialog title="新增回访记录" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="700px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px" size="mini">
            <el-form-item label="选择联系人">
                <el-select @change="changeConcat" v-model="form.concat" filterable>
                    <el-option v-for="(item, index) in concatList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="联系方式">
                <el-input disabled type="text" v-model="form.phone"></el-input>
            </el-form-item>
            <el-form-item label="下次回访时间">
                <el-date-picker v-model="form.nextVisitTime" type="date" placeholder="选择日期"></el-date-picker>
            </el-form-item>
            <el-form-item label="附加商品信息">
                <el-select  @change="selectGoods" v-model="form.goodsId" filterable placeholder="请选择附加商品">
                    <el-option v-for="(item, index) in goodsList" :key="index" :label="item.name + item.model"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-table :data="form.goodsList" border style="width: 100%; margin-bottom: 20px;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in contactColumns" :key="index">
                        <template slot-scope="scope">
                            <slot v-if="item.key == 'opreat'" :name="item.key" :row="scope.row">
                                <el-button @click="delGoods(scope.row)" type="danger" size="mini" round plain>删除</el-button>
                            </slot>
                            <slot v-else :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            <el-form-item label="产品满意度">
                <el-select v-model="form.degree" filterable placeholder="请选择产品满意度">
                    <el-option label="满意" :value="1"></el-option>
                    <el-option label="不满意" :value="0"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="产品满意度备注">
                <el-input type="textarea" autosize placeholder="请输入内容" v-model="form.degreeRemark"></el-input>
            </el-form-item>
            <el-form-item label="客户反馈问题">
                <el-input type="textarea" autosize placeholder="请输入内容" v-model="form.feedBack"></el-input>
            </el-form-item>
            <el-form-item label="处理意见">
                <el-input type="textarea" autosize placeholder="请输入内容" v-model="form.resolution"></el-input>
            </el-form-item>           
            <el-form-item label="继续购买意向">
                <el-select v-model="form.purpose" filterable placeholder="请选择继续购买意向">
                    <el-option label="有" :value="1"></el-option>
                    <el-option label="继续跟进" :value="2"></el-option>
                    <el-option label="无" :value="0"></el-option>
                </el-select>
            </el-form-item>           
            <el-form-item label="备注信息">
                <el-input type="textarea" autosize placeholder="请输入内容" v-model="form.remark"></el-input>
            </el-form-item>  
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                form: {},
                concatList: [],
                goodsList: [],
                contactColumns: [
                    {
                        title: '商品ID',
                        key: 'id',
                    },
                    {
                        title: '商品名称',
                        key: 'name',
                    },
                    {
                        title: '型号',
                        key: 'goodsNo',
                    },
                    {
                        title: '数量',
                        key: 'num',
                    },
                    {
                        title: '运行状态',
                        key: 'status',
                    },
                    {
                        title: '备注信息',
                        key: 'remark',
                    },
                    {
                        title: '操作',
                        key: 'opreat',
                    }
                ],
            }
        },
        methods: {
            open () {
                this.form = {
                    goodsList: [{
                        id: 1,
                        name: '叽叽叽叽斤斤计较经济界',
                        goodsNo: '12',
                        num: '12',
                        status: '12',
                        remark: '12'
                    },
                    {
                        id: 2,
                        name: '叽叽叽叽斤斤计较经济界',
                        goodsNo: '12',
                        num: '12',
                        status: '12',
                        remark: '12'
                    }]
                };
                this.getGoodsList();
                this.getConcatList();
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            getGoodsList () {
                // Sun.post({
                //     url: this.url.getGoodsListByType,
                //     data: {type: 1},
                //     success: (data) => {
                //         this.goodsList = data;
                //     }
                // })
            },
            // 获取联系人
            getConcatList () {
                // this.concatList = []
            },
            // 选择联系人
            changeConcat (value) {
                if (!value) {
                    return;
                }
                // TODO
            },
            // 选择商品
            selectGoods (v) {
                console.log(v);
                // TODO
            },
            // 删除商品
            delGoods (item) {
                let list = this.form.goodsList;
                for( let i = 0; i < list.length; i++) {
                    if (list[i].id == item.id) {
                        list.splice(i, 1);
                        i--;
                    }
                }
                this.form.goodsList = list;
            },
            submit() {
                this.form.nextVisitTime = new Date(this.form.nextVisitTime).getTime()/1000;
                // Sun.post({
                //     url: this.url.add,
                //     data: this.form,
                //     success: () => {
                //         if (this.callBack) {
                //             this.callBack(true);
                //         }
                //     }
                // });
            }
        },
        props: ['url', 'show', 'callBack'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
