<template>
    <el-dialog title="转赠客户" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" size="mini" label-width="140px">
             <el-form-item required label="请选择转增子公司">
                <el-select  @change="getUserList" v-model="form.company" filterable>
                    <el-option v-for="(item, index) in companyList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item required label="请选择销售专员">
                <el-select  v-model="form.user" filterable>
                    <el-option v-for="(item, index) in userList" :key="index" :label="item.name"
                               :value="item.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="请填写备注">
                <el-input :rows="5" type="textarea" placeholder="最多120个字符" v-model="form.intro"></el-input>
                <div class="input-limit" :style="{color:(form.intro.length/120 > 1 ? '#F56C6C' : '#67C23A')}">{{form.intro.length}}/120</div>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button :loading="loading" class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                loading: false,
                form: {
                    intro: ''
                },
                companyList: [],
                userList: []
            }
        },
        methods: {
            open () {
                this.loading = false;
                this.form = {
                    intro: ''
                };
                this.getCompanyList();
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            getCompanyList () {
                // this.companyList = [];
            },
            getUserList (value) {
                if (!value) {
                    return;
                }
                // Sun.post({
                //     url: this.url.getMenuListByAuth,
                //     data: {id: value},
                //     success: (data) => {
                //         this.userList = data;
                //     }
                // })
            },
            submit() {
                if (!this.form.company) {
                    Sun.showError('请选择转增子公司!');
                    return;
                }
                if (!this.form.user) {
                    Sun.showError('请选择销售专员!');
                    return;
                }
                if (this.form.intro.length > 120) {
                    Sun.showError('备注不得超过120个字符!');
                    return;
                }
                
                // this.loading = true;
                // setTimeout(() =>{
                //     this.loading = false
                // },1000)
                // // 
                // let obj = {
                //     nameList: this.tagList,
                //     pid: this.pid
                // }
                // Sun.post({
                //     url: this.url.add,
                //     data: obj,
                //     success: () => {
                //         Sun.showMsg('添加成功');
                //         if (this.callBack) {
                //             this.callBack(true);
                //         }
                //     }
                // });
            }
        },
        props: ['url', 'show', 'callBack'],
    }
</script>

<style scoped>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }
    .el-form-add {
        max-height: 400px !important;
        overflow: scroll;
        padding-right: 20px;
        box-sizing: border-box;
    }
    
    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
    /* 设置滚动条的样式 */
    .el-form-add::-webkit-scrollbar {
        border-radius: 10px;
        width: 10px;
        /* width: 0; */
        height: 0;
        background-color: #f0f0f0;
    }
    /* 滚动槽 */
    .el-form-add::-webkit-scrollbar-track {
        border-radius:10px;
    }
    /* 滚动条滑块 */
    .el-form-add::-webkit-scrollbar-thumb {
        transition: all ease .3s;
        border-radius:10px;
        background-color:#d8d8d8;
    }
    /* tag */
    .el-tag + .el-tag {
        margin-left: 10px;
    }
    .button-new-tag {
        margin-left: 10px;
        height: 28px;
        line-height: 28px;
        padding-top: 0;
        padding-bottom: 0;
    }
    .input-new-tag {
        width: 90px;
        margin-left: 10px;
        vertical-align: bottom;
    }
    /* textarea */
    .input-limit {
        text-align: right;
    }
</style>
