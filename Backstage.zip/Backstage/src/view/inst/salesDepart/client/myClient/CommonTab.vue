<template>
    <Page>
        <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="基本信息" name="1">
                <clientDetailDetail v-if="activeName == 1"></clientDetailDetail>
            </el-tab-pane>
            <el-tab-pane label="客户回访" name="2">
                <visitVisit v-if="activeName == 2"></visitVisit>
            </el-tab-pane>
            <el-tab-pane label="购买意向" name="3">3
                <!-- <partsClassify v-if="activeName == 3"></partsClassify> -->
            </el-tab-pane>
        </el-tabs>
    </Page>
</template>

<script>
    import clientDetailDetail from './clientDetail/Detail';
    import visitVisit from './visit/Visit';
    // import Scene from './scene/Scene';

    export default {
        extends: Sun.vuePage,
        components: {
            clientDetailDetail,
            visitVisit,
        //     Scene
        },
        data() {
            return {
                activeName: '1'
            }
        },
        created () {
            let activeName = Sun.getQuery('activeName');
            if (activeName) {
                this.activeName = activeName.toString();
            }
        },
        methods: {
            handleClick(tab, event) {
                // console.log(tab, event);
            }
        },
        filters: {
        }
    }
</script>

<style scoped>

</style>
