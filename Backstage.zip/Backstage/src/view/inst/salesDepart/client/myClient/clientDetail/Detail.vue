<template>
    <div>
        <!-- 客户信息 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 客户信息</el-divider>
        <el-row class="row-box" :gutter="10">
            <el-col :md="12" :lg="8" :xl="6">用户ID:</el-col>
            <el-col :md="12" :lg="8" :xl="6">注册账号:</el-col>
            <el-col :md="12" :lg="8" :xl="6">公司名称:</el-col>
            <el-col :md="12" :lg="8" :xl="6">公司简称:</el-col>
            <el-col :md="12" :lg="8" :xl="6">公司地址:</el-col>
            <el-col :md="12" :lg="8" :xl="6">行业信息:</el-col>
            <el-col :md="12" :lg="8" :xl="6">客户标签:</el-col>
            <el-col :md="12" :lg="8" :xl="6">个人标签:</el-col>
            <el-col :md="12" :lg="8" :xl="6">客户来源:</el-col>
            <el-col :md="12" :lg="8" :xl="6">会员级别:</el-col>
            <el-col :md="12" :lg="8" :xl="6">注册时间:</el-col>
            <el-col :md="12" :lg="8" :xl="6">上次登录时间:</el-col>
            <el-col :md="12" :lg="8" :xl="6">所属售后:</el-col>
            <el-col :md="12" :lg="8" :xl="6">添加客户人员:</el-col>
        </el-row>
        <div class="item-btn">
            <el-button @click="editUser" type="primary" size="mini" round plain>编辑用户信息</el-button>
            <el-button @click="given" type="primary" size="mini" round plain>转增该客户</el-button>
        </div>
        <!-- 客户联系人 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 客户联系人</el-divider>
        <el-table :data="contactList" border style="width: 100%;">
            <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in contactColumns" :key="index">
                <template slot-scope="scope">
                    <slot v-if="item.key == 'isFirst'" :name="item.key" :row="scope.row">
                        {{scope.row[item.key] ? '首要联系人' : '次要联系人'}}
                    </slot>
                    <slot v-else-if="item.key == 'opreat'" :name="item.key" :row="scope.row">
                        <el-button @click="editContact(scope.row)" type="text" size="mini"  round plain>编辑</el-button>
                        <el-button @click="delContact(scope.row)" style="margin-left: 0;" v-if="!scope.row['isInit']" type="text" size="mini" round plain>删除</el-button>
                    </slot>
                    <slot v-else :name="item.key" :row="scope.row">
                        {{scope.row[item.key]}}
                    </slot>
                </template>
            </el-table-column>
        </el-table>
        <div class="item-btn">
            <el-button @click="addContact" type="primary" size="mini" round plain>新增次要联系人</el-button>
        </div>
        <!-- 客户收货地址 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 客户收货地址</el-divider>
        <el-table :data="addressList" border style="width: 100%;">
            <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in addressColumns" :key="index">
                <template slot-scope="scope">
                    <slot v-if="item.key == 'opreat'" :name="item.key" :row="scope.row">
                        <el-button @click="editAddress(scope.row)" v-if="!scope.row['isSalesAdd']" type="text" size="mini"  round plain>编辑</el-button>
                        <el-button @click="delAddress(scope.row)" style="margin-left: 0;" v-if="!scope.row['isSalesAdd']" type="text" size="mini" round plain>删除</el-button>
                    </slot>
                    <slot v-else :name="item.key" :row="scope.row">
                        {{scope.row[item.key]}}
                    </slot>
                </template>
            </el-table-column>
        </el-table>
        <div class="item-btn">
            <el-button @click="addAddress" type="primary" size="mini" round plain>新增收货地址</el-button>
        </div>
        <!-- 客户服务人员变更记录 -->
        <el-divider class="divider" content-position="left"><i class="el-icon-collection-tag"></i> 客户服务人员变更记录</el-divider>
        <el-row class="row-box" :gutter="10">
            <el-col v-for="(item, index) in recorde" :key="index" :md="12" :lg="8" :xl="6">{{item.time}}-{{item.company}}-{{item.part}}-{{item.people}}</el-col>
        </el-row>
        <!--转赠-->
        <GivenClient :url="url" :show="showGiven" 
                    :callBack="(flag)=>{showGiven = false;if (flag) refresh()}"></GivenClient>
        <!--新增次要联系人-->
        <ContactAdd :url="url" :show="showContactAdd" 
                    :callBack="(flag)=>{showContactAdd = false;if (flag) refresh()}"></ContactAdd>
        <!--新增收货人-->
        <AddressAdd :url="url" :show="showAddressAdd" 
                    :callBack="(flag)=>{showAddressAdd = false;if (flag) refresh()}"></AddressAdd>
    </div>
</template>

<script>   
    import GivenClient from './GivenClient';  
    import ContactAdd from './ContactAdd';  
    import AddressAdd from './AddressAdd';  

    const url = {
        
    };

    export default {
        extends: Sun.vuePage,
        components: { 
            GivenClient,
            ContactAdd,
            AddressAdd
        },
        data() {
            return {
                url: url,
                showGiven: false,
                showContactAdd: false,
                showAddressAdd: false,
                contactColumns: [
                    {
                        title: '联系人级别',
                        key: 'isFirst',
                    },
                    {
                        title: '姓名',
                        key: 'name',
                    },
                    {
                        title: '职位',
                        key: 'work',
                    },
                    {
                        title: '手机号',
                        key: 'phone',
                    },
                    {
                        title: '微信',
                        key: 'wx',
                    },
                    {
                        title: 'QQ',
                        key: 'qq',
                    },
                    {
                        title: '邮箱',
                        key: 'email',
                    },
                    {
                        title: '操作',
                        key: 'opreat',
                    }
                ],
                contactList: [
                    {
                        isFirst: '12',
                        name: '12',
                        work: '12',
                        phone: '12',
                        wx: '12',
                        qq: '12',
                        email: '12',
                        isInit: true
                    },
                    {
                        isFirst: '12',
                        name: '12',
                        work: '12',
                        phone: '12',
                        wx: '12',
                        qq: '12',
                        email: '12',
                        isInit: false
                    }
                ],
                addressColumns: [
                    {
                        title: '收货人',
                        key: 'name',
                    },
                    {
                        title: '手机号',
                        key: 'phone',
                    },
                    {
                        title: '收货地址',
                        key: 'address',
                    },
                    {
                        title: '详细地址',
                        key: 'addressDetail',
                    },
                    {
                        title: '来源',
                        key: 'from',
                    },
                    {
                        title: '操作',
                        key: 'opreat',
                    }
                ],
                addressList: [
                    {
                        name: '232',
                        phone: '232',
                        address: '232',
                        addressDetail: '232',
                        from: '232',
                        isSalesAdd: false
                    },
                    {
                        name: '232',
                        phone: '232',
                        address: '232',
                        addressDetail: '232',
                        from: '232',
                        isSalesAdd: true
                    }
                ],
                recorde: [
                    {
                        time: '2017-06-05 12:15:58',
                        company: '公司',
                        part: '部门',
                        people: '辣椒'
                    },
                    {
                        time: '2017-06-05 12:15:58',
                        company: '公司',
                        part: '部门',
                        people: '辣椒'
                    }
                ]
            }
        },
        created () {
            
        },
        methods: {
            refresh () {

            },
            // 编辑用户资料
            editUser () {

            },
            // 转赠该客户
            given () {
                this.showGiven = true;
            },
            // 编辑联系人
            editContact (item) {
                console.log(item);
            },
            // 新增联系人
            addContact () {
                this.showContactAdd = true;
            },
            // 删除联系人
            delContact (item) {
                Sun.confirm('提示', '确定要删除此联系人吗?', () => {
                    
                });
            },
            // 编辑地址
            editAddress (item) {

            },
            // 删除地址
            delAddress (item) {
                Sun.confirm('提示', '确定要删除此收货地址吗?', () => {
                    
                });
            },
            // 新增地址
            addAddress () {
                this.showAddressAdd = true;
            }
        },
        filters: {
            
        }
    }
</script>

<style lang="less" scoped>
    @import url('../../../../../../assets/css/config.less');
    .row-box {
        padding: 20px 20px;
        padding-bottom: 0;
        box-sizing: border-box;
    }
    .el-col {
        margin-bottom: 20px;
        color: #606266;
    }
    /* divider */
    .el-divider__text{
        color: #67C23A;
    }
    // btn
    .item-btn {
        text-align: right; 
        // padding: 10px 0;
        padding-top: 20px;
        button {
            margin-left: 20px;
        }
    }
</style>

