<template>
    <Page>
        <div class="all">        
            <!-- 状态 -->
          
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header">审批状态: <span :style="{color: baseInfo.status == 2 ? '#F56C6C' : '#32CD32'}">{{baseInfo.status | famateStatus}}</span></div>
                <div class="main clearfix">
                    <div class="text item">客户名称: {{baseInfo.demo}}</div>
                    <div class="text item">进入公海时间: {{baseInfo.demo}}</div>
                    <div class="text item">发起申请人: {{baseInfo.demo}}</div>
                    <div class="text item">发起申请时间: {{baseInfo.demo}}</div>
                </div>
                <p style="color: #F56C6C;" v-if="baseInfo.status == 2">驳回原因：爱上凤凰大厦</p>
            </el-card>
        </div>  
        <div class="footer-btn">
            <el-button class="button-edit"  type="primary" @click="back">返回</el-button>
            <el-button v-if="baseInfo.status == 1" class="button-edit"  type="danger" @click="stop">驳回</el-button>
            <el-button v-if="baseInfo.status == 1" class="button-edit"  type="primary" @click="pass">通过</el-button>
        </div>  
        <ClaimReject :url="url" :show="showEdit"
                       :callBack="(flag)=>{showEdit = false;if (flag) back()}"></ClaimReject>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    import ClaimReject from './ClaimReject';
    const url = {
        edit: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        components: {ClaimReject},
        data() {
            return {
                url: url,
                showEdit: false,
                baseInfo: {
                    demo: '上海分公司',
                    // 订单状态 1发起申请（待审批） 2 审批驳回  3 审批通过
                    status: 1
                }
            }
        },
        methods: {
            back () {
                Sun.closePage();
                Sun.push('/inst/visitAndOrder/saleClaimLeader/saleClaimLeader');
            },
            stop () {
                this.showEdit = true;
            },
            pass () {
                Sun.confirm('提示', '确认通过?', () => {
                    // TODO
                });
            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            famateStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return '待审批';
                    case 2: return '审批驳回';
                    case 3: return '审批通过';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
    }
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }
    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
