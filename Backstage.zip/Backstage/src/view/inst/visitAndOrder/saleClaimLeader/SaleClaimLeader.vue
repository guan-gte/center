<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.master.getAdminPage,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    add: true,
                    query: true
                },
                showAdd: false,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '客户姓名',
                                key: 'trueName'
                            },   
                            {
                                title: '认领人',
                                key: 'trueName'
                            },
                            {
                                title: '认领发起时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '进入公海时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '审批状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待审批', value: '0'},
                                        {name: '已通过', value: '1'},
                                        {name: '已驳回', value: '2'},
                                    ]
                                },
                                filter:[
                                    {text: '待审批', value: '= 0'},
                                    {text: '已通过', value: '= 1'},
                                    {text: '已驳回', value: '= 2'},
                                ]
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query () {
                Sun.push('/inst/visitAndOrder/saleClaimLeader/saleClaimDetail');
            }
        },
        filters: {
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '待审批';
                    case 1: return '已通过';
                    case 2: return '已驳回';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
