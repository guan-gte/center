<template>
    <Page>
        <div class="all">        
            <!-- 审批信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>审批信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">发起审批: {{examineInfo.demo}}</div>
                    <div class="text item">发起时间: {{examineInfo.demo}}</div>
                    <div class="text item">一级审批: {{examineInfo.demo}}</div>
                    <div class="text item">审批时间: {{examineInfo.demo}}</div>
                    <div class="text item">审批状态: 
                        <span :style="examineInfo.status == 0 ? 'color: #67C23A' : 'color: #F56C6C'">{{examineInfo.status | formatStatus}}</span>
                    </div>
                    <div v-if="examineInfo.status == 1" class="text item">驳回原因: {{examineInfo.remark}}</div>
                </div>
            </el-card>
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>基本信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">开单人: {{baseInfo.demo}}</div>
                    <div class="text item">开单部门: {{baseInfo.demo}}</div>
                    <div class="text item">所属子公司: {{baseInfo.demo}}</div>
                    <div class="text item">订单编号: {{baseInfo.demo}}</div>
                    <div class="text item">审批状态: {{baseInfo.status | formatOrderStatus}}</div>
                    <div class="text item">开单日期: {{baseInfo.demo}}</div>
                    <div class="text item">送货日期: {{baseInfo.demo}}</div>
                    <div class="text item">仓库: {{baseInfo.demo}}</div>
                    <div class="text item">订单星级: {{baseInfo.demo}}</div>
                </div>
            </el-card>
            <!-- 后续单据 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>后续单据:</span></div>
                <div class="main clearfix">
                    <div class="text item">收款单号: {{documents.demo}}</div>
                    <div class="text item">出库单: {{documents.demo}}</div>
                    <div class="text item">打包人员: {{documents.demo}}</div>
                    <div class="text item">发货单号: {{documents.demo}}</div>
                    <div class="text item">发货人: {{documents.demo}}</div>
                </div>
            </el-card>
            <!-- 客户信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>客户信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">公司信息: {{customer.demo}}</div>
                    <div class="text item">联系人: {{customer.demo}}</div>
                    <div class="text item">联系方式: *********</div>
                    <div class="text item">公司地址: {{customer.demo}}</div>
                    <div class="text item">收货地址: {{customer.demo}}</div>
                    <div class="text item">客户咨询日期: {{customer.demo}}</div>
                </div>
                <el-form ref="form" :model="customer" label-width="45px">
                    <el-form-item label="备注:">
                        <el-input type="textarea" autosize placeholder="请输入内容" v-model="customer.remark"></el-input>
                    </el-form-item>
                </el-form>
            </el-card>
            <!-- 财务信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>财务信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">金额合计: {{financial.demo}}</div>
                    <div class="text item">发票类型: {{financial.demo}}</div>
                    <div class="text item">付款方式: {{financial.demo}}</div>
                    <div class="text item">开票日期: {{financial.demo}}</div>
                </div>
                <div class="footer">
                    <el-button type="primary">下载附件</el-button>
                </div>
            </el-card>
            <!--货品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>货品信息:</span><span style="float: right;">订单总金额: {{totalPrice}}元</span></div>
                <el-table :data="list" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
        </div>          
        <div class="footer-btn" v-show="!examineInfo.status">
            <el-button v-show="auth.edit" class="button-edit"  type="danger" @click="submit(2)">驳回</el-button>
            <el-button v-show="auth.edit" class="button-edit"  type="primary" @click="submit(1)">通过</el-button>
        </div>  
        <ExamineReject :url="url" :show="showEdit"
                       :callBack="(flag)=>{showEdit = false;if (flag) init()}"></ExamineReject>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    import ExamineReject from './ExamineReject';
    const url = {
        edit: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        components: {ExamineReject},
        data() {
            return {
                url: url,
                auth: {
                    edit: true
                },
                showEdit: false,
                // 审批详情
                examineInfo: {
                    demo: '上海分公司',
                    status: 0,
                    remark: ''
                },
                baseInfo: {
                    demo: '上海分公司',
                    // 订单状态 1发起申请（一级待审批） 2 一级审批 驳回  3 一级审批通过（二级待审批） 4二级审批驳回 5二级审批通过(等待确认)6 财务已确认
                    status: 1
                },
                documents: {
                    demo: '上海分公司'
                },
                customer: {
                    demo: '上海分公司'
                },
                financial: {
                    demo: '上海分公司',
                    remark: ''
                },
                columns: [
                    {
                        title: '商品ID',
                        key: 'trueName',
                    },
                    {
                        title: '商品名称',
                        key: 'trueName',
                    },
                    {
                        title: '适用机型',
                        key: 'trueName',
                    },
                    {
                        title: '规格型号',
                        key: 'trueName',
                    },
                    {
                        title: '计量单位',
                        key: 'trueName',
                    },
                    {
                        title: '零售价',
                        key: 'trueName',
                    },
                    {
                        title: '商品数量',
                        key: 'trueName',
                    },
                    {
                        title: '订单小计',
                        key: 'total',
                    },
                ],
                list: [],
                totalPrice: 0
            }
        },
        methods: {
            // 通过 驳回
            submit (type) {
                if (type == 1) {
                    Sun.confirm('提示', '确认通过?', () => {
                        // TODO
                    });
                } else if (type == 2){
                    this.showEdit = true;
                }
            },
            //
            init() {

            },
            // 
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },        
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '待审批';
                    case 1: return '已驳回';
                }
            },
            formatOrderStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return '待审批';
                    case 2: return '已驳回';
                    case 3: return '待审批';
                    case 4: return '已驳回';
                    case 5: return '等待财务确认';
                    case 6: return '财务已确认';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
    }    
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }
    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
