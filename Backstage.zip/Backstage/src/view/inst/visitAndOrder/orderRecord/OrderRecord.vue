<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="orderAdd" type="primary">新增订单</el-button>
            <div slot="type" slot-scope="data">
                <span :style="{color: data.row.type == 1 ? '#32CD32' : '#E49348'}">{{data.row.type == 1 ? '线上订单' : '线下订单'}}</span>
            </div>
            <div slot="status" slot-scope="data">{{data.row.status | formatOrderStatus}}</div>
            <div slot="payStatus" slot-scope="data">{{data.row.payStatus | formatPayStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.inst.getMyCustomerOrderPage,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    add: true,
                    query: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '订单编号',
                                key: 'orderNo',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '订单类型',
                                key: 'type',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '线上订单', value: '1'},
                                        {name: '线下订单', value: '2'}
                                    ]
                                },
                                filter:[
                                    {text: '线上订单', value: '= 1'},
                                    {text: '线下订单', value: '= 2'}
                                ]
                            },              
                            {
                                title: '客户姓名',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '联系方式',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '下单时间',
                                key: 'createTime',
                                sortable: true
                            },
                            // payStatus=1代表支付完成了，status=1代表订单待发货。如果是线上流程两个是等价的，如果是线下的可能payStatus=0但是status=1
                            {
                                title: '订单状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未支付', value: '0'},
                                        {name: '已支付(待发货)', value: '1'},
                                        {name: '已取消', value: '2'},
                                        {name: '已关闭', value: '3'},
                                        {name: '待收货', value: '4'},
                                        {name: '已收货', value: '5'},
                                        {name: '已完成', value: '6'}
                                    ]
                                },
                                filter:[
                                    {text: '未支付', value: '= 0'},
                                    {text: '已支付(待发货)', value: '= 1'},
                                    {text: '已取消', value: '= 2'},
                                    {text: '已关闭', value: '= 3'},
                                    {text: '待收货', value: '= 4'},
                                    {text: '已收货', value: '= 5'},
                                    {text: '已完成', value: '= 6'},
                                ]
                            },
                            // 支付状态显示如果status=0且payStatus=0未支付。status=1，payStatus=0则显示pay/needPay
                            {
                                title: '支付状态',
                                key: 'payStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未支付', value: '0'},
                                        {name: '已支付', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '未支付', value: '= 0'},
                                    {text: '已支付', value: '= 1'}
                                ]
                            },
                            {
                                title: '订单金额',
                                key: 'needPayMoney',
                                sortable: true
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            // 新增订单
            orderAdd () {
                Sun.push('/inst/visitAndOrder/orderRecord/orderAdd');
            },
            // 订单记录详情
            query (item) {
                if (item.type == 1) {
                    // 线上订单
                    Sun.temp.onlineOrderDetail = item;
                    Sun.push('/inst/visitAndOrder/orderRecord/onlineOrder');
                } else if (item.type == 0) {
                    // 线下订单
                    Sun.temp.offlineOrderDetail = item;
                    Sun.push('/inst/visitAndOrder/orderRecord/offlineOrder');
                }
            }
        },
        filters: {
            formatType(type) {
                if (type == 1) {
                    return '线上订单'
                }
                if (type == 2) {
                    return '线下订单'
                }
            },
            formatOrderStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未支付';
                    case 1: return '已支付(待发货)';
                    case 2: return '已取消';
                    case 3: return '已关闭';
                    case 4: return '待收货';
                    case 5: return '已收货';
                    case 6: return '已完成';
                }
            },
            formatPayStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未支付';
                    case 1: return '已支付';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
