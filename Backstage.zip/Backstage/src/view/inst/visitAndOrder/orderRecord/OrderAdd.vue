<template>
    <Page>
        <div class="all">        
            <!-- 状态 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>订单状态:</span></div>
                <el-steps class="order-status" finish-status="success" :active="baseInfo.status | formatType" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.applyName}}</p></div></div>
                            <p class="status-desc">{{baseInfo.status == 1 ? '发起申请' : '发起申请'}}</p>
                            <p class="status-time" v-if="baseInfo.applyTime">{{baseInfo.applyTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="一级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesDirectorImg ? baseInfo.salesDirectorImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">销售组长</p><p class="name">{{baseInfo.salesDirector}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 2 ? 'dinger-color' : ': #303133'">
                                {{baseInfo.status == 3 ? '审批通过' : (baseInfo.status == 2 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.firstPassTime"
                                :class="baseInfo.status == 2 ? 'dinger-color' : ''">
                                {{baseInfo.firstPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="二级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesLeaderImg ? baseInfo.salesLeaderImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">销售总监</p><p class="name">{{baseInfo.salesLeader}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 4 ? 'dinger-color' : ''">
                                {{baseInfo.status == 5 ? '审批通过' : (baseInfo.status == 4 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.secondPassTime"
                                :class="baseInfo.status == 4 ? 'dinger-color' : ''">
                                {{baseInfo.secondPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="财务确认">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.confirmImg ? baseInfo.confirmImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">财务</p><p class="name">{{baseInfo.confirmName}}</p></div></div>
                            <p class="status-desc">
                                {{baseInfo.status == 6 ? '已确认' : '等待确认'}}</p>
                            <p class="status-time" v-if="baseInfo.confirmTime">{{baseInfo.confirmTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="开始打包">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="img.imgBlank" alt="">
                            </div>
                            <p class="status-desc">{{baseInfo.status == 4 ? '开始打包' : ''}}</p>
                        </div>
                    </el-step>
                </el-steps>
            </el-card>
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>基本信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">开单人: {{baseInfo.demo}}</div>
                    <div class="text item">开单部门: {{baseInfo.demo}}</div>
                    <div class="text item">所属子公司: {{baseInfo.demo}}</div>
                    <div class="text item">订单编号: {{baseInfo.demo}}</div>
                    <div class="text item">订单状态: {{baseInfo.demo}}</div>
                    <div class="text item">开单日期: {{baseInfo.demo}}</div>
                    <div class="text item">送货日期: {{baseInfo.demo}}</div>
                    <!-- 仓库开始为空，选择商品后进行判定，如果子公司仓库足够显示仓库，如果子公司仓库不足，显示为总仓库 -->
                    <div class="text item">仓库: {{baseInfo.demo}}</div>
                    <div class="text item">订单星级: {{baseInfo.demo}}</div>
                </div>
            </el-card>
            <!-- 客户信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>客户信息:</span></div>
                <div class="main clearfix">
                    <div class="text form-item">
                        <el-form ref="form" :model="customer" label-width="120px">
                            <el-form-item required label="公司名称:">
                                <el-select @clear="clearCompany" @change="selcetedCom" clearable v-model="customer.searchId" filterable :filter-method="searchCompany" placeholder="请搜索并选择公司">
                                    <el-option v-for="ktem in searchComList" :key="ktem.userId" :label="ktem.company" :value="ktem.userId">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text form-item">
                        <el-form ref="form" :model="customer" label-width="120px">
                            <el-form-item required label="联系人:">
                                <el-input disabled placeholder="联系人" v-model="customer.trueName"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text form-item">
                        <el-form  ref="form" :model="customer" label-width="120px">
                            <el-form-item required label="联系方式:">
                                <el-input disabled placeholder="联系方式" v-model="customer.telPhone"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text form-item">
                        <el-form  ref="form" :model="customer" label-width="120px">
                            <el-form-item required label="公司地址:">
                                <el-cascader disabled placeholder="" :options="cityList" :props="optionProps" v-model="comCodeList"></el-cascader>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text form-item">
                        <el-form  ref="form" :model="customer" label-width="120px">
                            <el-form-item required label="公司详细地址:">
                                <el-input disabled placeholder="公司详细地址" v-model="customer.companyAddressDetail"></el-input>
                            </el-form-item> 
                        </el-form>
                    </div>
                    <div class="text form-item" style="height: 55px;"></div>
                    <div class="text form-item">
                        <el-form  ref="form" :model="customer" label-width="120px">
                            <el-form-item required label="收货地址:">
                                <el-cascader @change="selectUserAddress" placeholder="请选择" :options="cityList" :props="optionProps" v-model="recCodeList"></el-cascader>
                            </el-form-item>
                        </el-form>   
                    </div>
                    <div class="text form-item">
                        <el-form  ref="form" :model="customer" label-width="120px">
                            <el-form-item required label="收货详细地址:">
                                <el-input placeholder="请输入收货详细地址" v-model="customer.userAddressDetail"></el-input>
                            </el-form-item> 
                        </el-form>   
                    </div>
                    <div class="text form-item" style="height: 55px;"></div>
                    <div class="text item">
                        <el-form  ref="form" :model="customer" label-width="120px">
                            <el-form-item required label="客户咨询日期:">
                                <el-date-picker value-format="timestamp" v-model="customer.time" type="date" placeholder=""></el-date-picker>
                            </el-form-item> 
                        </el-form>   
                    </div>
                    <div class="text form-item">
                        <el-form  ref="form" :model="customer" label-width="120px">
                            <el-form-item label="备注:">
                                <el-input type="textarea" autosize placeholder="" v-model="customer.remark"></el-input>
                            </el-form-item> 
                        </el-form>   
                    </div>
                </div>
            </el-card>
            <!-- 财务信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>财务信息:</span></div>
                <div class="main clearfix">
                    <div class="text form-item">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item required label="发票类型:">
                                <el-select v-model="financial.invioceType" filterable placeholder="请选择">
                                    <el-option v-for="(item, index) in invoiceList" :key="index" :label="item.name" :value="item.value"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text form-item">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item required label="付款方式:">
                                <!-- * 10 => 货到付款 11 => 款到发货 12 => 物流代收，13=>现金，14=>预付定金 -->
                                <el-select v-model="financial.payMethod" filterable placeholder="请选择">
                                    <el-option label="款到发货" :value="11"></el-option>
                                    <el-option label="货到付款" :value="10"></el-option>
                                    <!-- <el-option label="预付定金" :value="14"></el-option> -->
                                    <el-option label="现金" :value="13"></el-option>
                                    <el-option label="物流代收" :value="12"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text form-item" v-if="financial.payMethod == 14">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item required label="付款次数:">
                                <el-select v-model="financial.number" filterable placeholder="请选择">
                                    <el-option label="2" :value="2"></el-option>
                                    <el-option label="3" :value="3"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text form-item" v-if="financial.payMethod == 14">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item required label="预付定金金额:">
                                <el-input v-model="financial.demo"></el-input>
                            </el-form-item> 
                        </el-form>
                    </div>
                    <div class="text form-item" v-if="financial.payMethod == 14">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item required label="第二次付款金额:">
                                <el-input v-model="financial.demo"></el-input>
                            </el-form-item> 
                        </el-form>
                    </div>
                    <div class="text form-item" v-if="financial.payMethod == 14">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item required label="第二次付款时间:">
                                <el-date-picker v-model="financial.time" type="date" placeholder="选择日期"></el-date-picker>
                            </el-form-item> 
                        </el-form>
                    </div>
                    <!-- <div class="text form-item">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item required label="开票日期:">
                                <el-date-picker v-model="financial.time" type="date" placeholder="选择日期"></el-date-picker>
                            </el-form-item> 
                        </el-form>
                    </div> -->
                    <div class="text form-item">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item label="金额合计:">
                                <el-input disabled v-model="financial.demo"></el-input>
                            </el-form-item> 
                        </el-form>
                    </div>
                    <div class="text form-item">
                        <el-form ref="form" :model="financial" label-width="130px">
                            <el-form-item label="已到账金额:">
                                <el-input disabled v-model="financial.demo"></el-input>
                            </el-form-item> 
                        </el-form>
                    </div>
                </div>
                <!-- <div class="footer">
                    <el-button type="primary">上传附件</el-button>
                </div> -->
            </el-card>
            <!--货品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>货品信息:</span>
                    <el-button  @click="showAdd = true" style="margin-left: 20px;" round plain size="mini" type="primary">新增商品</el-button>
                    <span style="float: right;">订单总金额: {{totalPrice}}元</span>
                </div>
                <el-table :data="list" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                        <template slot-scope="scope">
                            <slot v-if="item.key !== 'opreate'" :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                            <slot v-else :name="item.key" :row="scope.row">
                                <el-button  @click="del(scope.row)" type="danger" size="mini">删除</el-button>
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
                <!-- v-show="auth.add" -->
            </el-card>
        </div>  
        <!-- 新增商品 -->
        <el-dialog title="新增商品" :visible.sync="showAdd" @open="open" top="12vh" width="600px">
            <el-form class="el-form-add" ref="form" :model="goods" label-width="150px">
                <el-form-item label="请输入搜索商品名称">
                    <el-select @clear="clearGoods" @change="selcetedGoods" clearable v-model="searchId" filterable :filter-method="searchGoods" placeholder="请搜索并选择产品">
                        <el-option v-for="ktem in searchGoodsList" :key="ktem.id" :label="(ktem.brandNname ? ktem.brandNname : '') + ktem.name + ktem.model" :value="ktem.id">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item required label="请输入商品数量">
                    <el-input v-model="goods.num"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <div class="el-line-add"></div>
                <el-button class="el-button-add" type="primary" @click="addGoods()">确认</el-button>
                <el-button class="el-button-add" @click="close">取消</el-button>
            </div>
        </el-dialog>
        <!-- btn -->
        <div class="footer-btn">
            <el-button class="button-edit">取消</el-button>
            <el-button @click="createOrder" class="button-edit" type="primary">确定</el-button>
        </div> 
    </Page>
</template>

<script>
    import {formatTime, Calc} from "../../../../js/util";  
    import cityList from "../../../../js/city";  
    import img_blank from '../../../../assets/head.png';
    const url = {
        add: Http.master.addAuth,
        getUserInfoByCompany: Http.inst.getUserInfoByCompany,
        searchGoodsList: Http.common.searchGoodsList,
        createPreOrder: Http.inst.createPreOrder
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },              
                auth: {
                    add: true
                },
                url: url,
                cityList: cityList,                
                // 指定option
                optionProps: {
                    value: 'i',
                    label: 'n',
                    children: 'l'
                },
                // 公司地址
                comCodeList: [],
                // 收货地址
                recCodeList: [],
                baseInfo: {
                    demo: '上海分公司',
                    // 申请时间
                    applyTime: '',
                    applyName: '',
                    applyImg: '',
                    // 一级通过审批时间
                    firstPassTime: '',
                    salesDirector: '',
                    salesDirectorImg: '',
                    // 二级通过审批时间
                    secondPassTime: '',
                    salesLeader: '',
                    salesLeaderImg: '',
                    // 确认时间
                    confirmTime: '',
                    confirmName: '',
                    confirmImg: '',
                    // 订单状态 1发起申请（一级待审批） 2 一级审批 驳回  3 一级审批通过（二级待审批） 4二级审批驳回 5二级审批通过(等待确认)6 财务已确认
                    //  * 1：组长待审，2：组长通过总监待审，3：总监通过，财务待审，4：通过，放入订单表，0：拒绝
                    status: 1
                },
                //客户信息
                customer: {
                    company: '',
                    trueName: '',
                    telPhone: '',
                    companyCityId: '',
                    companyAddressDetail: '',
                    userCityId: '',
                    userAddressDetail: '',
                    time: '',
                    remark: ''
                },
                // 财务信息
                invoiceList: [
                    {name: '普票', value: 1},
                    {name: '增票', value: 2},
                ],
                financial: {
                    demo: '',
                    remark: '',
                    invioceType: '',
                    payMethod: '',
                    number: '',
                },
                // 货品信息
                columns: [
                    {
                        title: '商品ID',
                        key: 'id',
                    },
                    {
                        title: '商品名称',
                        key: 'name',
                    },
                    // {
                    //     title: '适用机型',
                    //     key: 'models',
                    // },
                    {
                        title: '规格型号',
                        key: 'model',
                    },
                    {
                        title: '计量单位',
                        key: 'unit',
                    },
                    {
                        title: '零售价',
                        key: 'price',
                    },
                    {
                        title: '商品数量',
                        key: 'num',
                    },
                    {
                        title: '订单小计',
                        key: 'totalPrice',
                    },
                    {
                        title: '操作',
                        key: 'opreate'
                    }
                ],
                list: [],
                totalPrice: 0,
                // 添加商品相关
                showAdd: false,
                searchId: '',
                searchGoodsName: '',
                searchGoodsList: [],
                goods: {},
                // 客户搜索结果
                searchComList: [],
                searchName: '',
            }
        },
        methods: {
            createOrder () {
                if (!this.customer.searchId) {
                    Sun.showError('请填写客户信息');
                    return;
                }
                if (!this.financial.invioceType) {
                    Sun.showError('请选择发票类型');
                    return;
                }
                if (!this.financial.payMethod) {
                    Sun.showError('请选择付款方式');
                    return;
                }
                if (!this.list.length) {
                    Sun.showError('请添加商品');
                    return;
                }
                let goodsList = [];
                this.list.forEach(ele => {
                    goodsList.push({
                        goodsId: ele.id,
                        num: ele.num
                    })
                });
                Sun.post({
                    url: this.url.createPreOrder,
                    data: {
                        goodsList: goodsList,
                        //user
                        userId: this.customer.searchId,
                        telPhone: this.customer.telPhone,
                        trueName: this.customer.trueName,
                        userAddressDetail: this.customer.userAddressDetail,
                        userAddress: this.customer.userAddress,
                        userCityId: this.customer.userCityId,
                        //财务
                        invioceType: this.financial.invioceType,
                        payMethod: this.financial.payMethod
                    },
                    success: () => {
                        Sun.showMsg('成功添加一个订单');
                        Sun.closePage();
                        Sun.push('/inst/visitAndOrder/orderRecord/orderRecord');
                    }
                });
            },
            // 确认添加一个商品
            addGoods () {   
                if (!this.goods.id) {
                    Sun.showError('请选择商品!');
                    return;
                }
                if (!this.goods.num) {
                    Sun.showError('请设置商品数量!');
                    return;
                }
                this.showAdd = false;
                this.goods.totalPrice = Calc.Mul(this.goods.num, this.goods.price);
                this.list.push(this.goods);
                this.calcTotalPrice(this.list);
            },
            calcTotalPrice (list) {
                if (list.length) {
                    let res = 0;
                    list.forEach(ele => {
                        let item = Calc.Mul(ele.num, ele.price);
                        res = Calc.Add(res, item);
                    });
                    this.totalPrice = res;
                } else {
                    this.totalPrice = 0;
                }
            },
            del (item) {
                if (this.list.length) {
                    this.list.forEach((ele, index) => {
                        if (item.id == ele.id) {
                            this.list.splice(index, 1);
                        }
                    })
                }
                this.calcTotalPrice(this.list);
            },
            // 搜索公司
            searchCompany (val) {
                this.searchGoodsName = val;
                this.searchComList = [];
                Sun.post({
                    url: this.url.getUserInfoByCompany,
                    data: {company: this.searchGoodsName},
                    loading: true,
                    success: (data) => {
                        this.searchComList = data;
                        this.searchGoodsName = '';
                    }
                });
            },
            // 选中一个公司
            selcetedCom () {
                this.searchComList.forEach(ele => {
                    if (this.customer.searchId == ele.userId) {
                        this.customer.company = ele.company;
                        this.customer.trueName = ele.trueName;
                        this.customer.telPhone = ele.telPhone; 
                        // 
                        this.customer.companyCityId = ele.companyCityId;
                        this.customer.companyAddressDetail = ele.companyAddressDetail;
                        this.customer.userCityId = ele.userCityId;
                        this.customer.userAddressDetail = ele.userAddressDetail;
                        this.customer.userAddress = ele.userAddress;
                        // 
                        this.comCodeList = this.formatCity(ele.companyCityId);
                        this.recCodeList = this.formatCity(ele.userCityId);
                    }
                })
            },
            selectUserAddress () {
                this.customer.userCityId = this.recCodeList[this.recCodeList.length - 1];
                this.customer.userAddress = this.parseAddress(this.recCodeList);
            },
            parseAddress (idList) {
                let address = '';
                this.cityList.forEach((item) => {
                   if (item.i == idList[0]) {
                       address += item.n;
                       if (item.l) {
                            item.l.forEach((jtem) => {
                                if (jtem.i == idList[1]) {
                                    address += jtem.n;
                                    if (jtem.l) {
                                        jtem.l.forEach((ktem) => {
                                            if (ktem.i == idList[2]) {
                                                address += ktem.n;
                                            }
                                        });
                                    }
                                }
                            });
                       }
                   }
                });
                return address;
            },
            // 清除选中公司 信息
            clearCompany () {
                this.customer.searchId = '';
                this.customer.company = '';
                this.customer.trueName = '';
                this.customer.telPhone = '';
                this.customer.companyCityId = '';
                this.customer.companyAddressDetail = '';
                this.customer.userCityId = '';
                this.customer.userAddressDetail = '';
                //
                this.comCodeList = [];
                this.recCodeList = [];
            },
            // 搜索商品
            searchGoods (val) {
                this.searchName = val;
                this.searchGoodsList = [];
                Sun.post({
                    url: this.url.searchGoodsList,
                    data: {name: this.searchName},
                    loading: true,
                    success: (data) => {
                        this.searchGoodsList = data;
                        this.searchName = '';
                    }
                });
            },
            // 选中一个商品
            selcetedGoods () {
                this.searchGoodsList.forEach(ele => {
                    if (this.searchId == ele.id) {
                        this.goods = ele;
                    }
                })
                this.goods.num = '';
            },
            // 清除选中商品 
            clearGoods () {
                // this.goodsList[index].searchId = '';
            },
            formatCity (id) {
                let idList = [];
                this.cityList.forEach((item) => {
                    if (item.l) {
                        item.l.forEach((jtem) => {
                            if (jtem.l) {
                                jtem.l.forEach((ktem) => {
                                    if (ktem.i == id) {
                                        idList = [item.i, jtem.i, ktem.i];
                                    }
                                });
                            } else {
                                if (jtem.i == id) idList = [item.i, jtem.i, ''];
                            }
                        });
                    } else {
                        if (item.i == id) idList = [item.i, '', ''];
                    }
                });
                return idList;
            },
            open () {
                this.goods = {};
                this.searchId = '';
                this.searchGoodsName = '';
                this.searchGoodsList = [];
            },
            close () {
                this.showAdd = false;
                this.goods = {};
            },
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 进度条 状态
            formatType(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return 0;
                    case 2: return 2;
                    case 3: return 2;
                    case 4: return 3;
                    case 5: return 3;
                    case 6: return 6;
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
        .form-item {
            width: 33.33%;
            float: left;
        }    
        .dialog-footer {
        clear: both;
        height: 30px;
        }
        .el-line-add {
            width: 100%;
            height: 1px;
            background-color: #dedede;
        }
        .el-form-add {
            max-height: 400px !important;
            overflow: scroll
        }
        .el-button-add {
            float: right;
            margin-right: 10px;
            margin-top: 10px;
        }
    }
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
