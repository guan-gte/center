<template>
    <Page>
        <div class="all">
            <!-- 订单信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>订单信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">订单编号: {{onlineOrderDetail.orderNo}}</div>
                    <div class="text item">订单状态: {{onlineOrderDetail.status | formatOrderStatus}}</div>
                    <div class="text item">订单星级: {{onlineOrderDetail.demo}}</div>
                    <div class="text item">下单时间: {{onlineOrderDetail.createTime | formatTime}}</div>
                    <div class="text item">支付时间: {{onlineOrderDetail.payTime | formatTime}}</div>
                    <div class="text item">出库时间: {{onlineOrderDetail.demo}}</div>
                    <div class="text item">打包人员: {{onlineOrderDetail.demo}}</div>
                    <div class="text item">出库单号: {{onlineOrderDetail.demo}}</div>
                    <div class="text item">发货时间: {{onlineOrderDetail.demo}}</div>
                    <div class="text item">发货人: {{onlineOrderDetail.transName}}</div>
                    <div class="text item">签收时间: {{onlineOrderDetail.demo}}</div>
                </div>
                <el-form ref="form" :model="customer" label-width="45px">
                    <el-form-item label="备注:">
                        <el-input disabled type="textarea" autosize placeholder="请输入内容" v-model="customer.remark"></el-input>
                    </el-form-item>
                </el-form>
            </el-card>
            <!-- 收货信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>收货信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">收货人姓名: {{address.demo}}</div>
                    <div class="text item">收货人电话: {{address.demo}}</div>
                    <div class="text item">收货人地址: {{address.demo}}</div>
                </div>
                <div class="footer">
                    <el-button type="primary">查看物流</el-button>
                </div>
            </el-card>
            <!--货品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>订单总金额: {{totalPrice}}元</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>实际支付金额: {{payTotalPrice}}元</span>
                </div>
                <el-table :data="list" border height="300px" style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" 
                                        v-for="(item, index) in columns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
            <!-- 客户信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>客户信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">客户昵称: {{customer.demo}}</div>
                    <div class="text item">客户ID: {{customer.demo}}</div>
                    <div class="text item">客户账号: {{customer.demo}}</div>
                    <div class="text item">联系方式: {{customer.demo}}</div>
                </div>
            </el-card>
            <!-- 发票信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>发票信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">{{invoice.demo}}</div>
                </div>
            </el-card>
        </div>  
    </Page>
</template>

<script>    
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                orderDetail: {
                    demo: '上海分公司'
                },
                documents: {
                    demo: '上海分公司'
                },
                customer: {
                    demo: '上海分公司'
                },
                address: {
                    demo: '上海分公司',
                    remark: ''
                },
                invoice: {
                    demo: '上海分公司'
                },
                columns: [
                    {
                        title: '商品ID',
                        key: 'trueName',
                    },
                    {
                        title: '商品名称',
                        key: 'trueName',
                    },
                    {
                        title: '商品零售价',
                        key: 'trueName',
                    },
                    {
                        title: '商品数量',
                        key: 'trueName',
                    },
                    {
                        title: '订单小计',
                        key: 'total',
                    },
                ],
                list: [],
                totalPrice: 0,
                payTotalPrice: 0,
                onlineOrderDetail: {}
            }
        },
        created () {
            if (Sun.temp.onlineOrderDetail) {
                this.onlineOrderDetail = Sun.temp.onlineOrderDetail;
            } else {
                Sun.showError('订单信息不存在');
                Sun.closePage();
                Sun.push('/inst/visitAndOrder/orderRecord/orderRecord');
            }
        },
        methods: {
            
        },
        filters: {
            formatOrderStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未支付';
                    case 1: return '已支付(待发货)';
                    case 2: return '已取消';
                    case 3: return '已关闭';
                    case 4: return '待收货';
                    case 5: return '已收货';
                    case 6: return '已完成';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
    }
</style>
