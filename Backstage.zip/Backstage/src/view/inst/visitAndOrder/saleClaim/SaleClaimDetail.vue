<template>
    <Page>
        <div class="all">        
            <!-- 状态 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>审批状态: {{baseInfo.status | famateStatus}}</span></div>
                <el-steps class="order-status" finish-status="success" :active="baseInfo.status | formatType" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.applyName}}</p></div></div>
                            <p class="status-desc">{{baseInfo.status == 1 ? '发起申请' : '发起申请'}}</p>
                            <p class="status-time" v-if="baseInfo.applyTime">{{baseInfo.applyTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="一级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesDirectorImg ? baseInfo.salesDirectorImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">职位</p><p class="name">{{baseInfo.salesDirector}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 2 ? 'dinger-color' : ': #303133'">
                                {{baseInfo.status == 3 ? '审批通过' : (baseInfo.status == 2 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.firstPassTime"
                                :class="baseInfo.status == 2 ? 'dinger-color' : ''">
                                {{baseInfo.firstPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                </el-steps>
                <p v-if="baseInfo.status ==  2">驳回原因: {{baseInfo.reason}}</p>
            </el-card>
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>基本信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">客户名称: {{baseInfo.demo}}</div>
                    <div class="text item">进入公海时间: {{baseInfo.demo}}</div>
                    <div class="text item">发起申请时间: {{baseInfo.demo}}</div>
                    <div class="text item">审批人: {{baseInfo.demo}}</div>
                </div>
            </el-card>
        </div>  
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    import img_blank from '../../../../assets/head.png';
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },
                baseInfo: {
                    demo: '上海分公司',
                    // 申请时间
                    applyTime: 1560734591,
                    applyName: '张三',
                    applyImg: '',
                    // 审批
                    firstPassTime: 1560734591,
                    salesDirector: '李四',
                    salesDirectorImg: '',
                    // 订单状态 1发起申请（待审批） 2 审批驳回  3 审批通过
                    status: 2,
                    reason: '太丑'
                }
            }
        },
        methods: {
            
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 进度条 状态
            formatType(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return 1;
                    case 2: return 2;
                    case 3: return 2;
                }
            },
            famateStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return '待审批';
                    case 2: return '审批驳回';
                    case 3: return '审批通过';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
    }
</style>
