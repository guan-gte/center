<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.master.getAdminPage,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    query: true
                },
                userId: '',
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '发起人',
                                key: 'name',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '发起时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '审批状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待审批', value: '1'},
                                        {name: '审批通过', value: '2'},
                                        {name: '审批驳回', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '待审批', value: '= 1'},
                                    {text: '审批通过', value: '= 2'},
                                    {text: '审批驳回', value: '= 3'}
                                ]
                            },
                            {
                                title: '二级审批状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待审批', value: '1'},
                                        {name: '审批通过', value: '2'},
                                        {name: '审批驳回', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '待审批', value: '= 1'},
                                    {text: '审批通过', value: '= 2'},
                                    {text: '审批驳回', value: '= 3'}
                                ]
                            },
                            {
                                title: '三级审批状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待审批', value: '1'},
                                        {name: '审批通过', value: '2'},
                                        {name: '审批驳回', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '待审批', value: '= 1'},
                                    {text: '审批通过', value: '= 2'},
                                    {text: '审批驳回', value: '= 3'}
                                ]
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query (item) {
                Sun.push('/inst/visitAndOrder/refundExamByDirector/examDetail');
            }
        },
        filters: {
            formatStatus(status) {
                 if (status == 1) {
                    return '待审批';
                } else if (status == 2) {
                    return '审批通过';
                } else if (status == 3) {
                    return '审批驳回';
                } else {
                    return '/';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
