<template>
    <el-dialog title="驳回原因" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="100px">          
            <el-form-item required label="驳回原因：">
                <el-input type="textarea" :autosize="{ minRows: 10, maxRows: 15}" placeholder="请输入内容" v-model="form.remark"></el-input>
            </el-form-item>  
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                form: {}
            }
        },
        methods: {
            open () {
                this.form = {};
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            submit() {
                if (!this.form.remark) {
                    Sun.showError('请输入驳回原因!');
                    return;
                }
                // Sun.post({
                //     url: this.url.add,
                //     data: this.remark,
                //     success: () => {
                //         if (this.callBack) {
                //             this.callBack(true);
                //         }
                //     }
                // });
            }
        },
        props: ['url', 'show', 'callBack'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
