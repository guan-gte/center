<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showSearch = true" type="primary">新增回访记录</el-button>
            <div slot="status" slot-scope="data">{{data.row.status | formatSatStatus}}</div>
            <div slot="intention" slot-scope="data">{{data.row.intention | formatIntStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatDay}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
        <!--searchUser-->
        <SearchMyUser @getUserId="getUserId" :url="url" :show="showSearch" :userId="userId"
                       :callBack="(flag)=>{showSearch = false;}"></SearchMyUser>
        <!--add-->
        <VisitRecordAdd :url="url" :show="showAdd" :userId="userId"
                       :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></VisitRecordAdd>
    </Page>
</template>

<script>
    import {formatDay} from "../../../../js/util";
    import VisitRecordAdd from './VisitRecordAdd';
    import SearchMyUser from './SearchMyUser';
    const url = {
        table: Http.inst.getUserVistPage,
        add: Http.inst.addVisit,
        searchMyUser: Http.inst.searchMyUser,      
        getGoodsListByType: Http.inst.getGoodsListByType,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        components: {VisitRecordAdd, SearchMyUser},
        data() {
            return {
                url: url,
                auth: {
                    add: true,
                    query: true
                },
                showAdd: false,
                showSearch: false,
                userId: '',
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '回访编号',
                                key: 'id',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '客户账号',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '客户姓名',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '联系方式',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品满意度',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '不满意', value: '0'},
                                        {name: '满意', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '不满意', value: '= 0'},
                                    {text: '满意', value: '= 1'}
                                ]
                            },
                            {
                                title: '继续购买意向',
                                key: 'intention',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '无', value: '0'},
                                        {name: '有', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '无', value: '= 0'},
                                    {text: '有', value: '= 1'}
                                ]
                            },
                            {
                                title: '回访时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '下次回访时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '售后回访时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query () {
            },
            getUserId (getUserId) {
                this.userId = getUserId;
                if (this.userId) {
                    this.showAdd = true;
                }
            }
        },
        filters: {
            formatSatStatus(status) {
                if (status == 0) {
                    return '满意'
                }
                if (status == 1) {
                    return '不满意'
                }
            },
            formatIntStatus(status) {
                if (status == 0) {
                    return '无'
                }
                if (status == 1) {
                    return '有'
                }
            },
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
