<template>
    <el-dialog title="搜索用户" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <el-form class="el-form-add" ref="form" :model="form" label-width="120px">
            <el-form-item label="客户电话">
                <el-input placeholder="输入电话搜索客户" v-model="form.telPhone"></el-input>
            </el-form-item> 
            <el-form-item label="客户注册电话">
                <el-input placeholder="输入电话搜索客户" v-model="form.regPhone"></el-input>
            </el-form-item> 
            <el-form-item v-if="!user && doSearch" label="">
                <p style="color: #F56C6C;text-align: center;">无搜索结果~</p>
            </el-form-item> 
            <el-form-item v-if="user" label="客户名称">
                <el-input disabled v-model="user.trueName"></el-input>
            </el-form-item> 
            <el-form-item style="text-align: center;">
                <el-button @click="searchUser" type="primary" round plain size="mini" icon="el-icon-search">搜索</el-button>
            </el-form-item> 
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" type="primary" @click="submit()">提交</el-button>
            <el-button class="el-button-add" @click="close">取消</el-button>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        data() {
            return {
                form: {},
                user: null,
                doSearch: false
            }
        },
        methods: {
            open () {
                this.form = {};
                this.user = null;
                this.doSearch = false;
            },
            close () {
                if (this.callBack) {
                    this.callBack(false);
                }
            },
            searchUser () {
                if (!this.form.telPhone && !this.form.regPhone) {
                    Sun.showError('请输入搜索项');
                    return;
                }
                Sun.post({
                    url: this.url.searchMyUser,
                    data: {
                        telPhone: this.form.telPhone,
                        regPhone: this.form.regPhone
                    },
                    success: (data) => {
                        this.doSearch = true;
                        data ? this.user = data : this.user = null;
                    }
                })
            },
            submit() {
                if (!this.user) {
                    Sun.showError('请先选择客户');
                    return;
                }
                this.$emit('getUserId', this.user.userId);
                if (this.callBack) {
                    this.callBack(true);
                }
            }
        },
        props: ['url', 'show', 'callBack', 'userId'],
    }
</script>

<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
