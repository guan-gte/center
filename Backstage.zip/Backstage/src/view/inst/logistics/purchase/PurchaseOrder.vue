<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="addPurchase" type="primary">发起采购订单</el-button>
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>
            <div slot="sendStatus" slot-scope="data">{{data.row.sendStatus | formatSendStatus}}</div>
            <div slot="storeInStatus" slot-scope="data">{{data.row.storeInStatus | formatStoreInStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.master.getAdminPage,
        add: Http.master.editAuth,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    add: true,
                    query: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '采购编号',
                                key: 'trueName'
                            },             
                            {
                                title: '商品ID',
                                key: 'trueName'
                            },             
                            {
                                title: '商品名称',
                                key: 'trueName'
                            },             
                            {
                                title: '发起时间',
                                key: 'createTime',
                                sortable: true
                            },  
                            {
                                title: '订单状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '待确认', value: '0'},
                                        {name: '已确认', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '待确认', value: '= 0'},
                                    {text: '已确认', value: '= 1'}
                                ]
                            },             
                            {
                                title: '发货状态',
                                key: 'sendStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未发货', value: '0'},
                                        {name: '已发货', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '未发货', value: '= 0'},
                                    {text: '已发货', value: '= 1'}
                                ]
                            },  
                            {
                                title: '入库状态',
                                key: 'storeInStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未入库', value: '0'},
                                        {name: '已入库', value: '1'},
                                        {name: '入库未完', value: '2'}
                                    ]
                                },
                                filter:[
                                    {text: '未入库', value: '= 0'},
                                    {text: '已入库', value: '= 1'},
                                    {text: '入库未完', value: '= 2'}
                                ]
                            },  
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
        },
        methods: {
            // 添加采购订单
            addPurchase () {
                Sun.push('/inst/logistics/store/purchaseOrderAdd');
            },
            query () {
                Sun.push('/inst/logistics/purchase/purchaseDetail');
            }
        },
        filters: {
            formatStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '待确认';
                    case 1: return '已确认';
                    default: return '/';
                }
            },
            formatSendStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未发货';
                    case 1: return '已发货';
                    default: return '/';
                }
            },
            formatStoreInStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未入库';
                    case 1: return '已入库';
                    case 1: return '入库未完';
                    default: return '/';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
