<template>
    <Page>
        <div class="all">        
            <!-- 采购订单状态状态 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>采购订单状态1:</span></div>
                <el-steps class="order-status" finish-status="success" :active="baseInfo.status | formatType" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.applyName}}</p></div></div>
                            <p class="status-desc">发起申请</p>
                            <p class="status-time" v-if="baseInfo.applyTime">{{baseInfo.applyTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.supplyChainImg ? baseInfo.supplyChainImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">职位</p><p class="name">{{baseInfo.supplyChain}}</p></div></div>
                            <p class="status-desc">{{baseInfo.status > 1 ? '已确认' : '等待确认'}}</p>
                            <p class="status-time" v-if="baseInfo.firstPassTime">{{baseInfo.firstPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="发货">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="img.imgBlank" alt="">
                            </div>
                            <p class="status-desc">{{baseInfo.status == 3 ? '发货' : ''}}</p>
                        </div>
                    </el-step>
                </el-steps>
            </el-card>
            <!-- 采购商品信息 -->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in goodsList" :key="index">
                <div slot="header">
                    <span class="header-title">采购产品{{++index}}:</span>
                </div>
                <div class="main clearfix">
                    <div class="text item">产品ID：{{item.demo}}</div>
                    <div class="text item">产品名称：{{item.demo}}</div>
                    <div class="text item">产品类型：{{item.demo}}</div>
                    <div class="text item">产品型号：{{item.demo}}</div>
                    <div class="text item">产品货号：{{item.demo}}</div>
                    <div class="text item">供应商：{{item.demo}}</div>
                    <div class="text item">品牌：{{item.demo}}</div>
                    <div class="text item">计量单位：{{item.demo}}</div>
                    <div class="text item">进货价：{{item.demo}}</div>
                    <div class="text item">原价：{{item.demo}}</div>
                    <div class="text item">销售价：{{item.demo}}</div>
                    <div class="text item">调度比例：{{item.demo}}</div>
                    <div class="text item">当前库存数量：{{item.demo}}</div>
                    <div class="text item">采购数量：{{item.demo}}</div>
                    <!-- 到货数量小于采购数量,字体异色 -->
                    <div class="text item" :style="item.demo < item.demo ? 'color: #F56C6C;' : ''" 
                            v-if="baseInfo.status > 3">实际到货数量：{{item.demo}}</div>
                    <div class="text item" v-if="item.demo < item.demo">请联系商家续发该产品</div>
                    <div class="text item">总价：{{item.totalPrice}}元</div>    
                </div> 
            </el-card>
            <!-- 快递单号 v-if="baseInfo.status > 2 && baseInfo.transSn"-->
            <el-card  class="box-card" shadow="hover">
                <div class="main clearfix">
                    <div class="text item" style="margin: 0;">快递单号：{{baseInfo.transSn ? baseInfo.transSn : '未填写'}}</div>
                    <!--  -->
                    <div v-if="baseInfo.status == 2" class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="130px">
                            <el-form-item required label="请输入接受数量:">
                                <el-input type="text" placeholder="请输入接受数量" v-model="form.num"></el-input>
                            </el-form-item> 
                        </el-form>  
                    </div>
                    <!-- 接受数量 -->
                    <div v-if="baseInfo.status > 2"  class="text item" style="margin: 0;">接受数量：{{baseInfo.demo}}</div>
                    <div class="text item" style="height: 20px;"></div>
                    <!-- 补发快递单号 -->
                    <div v-if="baseInfo.status == 4" class="text item" style="margin: 0;height: 33px;line-height: 33px;">补发快递单号：{{baseInfo.demo ? baseInfo.demo : '未填写'}}</div>
                    <div v-if="baseInfo.status == 4" class="text item" style="margin: 0;">
                        <el-form  ref="form" :model="form" label-width="125px">
                            <el-form-item required label="请输入接受数量:">
                                <el-input type="text" placeholder="请输入接受数量" v-model="form.numAgain"></el-input>
                            </el-form-item> 
                        </el-form>  
                    </div>
                </div>
            </el-card>  
        </div>          
        <div v-show="auth.edit && baseInfo.status == 1" class="footer-btn">
            <el-button class="button-edit">取消</el-button>
            <el-button class="button-edit" @click="submit" type="primary">确认</el-button>
        </div>  
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    import img_blank from '../../../../assets/head.png';
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },
                auth: {
                    edit: true
                },
                form: {
                    numAgain: '',
                    num: ''
                },
                baseInfo: {
                    demo: '上海分公司',
                    purchaseSn: 'SH331231',
                    storeInSn: 'DJ7777777',
                    // 申请时间
                    applyTime: 1560734591,
                    applyName: '张三',
                    applyImg: '',
                    // 一级通过审批时间
                    firstPassTime: '',
                    supplyChain: '李四',
                    supplyChainImg: '',
                    // 订单状态 1待确认2 已确认 未入库  3 已确认 已入库 4 已确认 入库未完
                    status: 3,
                    transSn: ''
                },
                // 采购商品信息
                goodsList: [
                    {demo: '商品详情', totalPrice: 4563, receiveNum: '', addNum: ''}
                ],
            }
        },
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        methods: {
            // 发起申请
            submit () {

            },
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 进度条 状态
            formatType(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return 1;
                    case 2: return 2;
                    case 3: return 2;
                    case 4: return 2;
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
    }
    .footer-btn {
        text-align: center;
        margin-top: 20px;
    }
</style>
