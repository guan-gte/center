<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>           
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    const url = {
        table: Http.master.getAdminPage,
        edit: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url, 
                auth: {
                    edit: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '商品ID',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },             
                            {
                                title: '商品名称',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },             
                            {
                                title: '适用机型',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },             
                            {
                                title: '规格型号',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },                 
                            {
                                title: '进货价',
                                key: 'createTime',
                                sortable: true
                            },            
                            {
                                title: '调度费比例',
                                key: 'createTime',
                                sortable: true
                            }, 
                            {
                                title: '零售价',
                                key: 'createTime',
                                sortable: true
                            },  
                            {
                                title: '仓库数量',
                                key: 'createTime',
                                sortable: true
                            },  
                            {
                                title: '总公司仓库数量',
                                key: 'createTime',
                                sortable: true
                            },  
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        methods: {
            // 编辑
            edit () {
                Sun.push('/inst/logistics/store/storeGoodsEdit');
            }
        }
    }
</script>

<style scoped>

</style>
