<template>
    <Page>
        <div class="all">        
            <!-- 采购订单状态状态 -->
            <el-card class="box-card" shadow="hover">
                <el-steps class="order-status" finish-status="success" :active="0" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                                <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.applyName}}</p></div>
                            </div>
                            <p class="status-desc">发起申请</p>
                        </div>
                    </el-step>
                    <el-step title="审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.supplyChainImg ? baseInfo.supplyChainImg : img.imgBlank" alt="">
                                <div class="user-info"><p class="position">职位</p><p class="name">{{baseInfo.supplyChain}}</p></div>
                            </div>
                        </div>
                    </el-step>
                    <el-step title="发货">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="img.imgBlank" alt="">
                            </div>
                        </div>
                    </el-step>
                </el-steps>
                <div class="main clearfix">
                    <div style="margin: 20px 0 0 0;" class="text item">采购订单编号: {{baseInfo.purchaseSn}}</div>
                </div>
            </el-card>
            <!-- 采购商品信息 -->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in goodsList" :key="index">
                <div slot="header">
                    <span class="header-title">采购产品{{goodsList.length}}:</span>
                </div>
                <div class="main clearfix">
                    <!-- 搜索产品 -->
                    <div style="margin: 0;" class="text item">
                        <el-form label-position="left" ref="form" :model="item" label-width="140px">
                            <el-form-item required label="请输入搜索产品ID:">
                                <el-select clearable v-model="searchId" filterable placeholder="请搜索并选择产品">
                                    <el-option v-for="ktem in options" :key="ktem.value" :label="ktem.label" :value="ktem.value">
                                    </el-option>
                                </el-select>
                            </el-form-item> 
                        </el-form>  
                    </div>
                    <div style="margin: 0;" class="text item">
                         <el-form label-position="left" ref="form" :model="item" label-width="160px">
                            <el-form-item required label="请输入搜索产品名称:">
                                <el-select clearable v-model="searchName" filterable placeholder="请搜索并选择产品">
                                    <el-option v-for="ktem in options" :key="ktem.value" :label="ktem.label" :value="ktem.value">
                                    </el-option>
                                </el-select>
                            </el-form-item> 
                        </el-form> 
                    </div>
                    <div style="margin: 0;" class="text item">
                         <el-form label-position="left" ref="form" :model="item" label-width="130px">
                            <el-form-item required label="请输入采购数量:">
                                <el-input v-model="item.addNum"></el-input>
                            </el-form-item> 
                        </el-form> 
                    </div>
                    <!-- 商品详情 -->
                    <div class="text item">产品类型：{{item.type}}</div>
                    <div class="text item">产品型号：{{item.sku}}</div>
                    <div class="text item">产品货号：{{item.no}}</div>
                    <div class="text item">供应商：{{item.supply}}</div>
                    <div class="text item">品牌：{{item.brand}}</div>
                    <div class="text item">计量单位：{{item.unit}}</div>
                    <div class="text item">进货价：{{item.inPrice}}</div>
                    <div class="text item">原价：{{item.price}}</div>
                    <div class="text item">销售价：{{item.salePrice}}</div>
                    <div class="text item">调度比例：{{item.rate}}</div>
                    <div class="text item">当前库存数量：{{item.stock}}</div>
                    <div class="text item">总仓库存数量：{{item.totalStock}}</div>
                    <!-- 总价为输入数量后自动用进货价X数量,需要计算调度比例 -->
                    <div class="text item">总价：{{item.totalPrice ? item.totalPrice + '元' : ''}}</div>    
                    <div class="text item">
                        <el-form class="el-form-add" ref="form" :model="supply" label-width="40px">
                            <el-form-item label="类型">
                                <el-select v-model="supply.type" filterable placeholder="请选择是否指定供应商">
                                    <el-option label="否" :value="0"></el-option>
                                    <el-option label="是" :value="1"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>    
                    <div v-show="supply.type" class="text item">供应商名称：{{item.supply}}</div> 
                </div>     
                <div class="item-footer-btn">
                    <span>请输入采购数量：</span>
                    <el-input v-model="item.addNum" style="width: 200px;" placeholder="请输入采购数量"></el-input>
                    <!-- 当点击确认数量按钮后，与总仓库数量进行对比，如果数量充足不做任何变化。如果数量不足，产生是否指定供应商判定。如重新改变数量，则需要重新确认 -->
                    <el-button type="primary" plain round size="mini" @click="confirm(item, index)">确认数量</el-button>
                </div> 
            </el-card>   
        </div>          
        <div v-show="auth.edit" class="footer-btn">
            <el-button class="button-edit">取消</el-button>
            <el-button class="button-edit" @click="submit" type="primary">确认采购</el-button>
        </div>  
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    import img_blank from '../../../../assets/head.png';
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },
                auth: {
                    edit: true
                },
                // 搜索结果
                options: [],
                searchId: '',
                searchName: '',
                // 
                baseInfo: {
                    demo: '上海分公司',
                    purchaseSn: 'SH331231',
                    // 申请时间
                    applyTime: 1560734591,
                    applyName: '张三',
                    applyImg: '',
                    // 一级通过审批时间
                    firstPassTime: '',
                    supplyChain: '李四',
                    supplyChainImg: '',
                    // 仓管
                    confirmTime: '',
                    confirmName: '周六',
                    confirmImg: '',
                    transSn: '1221'
                },
                // 采购商品信息
                goodsList: [
                    {
                        id: '',
                        name: '',
                        type: '',
                        sku: '',
                        no: '',
                        supply: '',
                        brand: '',
                        unit: '',
                        inPrice: '',
                        price: '',
                        salePrice: '',
                        rate: '',
                        stock: '',
                        totalStock: '',
                        totalPrice: '',
                        addNum: ''
                    }
                ],
                supply: {
                    type: 0
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        methods: {
            // 确认数量
            confirm () {

            },
            // 确认采购
            submit () {

            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                    padding-right: 20px;
                    box-sizing: border-box;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
    }
    .item-footer-btn {
        text-align: right;
        // text-align: center;
        margin-top: 20px;
    }
    .footer-btn {
        // text-align: right;
        text-align: center;
        margin-top: 20px;
    }
</style>
