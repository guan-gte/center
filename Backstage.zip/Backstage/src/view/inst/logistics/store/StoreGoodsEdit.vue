<template>
    <Page>
        <div class="all">        
            <!-- 库存信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>库存信息:</span>
                    <el-button v-show="auth.add" style="float: right;" round plain size="mini" type="primary" @click="add">采购该商品</el-button>
                </div>
                <div class="main clearfix">
                    <div class="text item">仓库库存数量: {{detail.demo}}</div>
                    <div class="text item">总仓库库存数量: {{detail.demo}}</div>
                    <div class="text item">
                        <el-form ref="form" :model="detail" label-width="130px">
                            <el-form-item label="库存警报值:">
                                <el-input v-model="detail.demo"></el-input>
                            </el-form-item> 
                        </el-form>
                    </div>
                </div>
            </el-card>
            <!-- 产品基础信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>产品基础信息:</span></div>
                <div class="main clearfix">
                    <div class="text item"></div>
                </div>
            </el-card>
        </div> 
        <!-- btn -->
        <div class="footer-btn">
            <el-button class="button-edit">取消</el-button>
            <el-button class="button-edit" type="primary">确定</el-button>
        </div> 
    </Page>
</template>

<script>
    const url = {
        add: Http.master.addAuth,
        edit: Http.master.addAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {             
                auth: {
                    add: true,
                    edit: true
                },
                url: url,
                detail: {
                    demo: 123
                }
            }
        },        
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        methods: {
            add () {
                Sun.push('/inst/logistics/store/purchaseOrderAdd');
            }
        },
        filters: {   
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
    }    
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
