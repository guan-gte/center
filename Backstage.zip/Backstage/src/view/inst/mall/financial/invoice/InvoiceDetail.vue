<template>
    <Page>
        <div class="all">
            <!-- 发票信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>发票信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">发票类型: <span style="color: #32CD32;">{{invoiceDetail.invoiceUser.type | formatType}}</span></div>
                    <div class="text item" v-if="invoiceDetail.invoiceUser.transType == 2">企业名称: {{invoiceDetail.status}}</div>
                    <div class="text item" v-if="invoiceDetail.invoiceUser.transType == 2">纳税人识别码: {{invoiceDetail.demo}}</div>
                </div>
            </el-card>
            <!-- 收货信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>收货信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">收货人: {{invoiceDetail.invoiceAddress.name}}</div>
                    <div class="text item">联系方式: {{invoiceDetail.invoiceAddress.phone}}</div>
                    <div class="text item">收货地址: {{invoiceDetail.invoiceAddress.address}}{{invoiceDetail.invoiceAddress.detail}}</div>
                </div>
            </el-card>
            <!--商品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header">商品信息:</div>
                <el-table :data="invoiceDetail.goodsList" border :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" 
                                        v-for="(item, index) in columns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
            <!--发货-->
            <el-card v-if="invoiceDetail.invoiceUser.openType == 1" class="box-card" shadow="hover">
                <div slot="header"><span>填写发货信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                             <el-form-item required label="填写发票编号">
                                <el-input placeholder="请填写发票编号" v-model="delivery.invoiceNo"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                     <div class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                            <!-- <el-form-item required label="选择物流公司">
                                <el-select v-model="delivery.transName" filterable placeholder="请选择">
                                    <el-option v-for="(item, index) in transList" :key="index" :label="item.name"
                                            :value="item.id"></el-option>
                                </el-select>
                            </el-form-item> -->
                            <el-form-item required label="填写物流公司">
                                <el-input placeholder="请填写物流公司" v-model="delivery.transName"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                             <el-form-item required label="填写物流编号">
                                <el-input placeholder="请填写物流编号" v-model="delivery.transNo"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                </div>
            </el-card> 
            <!-- 发货信息 -->
            <el-card v-else class="box-card" shadow="hover">
                <div slot="header"><span>发货信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">发货方式: {{invoiceDetail.invoiceUser.transType == 1 ? '快递物流' : '/'}}</div>
                    <div v-show="invoiceDetail.invoiceUser.transType == 1" class="text item">快递公司: {{invoiceDetail.invoiceUser.transName}}</div>
                    <div v-show="invoiceDetail.invoiceUser.transType == 1" class="text item">快递编号: {{invoiceDetail.invoiceUser.transNo}}</div>
                </div>
                <div  class="footer">
                    <el-button @click="transDetail" type="primary" plain round>查看物流</el-button>
                </div>
            </el-card>    
        </div>   
        <div class="footer">
            <el-button class="button-edit" @click="back" type="primary" plain>返回</el-button>
            <el-button :loading="loading" class="button-edit" @click="submit" type="primary">确定</el-button>
        </div> 
    </Page>
</template>

<script>   
    const url = {
        // 开票详情
        getInvoiceInfo: Http.inst.getInvoiceInfo,
        // 填写物流信息
        updateInvoiceTrans: Http.inst.updateInvoiceTrans
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                loading: false,
                url: url,
                // query
                invoiceId: '',
                address: {
                    demo: '上海分公司',
                    remark: ''
                },
                columns: [
                    {
                        title: '商品名称',
                        key: 'goodsName',
                    },
                    {
                        title: '商品数量',
                        key: 'num',
                    },
                    {
                        title: '商品单价',
                        key: 'totalMoney',
                    }
                ],
                list: [],
                invoiceDetail: {
                    goodsList: [],
                    invoiceUser: {},
                    invoiceAddress: {}
                },
                // 发货
                transList: [],
                delivery: {
                    invoiceNo: '',
                    deliverType: 1,
                    transName: '',
                    transNo: ''
                },
            }
        },
        created () {
            this.invoiceId = Sun.getQuery('invoiceId');
            if (this.invoiceId) {
                this.getInvoice(this.invoiceId);
            } else {
                Sun.showError('发票信息不存在');
                Sun.closePage();
                Sun.push('/inst/mall/financial/invoice/invoiceApply');
            }
        },
        methods: {
            getInvoice (invoiceId) {
                Sun.post({
                    url: this.url.getInvoiceInfo,
                    data: {
                        invoiceId: invoiceId
                    },
                    loading: true,
                    success: (data) => {
                        this.invoiceDetail = data;
                    }
                })
            },
            // 更新发货
            submit () {
                let postData = this.parseData(this.delivery);
                if (!postData.invoiceNo) {
                    Sun.showError('请填写发票编号');
                    return;
                } 
                if (!postData.transName) {
                    Sun.showError('请填写物流公司');
                    return;
                } 
                if (!postData.transNo) {
                    Sun.showError('请填写物流单号');
                    return;
                } 
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                Sun.post({
                    url: this.url.updateInvoiceTrans,
                    loading: true,
                    data: postData,
                    success: (data) => {
                        Sun.showMsg('物流信息填写成功');
                        this.getInvoice(this.invoiceId);
                    }
                })
            },
            parseData (data) {
                let postData = {};
                postData.invoiceId = this.invoiceDetail.invoiceUser.invoiceId;
                postData.transType = data.deliverType;
                postData.invoiceNo = data.invoiceNo;
                postData.transNo = data.transNo;
                postData.transName = data.transName;
                return postData;
            },
            // 物流查询 
            transDetail () {
                if (this.invoiceDetail.invoiceUser.transType == 1) {
                    window.open(`https://www.kuaidi100.com/chaxun?nu=${this.invoiceDetail.invoiceUser.transNo}`, '_blank'); 
                } else {
                    Sun.showMsg('暂无物流信息');
                }
            },
            back () {
                Sun.closePage();
                Sun.push('/inst/mall/financial/invoice/invoiceApply');
            },
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },
        filters: {
            formatType(type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '个人发票';
                    case 2: return '企业发票';
                    case 3: return '增值税发票';
                }
            },
            formatOrderStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未支付';
                    case 1: return '已支付(待发货)';
                    case 2: return '已取消';
                    case 3: return '已关闭';
                    case 4: return '待收货';
                    case 5: return '已收货';
                    case 6: return '已完成';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
    }
    .footer {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }
    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
