<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatDay}}</div>
            <div slot="openType" slot-scope="data">
                 <span :style="{color: data.row.openType == 1 ? '#F56C6C' : '#32CD32'}">{{data.row.openType | formatType}}</span>
            </div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>    
    const url = {
        table: Http.inst.getInvoiceListPage,
        query: Http.inst.getInvoiceInfo
    };
    import {formatDay} from "../../../../../js/util";
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    query: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '发票申请编号',
                                key: 'invoiceId'
                            },
                            {
                                title: '申请时间',
                                key: 'createTime',
                                // sortable: true
                            },
                            {
                                title: '金额',
                                key: 'money',
                                // sortable: true
                            },
                            {
                                title: '邮寄状态',
                                key: 'openType',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: [
                                //         {name: '未邮寄', value: '1'},
                                //         {name: '已邮寄', value: '2'}
                                //     ]
                                // },
                                // filter:[
                                //     {text: '未邮寄', value: '= 1'},
                                //     {text: '已邮寄', value: '= 2'}
                                // ]
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query (item) {
                // console.log(item);
                Sun.push('/inst/mall/financial/invoice/invoiceDetail', {invoiceId: item.invoiceId, openType: item.openType});
            }
        },
        filters: {
            formatType(type) {
                type = parseInt(type);
                switch (type) {
                    case 1: return '未邮寄';
                    case 2: return '已邮寄';
                }
            },
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '/';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
