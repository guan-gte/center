<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="needPayMoney" slot-scope="data">{{data.row.needPayMoney}}元</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="type" slot-scope="data">
                <span :style="{color: data.row.type == 1 ? '#32CD32' : '#E49348'}">{{data.row.type == 1 ? '线上订单' : '线下订单'}}</span>
            </div>
            <div slot="status" slot-scope="data">{{data.row.status | formatOrderStatus}}</div>
            <div slot="payStatus" slot-scope="data">{{data.row.payStatus | formatPayStatus}}</div>
            <div slot="payMethod" slot-scope="data">{{data.row.payMethod | formatPayMethod}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>    
    const url = {
        table: Http.inst.getOrderListPage
    };
    import {formatTime} from "../../../../js/util";
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    query: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '订单编号',
                                key: 'orderNo',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '订单类型',
                                key: 'type',
                                // search:{
                                //     type: 'select',
                                //     symbol: '=',
                                //     list: [
                                //         {name: '线上订单', value: '1'},
                                //         {name: '线下订单', value: '2'}
                                //     ]
                                // },
                                // filter:[
                                //     {text: '线上订单', value: '= 1'},
                                //     {text: '线下订单', value: '= 2'}
                                // ]
                            },              
                            {
                                title: '用户昵称',
                                key: 'nickName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '联系方式',
                                key: 'phone',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '下单时间',
                                key: 'createTime'
                            },
                            // payStatus=1代表支付完成了，status=1代表订单待发货。如果是线上流程两个是等价的，如果是线下的可能payStatus=0但是status=1
                            {
                                title: '订单状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未支付', value: '0'},
                                        {name: '已支付(待发货)', value: '1'},
                                        {name: '已取消', value: '2'},
                                        {name: '已关闭', value: '3'},
                                        {name: '待收货', value: '4'},
                                        {name: '已收货', value: '5'},
                                        {name: '已完成', value: '6'},
                                        {name: '售后中', value: '7'},
                                        {name: '退款中', value: '8'},
                                        {name: '退款完成', value: '9'},
                                    ]
                                },
                                filter:[
                                    {text: '未支付', value: '= 0'},
                                    {text: '已支付(待发货)', value: '= 1'},
                                    {text: '已取消', value: '= 2'},
                                    {text: '已关闭', value: '= 3'},
                                    {text: '待收货', value: '= 4'},
                                    {text: '已收货', value: '= 5'},
                                    {text: '已完成', value: '= 6'},
                                    {text: '售后中', value: '= 7'},
                                    {text: '退款中', value: '= 8'},
                                    {text: '退款完成', value: '= 9'},
                                ]
                            },
                            // 支付状态显示 如果status=0且payStatus=0未支付。status=1，payStatus=0则显示pay/needPay
                            {
                                title: '支付状态',
                                key: 'payStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未支付', value: '0'},
                                        {name: '已支付', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '未支付', value: '= 0'},
                                    {text: '已支付', value: '= 1'}
                                ]
                            },
                            {
                                title: '支付方式',
                                key: 'payMethod',
                                // filter:[
                                //     {text: '支付宝app', value: '= 1'},
                                //     {text: '支付宝web', value: '= 2'},
                                //     {text: '微信app', value: '= 3'},
                                //     {text: '微信web', value: '= 4'},
                                //     {text: '微信公众号', value: '= 5'},
                                //     {text: '微信小程序', value: '= 6'},
                                //     {text: '货到付款', value: '= 10'},
                                //     {text: '款到发货', value: '= 11'},
                                //     {text: '物流代收', value: '= 12'},
                                //     {text: '现金', value: '= 13'},
                                //     {text: '预付定金', value: '= 14'},
                                // ]
                            },
                            {
                                title: '订单金额',
                                key: 'needPayMoney',
                                sortable: true
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query (item) {
                Sun.push('/inst/mall/order/orderDetail', {orderNo: item.orderNo});
            }
        },
        filters: {
            formatType(type) {
                if (type == 1) {
                    return '线上订单'
                }
                if (type == 2) {
                    return '线下订单'
                }
            },
            formatOrderStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未支付';
                    case 1: return '已支付(待发货)';
                    case 2: return '已取消';
                    case 3: return '已关闭';
                    case 4: return '待收货';
                    case 5: return '已收货';
                    case 6: return '已完成';
                    case 7: return '售后中';
                    case 8: return '退款中';
                    case 9: return '退款完成';
                }
            },
            formatPayStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未支付';
                    case 1: return '已支付';
                }
            },
            formatPayMethod(payMethod) {
                payMethod = parseInt(payMethod);
                switch (payMethod) {
                    case 1: return '支付宝app';
                    case 2: return '支付宝web';
                    case 3: return '微信app';
                    case 4: return '微信web';
                    case 5: return '微信公众号';
                    case 6: return '微信小程序';
                    case 10: return '货到付款';
                    case 11: return '款到发货';
                    case 12: return '物流代收';
                    case 13: return '现金';
                    case 14: return '预付定金';
                    default: return '/';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
