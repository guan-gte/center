<template>
    <Page>
        <div class="all">
            <!-- 订单信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>订单信息:</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span style="color: #67C23A;">订单{{order.status | formatOrderStatus}}</span>
                    <el-button v-if="order.status == 7" style="float: right;" @click="completeAfter" type="primary" size="mini" plain round>售后完成</el-button>
                    <el-button v-if="order.status == 8" style="float: right;margin-right: 10px;" @click="completeRefund" type="primary" size="mini" plain round>退款完成</el-button>
                </div>
                <div class="main clearfix">
                    <div class="text item">订单编号: {{order.orderNo}}</div>
                    <div class="text item">下单时间: {{order.createTime | formatTime}}</div>
                    <div class="text item">支付时间: {{order.payTime | formatTime}}</div>
                    <div class="text item">支付方式: {{order.payMethod | formatPayMethod}}</div>
                    <div class="text item">发货时间: {{order.transTime | formatTime}}</div>
                </div>
            </el-card>
            <!--商品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>商品信息:</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>订单总金额: {{order.totalMoney}}元</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>实际支付金额: {{order.payMoney}}元</span>
                </div>
                <el-table :data="order.goodsList" border  style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" 
                                    :label="item.title" v-for="(item, index) in columns" :key="index">
                        <template slot-scope="scope">
                            <slot v-if="item.key == 'model'" :name="item.key" :row="scope.row">
                                {{scope.row[item.key] ? scope.row[item.key] : '/'}}
                            </slot>
                            <slot v-else :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
            <!-- 收货信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>收货信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">收货人姓名: {{order.address.name}}</div>
                    <div class="text item">收货人电话: {{order.address.phone}}</div>
                    <div class="text item">收货人地址: {{order.address.address}}{{order.address.detail}}</div>
                </div>
            </el-card>
            <!--发货-->
            <el-card v-if="order.status == 1" class="box-card" shadow="hover">
                <div slot="header"><span>填写发货信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="150px">
                            <el-form-item required label="选择订单发货方式">
                                <el-select v-model="delivery.deliverType" filterable placeholder="请选择">
                                    <el-option label="快递物流" :value="1"></el-option>
                                    <el-option label="公司承运" :value="2"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                     <div v-if="delivery.deliverType == 1" class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                            <!-- <el-form-item required label="选择物流公司">
                                <el-select v-model="delivery.transName" filterable placeholder="请选择">
                                    <el-option v-for="(item, index) in transList" :key="index" :label="item.name"
                                            :value="item.id"></el-option>
                                </el-select>
                            </el-form-item> -->
                            <el-form-item required label="填写物流公司">
                                <el-input v-model="delivery.transName"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div v-else class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                            <el-form-item required label="填写承运人姓名">
                                <el-input v-model="delivery.dirver"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div v-if="delivery.deliverType == 1" class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                             <el-form-item required label="填写物流编号">
                                <el-input v-model="delivery.transNo"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <!-- 选择司机后自动获取联系方式，可以更改，必填 -->
                    <div v-else class="text item">       
                        <el-form class="el-form-add" ref="delivery" :model="delivery" label-width="130px">
                        <el-form-item required label="联系方式">
                            <el-input v-model="delivery.phone"></el-input>
                        </el-form-item>
                        </el-form>
                    </div>
                </div>
            </el-card> 
            <!-- 发货信息 -->
            <el-card  v-if="order.status > 3" class="box-card" shadow="hover">
                <div slot="header"><span>发货信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">发货方式: {{order.transType == 1 ? '快递物流' : '公司承运'}}</div>
                    <div v-show="order.transType == 1" class="text item">快递公司: {{order.transName}}</div>
                    <div v-show="order.transType == 1" class="text item">快递编号: {{order.transNo}}</div>
                    <div v-show="order.transType == 2" class="text item">承运人: {{order.transName}}</div>
                    <div v-show="order.transType == 2" class="text item">联系方式: {{order.transNo}}</div>
                </div>
                <div v-if="order.status > 3" class="footer">
                    <el-button @click="transDetail" type="primary" plain round>查看物流</el-button>
                </div>
            </el-card>       
        </div>  
        <div class="footer">
            <el-button class="button-edit" @click="back" type="primary" plain>返回</el-button>
            <el-button :loading="loading"  v-if="order.status == 1" class="button-edit" @click="submit" type="primary">确定</el-button>
        </div>  
    </Page>
</template>

<script>    
    import {formatTime, getTime} from "../../../../js/util";
    const url = {
        // 用户订单详情
        getOrderInfoByOrderNo: Http.inst.getOrderInfoByOrderNo,
        // 填入物流信息
        updateTransTime: Http.inst.updateTransTime,
        // 订单 完成 售后/退款
        updateAfterStatus: Http.inst.updateAfterStatus
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                loading: false,
                url: url,
                // param
                orderNo: '',
                // goodsList
                columns: [
                    {
                        title: '商品ID',
                        key: 'goodsId',
                    },
                    {
                        title: '商品名称',
                        key: 'name',
                    },
                    {
                        title: '型号',
                        key: 'model',
                    },
                    {
                        title: '商品价格',
                        key: 'price',
                    },
                    {
                        title: '购买数量',
                        key: 'num',
                    }
                ],
                // orderDetail
                order: {
                    address: {},
                    goodsList: []
                },
                // trans
                deliveryInfo: {
                    demo: '韵达'
                },
                // 发货
                transList: [],
                delivery: {
                    deliverType: '',
                    transName: '',
                    transNo: '',
                    dirver: '',
                    phone: '' 
                },
            }
        },
        created () {
            let orderNo = Sun.getQuery('orderNo');
            if (orderNo) {
                this.orderNo = orderNo;
                this.getOrder(this.orderNo);
            } else {
                Sun.showError('订单信息不存在');
                Sun.closePage();
            }
        },
        methods: {
            // 订单详情
            getOrder (orderNo) {
                Sun.post({
                    url: this.url.getOrderInfoByOrderNo,
                    loading: true,
                    data: {
                        orderNo: orderNo
                    },
                    success: (data) => {
                        this.order = data;
                    }
                })
            },
            // 更新发货
            submit () {
                let postData = this.parseData(this.delivery);
                if (!postData.transType) {
                    Sun.showError('请选择发货方式');
                    return;
                } 
                if (postData.transType == 1 && !postData.transName) {
                    Sun.showError('请填写物流公司');
                    return;
                } 
                if (postData.transType == 1 && !postData.transNo) {
                    Sun.showError('请填写物流单号');
                    return;
                } 
                if (postData.transType == 2 && !postData.transName) {
                    Sun.showError('请填写承运人');
                    return;
                } 
                if (postData.transType == 2 && !postData.transNo) {
                    Sun.showError('请填写承运人联系方式');
                    return;
                } 
                this.loading = true;
                setTimeout(() =>{
                    this.loading = false
                },1000)
                Sun.post({
                    url: this.url.updateTransTime,
                    loading: true,
                    data: postData,
                    success: (data) => {
                        Sun.showMsg('物流信息填写成功');
                        this.getOrder(this.orderNo);
                    }
                })
            },
            parseData (data) {
                let postData = {};
                postData.orderNo = this.order.orderNo;
                postData.transType = data.deliverType;
                if (this.delivery.deliverType == 1) {
                    postData.transNo = data.transNo;
                    postData.transName = data.transName;
                } else if (this.delivery.deliverType == 2) {
                    postData.transNo = data.phone;
                    postData.transName = data.dirver;
                }
                return postData;
            },
            // 物流查询 
            transDetail () {
                if (this.order.transType == 1) {
                    window.open(`https://www.kuaidi100.com/chaxun?nu=${this.order.transNo}`, '_blank'); 
                } else if (this.order.transType == 2) {
                    Sun.showMsg('公司承运，请拨打承运人联系方式');
                } else {
                    Sun.showMsg('暂无物流信息');
                }
            },
            back () {
                Sun.closePage();
                Sun.push('/inst/mall/order/order');
            },
            completeAfter () {
                Sun.confirm('温馨提示', '确定要完成售后吗', () => {
                    Sun.post({
                        url: this.url.updateAfterStatus,
                        loading: true,
                        data: {
                            status: Static.orderStatus.orderStatus_complete,
                            orderNo: this.order.orderNo,
                            userId: this.order.userId
                        },
                        success: (data) => {
                            Sun.showMsg('已确认');
                            this.order.status = Static.orderStatus.orderStatus_complete;
                        }
                    })
                });
            },
            completeRefund () {
                Sun.confirm('温馨提示', '确定要完成退款吗', () => {
                    Sun.post({
                        url: this.url.updateAfterStatus,
                        loading: true,
                        data: {
                            status: Static.orderStatus.orderStatus_refunded,
                            orderNo: this.order.orderNo,
                            userId: this.order.userId
                        },
                        success: (data) => {
                            Sun.showMsg('已确认');
                            this.order.status = Static.orderStatus.orderStatus_refunded;
                        }
                    })
                });
            }
        },
        filters: {
            formatOrderStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未支付';
                    case 1: return '已支付(待发货)';
                    case 2: return '已取消';
                    case 3: return '已关闭';
                    case 4: return '待收货';
                    case 5: return '已收货';
                    case 6: return '已完成';
                    case 7: return '售后中';
                    case 8: return '退款中';
                    case 9: return '退款完成';
                }
            }, 
            formatPayMethod(payMethod) {
                payMethod = parseInt(payMethod);
                switch (payMethod) {
                    case 1: return '支付宝app';
                    case 2: return '支付宝web';
                    case 3: return '微信app';
                    case 4: return '微信web';
                    case 5: return '微信公众号';
                    case 6: return '微信小程序';
                    case 10: return '货到付款';
                    case 11: return '款到发货';
                    case 12: return '物流代收';
                    case 13: return '现金';
                    case 14: return '预付定金';
                    default: return '/';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '暂无';
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
    }    
    .footer {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
