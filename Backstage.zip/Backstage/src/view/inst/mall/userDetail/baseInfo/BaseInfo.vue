
<template>
    <Page>
        <!-- 基本信息 -->
        <ul class="clearfix">
            <li>用户ID: {{user.id}}</li>
            <li>手机号: {{user.phone}}</li>
            <li>昵称: {{user.nickName}}</li>
            <li>注册时间: {{user.createTime | formatTime}}</li>
        </ul>
        <!-- 地址 -->
        <el-table :data="userAddressList" border style="width: 100%;">
            <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                <template slot-scope="scope">
                    <slot v-if="item.key == 'isDefault'" :name="item.key" :row="scope.row">
                        {{scope.row[item.key] ? '默认' : '/'}}
                    </slot>
                    <slot v-else :name="item.key" :row="scope.row">
                        {{scope.row[item.key]}}
                    </slot>
                </template>
            </el-table-column>
        </el-table>
        <div class="footer">
            <el-button class="button-edit" @click="back" type="primary">返回</el-button>
        </div>        
    </Page>
</template>

<script>
    import {formatTime} from "../../../../../js/util";
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                user: {},
                columns: [
                    {
                        title: '收货人',
                        key: 'name',
                    },
                    {
                        title: '电话',
                        key: 'phone',
                    },
                    {
                        title: '收货地址',
                        key: 'address',
                    },
                    {
                        title: '详细地址',
                        key: 'detail',
                    },
                    {
                        title: '是否默认',
                        key: 'isDefault',
                    }
                ],
                userAddressList: []
            }
        },
        created () {
            this.getCustomerInfo(this.url.getUserInfoByUserId);
        },
        methods: {
            // 获取用户信息
            getCustomerInfo (query) {
                Sun.post({
                    url: query,
                    data: {userId: this.userId},
                    success: (data) => {
                        this.user = data;
                        this.userAddressList = data.userAddressList;
                    }
                });
            },
            back () {
                Sun.closePage();
                Sun.push('/inst/mall/user/user');
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            formatValue(value) {
                if (value) {
                    return value;
                } else {
                    return '暂无';
                }
            },
        },
        props: ['url', 'userId']
    }
</script>

<style lang="less" scoped>
    @import url('../../../../../assets/css/config.less');
    ul {
        width: 100%;    
        li {
            width: 50%;
            float: left;
            color: @black;
            margin-bottom: 20px;
            .cell {
                margin: 20px 0;
            }
            .cell:last-child {
                margin-bottom: 0;
            }
        }
        li:last-child {
            margin-bottom: 40px;
        }
    }
    .footer {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>

