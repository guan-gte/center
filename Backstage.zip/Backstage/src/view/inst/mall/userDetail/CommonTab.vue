<template>
    <Page>
        <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
            <el-tab-pane label="基本信息" name="0">
                <BaseInfo :url="url" :userId="userId" v-if="activeName == 0"></BaseInfo>
            </el-tab-pane>
            <el-tab-pane label="用户订单" name="1">
                <OrderInfo :url="url" :userId="userId" v-if="activeName == 1"></OrderInfo>
            </el-tab-pane>
        </el-tabs>
    </Page>
</template>

<script>
    import BaseInfo from './baseInfo/BaseInfo';
    import OrderInfo from './orderInfo/OrderInfo';
    const url = {
        // 用户信息
        getUserInfoByUserId: Http.inst.getUserInfoByUserId,
        // 用户订单
        getOrderListByUserId: Http.inst.getOrderListByUserId
    };
    export default {
        extends: Sun.vuePage,
        components: {
            BaseInfo,
            OrderInfo
        },
        data() {
            return {
                url: url,
                activeName: '0',
                userId: ''
            }
        },
        created () {
            let userId = Sun.getQuery('userId');
            if (userId) {
                this.userId = userId;
            } else {
                // TODO
            }
        },
        methods: {
            handleClick(tab, event) {
                // console.log(tab, event);
            }
        },
        filters: {
        }
    }
</script>

<style scoped>

</style>
