<template>
    <Page>
        <div class="all">
            <div class="head">
                <el-date-picker v-model="month" type="month" placeholder="选择月份"></el-date-picker>  
            </div>    
            <el-table :data="list" border  :summary-method="getSummaries" show-summary style="width: 100%;">
                <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                    <template slot-scope="scope">
                        <slot :name="item.key" :row="scope.row">
                            {{scope.row[item.key]}}
                        </slot>
                    </template>
                </el-table-column>
                <el-table-column align="center" label="操作" width="100">
                    <template slot-scope="scope">
                        <el-button @click="query(scope.row)" type="text" size="small">查看</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>   
    </Page>
</template>

<script> 
    const url = {
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    query: true
                },
                showQuery: false,
                month: '',
                columns: [
                    {
                        title: '小组名称',
                        key: 'trueName',
                    },
                    {
                        title: '销售组长',
                        key: 'trueName',
                    },
                    {
                        title: '组员人数',
                        key: 'trueName',
                    },
                    {
                        title: '销售目标',
                        key: 'trueName',
                    },
                    {
                        title: '已经完成',
                        key: 'trueName',
                    },
                    {
                        title: '完成比例',
                        key: 'trueName',
                    }
                ],
                list: [{trueName: 12}]
            }
        },      
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query (item) {
                console.log(item);
                Sun.push('/inst/statistics/deployBusiByLeader/deployDetail');
            },
            // 表格总计
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },
        filters: {    
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
       .head {
           width: 100%;
           margin-bottom: 20px;
       }
        
    }  
</style>
