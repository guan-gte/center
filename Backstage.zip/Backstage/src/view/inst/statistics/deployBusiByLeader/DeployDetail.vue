<template>
    <Page>
        <div class="head">
            <el-date-picker v-model="month" type="month" placeholder="选择月份"></el-date-picker>  
        </div>    
        <div class="all">        
            <!-- 审批信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>销售一组:</span>
                    <el-button @click="showEdit = true" style="float: right;" type="primary" size="mini" round plain>重新定义目标</el-button>
                </div>
                <div class="main clearfix">
                    <div class="text item">小组目标: {{examineInfo.demo}}</div>
                    <div class="text item">已经完成订单数额: {{examineInfo.demo}}</div>
                    <div class="text item">完成比例: {{examineInfo.demo}}</div>
                </div>
            </el-card>
        </div>        
        <el-table :data="list" border  :summary-method="getSummaries" show-summary style="width: 100%;">
            <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                <template slot-scope="scope">
                    <slot :name="item.key" :row="scope.row">
                        {{scope.row[item.key]}}
                    </slot>
                </template>
            </el-table-column>
        </el-table>
        <!-- <div class="footer-btn" v-show="auth.edit && isConfirm">
            <el-button class="button-edit"  type="primary" @click="submit">{{examineInfo.payType == 1 ? '再次收款' : '确认收款'}}</el-button>
        </div>     -->
        <!-- -->
        <ResetGoal :url="url" :show="showEdit"
                    :callBack="(flag)=>{showEdit = false;if (flag) init()}"></ResetGoal> 
    </Page>
</template>

<script>
    import ResetGoal from './ResetGoal';
    import {formatTime} from "../../../../js/util";  
    const url = {
        edit: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        components: {ResetGoal},
        data() {
            return {
                url: url,
                auth: {
                    edit: true
                },
                showEdit: false,
                month: '',
                // 审批详情
                examineInfo: {
                    demo: '上海分公司'
                },
                columns: [
                    {
                        title: '姓名',
                        key: 'trueName',
                    },
                    {
                        title: '职位',
                        key: 'trueName',
                    },
                    {
                        title: '订单数量',
                        key: 'trueName',
                    },
                    {
                        title: '目标金额',
                        key: 'trueName',
                    },
                    {
                        title: '已经完成',
                        key: 'trueName',
                    },
                    {
                        title: '完成率',
                        key: 'trueName',
                    }
                ],
                list: [{trueName: 12}]
            }
        },      
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        methods: {
            init () {
                console.log('init');
            },
            // 表格总计
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },
        filters: {
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
    } 
    .head {
        width: 100%;
        margin-bottom: 20px;
    }
</style>
