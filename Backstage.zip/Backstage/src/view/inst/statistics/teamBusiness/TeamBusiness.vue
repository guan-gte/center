<template>
    <Page>
        <schart class="schart" canvasId="pie" :data="schartTotal" type="pie" :options="optionsTotal"></schart>
    </Page>
</template>

<script>
    import bus from '../../../../common/bus';
    import Schart from 'vue-schart';
    export default {
        extends: Sun.vuePage,        
        components: {
            Schart
        },
        data() {
            return {
                total: [
                    {name: '订单总数', num: 0},
                    {name: '已完成订单', num: 0},
                    {name: '销售总额', num: 0},
                    {name: '客户总数', num: 0}
                ],
                schartTotal : [
                    {name:'本月未完成数额', value: 30},
                    {name:'本月完成数额', value: 70}
                ],
                optionsTotal: {
                    bgColor: '#ffffff',   
                    title: '',                 
                    titleColor: '#000000',         
                    titlePosition: 'top',          
                    legendColor: '#000000',         
                    legendTop: 40,                 
                    colorList: ['#FF4949', '#1E9FFF'],   
                    radius: 40,                    
                }
            }
        },
        computed: {
        },
        created(){ 
        },
        activated(){
        },
        created () {
        },
        deactivated(){
        },
        methods: {
        }
    }

</script>


<style scoped>
    .title-desc {
        width: 100%;
        padding: 0 0 10px 0;
        box-sizing: border-box;
        color: #303133;
        font-size: 14px;
    }
    .total {
        margin-bottom: 40px;
    }
    .content-title {
        width: 100%;
    }
    .grid-content {
        display: flex;
        align-items: center;
        height: 100px;
    }

    .grid-cont-right {
        flex: 1;
        text-align: center;
        font-size: 14px;
        color: #999;
    }

    .grid-num {
        font-size: 30px;
        font-weight: bold;
    }

    .grid-con-icon {
        font-size: 50px;
        width: 100px;
        height: 100px;
        text-align: center;
        line-height: 100px;
        color: #fff;
    }

    .grid-con-1 .grid-con-icon {
        /* background: rgb(45, 140, 240); */
        background: rgb(100, 213, 114);
        /* background: rgb(242, 94, 67); */
        /* background: #E6A23C; */
    }
    .grid-con-1 .grid-num {
        color: rgb(45, 140, 240);
    }
</style>
