<template>
    <Page>
        <el-row :gutter="20">
            <div class="title-desc">历史汇总：</div>
            <el-col :span="24">
                <el-row :gutter="20" class="total">
                    <el-col :span="6" v-for="(item, index) in total" :key="index">
                        <el-card shadow="hover" :body-style="{padding: '0px'}">
                            <div class="grid-content grid-con-1">
                                <i class="el-icon-tickets grid-con-icon"></i>
                                <div class="grid-cont-right">
                                    <div class="grid-num">{{item.num}}</div>
                                    <div>{{item.name}}</div>
                                </div>
                            </div>
                        </el-card>
                    </el-col>
                </el-row>
            </el-col>
            <div class="title-desc">本月汇总：</div>
            <el-col :span="24">
                <el-row :gutter="20" class="month">
                    <el-col :span="6" v-for="(item, index) in month" :key="index">
                        <el-card shadow="hover" :body-style="{padding: '0px'}">
                            <div class="grid-content grid-con-1">
                                <i class="el-icon-tickets grid-con-icon"></i>
                                <div class="grid-cont-right">
                                    <div class="grid-num">{{item.num}}</div>
                                    <div>{{item.name}}</div>
                                </div>
                            </div>
                        </el-card>
                    </el-col>
                </el-row>
            </el-col>
            <!-- 待处理事务 -->
            <el-col :span="24">
                <el-row :gutter="20" class="mgb20">
                    <el-card shadow="hover" style="height:330px;">
                        <div slot="header" class="clearfix">
                            <span>待处理事务</span>
                        </div>
                        <el-col :span="24">
                            <el-col :span="8">
                                <el-table :data="orderList" :show-header="false" border style="width: 100%;font-size:14px;">
                                    <el-table-column align="center">
                                        <template slot-scope="scope">
                                            <div class="todo-item">{{scope.row.title}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column align="center">
                                        <template slot-scope="scope">
                                            <div class="todo-item">({{scope.row.number}})</div>
                                        </template>
                                    </el-table-column>
                                </el-table>
                            </el-col>
                            <el-col :span="8">
                                <el-table :data="secondList" :show-header="false" border style="width: 100%;font-size:14px;">
                                    <el-table-column align="center">
                                        <template slot-scope="scope">
                                            <div class="todo-item" >{{scope.row.title}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column align="center">
                                        <template slot-scope="scope">
                                            <div class="todo-item">({{scope.row.number}})</div>
                                        </template>
                                    </el-table-column>
                                </el-table>
                            </el-col>
                            <!-- <el-col :span="8">
                                <el-table :data="otherList" :show-header="false" border style="width: 100%;font-size:14px;">
                                    <el-table-column align="center">
                                        <template slot-scope="scope">
                                            <div class="todo-item">{{scope.row.title}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column align="center">
                                        <template slot-scope="scope">
                                            <div class="todo-item">({{scope.row.number}})</div>
                                        </template>
                                    </el-table-column>
                                </el-table>
                            </el-col> -->
                        </el-col>
                    </el-card>
                </el-row>
            </el-col>
        </el-row>
    </Page>
</template>

<script>
    import bus from '../../../../common/bus';
    export default {
        extends: Sun.vuePage,    
        data() {
            return {
                total: [
                    {name: '订单总数', num: 0},
                    {name: '已完成订单', num: 0},
                    {name: '销售总额', num: 0},
                    {name: '客户总数', num: 0}
                ],
                month: [
                    {name: '本月订单总数', num: 0},
                    {name: '已完成订单', num: 0},
                    {name: '销售总额', num: 0},
                    {name: '本月销售目标', num: 0}
                ],
                orderList: [
                    {title: '待付款订单', number: 0},
                    {title: '待发货订单', number: 0},
                    {title: '已发货订单', number: 0},
                    {title: '待结款订单', number: 0},
                    {title: '已完成订单', number: 0}
                ],
                secondList: [
                    {title: '待回访客户', number: 0},
                    {title: '待处理审批', number: 0}
                ],
                otherList: []
            }
        },
        computed: {
        },
        created(){ 
            // this.$set(this.orderList[0],"number", demo);
        },
        activated(){
            this.handleListener();
        },
        created () {
        },
        deactivated(){
            window.removeEventListener('resize', this.renderChart);
            bus.$off('collapse', this.handleBus);
        },
        methods: {
            handleListener(){
                bus.$on('collapse', this.handleBus);
            },
            handleBus(msg){
                setTimeout(() => {
                    this.renderChart()
                }, 300);
            },
            renderChart(){
                this.$refs.bar.renderChart();
                this.$refs.line.renderChart();
            }
        }
    }

</script>


<style scoped>
    .title-desc {
        width: 100%;
        padding: 0 10px 10px 10px;
        box-sizing: border-box;
        color: #303133;
        font-size: 14px;
    }
    .total {
        margin-bottom: 40px;
    }
    .month {
        margin-bottom: 90px;
    }

    .grid-content {
        display: flex;
        align-items: center;
        height: 100px;
    }

    .grid-cont-right {
        flex: 1;
        text-align: center;
        font-size: 14px;
        color: #999;
    }

    .grid-num {
        font-size: 30px;
        font-weight: bold;
    }

    .grid-con-icon {
        font-size: 50px;
        width: 100px;
        height: 100px;
        text-align: center;
        line-height: 100px;
        color: #fff;
    }

    .grid-con-1 .grid-con-icon {
        /* background: rgb(45, 140, 240); */
        background: rgb(100, 213, 114);
        /* background: rgb(242, 94, 67); */
        /* background: #E6A23C; */
    }
    .grid-con-1 .grid-num {
        color: rgb(45, 140, 240);
    }
</style>
