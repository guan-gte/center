<template>
    <Page>
        <div class="all">
            <div class="head">
                <el-date-picker v-model="month" type="month" placeholder="选择月份"></el-date-picker>  
            </div>    
            <el-card class="box-card" shadow="hover">
                <div class="main clearfix">
                    <div class="text item">小组目标: {{examineInfo.demo}}</div>
                    <div class="text item">已经完成目标: {{examineInfo.demo}}</div>
                    <div class="text item">完成率: {{examineInfo.demo}}</div>
                </div>
            </el-card>
            <el-table :data="list" border  style="width: 100%;">
                <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                    <template slot-scope="scope">
                        <slot :name="item.key" :row="scope.row">
                            {{scope.row[item.key]}}
                        </slot>
                    </template>
                </el-table-column>
                <el-table-column align="center" label="操作" width="100">
                    <template slot-scope="scope">
                        <el-button @click="edit(scope.row)" type="text" size="small">编辑</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>           
        <ResetGoal :url="url" :show="showEdit" :data="editData"
                    :callBack="(flag)=>{showEdit = false;if (flag) init()}"></ResetGoal> 
    </Page>
</template>

<script> 
    const url = {
        edit: Http.master.editAuth,
    };
    import ResetGoal from './ResetGoal';
    export default {
        extends: Sun.vuePage,
        components: {ResetGoal},
        data() {
            return {
                url: url,
                auth: {
                    edit: true
                },
                showEdit: false,
                editData: {},
                showQuery: false,
                month: '',                
                examineInfo: {
                    demo: '上海分公司'
                },
                columns: [
                    {
                        title: '姓名',
                        key: 'trueName',
                    },
                    {
                        title: '职位',
                        key: 'trueName',
                    },
                    {
                        title: '订单数量',
                        key: 'trueName',
                    },
                    {
                        title: '目标金额',
                        key: 'trueName',
                    },
                    {
                        title: '已经完成',
                        key: 'trueName',
                    },
                    {
                        title: '完成比例',
                        key: 'trueName',
                    }
                ],
                list: [{trueName: 12}]
            }
        },      
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        methods: {
            edit (item) {
                this.editData = item;
                this.showEdit = true;
            }
        },
        filters: {    
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .head {
            width: 100%;
            margin-bottom: 20px;
        }
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
    }  
</style>
