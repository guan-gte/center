<template>
    <Page>
        <div class="all">        
            <!-- 状态 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>审核状态:</span>
                    <span class="header-span">退款单编号: {{baseInfo.afterSalesNo}}</span>
                    <span class="header-span">发起人: {{baseInfo.startPerson}}</span>
                </div>
                <el-steps class="order-status" finish-status="success" :active="baseInfo.status | formatType" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.applyName}}</p></div></div>
                            <p class="status-desc">{{baseInfo.status == 1 ? '发起申请' : '发起申请'}}</p>
                            <p class="status-time" v-if="baseInfo.applyTime">{{baseInfo.applyTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="一级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesImg ? baseInfo.salesImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">销售经理</p><p class="name">{{baseInfo.sales}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 2 ? 'dinger-color' : ': #303133'">
                                {{baseInfo.status == 3 ? '审批通过' : (baseInfo.status == 2 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.firstPassTime"
                                :class="baseInfo.status == 2 ? 'dinger-color' : ''">
                                {{baseInfo.firstPassTime | formatTime}}</p>
                            <el-button v-if="baseInfo.status == 2" @click="open" round size="mini" type="danger" plain>查看原因</el-button>
                        </div>
                    </el-step>
                    <el-step title="二级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesLeaderImg ? baseInfo.salesLeaderImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">销售组长</p><p class="name">{{baseInfo.salesLeader}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 4 ? 'dinger-color' : ''">
                                {{baseInfo.status == 5 ? '审批通过' : (baseInfo.status == 4 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.secondPassTime"
                                :class="baseInfo.status == 4 ? 'dinger-color' : ''">
                                {{baseInfo.secondPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="三级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesDirectorImg ? baseInfo.salesDirectorImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">销售总监</p><p class="name">{{baseInfo.salesDirector}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 6 ? 'dinger-color' : ''">
                                {{baseInfo.status == 7 ? '审批通过' : (baseInfo.status == 6 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.thirdPassTime"
                                :class="baseInfo.status == 6 ? 'dinger-color' : ''">
                                {{baseInfo.thirdPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="填入单号">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.writePersonImg ? baseInfo.writePersonImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.writePerson}}</p></div></div>
                            <p class="status-desc">
                                {{baseInfo.status > 7 ? '已填写' : '未填写'}}</p>
                            <p class="status-time" v-if="baseInfo.transTime">{{baseInfo.transTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="财务确认">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.confirmImg ? baseInfo.confirmImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">财务</p><p class="name">{{baseInfo.confirmName}}</p></div></div>
                            <p class="status-desc">
                                {{baseInfo.status == 9 ? '已打款' : '等待打款'}}</p>
                            <p class="status-time" v-if="baseInfo.confirmTime">{{baseInfo.confirmTime | formatTime}}</p>
                        </div>
                    </el-step>
                </el-steps>
            </el-card>   
            <!-- 打款信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>打款信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">打款金额: {{customer.demo}}</div>
                    <div class="text item">公司信息: {{customer.demo}}</div>
                    <div class="text item">公司简称: {{customer.demo}}</div>
                    <div class="text item">联系人: {{customer.demo}}</div>
                    <div class="text item">手机号: {{customer.demo}}</div>
                    <div class="text item">退款方式: {{customer.demo}}</div>
                    <div class="text item">银行: {{customer.demo}}</div>
                    <div class="text item">银行账号: {{customer.demo}}</div>
                    <div class="text item">收款人或公司名称: {{customer.demo}}</div>
                </div>
            </el-card>
        </div>  
        <div class="footer-btn">
            <el-button class="button-edit" @click="submit(1)">返回</el-button>
            <el-button v-show="baseInfo.status == 8" class="button-edit"  type="primary" @click="submit(2)">确认已打款</el-button>
        </div>          
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";  
    import img_blank from '../../../../assets/head.png';
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },
                url: url,
                baseInfo: {
                    demo: '上海分公司1',
                    // 申请时间
                    applyTime: 1560734591,
                    applyName: '张三',
                    applyImg: '',
                    // 一级通过审批时间
                    firstPassTime: 1560734591,
                    sales: '汉三',
                    salesImg: '',
                    // 二级通过审批时间
                    secondPassTime: 1560734591,
                    salesDirector: '李四',
                    salesDirectorImg: '',
                    // 三级通过审批时间
                    thirdPassTime: 1560734591,
                    salesLeader: '王五',
                    salesLeaderImg: '',
                    // 填写单号
                    transTime: 1560734591,
                    writePerson: '苏叁',
                    writePersonImg: '',
                    // 确认时间
                    confirmTime: '',
                    confirmName: '周六',
                    confirmImg: '',
                    // 订单状态 1一级待审批 2 一级审批 驳回  3 一级审批通过（二级待审批） 
                    // 4二级审批驳回 5二级审批通过(三级待审批) 6 三级审批驳回 7三级审批通过(等待填写单号) 8单号已填写(等待财务打款) 9 财务已打款 
                    status: 8,
                    // 退款信息
                    afterSalesNo: '',
                    startPerson: ''
                },
                // 打款信息
                customer: {
                    demo: '上海分公司'
                }
            }
        },
        methods: {
            submit (type) {
                if (type == 1) {
                    Sun.closePage();
                    Sun.push('/inst/financial/afterSales/afterSales');
                } else if (type == 2) {
                    Sun.confirm('提示', '确认已打款?', () => {
                        Sun.showMsg('确认成功');
                        Sun.closePage();
                        Sun.push('/inst/financial/afterSales/afterSales');
                    });
                }
            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 进度条 状态
            formatType(status) {
                // 订单状态 1一级待审批 2 一级审批 驳回  3 一级审批通过（二级待审批） 
                // 4二级审批驳回 5二级审批通过(三级待审批) 6 三级审批驳回 7三级审批通过(等待填写单号) 8单号已填写(等待财务打款) 9 财务已打款 
                status = parseInt(status);
                switch (status) {
                    case 1: return 1;
                    case 2: return 1;
                    case 3: return 2;
                    case 4: return 2;
                    case 5: return 3;
                    case 6: return 3;
                    case 7: return 4;
                    case 8: return 5;
                    case 9: return 6;
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
            .header-span {
                margin-right: 40px;
                float: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
    }
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }
    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
