<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="status" slot-scope="data">{{data.row.status | formatStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";
    const url = {
        table: Http.master.getAdminPage,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    query: true
                },
                userId: '1',
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '发起人',
                                key: 'name'
                            },
                            {
                                title: '发起时间',
                                key: 'createTime'
                            },
                            {
                                title: '退款金额',
                                key: 'createTime'
                            },
                            {
                                title: '三级审批时间',
                                key: 'createTime'
                            },
                            {
                                title: '打款状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未打款', value: '1'},
                                        {name: '已打款', value: '2'}
                                    ]
                                },
                                filter:[
                                    {text: '未打款', value: '= 1'},
                                    {text: '已打款', value: '= 2'}
                                ]
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query (item) {
                Sun.push('/inst/financial/afterSales/afterSalesDetail');
            }
        },
        filters: {
            formatStatus(status) {
                if (status == 1) {
                    return '未打款';
                } else if (status == 2) {
                    return '已打款';
                } else {
                    return '/';
                }
            },
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
