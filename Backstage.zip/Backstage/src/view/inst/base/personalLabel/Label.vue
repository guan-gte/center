<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true" type="primary">新增个人标签</el-button>
            <div slot="status" slot-scope="data">
                <el-switch @change="change(data.row)" v-model="data.row.status"
                    :active-value="1" :inactive-value="0" active-color="#13ce66" inactive-color="#c0c0c0"></el-switch>
            </div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">编辑</el-button>
                <el-button v-show="auth.del" class="opreate-del" type="text" size="mini" @click="del(data.row)">删除</el-button>
            </div>
        </SunTable>
        <!--add-->
        <LabelAdd :url="url" :show="showAdd"
                    :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></LabelAdd>
        <!--edit-->
        <LabelEdit :url="url" :show="showEdit" :id="id" :data="editData"
                    :callBack="(flag)=>{showEdit = false;if (flag) table.el.refresh()}"></LabelEdit>
    </Page>
</template>

<script>
    import LabelAdd from './LabelAdd';
    import LabelEdit from './LabelEdit';    
    const url = {
        table: Http.inst.getPersonLabelList,
        add: Http.inst.addPersonLabel,
        edit: Http.inst.editPersonLabel,
        del: Http.inst.delPersonLabel
    };
    export default {
        extends: Sun.vuePage,
        components: {LabelAdd, LabelEdit},
        data() {
            return {
                auth: {
                    add: true,
                    edit: true,
                    del: true
                },
                url: url,
                showAdd: false,
                showEdit: false,
                editData: {},
                id: '',
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: false,
                        list: [
                            {
                                title: '个人标签',
                                key: 'name'
                            },
                            // {
                            //     title: '启用状态',
                            //     key: 'status'
                            // },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        methods: {
            created () {
                Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
                Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
                Sun.checkBtnAuth(url.del, () => {this.auth.del = false});
            },
            // 编辑
            edit (item) {
                this.editData = item;
                this.showEdit = true;
                this.id = item.id;
            },
            // 删除
            del (item) {
                Sun.confirm('提示', '确定要删除此个人标签吗?', () => {
                    Sun.post({
                        url: this.url.del,
                        data: {id: item.id},
                        success: () => {
                            Sun.showMsg('已删除');
                            this.table.el.refresh();
                        }
                    });
                });
            },
            // 更改状态
            change (item) {

            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
