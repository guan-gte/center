
<template>
    <Page>
        <ul class="clearfix">
            <li>客户姓名: {{user.trueName | formatValue}}</li>
            <li>客户ID: {{user.userId}}</li>
            <li>注册账号: {{user.regPhone}}</li>
            <li>联系方式: {{user.telPhone  | formatValue}}</li>
            <li>客户公司名称: {{user.company | formatValue}}</li>
            <li>客户公司地址: {{user.companyAddress | formatValue}}{{user.companyAddressDetail}}</li>
            <li>客户收货地址: {{user.userAddress | formatValue}}{{user.userAddressDetail}}</li>
            <li>会员级别: {{user.levelName | formatValue}}(消费金额:{{user.totalPay}}元)</li>
            <li>注册时间: {{user.demo | formatValue}}</li>
            <li>上次登陆时间: {{user.demo | formatValue}}</li>
            <li>所属售后: {{user.demo | formatValue}}</li>
            <li>行业信息: {{user.tradeName | formatValue}}</li>
            <li>客户标签: {{user.labelName | formatValue}}</li>
            <li>个人标签: {{user.personLabelName | formatValue}}</li>
            <li>客户来源: {{user.demo | formatValue}}</li>
            <li>添加客户人员: {{user.demo | formatValue}}</li>
            <li>客户服务人员变更记录: 
                <div class="cell" v-for="(item, index) in list" :key="index">
                    <p><span>{{item.createTime | formatTime}}</span>&nbsp;&nbsp;<span>{{item.event}}</span></p>
                </div>
                <span v-if="!list.length">暂无</span>
            </li>
        </ul>
        <div class="footer">
            <!-- <el-button class="button-edit" type="primary" @click="edit">编辑用户信息</el-button> -->
            <el-button class="button-edit" type="primary" @click="add">认领该客户</el-button>
            <!-- <el-button class="button-edit" >查看聊天记录</el-button> -->
        </div>        
        <!--edit-->
        <BaseInfoEdit :url="url" :show="showEdit" :data="editData"
                    :callBack="(flag)=>{showEdit = false;if (flag) this.getCustomerInfo(query)}"></BaseInfoEdit>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../../js/util";
    import BaseInfoEdit from './BaseInfoEdit';    
    const url = {
        getUserBelongChangeList: Http.inst.getUserBelongChangeList,
        edit: Http.inst.editMyUserInfo
    };
    export default {
        extends: Sun.vuePage,
        components: {BaseInfoEdit},
        data() {
            return {
                url: url,
                auth: {
                    edit: true
                },
                showEdit: false,
                data: {
                    demo: 1560414366
                },
                // 客户服务人员变更记录
                list: [],
                userId: '',
                user: {},
                editData: {},
                query: ''
            }
        },
        created () {
            let userId = Sun.getQuery('userId');
            this.query = Sun.getQuery('query');
            if (userId) {
                this.userId = userId;
                this.getCustomerInfo(this.query);
                this.getUserBelongChangeList();
            }
        },
        methods: {
            // 认领客户
            add () {

            },
            // 编辑
            edit (item) {
                this.editData = this.user;
                this.showEdit = true;
            },
            // 获取客户信息
            getCustomerInfo (query) {
                Sun.post({
                    url: query,
                    data: {userId: this.userId},
                    success: (data) => {
                        this.user = data;
                    }
                });
            },
            // 获取客户服务人员变更记录
            getUserBelongChangeList () {
                Sun.post({
                    url: this.url.getUserBelongChangeList,
                    data: {userId: this.userId},
                    success: (data) => {
                        this.list = data;
                    }
                });
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            formatValue(value) {
                if (value) {
                    return value;
                } else {
                    return '暂无';
                }
            },
        }
    }
</script>

<style lang="less" scoped>
    @import url('../../../../../assets/css/config.less');
    ul {
        width: 100%;    
        li {
            width: 50%;
            float: left;
            color: @black;
            margin-bottom: 20px;
            .cell {
                margin: 20px 0;
            }
            .cell:last-child {
                margin-bottom: 0;
            }
        }
        li:last-child {
            margin-bottom: 0;
        }
    }
    .footer {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>

