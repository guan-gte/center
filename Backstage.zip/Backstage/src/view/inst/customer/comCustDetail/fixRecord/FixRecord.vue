<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../../js/util";
    const url = {
        table: Http.master.getAdminPage,
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    query: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '维修单编号',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '设备配件名称',
                                key: 'trueName'
                            },
                            {
                                title: '关联订单',
                                key: 'trueName'
                            },
                            {
                                title: '下单时间',
                                key: 'createTime',
                                sortable: true,
                                search: {
                                    type: 'time',
                                    symbol: 'between'
                                }
                            },
                            {
                                title: '维修次数',
                                key: 'trueName',
                                sortable: true,
                                search: {
                                    type: 'text',
                                    symbol: 'between'
                                }
                            },
                            {
                                title: '是否更换设备',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '是', value: '1'},
                                        {name: '否', value: '0'}
                                    ]
                                },
                                filter:[
                                    {text: '是', value: '= 1'},
                                    {text: '否', value: '= 0'}
                                ]
                            },
                            {
                                title: '更换设备单号',
                                key: 'trueName'
                            },
                            {
                                title: '维修是否完成',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '是', value: '1'},
                                        {name: '否', value: '0'}
                                    ]
                                },
                                filter:[
                                    {text: '是', value: '= 1'},
                                    {text: '否', value: '= 0'}
                                ]
                            }
                        ]
                    }
                }
            }
        },
        created () {
        },
        methods: {
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>

