
<template>
    <el-dialog title="编辑" :visible.sync="show" @open="open" :before-close="close" top="12vh" width="600px">
        <ul class="clearfix">
            <li>回访记录编号: {{form.id}}</li>
            <li>回访时间: {{form.visitTime | formatTime}}</li>
            <li>下次回访时间: {{form.nextVisitTime | formatTime}}</li>
            <!-- <li>回访人员: {{form.demo}}&nbsp;&nbsp;&nbsp;所属部门: {{form.demo}}</li> -->
            <li>关联设备信息: {{form.goodsName}}</li>
            <!-- <li>订单所属公司: {{form.demo}}</li> -->
            <li>产品满意度: {{form.degree ? '满意' : '不满意'}}</li>
            <li>产品满意度备注: {{form.degreeRemark}}</li>
            <li>客户反馈问题: {{form.feedBack}}</li>
            <li>处理意见: {{form.resolution}}</li>
            <li>继续购买意向: {{form.purpose | formatPurpose}}</li>
            <li>备注信息: {{form.remark}}</li>
        </ul>
        <div slot="footer" class="dialog-footer">
            <div class="el-line-add"></div>
            <el-button class="el-button-add" @click="close">关闭</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import {copyMap, formatTime} from "../../../../../js/util";

    export default {
        data() {
            return {
                form: {}
            }
        },
        methods: {
            open () {
                this.form = copyMap(this.data);
            },
            close () {
                if (this.callBack) {
                    this.callBack(true);
                }
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            formatPurpose (purpose) {
                purpose = parseInt(purpose);
                switch (purpose) {
                    case 0: return '无意向';
                    case 1: return '有意向';
                    case 2: return '继续跟进';
                }
            }
        },
        props: ['data', 'show', 'callBack'],
    }
</script>
<style lang="less" scoped>
    @import url('../../../../../assets/css/config.less');
    ul {
        width: 100%;    
        li {
            width: 50%;
            float: left;
            color: @black;
            margin-bottom: 20px;
        }
        li:last-child {
            margin-bottom: 0;
        }
    }
</style>
<style>
    .dialog-footer {
        clear: both;
        height: 30px;
    }

    .el-line-add {
        width: 100%;
        height: 1px;
        background-color: #dedede;
    }

    .el-form-add {
        max-height: 400px !important;
        overflow: scroll
    }

    .el-button-add {
        float: right;
        margin-right: 10px;
        margin-top: 10px;
    }
</style>


