<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatDay}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>    
    const url = {
        table: Http.master.getAdminPage,
        query: Http.master.editAuth
    };
    import {formatDay} from "../../../../../js/util";
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    query: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '订单编号',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '下单时间',
                                key: 'createTime',
                                sortable: true,
                                search: {
                                    type: 'time',
                                    symbol: 'between'
                                }
                            },
                            {
                                title: '订单类型',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '1', value: '1'},
                                        {name: '2', value: '2'},
                                        {name: '3', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '1', value: '= 1'},
                                    {text: '2', value: '= 2'},
                                    {text: '3', value: '= 3'}
                                ]
                            },
                            {
                                title: '订单状态',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '1', value: '1'},
                                        {name: '2', value: '2'},
                                        {name: '3', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '1', value: '= 1'},
                                    {text: '2', value: '= 2'},
                                    {text: '3', value: '= 3'}
                                ]
                            },
                            {
                                title: '服务星级',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '1', value: '1'},
                                        {name: '2', value: '2'},
                                        {name: '3', value: '3'}
                                    ]
                                },
                                filter:[
                                    {text: '1', value: '= 1'},
                                    {text: '2', value: '= 2'},
                                    {text: '3', value: '= 3'}
                                ]
                            },
                            {
                                title: '订单金额',
                                key: 'trueName',
                                sortable: true,
                                search: {
                                    type: 'time',
                                    symbol: 'between'
                                }
                            },
                            {
                                title: '订单内容',
                                key: 'trueName'
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query (item) {
                // console.log(item);
                Sun.push('/inst/customer/groupDetail/orderInfo/orderDetail');
            }
        },
        filters: {
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
