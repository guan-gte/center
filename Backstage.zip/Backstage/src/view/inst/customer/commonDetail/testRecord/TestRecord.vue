<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="add" type="primary">新增试机单</el-button>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../../js/util";
    const url = {
        table: Http.master.getAdminPage,
        add: Http.master.addAuth,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    query: true,
                    add: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '试机单编号',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },
                            {
                                title: '试机编号',
                                key: 'trueName'
                            },
                            {
                                title: '设备编号',
                                key: 'trueName'
                            },
                            {
                                title: '下单时间',
                                key: 'createTime',
                                sortable: true,
                                search: {
                                    type: 'time',
                                    symbol: 'between'
                                }
                            },
                            {
                                title: '试机时间',
                                key: 'createTime',
                                sortable: true
                            },
                            {
                                title: '是否购买',
                                key: 'status',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '是', value: '1'},
                                        {name: '否', value: '0'}
                                    ]
                                },
                                filter:[
                                    {text: '是', value: '= 1'},
                                    {text: '否', value: '= 0'}
                                ]
                            },
                            {
                                title: '购买订单编号',
                                key: 'trueName'
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            add () {
                Sun.push('/inst/customer/commonDetail/testRecord/testRecoAdd');
            },
            query (item) {
                Sun.push('/inst/customer/commonDetail/testRecord/testRecoDetail');
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
