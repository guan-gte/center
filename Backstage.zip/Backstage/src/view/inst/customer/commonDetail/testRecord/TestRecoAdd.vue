<template>
    <Page>
        <div class="all">        
            <!-- 状态 -->
            <el-card class="box-card" shadow="hover">
                <!-- <div slot="header"><span>订单状态1:</span></div> -->
                <el-steps class="order-status" finish-status="success" :active="baseInfo.status | formatType" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.applyName}}</p></div></div>
                            <p class="status-desc">{{baseInfo.status == 1 ? '发起申请' : '发起申请'}}</p>
                            <p class="status-time" v-if="baseInfo.applyTime">{{baseInfo.applyTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="一级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesDirectorImg ? baseInfo.salesDirectorImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">职位</p><p class="name">{{baseInfo.salesDirector}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 2 ? 'dinger-color' : ': #303133'">
                                {{baseInfo.status == 3 ? '审批通过' : (baseInfo.status == 2 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.firstPassTime"
                                :class="baseInfo.status == 2 ? 'dinger-color' : ''">
                                {{baseInfo.firstPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="开始打包">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="img.imgBlank" alt="">
                            </div>
                            <p class="status-desc">开始打包</p>
                        </div>
                    </el-step>
                </el-steps>
            </el-card>
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>基本信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">开单人: {{baseInfo.demo}}</div>
                    <div class="text item">开单部门: {{baseInfo.demo}}</div>
                    <div class="text item">所属子公司: {{baseInfo.demo}}</div>
                    <div class="text item">订单编号: {{baseInfo.demo}}</div>
                    <div class="text item">订单状态: {{baseInfo.demo}}</div>
                    <div class="text item">开单日期: {{baseInfo.demo}}</div>
                    <div class="text item">送货日期: {{baseInfo.demo}}</div>
                    <!-- 仓库开始为空，选择商品后进行判定，如果子公司仓库足够显示仓库，如果子公司仓库不足，显示为总仓库 -->
                    <div class="text item">仓库: {{baseInfo.demo}}</div>
                    <div class="text item">订单星级: {{baseInfo.demo}}</div>
                </div>
            </el-card>
            <!-- 公司信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>公司信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">公司信息: {{company.demo}}</div>
                    <div class="text item">联系人: {{company.demo}}</div>
                    <div class="text item">联系方式: {{company.demo}}</div>
                    <div class="text form-item">
                        <el-form label-position="left" ref="form" :model="address" label-width="90px">
                            <el-form-item required label="收货地址:">
                                <el-cascader placeholder="请选择" :options="cityList" :props="optionProps" v-model="recCodeList"></el-cascader>
                            </el-form-item>
                        </el-form>   
                    </div>
                    <div class="text form-item">
                        <el-form label-position="left" ref="form" :model="address" label-width="120px">
                            <el-form-item required label="收货详细地址:">
                                <el-input placeholder="请输入收货详细地址" v-model="address.demo"></el-input>
                            </el-form-item> 
                        </el-form>   
                    </div>
                    <div class="text form-item">
                        <el-form label-position="left" ref="form" :model="address" label-width="60px">
                            <el-form-item label="备注:">
                                <el-input type="textarea" autosize placeholder="请输入内容" v-model="address.demo"></el-input>
                            </el-form-item> 
                        </el-form>   
                    </div>
                </div>
            </el-card>
            <!--货品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header">
                    <span>货品信息:</span>
                    <el-button  @click="showAdd = true" style="margin-left: 20px;" round plain size="mini" type="primary">新增商品</el-button>
                    <span style="float: right;">订单总金额: {{totalPrice}}元</span>
                </div>
                <el-table :data="list" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                        <template slot-scope="scope">
                            <slot v-if="item.key !== 'opreate'" :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                            <slot v-else :name="item.key" :row="scope.row">
                                <el-button  @click="del(scope.row)" type="danger" size="mini">删除</el-button>
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
                <!-- v-show="auth.add" -->
            </el-card>
        </div>  
        <!-- 新增商品 -->
        <el-dialog title="新增商品" :visible.sync="showAdd" @open="open" top="12vh" width="600px">
            <el-form class="el-form-add" ref="form" :model="goods" label-width="150px">
                <el-form-item label="请输入商品id">
                    <!-- 自定义搜索方法 filter-method -->
                    <el-select v-model="searchId" filterable placeholder="搜索">
                        <el-option v-for="item in idList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="请输入商品名称">
                    <!-- 自定义搜索方法 filter-method -->
                    <el-select v-model="searchName" filterable placeholder="搜索">
                        <el-option v-for="item in nameList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item required label="请输入商品数量">
                    <el-input v-model="goods.num"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <div class="el-line-add"></div>
                <el-button class="el-button-add" type="primary" @click="addGoods()">确认</el-button>
                <el-button class="el-button-add" @click="close">取消</el-button>
            </div>
        </el-dialog>
        <!-- btn -->
        <div class="footer-btn">
            <el-button class="button-edit">取消</el-button>
            <el-button class="button-edit" type="primary">确定</el-button>
        </div> 
    </Page>
</template>

<script>
    import {formatTime} from "../../../../../js/util"; 
    import cityList from '../../../../../js/city' 
    import img_blank from '../../../../../assets/head.png';
    const url = {
        add: Http.master.addAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },              
                auth: {
                    add: true
                },
                url: url,
                cityList: cityList,                
                // 指定option
                optionProps: {
                    value: 'i',
                    label: 'n',
                    children: 'l'
                },
                // 收货地址
                recCodeList: [],
                baseInfo: {
                    demo: '上海分公司',
                    // 申请时间
                    applyTime: 1560734591,
                    applyName: '张三',
                    applyImg: '',
                    // 一级通过审批时间
                    firstPassTime: 1560734591,
                    salesDirector: '李四',
                    salesDirectorImg: '',
                    // 订单状态 1发起申请（一级待审批） 2 一级审批 驳回  3 一级审批通过（二级待审批）
                    status: 1
                },
                //公司信息
                company: {
                    demo: '上海分公司'
                },
                address: {
                    demo: '上海分公司'
                },
                // 货品信息
                columns: [
                    {
                        title: '商品ID',
                        key: 'id',
                    },
                    {
                        title: '商品名称',
                        key: 'name',
                    },
                    {
                        title: '适用机型',
                        key: 'models',
                    },
                    {
                        title: '规格型号',
                        key: 'modelNo',
                    },
                    {
                        title: '计量单位',
                        key: 'unit',
                    },
                    {
                        title: '零售价',
                        key: 'price',
                    },
                    {
                        title: '商品数量',
                        key: 'num',
                    },
                    {
                        title: '订单小计',
                        key: 'total',
                    },
                    {
                        title: '操作',
                        key: 'opreate',
                    }
                ],
                list: [],
                totalPrice: 0,
                // 新增商品
                showAdd: false,
                searchId: '',
                searchName: '',
                idList: '',
                nameList: '',
                goods: {}
            }
        },
        methods: {
            // 确认添加一个商品
            addGoods () {   
                if (!this.goods.id || !this.goods.name) {
                    Sun.showError('请选择商品!');
                    return;
                }
                if (!this.goods.num) {
                    Sun.showError('请设置商品数量!');
                    return;
                }
                this.showAdd = false;
                this.list.push({
                    id: '1',
                    name: '2',
                    models: '3',
                    modelNo: '4',
                    unit: '5',
                    price: '6',
                    num: '7',
                    total: '8'
                })
            },
            del (item) {
                if (this.list.length) {
                    this.list.forEach((ele, index) => {
                        if (item.id == ele.id) {
                            this.list.splice(index, 1);
                        }
                    })
                }
            },
            open () {
                this.goods = {};
            },
            close () {
                this.showAdd = false;
                this.goods = {};
            },
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 进度条 状态
            formatType(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return 1;
                    case 2: return 2;
                    case 3: return 2;
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
        .form-item {
            width: 33.33%;
            float: left;
        }    
        .dialog-footer {
        clear: both;
        height: 30px;
        }
        .el-line-add {
            width: 100%;
            height: 1px;
            background-color: #dedede;
        }
        .el-form-add {
            max-height: 400px !important;
            overflow: scroll
        }
        .el-button-add {
            float: right;
            margin-right: 10px;
            margin-top: 10px;
        }
    }
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
