<template>
    <Page>
        <div class="all">        
            <!-- 状态 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>订单状态:</span></div>
                <el-steps class="order-status" finish-status="success" :active="baseInfo.status | formatType" align-center>
                    <el-step title="发起申请">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.applyImg ? baseInfo.applyImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position"></p><p class="name">{{baseInfo.applyName}}</p></div></div>
                            <p class="status-desc">{{baseInfo.status == 1 ? '发起申请' : '发起申请'}}</p>
                            <p class="status-time" v-if="baseInfo.applyTime">{{baseInfo.applyTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="一级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesDirectorImg ? baseInfo.salesDirectorImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">职位</p><p class="name">{{baseInfo.salesDirector}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 2 ? 'dinger-color' : ': #303133'">
                                {{baseInfo.status == 3 ? '审批通过' : (baseInfo.status == 2 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.firstPassTime"
                                :class="baseInfo.status == 2 ? 'dinger-color' : ''">
                                {{baseInfo.firstPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="二级审批">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.salesLeaderImg ? baseInfo.salesLeaderImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">职位</p><p class="name">{{baseInfo.salesLeader}}</p></div></div>
                            <p class="status-desc" 
                                :class="baseInfo.status == 4 ? 'dinger-color' : ''">
                                {{baseInfo.status == 5 ? '审批通过' : (baseInfo.status == 4 ? '驳回申请' : '待审批')}}</p>
                            <p class="status-time" v-if="baseInfo.secondPassTime"
                                :class="baseInfo.status == 4 ? 'dinger-color' : ''">
                                {{baseInfo.secondPassTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="财务确认">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="baseInfo.confirmImg ? baseInfo.confirmImg : img.imgBlank" alt="">
                            <div class="user-info"><p class="position">职位</p><p class="name">{{baseInfo.confirmName}}</p></div></div>
                            <p class="status-desc">
                                {{baseInfo.status == 6 ? '已确认' : '等待确认'}}</p>
                            <p class="status-time" v-if="baseInfo.confirmTime">{{baseInfo.confirmTime | formatTime}}</p>
                        </div>
                    </el-step>
                    <el-step title="开始打包">
                        <div slot="description">
                            <div class="head-pic">
                                <img :src="img.imgBlank" alt="">
                            </div>
                            <p class="status-desc">{{baseInfo.status == 4 ? '开始打包' : ''}}</p>
                        </div>
                    </el-step>
                </el-steps>
            </el-card>
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>基本信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">开单人: {{baseInfo.demo}}</div>
                    <div class="text item">开单部门: {{baseInfo.demo}}</div>
                    <div class="text item">所属子公司: {{baseInfo.demo}}</div>
                    <div class="text item">订单编号: {{baseInfo.demo}}</div>
                    <div class="text item">订单状态: {{baseInfo.demo}}</div>
                    <div class="text item">开单日期: {{baseInfo.demo}}</div>
                    <div class="text item">送货日期: {{baseInfo.demo}}</div>
                    <div class="text item">仓库: {{baseInfo.demo}}</div>
                    <div class="text item">订单星级: {{baseInfo.demo}}</div>
                </div>
            </el-card>
            <!-- 后续单据 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>后续单据:</span></div>
                <div class="main clearfix">
                    <div class="text item">收款单号: {{documents.demo}}</div>
                    <div class="text item">收款时间: {{documents.demo}}</div>
                    <div class="text item">出库单: {{documents.demo}}</div>
                    <div class="text item">打包人员: {{documents.demo}}</div>
                    <div class="text item">出库时间: {{documents.demo}}</div>
                    <div class="text item">快递单号: {{documents.demo}}</div>
                    <div class="text item">发货人: {{documents.demo}}</div>
                </div>
            </el-card>
            <!-- 客户信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>客户信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">公司信息: {{customer.demo}}</div>
                    <div class="text item">联系人: {{customer.demo}}</div>
                    <!-- <div class="text item">联系方式: {{customer.demo}}</div> -->
                    <div class="text item">公司地址: {{customer.demo}}</div>
                    <div class="text item">收货地址: {{customer.demo}}</div>
                    <div class="text item">客户咨询日期: {{customer.demo}}</div>
                </div>
            </el-card>
            <!-- 财务信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>财务信息:</span></div>
                <div class="main clearfix">
                    <div class="text item">金额合计: {{financial.demo}}</div>
                    <div class="text item">发票类型: {{financial.demo}}</div>
                    <div class="text item">付款方式: {{financial.demo}}</div>
                    <div class="text item">开票日期: {{financial.demo}}</div>
                    <div class="text item">已到账金额: {{financial.demo}}</div>
                </div>
                <div class="footer">
                    <el-button type="primary">下载附件</el-button>
                </div>
            </el-card>            
            <!-- 备注信息 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>备注信息:</span></div>
                <el-form ref="form" label-width="45px">
                    <el-form-item label="备注:">
                        <el-input type="textarea" autosize disabled v-model="remark"></el-input>
                    </el-form-item>
                </el-form>
            </el-card>
            <!--货品信息-->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>货品信息:</span><span style="float: right;">订单总金额: {{totalPrice}}元</span></div>
                <el-table :data="list" border height="300px" :summary-method="getSummaries" show-summary style="width: 100%;">
                    <el-table-column align="center" :prop="item.key" :column-key="item.key" :label="item.title" v-for="(item, index) in columns" :key="index">
                        <template slot-scope="scope">
                            <slot :name="item.key" :row="scope.row">
                                {{scope.row[item.key]}}
                            </slot>
                        </template>
                    </el-table-column>
                </el-table>
            </el-card>
        </div>  
    </Page>
</template>

<script>
    import {formatTime} from "../../../../../js/util";  
    import img_blank from '../../../../../assets/head.png'
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                img: {
                    imgBlank: img_blank
                },
                baseInfo: {
                    demo: '上海分公司',
                    // 申请时间
                    applyTime: 1560734591,
                    applyName: '张三',
                    applyImg: '',
                    // 一级通过审批时间
                    firstPassTime: 1560734591,
                    salesDirector: '李四',
                    salesDirectorImg: '',
                    // 二级通过审批时间
                    secondPassTime: 1560734591,
                    salesLeader: '王五',
                    salesLeaderImg: '',
                    // 确认时间
                    confirmTime: 1560734591,
                    confirmName: '周六',
                    confirmImg: '',
                    // 订单状态 1发起申请（一级待审批） 2 一级审批 驳回  3 一级审批通过（二级待审批） 4二级审批驳回 5二级审批通过(等待确认)6 财务已确认
                    status: 5
                },
                customer: {
                    demo: '上海分公司'
                },
                documents: {
                    demo: '上海分公司'
                },
                remark: '',
                financial: {
                    demo: '上海分公司',
                    remark: ''
                },
                columns: [
                    {
                        title: '商品ID',
                        key: 'trueName',
                    },
                    {
                        title: '商品名称',
                        key: 'trueName',
                    },
                    {
                        title: '适用机型',
                        key: 'trueName',
                    },
                    {
                        title: '规格型号',
                        key: 'trueName',
                    },
                    {
                        title: '计量单位',
                        key: 'trueName',
                    },
                    {
                        title: '零售价',
                        key: 'trueName',
                    },
                    {
                        title: '商品数量',
                        key: 'trueName',
                    },
                    {
                        title: '订单小计',
                        key: 'total',
                    },
                ],
                list: [],
                totalPrice: 0
            }
        },
        methods: {
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '小计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                        const value = Number(curr);
                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                        }, 0);
                    } else {
                        sums[index] = 'N/A';
                    }
                });
                return sums;
            }
        },
        filters: {        
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            },
            // 进度条 状态
            formatType(status) {
                status = parseInt(status);
                switch (status) {
                    case 1: return 1;
                    case 2: return 2;
                    case 3: return 2;
                    case 4: return 3;
                    case 5: return 3;
                    case 6: return 6;
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
        // 
        .order-status {
            width: 100%;
            margin-bottom: 20px;
        }
        .head-pic {
            width: 100%;
            height: 100px;
            position: relative;
            margin-bottom: 20px;
            img {
                width: 100px;
                background: #dbdbdb;
                height: 100px;
                border-radius: 50%;
                margin:  0 auto;
            }
            .user-info {
                position: absolute;
                height: 50px;
                width: 100px;
                left: 50%;
                bottom: 0;
                margin-left: -50px;
                background:linear-gradient(180deg,rgba(0,0,0,0.3) 0%,rgba(0,0,0,0.8) 100%);
                border-radius: 0 0 50px 50px;
                padding-top: 5px;
                box-sizing: border-box;
                p {
                    font-size: 12px;
                    color: #fff;
                    line-height: 25px;
                    height: 25px;
                    text-align: center;
                }
                .position {
                    line-height: 20px;
                    height: 20px;
                    font-size: 14px;
                }
            }
        }
        .status-desc {
            margin-bottom: 5px;
            font-size: 14px;
        }
        .status-time {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .dinger-color {
            color: #F56C6C;
        }
    }
</style>
