<template>
    <Page>
        <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
            <el-tab-pane label="客户基本信息" name="0">
                <BaseInfo v-if="activeName == 0"></BaseInfo>
            </el-tab-pane>
            <el-tab-pane label="回访信息" name="1">
                <ReturnInfo v-if="activeName == 1"></ReturnInfo>
            </el-tab-pane>
            <el-tab-pane label="订单信息" name="2">
                <OrderInfo v-if="activeName == 2"></OrderInfo>
            </el-tab-pane>
            <!-- <el-tab-pane label="维修记录" name="3">
                <FixRecord v-if="activeName == 3"></FixRecord>
            </el-tab-pane>
            <el-tab-pane label="试机单记录" name="4">
                <TestRecord v-if="activeName == 4"></TestRecord>
            </el-tab-pane> -->
        </el-tabs>
    </Page>
</template>

<script>
    import BaseInfo from './baseInfo/BaseInfo';
    import ReturnInfo from './returnInfo/ReturnInfo';
    import OrderInfo from './orderInfo/OrderInfo';
    import FixRecord from './fixRecord/FixRecord';
    import TestRecord from './testRecord/TestRecord';
    export default {
        extends: Sun.vuePage,
        components: {
            BaseInfo,
            ReturnInfo,
            OrderInfo,
            FixRecord,
            TestRecord
        },
        data() {
            return {
                activeName: '0'
            }
        },
        created () {
        },
        methods: {
            handleClick(tab, event) {
                // console.log(tab, event);
            }
        },
        filters: {
        }
    }
</script>

<style scoped>

</style>
