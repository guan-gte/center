<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <el-button v-show="auth.add" @click="showAdd = true" type="primary">新增公海客户</el-button>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="levelName" slot-scope="data">{{data.row.levelName ? data.row.levelName : '/'}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
                <el-button v-show="auth.edit" type="text" size="mini" @click="edit(data.row)">认领</el-button>
            </div>
        </SunTable>
        <!--add-->
        <AddCustomer :url="url" :show="showAdd" 
                    :callBack="(flag)=>{showAdd = false;if (flag) table.el.refresh()}"></AddCustomer>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";   
    import AddCustomer from './AddCustomer';   
    const url = {
        table: Http.inst.getCommonUserPage,
        add: Http.inst.addCommonUser,
        getUserLabelList: Http.common.getUserLabelList,
        getUserLevelList: Http.common.getUserLevelList,
        getUserTradeList: Http.common.getUserTradeList,
        getPersonLabelList: Http.inst.getPersonLabelList,
        edit: Http.master.editAuth,
        query: Http.inst.getMyUserInfo
    };
    export default {
        extends: Sun.vuePage,
        components: {AddCustomer},
        data() {
            return {
                url: url,
                auth: {
                    query: true,
                    edit: true,
                    add: true
                },
                showAdd: false,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '客户名称',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '联系方式',
                                key: 'telPhone',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '会员级别',
                                key: 'levelName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            // {
                            //     title: '回归公海时间',
                            //     key: 'createTime',
                            //     sortable: true,
                            //     search: {
                            //         type: 'time',
                            //         symbol: 'between'
                            //     }
                            // },
                            {
                                title: '订单数量',
                                key: 'orderNum',
                                sortable: true,
                                search: {
                                    type: 'text',
                                    symbol: 'between'
                                }
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
            // Sun.checkBtnAuth(url.add, () => {this.auth.add = false});
            this.getSearchList();
        },
        methods: {
            query (item) {
                Sun.push('/inst/customer/comCustDetail/commonTab', {userId: item.userId, query: this.url.query});
            },
            edit () {

            },
            // 获取搜索项数据
            getSearchList () {
                // 会员级别列表
                Sun.post({
                    url: this.url.getUserLevelList,
                    data: {},
                    success: (data) => {
                        this.levelList = data;
                        this.addSearchFilter('levelName', this.levelList, 'search',  'filter', 'name', 'id');
                    }
                });
            },
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
