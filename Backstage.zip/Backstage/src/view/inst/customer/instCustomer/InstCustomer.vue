<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatTime}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatTime} from "../../../../js/util";    
    const url = {
        table: Http.inst.getInstUserPage,
        query: Http.inst.getUserInfoWithoutContact,
        getUserLabelList: Http.common.getUserLabelList,
        getUserLevelList: Http.common.getUserLevelList,
        getUserTradeList: Http.common.getUserTradeList,
        getPersonLabelList: Http.inst.getPersonLabelList
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                auth: {
                    query: true
                },
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '名称',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '所属销售人员',
                                key: 'saleAdmin'
                            },
                            {
                                title: '销售所属部门',
                                key: 'groupName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            // {
                            //     title: '联系方式',
                            //     key: 'telPhone',
                            //     search:{
                            //         type: 'text',
                            //         symbol: 'like',
                            //         cat: '%?%'
                            //     }
                            // },
                            {
                                title: '客户标签',
                                key: 'labelName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '客户行业',
                                key: 'tradeName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            // {
                            //     title: '个人标签',
                            //     key: 'personLabelName',
                            //     search:{
                            //         type: 'select',
                            //         symbol: '=',
                            //         list: []
                            //     },
                            //     filter:[]
                            // },
                            {
                                title: '会员级别',
                                key: 'levelName',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: []
                                },
                                filter:[]
                            },
                            {
                                title: '上次回访时间',
                                key: 'lastVisitTime',
                                sortable: true
                            },
                            {
                                title: '下次回访时间',
                                key: 'nextVisitTime',
                                sortable: true
                            },
                            {
                                title: '订单数量',
                                key: 'orderNum',
                                sortable: true
                            },
                            {
                                title: '订单总金额',
                                key: 'totalPay',
                                sortable: true
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                },
                userLabelList: [],
                personLabelList: [],
                levelList: [],
                tradeList: []
            }
        },
        created () {
            Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
            this.getSearchList();
        },
        methods: {
            query (item) {
                Sun.push('/inst/customer/instCustDetail/commonTab', {userId: item.userId, query: this.url.query});
            },
            // 添加搜索列表项
            addSearchFilter (key, list, search, filter, k1, k2) {
                setTimeout(()=>{
                    this.table.data.list.forEach((item)=>{
                        if (item.key == key){
                            if (list.length) {
                                list.forEach(ele => {
                                    if (search) {
                                        item.search.list.push({
                                            name: ele[k1],
                                            value: ele[k2]
                                        })
                                    }
                                    if (filter) {
                                        item.filter.push({
                                            text: ele[k1],
                                            value: '= ' + ele[k2]
                                        })
                                    }
                                })
                            }
                        }
                    });
                },2000);
            },
            // 获取搜索项数据
            getSearchList () {
                // 个人标签列表
                // Sun.post({
                //     url: this.url.getPersonLabelList,
                //     data: {},
                //     success: (data) => {
                //         this.personLabelList = data;
                //         this.addSearchFilter('personLabelName', this.personLabelList, 'search',  'filter', 'name', 'id');
                //     }
                // });
                // 客户标签列表
                Sun.post({
                    url: this.url.getUserLabelList,
                    data: {},
                    success: (data) => {
                        this.userLabelList = data;
                        this.addSearchFilter('labelName', this.userLabelList, 'search',  'filter', 'name', 'id');
                    }
                });
                // 会员级别列表
                Sun.post({
                    url: this.url.getUserLevelList,
                    data: {},
                    success: (data) => {
                        this.levelList = data;
                        this.addSearchFilter('levelName', this.levelList, 'search',  'filter', 'name', 'id');
                    }
                });
                // 客户行业列表
                Sun.post({
                    url: this.url.getUserTradeList,
                    data: {},
                    success: (data) => {
                        this.tradeList = data;
                        this.addSearchFilter('tradeName', this.tradeList, 'search',  'filter', 'name', 'id');
                    }
                });
            }
        },
        filters: {
            formatTime(time) {
                if (time) {
                    return formatTime(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>
    .opreate-del {
        color: #F56C6C;
    }
</style>
