<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data">
            <div slot="packStatus" slot-scope="data">{{data.row.packStatus | formatPackStatus}}</div>
            <div slot="outStatus" slot-scope="data">{{data.row.outStatus | formatOutStatus}}</div>
            <div slot="sendStatus" slot-scope="data">{{data.row.sendStatus | formatSendStatus}}</div>
            <div slot="createTime" slot-scope="data">{{data.row.createTime | formatDay}}</div>
            <div slot="opreate" slot-scope="data">
                <el-button v-show="auth.query" type="text" size="mini" @click="query(data.row)">查看</el-button>
            </div>
        </SunTable>
    </Page>
</template>

<script>
    import {formatDay} from "../../../../js/util";
    const url = {
        table: Http.master.getAdminPage,
        query: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    query: true
                },
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '订单编号',
                                key: 'trueName',
                                sortable: true
                            },             
                            {
                                title: '指定发货时间',
                                key: 'trueName',
                                sortable: true
                            },
                            {
                                title: '打包分配状态',
                                key: 'packStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未分配', value: '0'},
                                        {name: '已分配', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '未分配', value: '= 0'},
                                    {text: '已分配', value: '= 1'}
                                ]
                            },
                            {
                                title: '出库状态',
                                key: 'outStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未出库', value: '0'},
                                        {name: '已出库', value: '1'}
                                    ]
                                },
                                filter:[
                                    {text: '未出库', value: '= 0'},
                                    {text: '已出库', value: '= 1'}
                                ]
                            },
                            {
                                title: '出库编号',
                                key: 'trueName',
                                sortable: true
                            },  
                            {
                                title: '发货状态',
                                key: 'sendStatus',
                                search:{
                                    type: 'select',
                                    symbol: '=',
                                    list: [
                                        {name: '未发货', value: '0'},
                                        {name: '已发货', value: '1'},
                                    ]
                                },
                                filter:[
                                    {text: '未发货', value: '= 0'},
                                    {text: '已发货', value: '= 1'},
                                ]
                            },
                            {
                                title: '操作',
                                key: 'opreate'
                            }
                        ]
                    }
                }
            }
        },
        created () {
            // Sun.checkBtnAuth(url.query, () => {this.auth.query = false});
        },
        methods: {
            query () {
                // 库存足够
                Sun.push('/inst/store/customerOrder/orderDetail');
            }
        },
        filters: {
            formatPackStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未分配';
                    case 1: return '已分配';
                    default: return '/';
                }
            },
            formatOutStatus(type) {
                type = parseInt(type);
                switch (type) {
                    case 0: return '未出库';
                    case 1: return '已出库';
                    default: return '/';
                }
            },
            formatSendStatus(status) {
                status = parseInt(status);
                switch (status) {
                    case 0: return '未发货';
                    case 1: return '已发货';
                    default: return '/';
                }
            },
            formatDay(time) {
                if (time) {
                    return formatDay(time);
                } else {
                    return '';
                }
            }
        }
    }
</script>

<style scoped>

</style>
