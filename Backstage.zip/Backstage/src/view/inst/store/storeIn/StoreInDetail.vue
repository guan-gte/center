<template>
    <Page>
        <div class="all clearfix">   
            <!-- 入库详情 -->
            <el-card class="box-card" shadow="hover">
                <div slot="header"><span>入库信1息:</span></div>
                <div class="main clearfix">
                    <div class="text item">采购订单编号: {{detail.demo}}</div>
                    <div class="text item">入库单编号: {{detail.demo}}</div>
                    <div class="text item">快递单号: {{detail.demo}}</div>
                    <!-- 如果续发快递未填写编号显示为等待供应链填写编号 -->
                    <div class="text item" v-if="detail.status == 1">续发快递单号: {{detail.demo ? detail.demo : '等待供应链填写编号'}}</div>
                </div>
            </el-card>     
            <!-- 基本信息 -->
            <el-card class="box-card" shadow="hover" v-for="(item, index) in goodsList" :key="index">
                <div slot="header">
                    <span class="header-title">采购产品{{++index}}:</span>
                    <!-- 未入库 填写到货数量 -->
                    <el-input v-if="!detail.status" class="input-num" v-model="item.receiveNum" placeholder="到货数量"></el-input>
                    <span v-if="!detail.status" class="input-label"><span style="color: #f56c6c;">* </span>请输入到货数量:</span>
                    <!-- 入库未完 到货数量小于采购数量  填写续发数量 -->
                    <el-input v-if="detail.status == 1 && (item.demo < item.demo)" 
                                class="input-num" v-model="item.addNum" placeholder="请输入续发数量"></el-input>
                    <span v-if="detail.status == 1 && (item.demo < item.demo)" class="input-label"><span style="color: #f56c6c;">* </span>请输入续发数量:</span>
                </div>
                <div class="main clearfix">
                    <div class="text item">产品ID：{{item.demo}}</div>
                    <div class="text item">产品名称：{{item.demo}}</div>
                    <div class="text item">产品类型：{{item.demo}}</div>
                    <div class="text item">产品型号：{{item.demo}}</div>
                    <div class="text item">产品货号：{{item.demo}}</div>
                    <div class="text item">供应：{{item.demo}}</div>
                    <div class="text item">品牌：{{item.demo}}</div>
                    <div class="text item">计量单位：{{item.demo}}</div>
                    <div class="text item">当前库存数量：{{item.demo}}</div>
                    <div class="text item">采购数量：{{item.demo}}</div>
                    <!-- 到货数量小于采购数量,字体异色 -->
                    <div class="text item" :style="item.demo < item.demo ? 'color: #F56C6C;' : ''" 
                            v-if="detail.status > 0">到货数量：{{item.demo}}</div>
                    <div class="text item">总价：{{item.totalPrice}}元</div>    
                </div> 
            </el-card>
        </div>          
        <div v-show="auth.edit && detail.status !== 2" class="footer-btn">
            <el-button class="button-edit">取消</el-button>
            <el-button class="button-edit" @click="submit" type="primary">确认</el-button>
        </div>  
    </Page>
</template>

<script>  
    const url = {
        edit: Http.master.editAuth
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                auth: {
                    edit: true
                },
                goodsList: [
                    {demo: '商品详情', totalPrice: 4563, receiveNum: '', addNum: ''},
                ],
                // 0 未入库 1 入库未完 2 已入库
                detail: {
                    status: 0,
                    demo: '23423423'
                }
            }
        },
        methods: {
            submit () {
                
            }
        },        
        created () {
            // Sun.checkBtnAuth(url.edit, () => {this.auth.edit = false});
        },
        filters: {  
        }
    }
</script>

<style scoped lang="less">
    @import url('../../../../assets/css/config.less');
    .all {
        width: 100%;
        .box-card {
            width: 100%;
            margin-bottom: 20px;
            float: left;
            .header-title {
                height: 32px;
                display: inline-block;
                height: 32px;
                line-height: 32px;
            }
            .input-num {
                float: right;
                width: 15%;
                margin-left: 10px;
            }
            .input-label {
                float: right;
                height: 32px;
                line-height: 32px;
            }
            .main {
                width: 100%;        
                .text {
                    font-size: 14px;
                }
                .item {
                    margin-bottom: 18px;
                    width: 33.33%;
                    float: left;
                    padding-right: 30px;
                    box-sizing: border-box;
                }
            }
            .footer {
                width: 100%;
                text-align: right;
            }
        }
        .box-card:last-child {
            margin-bottom: 0;
        }
    }    
    .footer-btn {
        width: 100%;
        padding-top: 20px;
        text-align: center;
    }

    .button-edit {
        margin-right: 10px;
        margin-top: 10px;
    }
</style>
<style>
    .el-card__header {
        font-weight: bold;
        font-size: 15px;
    }
</style>

