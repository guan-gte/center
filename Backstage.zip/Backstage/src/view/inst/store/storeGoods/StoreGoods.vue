<template>
    <Page>
        <!--table-->
        <SunTable :load="(that) => { table.el = that }" :data="table.data"></SunTable>
    </Page>
</template>

<script>
    const url = {
        table: Http.master.getAdminPage
    };
    export default {
        extends: Sun.vuePage,
        data() {
            return {
                url: url,
                table: {
                    el: null,
                    data: {
                        url: url.table,
                        isPage: true,
                        list: [
                            {
                                title: '产品I1D',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: '='
                                }
                            },             
                            {
                                title: '产品名称',
                                key: 'trueName',
                                search:{
                                    type: 'text',
                                    symbol: 'like',
                                    cat: '%?%'
                                }
                            },
                            {
                                title: '产品型号',
                                key: 'trueName'
                            },
                            {
                                title: '产品货号',
                                key: 'trueName'
                            },
                            {
                                title: '供应商',
                                key: 'trueName'
                            },  
                            {
                                title: '品牌',
                                key: 'trueName'
                            },
                            {
                                title: '库存',
                                key: 'trueName',
                                sortable: true,
                                search:{
                                    type: 'text',
                                    symbol: 'between'
                                }
                            },
                            {
                                title: '库存警报值',
                                key: 'trueName'
                            }
                        ]
                    }
                }
            }
        },
        created () {
        },
        methods: {
        },
        filters: {
        }
    }
</script>

<style scoped>

</style>
