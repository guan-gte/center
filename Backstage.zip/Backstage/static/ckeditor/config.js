/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
    // Define changes to default configuration here.
    // For complete reference see:
    // http://docs.ckeditor.com/#!/api/CKEDITOR.config
    config.extraPlugins = 'about,a11yhelp,html5video,basicstyles,bidi,blockquote,clipboard,colorbutton,colordialog,contextmenu,div,elementspath,enterkey,entities,filebrowser,find,flash,floatingspace,font,format,forms,horizontalrule,htmlwriter,image,iframe,indent,justify,link,list,liststyle,magicline,maximize,newpage,pagebreak,pastefromword,pastetext,preview,print,removeformat,resize,save,scayt,selectall,showblocks,showborders,smiley,sourcearea,specialchar,stylescombo,tab,table,tabletools,templates,toolbar,undo,wsc,wysiwygarea';
//     config.toolbarGroups = [
//         { name: 'document', groups: [ 'mode', 'document', 'doctools' ] },
//         { name: 'clipboard', groups: [ 'clipboard', 'undo' ] },
//         { name: 'editing', groups: [ 'find', 'selection', 'spellchecker' ] },
//         { name: 'forms' },
//         '/',
//         { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
//         { name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align' ] },
//         { name: 'links' },
//         { name: 'insert' },{ name: 'colors' },{ name: 'styles' },
// ]
    //设置前景色的取值 plugins/colorbutton/plugin.js
    // config.colorButton_colors = '000,800000,8B4513,2F4F4F,008080,000080,4B0082,696969,B22222,A52A2A,DAA520,006400,40E0D0,0000CD,800080,808080,F00,FF8C00,FFD700,008000,0FF,00F,EE82EE,A9A9A9,FFA07A,FFA500,FFFF00,00FF00,AFEEEE,ADD8E6,DDA0DD,D3D3D3,FFF0F5,FAEBD7,FFFFE0,F0FFF0,F0FFFF,F0F8FF,E6E6FA,FFF’

    //是否在选择颜色时显示“其它颜色”选项plugins/colorbutton/plugin.js
    config.colorButton_enableMore =false

    //区块的前景色默认值设置 plugins/colorbutton/plugin.js
    config.colorButton_foreStyle = {
        element : 'span',
        styles : { 'color' : '#(color)' }
    };
    config.colorButton_enableAutomatic = true;
    config.colorButton_enableMore = true;

    // config.extraPlugins = "colorbutton,html5video,resize";
    // The toolbar groups arrangement, optimized for two toolbar rows.
    // config.extraPlugins ='button,panelbutton,floatpanel,panel,colordialog,dialog,dialogui';
    config.toolbarGroups = [
        { name: 'document', groups: [ 'mode', 'document', 'doctools' ] },
        { name: 'clipboard',   groups: [ 'clipboard', 'undo' ] },
        { name: 'editing',     groups: [ 'find', 'selection', 'spellchecker' ] },
        { name: 'links' },
        { name: 'insert' },{ name: 'colors' },{ name: 'styles' },
        { name: 'forms' },
        { name: 'tools' },
        { name: 'document',	   groups: [ 'mode', 'document', 'doctools' ] },
        { name: 'others' },
        '/',
        { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
        { name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ] },
        { name: 'styles' },
        { name: 'colors' },

        { name: 'about' }
    ];
    // Remove some buttons provided by the standard plugins, which are
    // not needed in the Standard(s) toolbar.
    // config.removeButtons = 'Underline,Subscript,Superscript';

    // Set the most common block elements.
    config.format_tags = 'p;h1;h2;h3;pre';

    // Simplify the dialog windows.
    config.removeDialogTabs = 'image:advanced;link:advanced';

    ///
    /// Param 修改ckeditor属性
    /// Author Eric sheng
    /// data :2018/09/18
    //===================================
    ///
    config.image_previewText = "";
    config.filebrowserImageUploadUrl = "http://118.31.248.209:8610/ckeditUpload/?id=1";//文件上传URL
    config.filebrowserImageBrowseUrl = "";//浏览服务器URL
    config.filebrowserHtml5videoUploadUrl = "http://118.31.248.209:8610/ckeditUpload/?id=1";//上传视频的地址
    config.allowedContent = true;
    config.callbackImageUploadUrl = "http://download.liangyuxi.com.cn"; //图片回调地址
};
